%% =========================================================================================
% Pixelwise "SEM" (no latent variables) using ridge-regularized piecewise regressions
% Target: RS 3 scales | SW-limited (WL==1) & VPD-limited (WL==2) | veg & HFP<=25
% Scales: Monthly (MO), Annual (AN), Long-term (LT)   [LT WITHOUT CO2]
%
% UPDATED (THIS VERSION):
%   - Replace GPP with CSIF
%   - Analysis period: 2001-2020 (240 months)
%   - CSIF MO/AN/LT data length: 264 months (2001-2022) -> slice 1:240
%   - Environmental factors: use original paths, but slice 2001-2020 from 1982-2020 (468 months):
%       1982-01 index=1  => 2001-01 index=229; 2020-12 index=468
%   - WL maps folder changed to:
%       G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF
%
% Plot tweaks (keep from your version):
%   1) Arrow width contrast larger
%   2) SW<->VPD links: start/end closer to rectangles
%   3) ALL T -> VPD paths are straight arrows
%   4) Label positions:
%        - T -> SW label slightly farther from SW (target)  => labelT smaller
%        - T -> VPD label slightly farther from VPD (target)=> labelT smaller
%        - R -> VPD label slightly farther from VPD (target)=> labelT smaller
%   5) NEW (THIS EDIT):
%        - R -> VPD coefficient text slightly LOWER
%        - T -> SW  coefficient text slightly LOWER
%        - VPD -> SW coefficient text slightly HIGHER (all three panels that have VPD->SW)
%
% Tested: MATLAB R2021a
% -----------------------------------------------------------------------------------------

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
rng(2025);

%% ===================== Settings =====================
nx = 720; ny = 360;

minN_per_pixel = 10;     % minimum valid time points per pixel series
ridgeLambda    = 0.05;   % ridge strength
useMonthlyGS   = true;   % optional GS filter for monthly
gsFracP90_RS   = 0.2;    % threshold = frac * P90(CSIF)

% Progress print
printEveryRow = 40;

%% ===================== Time slicing (2001-2020) =====================
% Environmental monthly inputs are 1982-2020 (468 months):
%   2001-01 index = 229 ; 2020-12 index = 468  => 240 months
rawLen_env = 468;
sFrom_env  = 229;
sTo_env    = 468;
Tlen_out   = 240;   % final analysis length

% CSIF MO/AN/LT are 2001-2022 (264 months): slice 2001-2020 => 1:240
rawLen_csif = 264;
sFrom_csif  = 1;
sTo_csif    = 240;

%% ===================== RS Paths =====================
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

% ===================== CSIF (replace GPP) =====================
CSIF_MO_path = "G:\Resource use efficiencies new\dataprocessed\CSIF20012022_3D.raw";                 % 720x360x264
CSIF_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','CSIF05_SSA_Annual_3comp.raw');                   % 720x360x264
CSIF_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CSIF05_CEEMDAN_Trend_3comp.raw');                % 720x360x264

% ===================== Environmental factors (original paths) =====================
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";     % 468
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";      % 468
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";    % 468
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";% 468
VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468

% Annual (SSA) - keep original paths
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');

% Long-term (Trend) [NO CO2 here] - keep original paths
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');

% WL maps (folder changed)
wlFolder = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF';
WL_MO_path = fullfile(wlFolder,'WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw');
WL_AN_path = fullfile(wlFolder,'WLclass_Annual_q25_ttest_pcor_f32_720x360.raw');
WL_LT_path = fullfile(wlFolder,'WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw');

%% ===================== Output =====================
outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end
outFig = fullfile(outDir, sprintf('SEM_RS_3scales_CSIF_2001_2020_SW_and_VPD_limited_pixelwise_ridge_lambda%.3f.png', ridgeLambda));

%% ===================== Check files =====================
mustFiles = {lulcPath,hfpPath, ...
    CSIF_MO_path, T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path, ...
    CSIF_AN_path, T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path, ...
    CSIF_LT_path, T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path, ...
    WL_MO_path, WL_AN_path, WL_LT_path};

for k=1:numel(mustFiles)
    assert(isfile(mustFiles{k}), 'File not found: %s', mustFiles{k});
end

%% ===================== RS mask =====================
IGBP = imread(lulcPath)'; 
HFP  = imread(hfpPath)';

assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
valid_mask = ismember(IGBP,1:10) & (HFP<=25);
fprintf('RS valid pixels (veg & HFP<=25): %d\n', nnz(valid_mask));

%% ===================== Read WL maps =====================
WL_MO = read_raw_2d_single(WL_MO_path,[nx ny]);
WL_AN = read_raw_2d_single(WL_AN_path,[nx ny]);
WL_LT = read_raw_2d_single(WL_LT_path,[nx ny]);

WL_MO(~ismember(WL_MO,[0 1 2 3 4])) = 0;
WL_AN(~ismember(WL_AN,[0 1 2 3 4])) = 0;
WL_LT(~ismember(WL_LT,[0 1 2 3 4])) = 0;

mask_MO_SW = valid_mask & (WL_MO==1);
mask_AN_SW = valid_mask & (WL_AN==1);
mask_LT_SW = valid_mask & (WL_LT==1);

mask_MO_VP = valid_mask & (WL_MO==2);
mask_AN_VP = valid_mask & (WL_AN==2);
mask_LT_VP = valid_mask & (WL_LT==2);

fprintf('SW-limited pixels : MO=%d | AN=%d | LT=%d\n', nnz(mask_MO_SW), nnz(mask_AN_SW), nnz(mask_LT_SW));
fprintf('VPD-limited pixels: MO=%d | AN=%d | LT=%d\n', nnz(mask_MO_VP), nnz(mask_AN_VP), nnz(mask_LT_VP));

%% ===================== Read RS data blocks (CSIF + env aligned to 2001-2020) =====================
fprintf('Reading RS data blocks (CSIF + env) ...\n');

% ---- Monthly ----
CSIF_MO = read_raw_3d_len_slice(CSIF_MO_path, [nx,ny], rawLen_csif, sFrom_csif, sTo_csif);      % 240
T_MO    = read_raw_3d_len_slice(T_MO_path,    [nx,ny], rawLen_env,  sFrom_env,  sTo_env);       % 240
P_MO    = read_raw_3d_len_slice(P_MO_path,    [nx,ny], rawLen_env,  sFrom_env,  sTo_env);
R_MO    = read_raw_3d_len_slice(R_MO_path,    [nx,ny], rawLen_env,  sFrom_env,  sTo_env);
SW_MO   = read_raw_3d_len_slice(SW_MO_path,   [nx,ny], rawLen_env,  sFrom_env,  sTo_env);
VPD_MO  = read_raw_3d_len_slice(VPD_MO_path,  [nx,ny], rawLen_env,  sFrom_env,  sTo_env);

% ---- Annual (SSA) ----
CSIF_AN = read_raw_3d_len_slice(CSIF_AN_path, [nx,ny], rawLen_csif, sFrom_csif, sTo_csif);

T_AN    = read_raw_3d_auto_or_envslice(T_AN_path,   [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
P_AN    = read_raw_3d_auto_or_envslice(P_AN_path,   [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
R_AN    = read_raw_3d_auto_or_envslice(R_AN_path,   [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
SW_AN   = read_raw_3d_auto_or_envslice(SW_AN_path,  [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
VPD_AN  = read_raw_3d_auto_or_envslice(VPD_AN_path, [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);

% ---- Long-term (Trend) ----
CSIF_LT = read_raw_3d_len_slice(CSIF_LT_path, [nx,ny], rawLen_csif, sFrom_csif, sTo_csif);

T_LT    = read_raw_3d_auto_or_envslice(T_LT_path,   [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
P_LT    = read_raw_3d_auto_or_envslice(P_LT_path,   [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
R_LT    = read_raw_3d_auto_or_envslice(R_LT_path,   [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
SW_LT   = read_raw_3d_auto_or_envslice(SW_LT_path,  [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);
VPD_LT  = read_raw_3d_auto_or_envslice(VPD_LT_path, [nx,ny], rawLen_env, sFrom_env, sTo_env, Tlen_out);

fprintf('RS data loaded. (All series should be 240 months)\n');

%% =========================================================================================
%% ===================== Pixelwise SEM (Row1: SW-limited) ==================================
resSW = struct();
resSW.MO = run_pixelwise_sem_oneScale('MO | SW-limited', mask_MO_SW, CSIF_MO, SW_MO, VPD_MO, T_MO, P_MO, R_MO, ...
    minN_per_pixel, ridgeLambda, useMonthlyGS, gsFracP90_RS, nx, ny, printEveryRow, "SW");
resSW.AN = run_pixelwise_sem_oneScale('AN | SW-limited', mask_AN_SW, CSIF_AN, SW_AN, VPD_AN, T_AN, P_AN, R_AN, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "SW");
resSW.LT = run_pixelwise_sem_oneScale('LT | SW-limited', mask_LT_SW, CSIF_LT, SW_LT, VPD_LT, T_LT, P_LT, R_LT, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "SW");

%% =========================================================================================
%% ===================== Pixelwise SEM (Row2: VPD-limited) =================================
resVP = struct();
resVP.MO = run_pixelwise_sem_oneScale('MO | VPD-limited', mask_MO_VP, CSIF_MO, SW_MO, VPD_MO, T_MO, P_MO, R_MO, ...
    minN_per_pixel, ridgeLambda, useMonthlyGS, gsFracP90_RS, nx, ny, printEveryRow, "VPD");
resVP.AN = run_pixelwise_sem_oneScale('AN | VPD-limited', mask_AN_VP, CSIF_AN, SW_AN, VPD_AN, T_AN, P_AN, R_AN, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "VPD");
resVP.LT = run_pixelwise_sem_oneScale('LT | VPD-limited', mask_LT_VP, CSIF_LT, SW_LT, VPD_LT, T_LT, P_LT, R_LT, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "VPD");

%% =========================================================================================
%% ===================== Summaries + stars ==================================================
S = struct();
S.SW = struct(); S.VP = struct();

S.SW.MO = summarize_sem_betas(resSW.MO);
S.SW.AN = summarize_sem_betas(resSW.AN);
S.SW.LT = summarize_sem_betas(resSW.LT);

S.VP.MO = summarize_sem_betas(resVP.MO);
S.VP.AN = summarize_sem_betas(resVP.AN);
S.VP.LT = summarize_sem_betas(resVP.LT);

%% =========================================================================================
%% ===================== Plot: 2×3 SEM diagrams ============================================
fs_node  = round(11 * 1.3);
fs_coef  = round(9  * 1.3);
fs_title = round(12 * 1.3);

arrowScale = 0.62;

edgeInflate = 1.20;        % overall closer
edgeInflate_SVW = 1.05;    % SW-VPD only: closer still

gapStart_base = 0.010;
gapEnd_base   = 0.010;

gapStart_SVW  = 0.004;
gapEnd_SVW    = 0.004;

% linewidth mapping (strong contrast)
lwBase = 0.55;
lwSpan = 5.40;
lwCap  = 1.20;

% ---- label positions (BASE) ----
labelT_TtoSW  = 0.80;
labelT_TtoVPD = 0.78;
labelT_RtoVPD = 0.82;

% ---- NEW: vertical tweaks for coefficient TEXT ----
dY_TtoSW   = -0.012;   % T -> SW : slightly lower
dY_RtoVPD  = -0.012;   % R -> VPD: slightly lower
dY_VPDtoSW = +0.010;   % VPD -> SW: slightly higher

% node colors (user palette)
col_SW  = [0.63 0.82 0.45];
col_VPD = [0.55 0.40 0.74];
col_T   = [0.96 0.51 0.49];
col_P   = [0.25 0.63 0.76];
col_R   = [0.96 0.72 0.36];

lightFrac = 0.30;
fc_SW  = lighten_color(col_SW , lightFrac);
fc_VPD = lighten_color(col_VPD, lightFrac);
fc_T   = lighten_color(col_T  , lightFrac);
fc_P   = lighten_color(col_P  , lightFrac);
fc_R   = lighten_color(col_R  , lightFrac);
fc_CSIF = lighten_color([0.70 0.70 0.70], 0.18);

figure('Color','w','Position',[50 -200 1900 1050]);
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

rowNames   = {'SW-limited','VPD-limited'};
rowKeys    = {'SW','VP'};
scaleNames = {'Monthly (RS)','Annual (RS)','Long-term (RS)'};
scaleKeys  = {'MO','AN','LT'};

for r = 1:2
    for c = 1:3
        ax = nexttile((r-1)*3 + c);
        axis(ax,'off'); hold(ax,'on');
        set(ax,'XLim',[0 1],'YLim',[0 1]);

        pos.CSIF = [0.50 0.78];
        pos.SW   = [0.28 0.50];
        pos.VPD  = [0.72 0.50];
        pos.T    = [0.22 0.18];
        pos.P    = [0.50 0.18];
        pos.R    = [0.78 0.18];

        nodeW = 0.10; nodeH = 0.07;

        draw_node(ax, pos.CSIF, 'CSIF', nodeW, nodeH, fs_node, fc_CSIF);
        draw_node(ax, pos.SW  , 'SW',   nodeW, nodeH, fs_node, fc_SW);
        draw_node(ax, pos.VPD , 'VPD',  nodeW, nodeH, fs_node, fc_VPD);
        draw_node(ax, pos.T   , 'T',    nodeW, nodeH, fs_node, fc_T);
        draw_node(ax, pos.P   , 'P',    nodeW, nodeH, fs_node, fc_P);
        draw_node(ax, pos.R   , 'R',    nodeW, nodeH, fs_node, fc_R);

        rk = rowKeys{r};
        sk = scaleKeys{c};
        s  = S.(rk).(sk);

        if strcmp(rk,'SW')
            % Eq2: SW ~ VPD + T + P + R
            draw_curve_arrow_outside(ax, pos.VPD, pos.SW,  -0.95, s.SW.mean(1), s.SW.p(1), 0.60, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate_SVW, gapStart_SVW, gapEnd_SVW, lwBase, lwSpan, lwCap, dY_VPDtoSW);

            draw_curve_arrow_outside(ax, pos.T,   pos.SW,   0.18, s.SW.mean(2), s.SW.p(2), labelT_TtoSW, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_TtoSW);
            draw_curve_arrow_outside(ax, pos.P,   pos.SW,   0.10, s.SW.mean(3), s.SW.p(3), 0.55, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            draw_curve_arrow_outside(ax, pos.R,   pos.SW,  -0.25, s.SW.mean(4), s.SW.p(4), 0.86, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);

            % Eq3: VPD ~ T + P + R
            draw_straight_arrow_outside(ax, pos.T, pos.VPD, s.VPD.mean(1), s.VPD.p(1), labelT_TtoVPD, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);

            draw_curve_arrow_outside(ax, pos.P,   pos.VPD, -0.10, s.VPD.mean(2), s.VPD.p(2), 0.55, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            draw_curve_arrow_outside(ax, pos.R,   pos.VPD, -0.18, s.VPD.mean(3), s.VPD.p(3), labelT_RtoVPD, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_RtoVPD);

        else
            % Eq2: SW ~ T + P + R
            draw_curve_arrow_outside(ax, pos.T,   pos.SW,   0.18, s.SW.mean(1), s.SW.p(1), labelT_TtoSW, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_TtoSW);
            draw_curve_arrow_outside(ax, pos.P,   pos.SW,   0.10, s.SW.mean(2), s.SW.p(2), 0.55, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            draw_curve_arrow_outside(ax, pos.R,   pos.SW,  -0.25, s.SW.mean(3), s.SW.p(3), 0.86, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);

            % Eq3: VPD ~ SW + T + P + R
            draw_curve_arrow_outside(ax, pos.SW, pos.VPD,  -0.95, s.VPD.mean(1), s.VPD.p(1), 0.60, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate_SVW, gapStart_SVW, gapEnd_SVW, lwBase, lwSpan, lwCap, 0);

            draw_straight_arrow_outside(ax, pos.T, pos.VPD, s.VPD.mean(2), s.VPD.p(2), labelT_TtoVPD, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);

            draw_curve_arrow_outside(ax, pos.P,   pos.VPD, -0.10, s.VPD.mean(3), s.VPD.p(3), 0.55, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            draw_curve_arrow_outside(ax, pos.R,   pos.VPD, -0.18, s.VPD.mean(4), s.VPD.p(4), labelT_RtoVPD, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_RtoVPD);
        end

        % Eq1: CSIF ~ SW + VPD + T + P + R
        draw_curve_arrow_outside(ax, pos.SW,  pos.CSIF,  0.00, s.GPP.mean(1), s.GPP.p(1), 0.55, nodeW, nodeH, ...
            arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
        draw_curve_arrow_outside(ax, pos.VPD, pos.CSIF,  0.00, s.GPP.mean(2), s.GPP.p(2), 0.55, nodeW, nodeH, ...
            arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);

        draw_curve_arrow_outside(ax, pos.T, pos.CSIF,  0.62, s.GPP.mean(3), s.GPP.p(3), 0.62, nodeW, nodeH, ...
            arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
        draw_curve_arrow_outside(ax, pos.P, pos.CSIF,  0.00, s.GPP.mean(4), s.GPP.p(4), 0.80, nodeW, nodeH, ...
            arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, -0.02);
        draw_curve_arrow_outside(ax, pos.R, pos.CSIF, -0.62, s.GPP.mean(5), s.GPP.p(5), 0.62, nodeW, nodeH, ...
            arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);

        title(ax, sprintf('%s | %s', scaleNames{c}, rowNames{r}), ...
            'FontWeight','bold','FontSize',fs_title);
    end
end

exportgraphics(gcf, outFig, 'Resolution', 300);
fprintf('\n✅ Saved figure: %s\n', outFig);

%% =========================================================================================
%% ===================================== HELPERS ===========================================

function out = run_pixelwise_sem_oneScale(tag, mask, YS, SW, VPD, Tt, Pp, Rr, ...
    minN_per_pixel, lambda, useGS, gsFracP90, nx, ny, printEveryRow, modeStr)

fprintf('\n================== Pixelwise SEM | %s ==================\n', tag);

bGPP = nan(0,5); % [SW VPD T P R]   (here "GPP" container holds target betas, even if YS=CSIF)
bSW  = nan(0,4);
bVPD = nan(0,4);

nVisited = 0;
nBase = nnz(mask);
tRow = tic;

for i = 1:nx
    for j = 1:ny
        if ~mask(i,j), continue; end
        nVisited = nVisited + 1;

        y   = double(squeeze(YS (i,j,:)));
        sw  = double(squeeze(SW (i,j,:)));
        vpd = double(squeeze(VPD(i,j,:)));
        tt  = double(squeeze(Tt (i,j,:)));
        pp  = double(squeeze(Pp (i,j,:)));
        rr  = double(squeeze(Rr (i,j,:)));

        if useGS
            [y, sw, vpd, tt, pp, rr] = apply_gs_filter_noCO2(y, sw, vpd, tt, pp, rr, gsFracP90);
        end

        mk = isfinite(y) & (y>0) & isfinite(sw) & isfinite(vpd) & isfinite(tt) & isfinite(pp) & isfinite(rr);
        if nnz(mk) < minN_per_pixel
            continue;
        end

        y  = y(mk); sw = sw(mk); vpd = vpd(mk); tt = tt(mk); pp = pp(mk); rr = rr(mk);

        yz   = zscore_safe(y);
        swz  = zscore_safe(sw);
        vpdz = zscore_safe(vpd);
        tz   = zscore_safe(tt);
        pz   = zscore_safe(pp);
        rz   = zscore_safe(rr);

        mk2 = all(isfinite([yz swz vpdz tz pz rz]),2);
        if nnz(mk2) < minN_per_pixel
            continue;
        end
        yz=yz(mk2); swz=swz(mk2); vpdz=vpdz(mk2); tz=tz(mk2); pz=pz(mk2); rz=rz(mk2);

        bg = ridge_beta_closed_form([swz vpdz tz pz rz], yz, lambda);

        if strcmpi(modeStr,"SW")
            bs = ridge_beta_closed_form([vpdz tz pz rz], swz, lambda);
            bv = ridge_beta_closed_form([tz pz rz], vpdz, lambda);

            if all(isfinite(bg)) && all(isfinite(bs)) && all(isfinite(bv))
                bGPP(end+1,:)    = bg; %#ok<AGROW>
                bSW(end+1,1:4)   = bs; %#ok<AGROW>
                bVPD(end+1,1:3)  = bv; %#ok<AGROW>
            end
        else
            bs = ridge_beta_closed_form([tz pz rz], swz, lambda);
            bv = ridge_beta_closed_form([swz tz pz rz], vpdz, lambda);

            if all(isfinite(bg)) && all(isfinite(bs)) && all(isfinite(bv))
                bGPP(end+1,:)    = bg; %#ok<AGROW>
                bSW(end+1,1:3)   = bs; %#ok<AGROW>
                bVPD(end+1,1:4)  = bv; %#ok<AGROW>
            end
        end
    end

    if mod(i,printEveryRow)==0
        pct = 100*(nVisited/max(nBase,1));
        fprintf('  %s row %3d/720 | visited %d/%d (%.1f%%) | kept pixels=%d | elapsed %.1fs\n', ...
            tag, i, nVisited, nBase, pct, size(bGPP,1), toc(tRow));
        tRow = tic;
    end
end

out = struct();
out.bGPP = bGPP;
out.bSW  = bSW;
out.bVPD = bVPD;

fprintf('  %s done. kept pixels=%d\n', tag, size(bGPP,1));
end

function S = summarize_sem_betas(res)
S = struct();
S.nPixels = size(res.bGPP,1);
S.GPP = summarize_one(res.bGPP);
S.SW  = summarize_one(res.bSW);
S.VPD = summarize_one(res.bVPD);
end

function out = summarize_one(B)
out = struct();
if isempty(B)
    out.mean = [];
    out.sem  = [];
    out.p    = [];
    return;
end
m = mean(B,1,'omitnan');
sd = std(B,0,1,'omitnan');
n  = size(B,1);
sem = sd ./ sqrt(max(n,1));

p = nan(1,size(B,2));
for k = 1:size(B,2)
    x = B(:,k);
    x = x(isfinite(x));
    if numel(x) < 5
        p(k) = NaN;
    else
        [~,p(k)] = ttest(x, 0, 'Alpha', 0.05);
    end
end

out.mean = m;
out.sem  = sem;
out.p    = p;
end

function [y, sw, vpd, tt, pp, rr] = apply_gs_filter_noCO2(y, sw, vpd, tt, pp, rr, fracP90)
y = y(:); sw=sw(:); vpd=vpd(:); tt=tt(:); pp=pp(:); rr=rr(:);

yd = double(y);
ok0 = isfinite(yd) & (yd>0);
if nnz(ok0) < 5
    y(:)=NaN; sw(:)=NaN; vpd(:)=NaN; tt(:)=NaN; pp(:)=NaN; rr(:)=NaN;
    return;
end
P90 = prctile(yd(ok0), 90);
thr = fracP90 * P90;
gsMask = (yd > thr);

y(~gsMask)=NaN; sw(~gsMask)=NaN; vpd(~gsMask)=NaN; tt(~gsMask)=NaN; pp(~gsMask)=NaN; rr(~gsMask)=NaN;
end

function z = zscore_safe(x)
x = double(x(:));
m = mean(x,'omitnan');
s = std(x,0,'omitnan');
if ~isfinite(s) || s < 1e-12
    z = nan(size(x));
else
    z = (x - m) ./ s;
end
end

function beta = ridge_beta_closed_form(X, y, lambda)
X = double(X); y = double(y(:));
p = size(X,2);
A = (X'*X) + lambda*eye(p);
b = (X'*y);
if rcond(A) < 1e-12
    beta = nan(1,p);
    return;
end
beta = (A\b)';
end

function A = read_raw_2d_single(path, shape2)
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end

function A = read_raw_3d_len_slice(path, shape2, rawLen, sFrom, sTo)
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);
nTot = numel(dat);
nExpect = nx*ny*rawLen;
if nTot ~= nExpect
    error('Unexpected file size for %s: got %d floats; expected %d (len=%d).', path, nTot, nExpect, rawLen);
end
A = reshape(dat, [nx, ny, rawLen]);
A = A(:,:,sFrom:sTo);
end

function Aout = read_raw_3d_auto_or_envslice(path, shape2, rawLen_env, sFrom_env, sTo_env, Tlen_out)
% Robust reader for your SSACEEMDAN products:
%   - If file len == rawLen_env (468): slice to 2001-2020 via sFrom_env:sTo_env
%   - If file len == 264: slice 1:240 (assume already 2001-2022)
%   - If file len == 240: use as-is
%   - If file len == 420: slice 2001-2018 (205:420) then pad NaN to 240 to keep code runnable
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);
nTot = numel(dat);

len = nTot/(nx*ny);
if abs(len-round(len))>1e-9
    error('Unexpected file size for %s: cannot infer 3rd dim.', path);
end
len = round(len);

A = reshape(dat, [nx, ny, len]);

if len == rawLen_env
    Aout = A(:,:,sFrom_env:sTo_env);
elseif len == 264
    Aout = A(:,:,1:Tlen_out);
elseif len == Tlen_out
    Aout = A;
elseif len == 420
    % 1984-2018 => 2001-2018 is (2001-1984)*12+1 = 205
    Aout = nan(nx,ny,Tlen_out,'single');
    Aout(:,:,1:216) = A(:,:,205:420);
else
    error('Unexpected 3rd-dim length for %s: len=%d (supported: 468/264/240/420).', path, len);
end
end

function txt = coef_text_star(m, p)
if ~isfinite(m)
    txt = 'NA';
    return;
end
st = '';
if isfinite(p)
    if p < 0.001
        st = '***';
    elseif p < 0.01
        st = '**';
    elseif p < 0.05
        st = '*';
    else
        st = '';
    end
end
txt = sprintf('%.2f%s', m, st);
end

function c2 = lighten_color(c, frac)
c = c(:)'; 
frac = max(0, min(1, frac));
c2 = (1-frac)*[1 1 1] + frac*c;
end

function draw_node(ax, xy, label, w, h, fs, faceColor)
x = xy(1); y = xy(2);
rectangle(ax,'Position',[x-w/2, y-h/2, w, h], ...
    'Curvature',0.22, 'EdgeColor','k','LineWidth',1.0,'FaceColor',faceColor);
text(ax, x, y, label, 'HorizontalAlignment','center','VerticalAlignment','middle', ...
    'FontWeight','bold','FontSize',fs, 'Color','k');
end

function [col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap)
if ~isfinite(coefMean)
    col = [0 0 0];
    lw  = lwBase;
    return;
end
if coefMean > 0
    col = [0 0 1];
elseif coefMean < 0
    col = [1 0 0];
else
    col = [0 0 0];
end
a = min(abs(coefMean), lwCap) / lwCap;
lw = lwBase + lwSpan * a;
end

function draw_curve_arrow_outside(ax, p1c, p2c, curvature, coefMean, coefP, labelT, ...
    nodeW, nodeH, arrowScale, fsCoef, edgeInflate, gapStart, gapEnd, lwBase, lwSpan, lwCap, dY)

p1c = p1c(:)'; p2c = p2c(:)';

v = p2c - p1c;
if norm(v) < 1e-12, return; end
u = v / norm(v);

ux = abs(u(1)); uy = abs(u(2));
sx = (nodeW/2) / max(ux,1e-12);
sy = (nodeH/2) / max(uy,1e-12);
sEdge = min(sx, sy);

p1 = p1c + u*(sEdge*edgeInflate + gapStart);
p2 = p2c - u*(sEdge*edgeInflate + gapEnd);

mid = (p1 + p2)/2;
n = [-u(2), u(1)]; n = n / max(norm(n),1e-12);
ctrl = mid + curvature * n;

t = linspace(0,1,160);
Bx = (1-t).^2*p1(1) + 2*(1-t).*t*ctrl(1) + t.^2*p2(1);
By = (1-t).^2*p1(2) + 2*(1-t).*t*ctrl(2) + t.^2*p2(2);

[col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap);

plot(ax, Bx, By, '-', 'Color', col, 'LineWidth', lw);

k2 = numel(t); k1 = max(1, k2-7);
uu = [Bx(k2)-Bx(k1), By(k2)-By(k1)];
if norm(uu) < 1e-12, return; end
uu = uu / norm(uu);

L = 0.030 * arrowScale;
W = 0.018 * arrowScale;

tip = [Bx(k2), By(k2)];
base = tip - L*uu;
perp = [-uu(2), uu(1)];
pA = base + W*perp;
pB = base - W*perp;

plot(ax, [pA(1) tip(1) pB(1)], [pA(2) tip(2) pB(2)], '-', 'Color', col, 'LineWidth', lw);

labelT = max(0.05, min(0.95, labelT));
xm = (1-labelT)^2*p1(1) + 2*(1-labelT)*labelT*ctrl(1) + labelT^2*p2(1);
ym = (1-labelT)^2*p1(2) + 2*(1-labelT)*labelT*ctrl(2) + labelT^2*p2(2);

ym = ym + dY;

txt = coef_text_star(coefMean, coefP);
if ~isempty(txt)
    text(ax, xm, ym, txt, ...
        'FontSize', fsCoef, ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','middle', ...
        'BackgroundColor','w', ...
        'Margin',0.6);
end
end

function draw_straight_arrow_outside(ax, p1c, p2c, coefMean, coefP, labelT, ...
    nodeW, nodeH, arrowScale, fsCoef, edgeInflate, gapStart, gapEnd, lwBase, lwSpan, lwCap, dY)

p1c = p1c(:)'; p2c = p2c(:)';

v = p2c - p1c;
if norm(v) < 1e-12, return; end
u = v / norm(v);

ux = abs(u(1)); uy = abs(u(2));
sx = (nodeW/2) / max(ux,1e-12);
sy = (nodeH/2) / max(uy,1e-12);
sEdge = min(sx, sy);

p1 = p1c + u*(sEdge*edgeInflate + gapStart);
p2 = p2c - u*(sEdge*edgeInflate + gapEnd);

[col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap);

plot(ax, [p1(1) p2(1)], [p1(2) p2(2)], '-', 'Color', col, 'LineWidth', lw);

uu = (p2 - p1);
if norm(uu) < 1e-12, return; end
uu = uu / norm(uu);

L = 0.030 * arrowScale;
W = 0.018 * arrowScale;

tip  = p2;
base = tip - L*uu;
perp = [-uu(2), uu(1)];
pA = base + W*perp;
pB = base - W*perp;

plot(ax, [pA(1) tip(1) pB(1)], [pA(2) tip(2) pB(2)], '-', 'Color', col, 'LineWidth', lw);

labelT = max(0.05, min(0.95, labelT));
xm = (1-labelT)*p1(1) + labelT*p2(1);
ym = (1-labelT)*p1(2) + labelT*p2(2);

ym = ym + dY;

txt = coef_text_star(coefMean, coefP);
if ~isempty(txt)
    text(ax, xm, ym, txt, ...
        'FontSize', fsCoef, ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','middle', ...
        'BackgroundColor','w', ...
        'Margin',0.6);
end
end
