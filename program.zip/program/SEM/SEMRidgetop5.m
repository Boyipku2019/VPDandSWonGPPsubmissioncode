%% =========================================================================================
% Pixelwise "SEM" (no latent variables) using ridge-regularized piecewise regressions
% Target: RS 3 scales | SW-limited (WL==1) & VPD-limited (WL==2) | veg & HFP<=25
% Scales: Monthly (MO), Annual (AN), Long-term (LT)   [LT WITHOUT CO2]
%
% TOP-5 paths only within each panel
% Panel-specific path edits preserved
% This version: larger fonts, larger nodes, tighter SEM spacing
%
% Tested: MATLAB R2021a
% -----------------------------------------------------------------------------------------

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
rng(2025);

%% ===================== Settings =====================
nx = 720; ny = 360;

minN_per_pixel = 10;
ridgeLambda    = 0.05;
useMonthlyGS   = true;
gsFracP90_RS   = 0.2;

printEveryRow = 40;

%% ===================== RS Paths =====================
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

% Monthly
GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw";
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";
VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw";

% Annual
GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');

% Long-term
GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');

% WL maps
WL_MO_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw';
WL_AN_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_Annual_q25_ttest_pcor_f32_720x360.raw';
WL_LT_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw';

%% ===================== Output =====================
outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end
outPNG = fullfile(outDir, sprintf('SEM_RS_3scales_SW_and_VPD_limited_pixelwise_ridge_lambda%.3f_top5paths_journalStyle_largeFont_largeNode.png', ridgeLambda));
outPDF = fullfile(outDir, sprintf('SEM_RS_3scales_SW_and_VPD_limited_pixelwise_ridge_lambda%.3f_top5paths_journalStyle_largeFont_largeNode.pdf', ridgeLambda));

%% ===================== Check files =====================
mustFiles = {lulcPath,hfpPath, ...
    GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path, ...
    GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path, ...
    GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path, ...
    WL_MO_path, WL_AN_path, WL_LT_path};

for k = 1:numel(mustFiles)
    assert(isfile(mustFiles{k}), 'File not found: %s', mustFiles{k});
end

%% ===================== RS mask =====================
IGBP = imread(lulcPath)';
HFP  = imread(hfpPath)';

assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
valid_mask = ismember(IGBP,1:10) & (HFP<=25);
fprintf('RS valid pixels (veg & HFP<=25): %d\n', nnz(valid_mask));

%% ===================== Read WL maps =====================
WL_MO = read_raw_2d_single(WL_MO_path,[nx ny]);
WL_AN = read_raw_2d_single(WL_AN_path,[nx ny]);
WL_LT = read_raw_2d_single(WL_LT_path,[nx ny]);

WL_MO(~ismember(WL_MO,[0 1 2 3 4])) = 0;
WL_AN(~ismember(WL_AN,[0 1 2 3 4])) = 0;
WL_LT(~ismember(WL_LT,[0 1 2 3 4])) = 0;

mask_MO_SW = valid_mask & (WL_MO==1);
mask_AN_SW = valid_mask & (WL_AN==1);
mask_LT_SW = valid_mask & (WL_LT==1);

mask_MO_VP = valid_mask & (WL_MO==2);
mask_AN_VP = valid_mask & (WL_AN==2);
mask_LT_VP = valid_mask & (WL_LT==2);

fprintf('SW-limited pixels : MO=%d | AN=%d | LT=%d\n', nnz(mask_MO_SW), nnz(mask_AN_SW), nnz(mask_LT_SW));
fprintf('VPD-limited pixels: MO=%d | AN=%d | LT=%d\n', nnz(mask_MO_VP), nnz(mask_AN_VP), nnz(mask_LT_VP));

%% ===================== Read RS data blocks =====================
fprintf('Reading RS data blocks...\n');
Tlen   = 420;
rawLen = 468;
sFrom  = 25;
sTo    = 444;

GPP_MO = read_raw_3d_auto(GPP_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_MO   = read_raw_3d_auto(T_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_MO   = read_raw_3d_auto(P_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_MO   = read_raw_3d_auto(R_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_MO  = read_raw_3d_auto(SW_MO_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_MO = read_raw_3d_auto(VPD_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

GPP_AN = read_raw_3d_auto(GPP_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_AN   = read_raw_3d_auto(T_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_AN   = read_raw_3d_auto(P_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_AN   = read_raw_3d_auto(R_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_AN  = read_raw_3d_auto(SW_AN_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_AN = read_raw_3d_auto(VPD_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

GPP_LT = read_raw_3d_auto(GPP_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_LT   = read_raw_3d_auto(T_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_LT   = read_raw_3d_auto(P_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_LT   = read_raw_3d_auto(R_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_LT  = read_raw_3d_auto(SW_LT_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_LT = read_raw_3d_auto(VPD_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

fprintf('RS data loaded.\n');

%% ===================== Pixelwise SEM: SW-limited =====================
resSW = struct();
resSW.MO = run_pixelwise_sem_oneScale('MO | SW-limited', mask_MO_SW, GPP_MO, SW_MO, VPD_MO, T_MO, P_MO, R_MO, ...
    minN_per_pixel, ridgeLambda, useMonthlyGS, gsFracP90_RS, nx, ny, printEveryRow, "SW");
resSW.AN = run_pixelwise_sem_oneScale('AN | SW-limited', mask_AN_SW, GPP_AN, SW_AN, VPD_AN, T_AN, P_AN, R_AN, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "SW");
resSW.LT = run_pixelwise_sem_oneScale('LT | SW-limited', mask_LT_SW, GPP_LT, SW_LT, VPD_LT, T_LT, P_LT, R_LT, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "SW");

%% ===================== Pixelwise SEM: VPD-limited =====================
resVP = struct();
resVP.MO = run_pixelwise_sem_oneScale('MO | VPD-limited', mask_MO_VP, GPP_MO, SW_MO, VPD_MO, T_MO, P_MO, R_MO, ...
    minN_per_pixel, ridgeLambda, useMonthlyGS, gsFracP90_RS, nx, ny, printEveryRow, "VPD");
resVP.AN = run_pixelwise_sem_oneScale('AN | VPD-limited', mask_AN_VP, GPP_AN, SW_AN, VPD_AN, T_AN, P_AN, R_AN, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "VPD");
resVP.LT = run_pixelwise_sem_oneScale('LT | VPD-limited', mask_LT_VP, GPP_LT, SW_LT, VPD_LT, T_LT, P_LT, R_LT, ...
    minN_per_pixel, ridgeLambda, false, gsFracP90_RS, nx, ny, printEveryRow, "VPD");

%% ===================== Summaries =====================
S = struct();
S.SW.MO = summarize_sem_betas(resSW.MO);
S.SW.AN = summarize_sem_betas(resSW.AN);
S.SW.LT = summarize_sem_betas(resSW.LT);

S.VP.MO = summarize_sem_betas(resVP.MO);
S.VP.AN = summarize_sem_betas(resVP.AN);
S.VP.LT = summarize_sem_betas(resVP.LT);

%% =========================================================================================
%% ===================== Plot: 2×3 SEM diagrams ============================

fontScale = 1.25;

fs_node  = round(14 * fontScale);
fs_coef  = round(11 * fontScale);
fs_title = round(13 * fontScale);
fs_panel = round(16 * fontScale);

arrowScale = 0.56;

edgeInflate     = 1.02;
edgeInflate_SVW = 0.96;

gapStart_base = 0.002;
gapEnd_base   = 0.002;

gapStart_SVW  = 0.000;
gapEnd_SVW    = 0.000;

lwBase = 0.90;
lwSpan = 2.60;
lwCap  = 1.20;

labelT_TtoSW  = 0.80;
labelT_TtoVPD = 0.78;
labelT_RtoVPD = 0.82;

dY_TtoSW   = -0.010;
dY_RtoVPD  = -0.012;
dY_VPDtoSW = +0.008;

col_SW  = [0.57 0.73 0.47];
col_VPD = [0.62 0.53 0.73];
col_T   = [0.84 0.47 0.43];
col_P   = [0.35 0.60 0.73];
col_R   = [0.86 0.69 0.39];

lightFrac = 0.42;
fc_SW  = lighten_color(col_SW , lightFrac);
fc_VPD = lighten_color(col_VPD, lightFrac);
fc_T   = lighten_color(col_T  , lightFrac);
fc_P   = lighten_color(col_P  , lightFrac);
fc_R   = lighten_color(col_R  , lightFrac);
fc_GPP = lighten_color([0.58 0.58 0.58], 0.30);

rowNames   = {'SW-limited','VPD-limited'};
rowKeys    = {'SW','VP'};
scaleNames = {'Monthly','Annual','Long-term'};
scaleKeys  = {'MO','AN','LT'};
panelLetters = {'a','b','c','d','e','f'};

figure('Color','w','Position',[100 100 1500 600]);
tiledlayout(2,3,'Padding','tight','TileSpacing','tight');

nodeW = 0.108 * 1.2;
nodeH = 0.075 * 1.2;

for r = 1:2
    for c = 1:3
        ax = nexttile((r-1)*3 + c);
        axis(ax,'off'); hold(ax,'on');
        set(ax,'XLim',[0 1],'YLim',[0 1]);

        pos.GPP = [0.50 0.79];
        pos.SW  = [0.28 0.51];
        pos.VPD = [0.72 0.51];
        pos.T   = [0.22 0.19];
        pos.P   = [0.50 0.19];
        pos.R   = [0.78 0.19];

        opt = struct();
        opt.hideRNode               = false;
        opt.swapTP                  = false;
        opt.forceStraight_VPD_to_SW = false;
        opt.forceStraight_SW_to_VPD = false;
        opt.forceStraight_R_to_VPD  = false;
        opt.custom_SW_to_VPD_tightCurve = false;

        dY_TtoVPD_panel = 0;
        dY_RtoVPD_panel = dY_RtoVPD;

        if r==1 && c==1
            opt.hideRNode               = true;
            opt.forceStraight_VPD_to_SW = true;
        elseif r==1 && c==2
            opt.swapTP                  = true;
            opt.forceStraight_VPD_to_SW = true;
            opt.forceStraight_R_to_VPD  = true;
            dY_TtoVPD_panel = -0.08;
            dY_RtoVPD_panel = -0.03;
        elseif r==1 && c==3
            opt.swapTP                  = true;
            opt.forceStraight_VPD_to_SW = true;
            opt.forceStraight_R_to_VPD  = true;
            dY_TtoVPD_panel = -0.080;
            dY_RtoVPD_panel = -0.03;
        elseif r==2 && c==1
            opt.swapTP                  = true;
            opt.forceStraight_SW_to_VPD = true;
            dY_TtoVPD_panel = -0.020;
        elseif r==2 && c==2
            dY_TtoVPD_panel = -0.020;
        elseif r==2 && c==3
            opt.custom_SW_to_VPD_tightCurve = true;
        end

        if opt.swapTP
            tmp = pos.T;
            pos.T = pos.P;
            pos.P = tmp;
        end

        draw_node(ax, pos.GPP, 'GPP', nodeW, nodeH, fs_node, fc_GPP);
        draw_node(ax, pos.SW , 'SW',  nodeW, nodeH, fs_node, fc_SW);
        draw_node(ax, pos.VPD, 'VPD', nodeW, nodeH, fs_node, fc_VPD);
        draw_node(ax, pos.T  , 'T',   nodeW, nodeH, fs_node, fc_T);
        draw_node(ax, pos.P  , 'P',   nodeW, nodeH, fs_node, fc_P);
        if ~opt.hideRNode
            draw_node(ax, pos.R, 'R', nodeW, nodeH, fs_node, fc_R);
        end

        panelIdx = (r-1)*3 + c;
        text(ax, 0.02, 0.985, panelLetters{panelIdx}, ...
            'Units','normalized', 'FontSize',fs_panel, 'FontWeight','bold', ...
            'HorizontalAlignment','left', 'VerticalAlignment','top', ...
            'Color',[0.10 0.10 0.10]);

        text(ax, 0.105, 0.985, sprintf('%s | %s', scaleNames{c}, rowNames{r}), ...
            'Units','normalized', 'FontSize',fs_title, 'FontWeight','bold', ...
            'HorizontalAlignment','left', 'VerticalAlignment','top', ...
            'Color',[0.10 0.10 0.10]);

        rk = rowKeys{r};
        sk = scaleKeys{c};
        s  = S.(rk).(sk);

        forbid = struct();
        forbid.GPP = false(1,5);

        if strcmp(rk,'SW')
            forbid.SW  = false(1,4);
            forbid.VPD = false(1,3);
        else
            forbid.SW  = false(1,3);
            forbid.VPD = false(1,4);
        end

        if r==1 && c==1
            forbid.GPP(5) = true;
            forbid.SW(end) = true;
            forbid.VPD(end)= true;
        end

        pathKeep = select_top_paths_panel_custom(s, rk, 5, forbid);

        if strcmp(rk,'SW')
            if pathKeep.SW(1)
                if opt.forceStraight_VPD_to_SW
                    draw_straight_arrow_outside(ax, pos.VPD, pos.SW, s.SW.mean(1), s.SW.p(1), 0.60, nodeW, nodeH, ...
                        arrowScale, fs_coef, edgeInflate_SVW, gapStart_SVW, gapEnd_SVW, lwBase, lwSpan, lwCap, dY_VPDtoSW);
                else
                    draw_curve_arrow_outside(ax, pos.VPD, pos.SW, -0.95, s.SW.mean(1), s.SW.p(1), 0.60, nodeW, nodeH, ...
                        arrowScale, fs_coef, edgeInflate_SVW, gapStart_SVW, gapEnd_SVW, lwBase, lwSpan, lwCap, dY_VPDtoSW);
                end
            end
            if pathKeep.SW(2)
                draw_curve_arrow_outside(ax, pos.T, pos.SW, 0.18, s.SW.mean(2), s.SW.p(2), labelT_TtoSW, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_TtoSW);
            end
            if pathKeep.SW(3)
                draw_curve_arrow_outside(ax, pos.P, pos.SW, 0.10, s.SW.mean(3), s.SW.p(3), 0.55, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            end
            if numel(pathKeep.SW)>=4 && pathKeep.SW(4) && ~opt.hideRNode
                draw_curve_arrow_outside(ax, pos.R, pos.SW, -0.25, s.SW.mean(4), s.SW.p(4), 0.86, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            end

            if pathKeep.VPD(1)
                draw_straight_arrow_outside(ax, pos.T, pos.VPD, s.VPD.mean(1), s.VPD.p(1), labelT_TtoVPD, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_TtoVPD_panel);
            end
            if pathKeep.VPD(2)
                draw_curve_arrow_outside(ax, pos.P, pos.VPD, -0.10, s.VPD.mean(2), s.VPD.p(2), 0.55, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            end
            if numel(pathKeep.VPD)>=3 && pathKeep.VPD(3) && ~opt.hideRNode
                if opt.forceStraight_R_to_VPD
                    draw_straight_arrow_outside(ax, pos.R, pos.VPD, s.VPD.mean(3), s.VPD.p(3), labelT_RtoVPD, nodeW, nodeH, ...
                        arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_RtoVPD_panel);
                else
                    draw_curve_arrow_outside(ax, pos.R, pos.VPD, -0.18, s.VPD.mean(3), s.VPD.p(3), labelT_RtoVPD, nodeW, nodeH, ...
                        arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_RtoVPD_panel);
                end
            end

        else
            if pathKeep.SW(1)
                draw_curve_arrow_outside(ax, pos.T, pos.SW, 0.18, s.SW.mean(1), s.SW.p(1), labelT_TtoSW, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_TtoSW);
            end
            if pathKeep.SW(2)
                draw_curve_arrow_outside(ax, pos.P, pos.SW, 0.10, s.SW.mean(2), s.SW.p(2), 0.55, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            end
            if numel(pathKeep.SW)>=3 && pathKeep.SW(3)
                draw_curve_arrow_outside(ax, pos.R, pos.SW, -0.25, s.SW.mean(3), s.SW.p(3), 0.86, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            end

            if pathKeep.VPD(1)
                if opt.custom_SW_to_VPD_tightCurve
                    draw_curve_arrow_outside_anchored(ax, ...
                        pos.SW, pos.VPD, -0.95, ...
                        s.VPD.mean(1), s.VPD.p(1), 0.60, ...
                        nodeW, nodeH, arrowScale, fs_coef, ...
                        lwBase, lwSpan, lwCap, 0, ...
                        'southwest_out', -0.01, ...
                        'south',         0);
                elseif opt.forceStraight_SW_to_VPD
                    draw_straight_arrow_outside(ax, pos.SW, pos.VPD, s.VPD.mean(1), s.VPD.p(1), 0.60, nodeW, nodeH, ...
                        arrowScale, fs_coef, edgeInflate_SVW, gapStart_SVW, gapEnd_SVW, lwBase, lwSpan, lwCap, 0);
                else
                    draw_curve_arrow_outside(ax, pos.SW, pos.VPD, -0.95, s.VPD.mean(1), s.VPD.p(1), 0.60, nodeW, nodeH, ...
                        arrowScale, fs_coef, edgeInflate_SVW, gapStart_SVW, gapEnd_SVW, lwBase, lwSpan, lwCap, 0);
                end
            end
            if pathKeep.VPD(2)
                draw_straight_arrow_outside(ax, pos.T, pos.VPD, s.VPD.mean(2), s.VPD.p(2), labelT_TtoVPD, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_TtoVPD_panel);
            end
            if pathKeep.VPD(3)
                draw_curve_arrow_outside(ax, pos.P, pos.VPD, -0.10, s.VPD.mean(3), s.VPD.p(3), 0.55, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
            end
            if numel(pathKeep.VPD)>=4 && pathKeep.VPD(4)
                draw_curve_arrow_outside(ax, pos.R, pos.VPD, -0.18, s.VPD.mean(4), s.VPD.p(4), labelT_RtoVPD, nodeW, nodeH, ...
                    arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, dY_RtoVPD_panel);
            end
        end

        if pathKeep.GPP(1)
            draw_curve_arrow_outside(ax, pos.SW,  pos.GPP, 0.00, s.GPP.mean(1), s.GPP.p(1), 0.55, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
        end
        if pathKeep.GPP(2)
            draw_curve_arrow_outside(ax, pos.VPD, pos.GPP, 0.00, s.GPP.mean(2), s.GPP.p(2), 0.55, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
        end
        if pathKeep.GPP(3)
            draw_curve_arrow_outside(ax, pos.T, pos.GPP, 0.62, s.GPP.mean(3), s.GPP.p(3), 0.62, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
        end
        if pathKeep.GPP(4)
            draw_curve_arrow_outside(ax, pos.P, pos.GPP, 0.00, s.GPP.mean(4), s.GPP.p(4), 0.80, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, -0.018);
        end
        if pathKeep.GPP(5) && ~opt.hideRNode
            draw_curve_arrow_outside(ax, pos.R, pos.GPP, -0.62, s.GPP.mean(5), s.GPP.p(5), 0.62, nodeW, nodeH, ...
                arrowScale, fs_coef, edgeInflate, gapStart_base, gapEnd_base, lwBase, lwSpan, lwCap, 0);
        end
    end
end

exportgraphics(gcf, outPNG, 'Resolution', 600);
exportgraphics(gcf, outPDF, 'ContentType', 'vector');
fprintf('\n✅ Saved figure (PNG): %s\n', outPNG);
fprintf('✅ Saved figure (PDF): %s\n', outPDF);

%% =========================================================================================
%% ===================================== HELPERS ===========================================

function out = run_pixelwise_sem_oneScale(tag, mask, GPP, SW, VPD, Tt, Pp, Rr, ...
    minN_per_pixel, lambda, useGS, gsFracP90, nx, ny, printEveryRow, modeStr)

fprintf('\n================== Pixelwise SEM | %s ==================\n', tag);

bGPP = nan(0,5);
bSW  = nan(0,4);
bVPD = nan(0,4);

nVisited = 0;
nBase = nnz(mask);
tRow = tic;

for i = 1:nx
    for j = 1:ny
        if ~mask(i,j), continue; end
        nVisited = nVisited + 1;

        y   = double(squeeze(GPP(i,j,:)));
        sw  = double(squeeze(SW (i,j,:)));
        vpd = double(squeeze(VPD(i,j,:)));
        tt  = double(squeeze(Tt (i,j,:)));
        pp  = double(squeeze(Pp (i,j,:)));
        rr  = double(squeeze(Rr (i,j,:)));

        if useGS
            [y, sw, vpd, tt, pp, rr] = apply_gs_filter_noCO2(y, sw, vpd, tt, pp, rr, gsFracP90);
        end

        mk = isfinite(y) & (y>0) & isfinite(sw) & isfinite(vpd) & isfinite(tt) & isfinite(pp) & isfinite(rr);
        if nnz(mk) < minN_per_pixel
            continue;
        end

        y  = y(mk); sw = sw(mk); vpd = vpd(mk); tt = tt(mk); pp = pp(mk); rr = rr(mk);

        yz   = zscore_safe(y);
        swz  = zscore_safe(sw);
        vpdz = zscore_safe(vpd);
        tz   = zscore_safe(tt);
        pz   = zscore_safe(pp);
        rz   = zscore_safe(rr);

        mk2 = all(isfinite([yz swz vpdz tz pz rz]),2);
        if nnz(mk2) < minN_per_pixel
            continue;
        end

        yz=yz(mk2); swz=swz(mk2); vpdz=vpdz(mk2); tz=tz(mk2); pz=pz(mk2); rz=rz(mk2);

        bg = ridge_beta_closed_form([swz vpdz tz pz rz], yz, lambda);

        if strcmpi(modeStr,"SW")
            bs = ridge_beta_closed_form([vpdz tz pz rz], swz, lambda);
            bv = ridge_beta_closed_form([tz pz rz], vpdz, lambda);

            if all(isfinite(bg)) && all(isfinite(bs)) && all(isfinite(bv))
                bGPP(end+1,:)    = bg; %#ok<AGROW>
                bSW(end+1,1:4)   = bs; %#ok<AGROW>
                bVPD(end+1,1:3)  = bv; %#ok<AGROW>
            end
        else
            bs = ridge_beta_closed_form([tz pz rz], swz, lambda);
            bv = ridge_beta_closed_form([swz tz pz rz], vpdz, lambda);

            if all(isfinite(bg)) && all(isfinite(bs)) && all(isfinite(bv))
                bGPP(end+1,:)    = bg; %#ok<AGROW>
                bSW(end+1,1:3)   = bs; %#ok<AGROW>
                bVPD(end+1,1:4)  = bv; %#ok<AGROW>
            end
        end
    end

    if mod(i,printEveryRow)==0
        pct = 100*(nVisited/max(nBase,1));
        fprintf('  %s row %3d/720 | visited %d/%d (%.1f%%) | kept pixels=%d | elapsed %.1fs\n', ...
            tag, i, nVisited, nBase, pct, size(bGPP,1), toc(tRow));
        tRow = tic;
    end
end

out = struct();
out.bGPP = bGPP;
out.bSW  = bSW;
out.bVPD = bVPD;

fprintf('  %s done. kept pixels=%d\n', tag, size(bGPP,1));
end

function S = summarize_sem_betas(res)
S = struct();
S.nPixels = size(res.bGPP,1);
S.GPP = summarize_one(res.bGPP);
S.SW  = summarize_one(res.bSW);
S.VPD = summarize_one(res.bVPD);
end

function out = summarize_one(B)
out = struct();
if isempty(B)
    out.mean = [];
    out.sem  = [];
    out.p    = [];
    return;
end

m = mean(B,1,'omitnan');
sd = std(B,0,1,'omitnan');
n  = size(B,1);
sem = sd ./ sqrt(max(n,1));

p = nan(1,size(B,2));
for k = 1:size(B,2)
    x = B(:,k);
    x = x(isfinite(x));
    if numel(x) < 5
        p(k) = NaN;
    else
        [~,p(k)] = ttest(x, 0, 'Alpha', 0.05);
    end
end

out.mean = m;
out.sem  = sem;
out.p    = p;
end

function keep = select_top_paths_panel_custom(s, rowKey, topK, forbid)
keep.GPP = false(1,5);

if strcmp(rowKey,'SW')
    keep.SW  = false(1,4);
    keep.VPD = false(1,3);
else
    keep.SW  = false(1,3);
    keep.VPD = false(1,4);
end

allVals = zeros(0,1);
allGrp  = cell(0,1);
allIdx  = zeros(0,1);

for k = 1:min(5, numel(s.GPP.mean))
    if ~forbid.GPP(k) && isfinite(s.GPP.mean(k))
        allVals(end+1,1) = abs(s.GPP.mean(k)); %#ok<AGROW>
        allGrp{end+1,1}  = 'GPP'; %#ok<AGROW>
        allIdx(end+1,1)  = k; %#ok<AGROW>
    end
end

for k = 1:min(numel(keep.SW), numel(s.SW.mean))
    if ~forbid.SW(k) && isfinite(s.SW.mean(k))
        allVals(end+1,1) = abs(s.SW.mean(k)); %#ok<AGROW>
        allGrp{end+1,1}  = 'SW'; %#ok<AGROW>
        allIdx(end+1,1)  = k; %#ok<AGROW>
    end
end

for k = 1:min(numel(keep.VPD), numel(s.VPD.mean))
    if ~forbid.VPD(k) && isfinite(s.VPD.mean(k))
        allVals(end+1,1) = abs(s.VPD.mean(k)); %#ok<AGROW>
        allGrp{end+1,1}  = 'VPD'; %#ok<AGROW>
        allIdx(end+1,1)  = k; %#ok<AGROW>
    end
end

if isempty(allVals)
    return;
end

[~, ord] = sort(allVals, 'descend');
ord = ord(1:min(topK, numel(ord)));

for ii = 1:numel(ord)
    g = allGrp{ord(ii)};
    k = allIdx(ord(ii));
    keep.(g)(k) = true;
end
end

function [y, sw, vpd, tt, pp, rr] = apply_gs_filter_noCO2(y, sw, vpd, tt, pp, rr, fracP90)
y = y(:); sw=sw(:); vpd=vpd(:); tt=tt(:); pp=pp(:); rr=rr(:);

yd = double(y);
ok0 = isfinite(yd) & (yd>0);
if nnz(ok0) < 5
    y(:)=NaN; sw(:)=NaN; vpd(:)=NaN; tt(:)=NaN; pp(:)=NaN; rr(:)=NaN;
    return;
end

P90 = prctile(yd(ok0), 90);
thr = fracP90 * P90;
gsMask = (yd > thr);

y(~gsMask)=NaN;
sw(~gsMask)=NaN;
vpd(~gsMask)=NaN;
tt(~gsMask)=NaN;
pp(~gsMask)=NaN;
rr(~gsMask)=NaN;
end

function z = zscore_safe(x)
x = double(x(:));
m = mean(x,'omitnan');
s = std(x,0,'omitnan');

if ~isfinite(s) || s < 1e-12
    z = nan(size(x));
else
    z = (x - m) ./ s;
end
end

function beta = ridge_beta_closed_form(X, y, lambda)
X = double(X);
y = double(y(:));
p = size(X,2);

A = (X'*X) + lambda*eye(p);
b = (X'*y);

if rcond(A) < 1e-12
    beta = nan(1,p);
    return;
end

beta = (A\b)';
end

function A = read_raw_2d_single(path, shape2)
fid = fopen(path,'r');
assert(fid>0, 'Cannot open: %s', path);
A = fread(fid, prod(shape2), 'single');
fclose(fid);
A = reshape(A, shape2);
end

function A = read_raw_3d_auto(path, shape2, Tlen, rawLen, sFrom, sTo)
nx = shape2(1);
ny = shape2(2);

fid = fopen(path,'r');
assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single');
fclose(fid);

nTot = numel(dat);
n1 = nx*ny*Tlen;
n2 = nx*ny*rawLen;

if nTot == n1
    A = reshape(dat, [nx, ny, Tlen]);
elseif nTot == n2
    A = reshape(dat, [nx, ny, rawLen]);
    A = A(:,:,sFrom:sTo);
else
    error('Unexpected file size for %s: got %d floats; expected %d or %d.', path, nTot, n1, n2);
end
end

function txt = coef_text_star(m, p)
if ~isfinite(m)
    txt = 'NA';
    return;
end

st = '';
if isfinite(p)
    if p < 0.001
        st = '***';
    elseif p < 0.01
        st = '**';
    elseif p < 0.05
        st = '*';
    end
end

txt = sprintf('%.2f%s', m, st);
end

function c2 = lighten_color(c, frac)
c = c(:)';
frac = max(0, min(1, frac));
c2 = (1-frac)*[1 1 1] + frac*c;
end

function draw_node(ax, xy, label, w, h, fs, faceColor)
x = xy(1);
y = xy(2);

rectangle(ax,'Position',[x-w/2, y-h/2, w, h], ...
    'Curvature',0.20, ...
    'EdgeColor',[0.25 0.25 0.25], ...
    'LineWidth',1.2, ...
    'FaceColor',faceColor);

text(ax, x, y, label, ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontWeight','bold', ...
    'FontSize',fs, ...
    'Color',[0.12 0.12 0.12]);
end

function [col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap)
if ~isfinite(coefMean)
    col = [0.25 0.25 0.25];
    lw  = lwBase;
    return;
end

if coefMean > 0
    col = [0.19 0.39 0.73];
elseif coefMean < 0
    col = [0.78 0.28 0.24];
else
    col = [0.35 0.35 0.35];
end

a = min(abs(coefMean), lwCap) / lwCap;
lw = lwBase + lwSpan * a;
end

function p = node_anchor_point(center, w, h, modeStr, offset)
x = center(1);
y = center(2);

switch lower(modeStr)
    case 'south'
        p = [x, y - h/2 - offset];
    case 'southwest_out'
        p = [x - w/2 - offset, y - h/2 - offset];
    case 'southwest_edge'
        p = [x - w/2, y - h/2];
    otherwise
        p = center;
end
end

function draw_curve_arrow_outside(ax, p1c, p2c, curvature, coefMean, coefP, labelT, ...
    nodeW, nodeH, arrowScale, fsCoef, edgeInflate, gapStart, gapEnd, lwBase, lwSpan, lwCap, dY)

p1c = p1c(:)';
p2c = p2c(:)';

v = p2c - p1c;
if norm(v) < 1e-12
    return;
end

u = v / norm(v);

ux = abs(u(1));
uy = abs(u(2));
sx = (nodeW/2) / max(ux,1e-12);
sy = (nodeH/2) / max(uy,1e-12);
sEdge = min(sx, sy);

p1 = p1c + u*(sEdge*edgeInflate + gapStart);
p2 = p2c - u*(sEdge*edgeInflate + gapEnd);

mid = (p1 + p2)/2;
n = [-u(2), u(1)];
n = n / max(norm(n),1e-12);
ctrl = mid + curvature * n;

t = linspace(0,1,180);
Bx = (1-t).^2*p1(1) + 2*(1-t).*t*ctrl(1) + t.^2*p2(1);
By = (1-t).^2*p1(2) + 2*(1-t).*t*ctrl(2) + t.^2*p2(2);

[col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap);
plot(ax, Bx, By, '-', 'Color', col, 'LineWidth', lw);

k2 = numel(t);
k1 = max(1, k2-8);
uu = [Bx(k2)-Bx(k1), By(k2)-By(k1)];

if norm(uu) < 1e-12
    return;
end

uu = uu / norm(uu);

L = 0.026 * arrowScale;
W = 0.014 * arrowScale;

tip = [Bx(k2), By(k2)];
base = tip - L*uu;
perp = [-uu(2), uu(1)];
pA = base + W*perp;
pB = base - W*perp;

patch(ax, [pA(1) tip(1) pB(1)], [pA(2) tip(2) pB(2)], col, ...
    'EdgeColor', col, 'LineWidth', 0.6);

labelT = max(0.05, min(0.95, labelT));
xm = (1-labelT)^2*p1(1) + 2*(1-labelT)*labelT*ctrl(1) + labelT^2*p2(1);
ym = (1-labelT)^2*p1(2) + 2*(1-labelT)*labelT*ctrl(2) + labelT^2*p2(2);
ym = ym + dY;

txt = coef_text_star(coefMean, coefP);

if ~isempty(txt)
    text(ax, xm, ym, txt, ...
        'FontSize', fsCoef, ...
        'FontWeight','bold', ...
        'Color',[0.12 0.12 0.12], ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','middle', ...
        'BackgroundColor','w', ...
        'Margin',0.75);
end
end

function draw_curve_arrow_outside_anchored(ax, p1c, p2c, curvature, coefMean, coefP, labelT, ...
    nodeW, nodeH, arrowScale, fsCoef, lwBase, lwSpan, lwCap, dY, ...
    startMode, startOffset, endMode, endOffset)

p1c = p1c(:)';
p2c = p2c(:)';

p1 = node_anchor_point(p1c, nodeW, nodeH, startMode, startOffset);
p2 = node_anchor_point(p2c, nodeW, nodeH, endMode, endOffset);

v = p2 - p1;
if norm(v) < 1e-12
    return;
end

u = v / norm(v);

mid = (p1 + p2)/2;
n = [-u(2), u(1)];
n = n / max(norm(n),1e-12);
ctrl = mid + curvature * n;

t = linspace(0,1,180);
Bx = (1-t).^2*p1(1) + 2*(1-t).*t*ctrl(1) + t.^2*p2(1);
By = (1-t).^2*p1(2) + 2*(1-t).*t*ctrl(2) + t.^2*p2(2);

[col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap);
plot(ax, Bx, By, '-', 'Color', col, 'LineWidth', lw);

k2 = numel(t);
k1 = max(1, k2-8);
uu = [Bx(k2)-Bx(k1), By(k2)-By(k1)];

if norm(uu) < 1e-12
    return;
end

uu = uu / norm(uu);

L = 0.026 * arrowScale;
W = 0.014 * arrowScale;

tip = [Bx(k2), By(k2)];
base = tip - L*uu;
perp = [-uu(2), uu(1)];
pA = base + W*perp;
pB = base - W*perp;

patch(ax, [pA(1) tip(1) pB(1)], [pA(2) tip(2) pB(2)], col, ...
    'EdgeColor', col, 'LineWidth', 0.6);

labelT = max(0.05, min(0.95, labelT));
xm = (1-labelT)^2*p1(1) + 2*(1-labelT)*labelT*ctrl(1) + labelT^2*p2(1);
ym = (1-labelT)^2*p1(2) + 2*(1-labelT)*labelT*ctrl(2) + labelT^2*p2(2);
ym = ym + dY;

txt = coef_text_star(coefMean, coefP);

if ~isempty(txt)
    text(ax, xm, ym, txt, ...
        'FontSize', fsCoef, ...
        'FontWeight','bold', ...
        'Color',[0.12 0.12 0.12], ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','middle', ...
        'BackgroundColor','w', ...
        'Margin',0.75);
end
end

function draw_straight_arrow_outside(ax, p1c, p2c, coefMean, coefP, labelT, ...
    nodeW, nodeH, arrowScale, fsCoef, edgeInflate, gapStart, gapEnd, lwBase, lwSpan, lwCap, dY)

p1c = p1c(:)';
p2c = p2c(:)';

v = p2c - p1c;
if norm(v) < 1e-12
    return;
end

u = v / norm(v);

ux = abs(u(1));
uy = abs(u(2));
sx = (nodeW/2) / max(ux,1e-12);
sy = (nodeH/2) / max(uy,1e-12);
sEdge = min(sx, sy);

p1 = p1c + u*(sEdge*edgeInflate + gapStart);
p2 = p2c - u*(sEdge*edgeInflate + gapEnd);

[col, lw] = style_from_coef(coefMean, lwBase, lwSpan, lwCap);
plot(ax, [p1(1) p2(1)], [p1(2) p2(2)], '-', 'Color', col, 'LineWidth', lw);

uu = p2 - p1;

if norm(uu) < 1e-12
    return;
end

uu = uu / norm(uu);

L = 0.026 * arrowScale;
W = 0.014 * arrowScale;

tip  = p2;
base = tip - L*uu;
perp = [-uu(2), uu(1)];
pA = base + W*perp;
pB = base - W*perp;

patch(ax, [pA(1) tip(1) pB(1)], [pA(2) tip(2) pB(2)], col, ...
    'EdgeColor', col, 'LineWidth', 0.6);

labelT = max(0.05, min(0.95, labelT));
xm = (1-labelT)*p1(1) + labelT*p2(1);
ym = (1-labelT)*p1(2) + labelT*p2(2);
ym = ym + dY;

txt = coef_text_star(coefMean, coefP);

if ~isempty(txt)
    text(ax, xm, ym, txt, ...
        'FontSize', fsCoef, ...
        'FontWeight','bold', ...
        'Color',[0.12 0.12 0.12], ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','middle', ...
        'BackgroundColor','w', ...
        'Margin',0.75);
end
end