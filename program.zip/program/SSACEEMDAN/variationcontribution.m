clear all;close all;clc;
IGBP=imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP=IGBP';
HFP=imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');
HFP=HFP';

%% ---------- VarShare �ļ���Ϣ ----------
basePath  = 'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\';
fileNames = { ...
    'GPP05_VarShare4.raw', ...
    'T05_VarShare4.raw',   ...
    'P05_VarShare4.raw',   ...
    'R05_VarShare4.raw',   ...
    'SW05_VarShare4.raw',  ...
    'CO205_VarShare4.raw'  ...
};

% ��ͼ���⣨������˳��
varTitles = { ...
    'GPP', ...
    'Temperature', ...
    'Precipitation', ...
    'Radiation', ...
    'Soil water', ...
    'CO_{2}' ...
};

nVar   = numel(fileNames);   % 6 ������
nBiome = 9;                  % ENF, EBF, DNF, DBF, MF, SHL, SVA, GRA, WET
nScale = 3;                  % Semiannual / Annual / Long-term

% �������9��3��6
dataAll   = single(zeros(nBiome, nScale, nVar));
errorsAll = single(zeros(nBiome, nScale, nVar));

%% ---------- ����Ⱥϵ���� ----------
biomeNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'};

%% =====================================================================
%                       ѭ�� 6 �����������ͳ��
% ======================================================================
for v = 1:nVar
    % ��ȡ��ǰ������ VarShare4
    Variationcontribution = single(zeros(720,360,4));
    fid = fopen([basePath fileNames{v}], 'r');
    Variationcontribution = fread(fid, 720*360*4, 'single');
    fclose(fid);
    Variationcontribution = reshape(Variationcontribution, [720,360,4]);

    % ÿ������Ⱥϵ�� 3 ���߶ȵ�������2=Semiannual, 3=Annual, 4=Long-term
    valsLong  = cell(nBiome,1);
    valsInner = cell(nBiome,1);
    valsInter = cell(nBiome,1);
    for b = 1:nBiome
        valsLong{b}  = [];
        valsInner{b} = [];
        valsInter{b} = [];
    end

    % ������Ԫ���� IGBP & HFP ����ۺ�
    for i = 1:720
        for j = 1:360
            if HFP(i,j) > 25
                continue;
            end

            c = IGBP(i,j);
            % IGBP -> �к�ӳ��
            if     c == 1
                row = 1;   % ENF
            elseif c == 2
                row = 2;   % EBF
            elseif c == 3
                row = 3;   % DNF
            elseif c == 4
                row = 4;   % DBF
            elseif c == 5
                row = 5;   % MF
            elseif c == 6 || c == 7
                row = 6;   % SHL
            elseif c == 8 || c == 9
                row = 7;   % SVA
            elseif c == 10
                row = 8;   % GRA
            elseif c == 11
                row = 9;   % WET
            else
                continue;
            end

            valsLong{row}  = [valsLong{row};       Variationcontribution(i,j,2)];
            valsInner{row} = [valsInner{row};      Variationcontribution(i,j,3)];
            valsInter{row} = [valsInter{row};      Variationcontribution(i,j,4)];
        end
        i; %#ok<NOPTS>  % �鿴���ȣ���ע�͵�
    end

    % �����ֵ�ͱ�׼��ȱ���Ϊ 0~1����ͳһ�� 100��
    data   = single(zeros(nBiome, nScale));
    errors = single(zeros(nBiome, nScale));

    for b = 1:nBiome
        data(b,1)   = mean(valsLong{b});
        errors(b,1) = std(valsLong{b});

        data(b,2)   = mean(valsInner{b});
        errors(b,2) = std(valsInner{b});

        data(b,3)   = mean(valsInter{b});
        errors(b,3) = std(valsInter{b});
    end

    % ת�ٷֱ�
    dataAll(:,:,v)   = data   * 100;
    errorsAll(:,:,v) = errors * 100;
end

%% =====================================================================
%                       ��ͼ��3 �� 2 ����ͼ
% ======================================================================

% ��ɫ��3 ��ʱ��߶�
colors = [
    0,   0.5, 0.1;  % Semiannual
    0.6, 0.6, 0.6;  % Annual
    0.9, 0.6, 0.2;  % Long-term
];

% ���壺ԭ����ŵ� 2/3 ����
FS     = 12;   % ������
FS_leg = 10;   % ͼ������

figure;
set(gcf, 'Position', [50, 50, 1000, 800]);
t = tiledlayout(3,2,'TileSpacing','compact','Padding','compact');
set(0,'DefaultAxesFontName','Arial');

% ����ͼ���ľ����ȡ��һ����ͼ�� bar��
hBarLegend = [];

for v = 1:nVar
    nexttile;
    data   = dataAll(:,:,v);
    errors = errorsAll(:,:,v);

    % grouped bar
    b = bar(data, 'grouped'); hold on;

    % �����һ�������� bar ���������ȫ�� legend
    if v == 1
        hBarLegend = b;
    end

    % ������ɫ
    for k = 1:3
        b(k).FaceColor = colors(k,:);
        b(k).BarWidth  = 1 * b(k).BarWidth;
    end

    % �����
    ngroups    = size(data,1);
    nbars      = size(data,2);
    groupwidth = min(0.8, nbars/(nbars + 1.5));

    for i = 1:nbars
        x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
        errorbar(x, data(:,i), errors(:,i), 'k', ...
            'linestyle','none', 'CapSize', 8, 'LineWidth', 1);
    end

    % ���������ǩ
    set(gca, 'XTick', 1:nBiome, ...
        'XTickLabel', biomeNames, ...
        'FontSize', FS, 'FontName','Arial');

    ylim([0 100]);
    yticks(0:20:100);
    set(gca, 'YTickLabel', arrayfun(@(x) sprintf('%.0f%%', x), 0:20:100, ...
        'UniformOutput', false), ...
        'FontSize', FS, 'FontName','Arial');

    % ���м� y ���ǩ
    if mod(v,2)==1
        ylabel('Variation contribution', ...
            'FontSize', FS, 'FontName','Arial');
    end

    title(varTitles{v}, 'FontSize', FS, 'FontName','Arial');

    set(gca,'LineWidth',1);
    grid on; box on;
    hold off;
end

% --------- ȫ��ͼ�����������·��м� ----------
% ע�⣺���ܰ� tiledlayout ������� legend
lg = legend(hBarLegend, {'Semiannual','Annual','Long-term'}, ...
    'Orientation','horizontal', 'FontSize', FS_leg, 'FontName','Arial');
lg.Layout.Tile = 'south';   % �� legend ռ�ݲ��ֵײ�һ��

% ����ͼƬ��300 dpi
print('VarShare_6vars_3x2_mediumfont','-dpng','-r300');
