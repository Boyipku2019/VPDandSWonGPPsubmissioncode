%% ========== SSA(2-month / Semi / Annual) + CEEMDAN(Trend=last IMF) | 4 components ==========
% clear all;
close all; clc;

%% -------- 输入数据 --------
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif'); 
IGBP = IGBP';                                  % 注意：你的栅格转置
fllFileName = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";

fid = fopen(fllFileName,'r');
All = fread(fid,720*360*468,'single'); fclose(fid);
All = reshape(All,[720,360,468]);

%% -------- 参数设置 --------
N = 468;                        % 月序列长度（1982–2020 共39年×12月）
L = 180;                        % SSA窗口
valid_classes = 1:11;

% 固定频段（单位：月）
bimonth_band = [3, 5];          % 2个月周期（允许少量带宽容忍）
semi_band    = [5, 7];          % 半年 ≈ 6 ± 2
annual_band  = [10, 14];         % 年   ≈ 12 ± 3

%% -------- 预分配输出 --------
BiMonthCube  = single(zeros(720,360,N));   % 2个月（SSA）
SemiCube     = single(zeros(720,360,N));   % 半年（SSA）
AnnualCube   = single(zeros(720,360,N));   % 年（SSA）
TrendCube    = single(zeros(720,360,N));   % 长期（CEEMDAN 最后IMF）

VarShare4    = single(zeros(720,360,4));   % 四个分量方差占比：2m/Semi/Annual/Trend

count_valid = 0;

%% ================== 主循环 ==================
for i = 1:720
  for j = 1:360

    if ~isnan(All(i,j,1)) && any(IGBP(i,j) == valid_classes)

      temp = reshape(All(i,j,:), [N,1]);        % 原序列 (N×1)
      if ~any(isfinite(temp)) || std(temp(~isnan(temp))) < 1e-12, continue; end
      if any(isnan(temp)), temp = fillmissing(temp,'linear'); end

      count_valid = count_valid + 1;

      %% ===== CEEMDAN：长期趋势 = 最后一个IMF =====
      imf = ceemdan(temp, 0.2, 20, 50, 1)';     % [N × K]
      last_imf = imf(:, end);                   % 长期趋势 = 最后IMF

      %% ===== SSA：提取 2个月 / 半年 / 年 分量 =====
      [~,~,~,RC,~] = ssa_decompose(temp, L);
      peakP = estimate_rc_periods(RC);          % 每个RC主导周期（月）

      bimon_mask = (peakP >= bimonth_band(1) & peakP <= bimonth_band(2));
      semi_mask  = (peakP >= semi_band(1)    & peakP <= semi_band(2));
      ann_mask   = (peakP >= annual_band(1)  & peakP <= annual_band(2));

      BiMonth = ssa_reconstruct_groups(RC, find(bimon_mask));   % 2个月 (N×1)
      Semi    = ssa_reconstruct_groups(RC, find(semi_mask));    % 半年   (N×1)
      Annual  = ssa_reconstruct_groups(RC, find(ann_mask));     % 年     (N×1)

      %% ===== 保存四个分量 =====
      BiMonthCube(i,j,:) = single(BiMonth);
      SemiCube(i,j,:)    = single(Semi);
      AnnualCube(i,j,:)  = single(Annual);
      TrendCube(i,j,:)   = single(last_imf);

      %% ===== 四个分量的方差贡献（raw，不强求和=1） =====
      tv = var(temp, 1); if tv <= 0, tv = eps; end
      VarShare4(i,j,1) = single(var(BiMonth,  1) / tv);   % 2个月
      VarShare4(i,j,2) = single(var(Semi,     1) / tv);   % 半年
      VarShare4(i,j,3) = single(var(Annual,   1) / tv);   % 年
      VarShare4(i,j,4) = single(var(last_imf, 1) / tv);   % 长期

    end
  end
  fprintf('Row %d/720 processed. Valid pixels so far = %d\n', i, count_valid);
end

%% -------- 保存结果 --------
fid=fopen('D:\P05_SSA_BiMonth_4comp.raw','wb');     fwrite(fid,BiMonthCube,'single');  fclose(fid);
fid=fopen('D:\P05_SSA_Semiannual_4comp.raw','wb');  fwrite(fid,SemiCube,'single');     fclose(fid);
fid=fopen('D:\P05_SSA_Annual_4comp.raw','wb');      fwrite(fid,AnnualCube,'single');   fclose(fid);
fid=fopen('D:\P05_CEEMDAN_Trend_4comp.raw','wb');   fwrite(fid,TrendCube,'single');    fclose(fid);

fid=fopen('D:\P05_VarShare4.raw','wb');             fwrite(fid,VarShare4,'single');    fclose(fid);

fprintf('Done. Valid pixels processed: %d\n', count_valid);

%% ================== 本地函数（SSA） ==================
function [U,S,V,RC,lambda] = ssa_decompose(y,L)
% SSA decomposition
y = y(:); N = length(y);
if L < 2 || L > N-1, error('L must be in [2, N-1].'); end
K = N - L + 1;

% 轨迹矩阵
X = zeros(L,K);
for ii = 1:K, X(:,ii) = y(ii:ii+L-1); end

% SVD
[U,S,V] = svd(X,'econ'); lambda = diag(S).^2;

% 对角平均重构 RC
Krc = min(L,K); RC = zeros(N,Krc);
for r = 1:Krc
  Xr = U(:,r)*S(r,r)*V(:,r)'; 
  RC(:,r) = hankel_averaging(Xr);
end
end

function z = hankel_averaging(Xr)
[L,K] = size(Xr); N = L + K - 1;
z = zeros(N,1); w = zeros(N,1);
for ii = 1:L
  for jj = 1:K
    z(ii+jj-1) = z(ii+jj-1) + Xr(ii,jj);
    w(ii+jj-1) = w(ii+jj-1) + 1;
  end
end
z = z ./ max(w,1);
end

function peakPeriod = estimate_rc_periods(RC)
% 估计每个 RC 的主导周期（样本步=月）
[N,K] = size(RC); peakPeriod = zeros(1,K);
for k = 1:K
  x = RC(:,k) - mean(RC(:,k));
  if ~any(isfinite(x)) || std(x) < 1e-10
    peakPeriod(k) = Inf; continue;
  end
  X = fft(x); P2 = abs(X/N).^2; P1 = P2(1:floor(N/2));
  if ~isempty(P1), P1(1)=0; end
  if isempty(P1)
    peakPeriod(k) = Inf;
  else
    [val,idx] = max(P1);
    if val <= 1e-12 || idx <= 1
      peakPeriod(k) = Inf;
    else
      f = (idx-1)/N; 
      if f <= 0, peakPeriod(k) = Inf; else, peakPeriod(k) = 1/f; end
    end
  end
end
end

function Y = ssa_reconstruct_groups(RC, idx)
% 将选定的 RC 索引集合重构为一个分量
[N,~] = size(RC);
if isempty(idx), Y = zeros(N,1);
else, Y = sum(RC(:,idx),2,'omitnan');
end
end
