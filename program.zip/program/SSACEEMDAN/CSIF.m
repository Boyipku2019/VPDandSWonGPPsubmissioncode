%% ========== SSA(Semi/Annual) + CEEMDAN(Trend=last IMF from Program2) ========== 
% clear all;
close all; clc;

%% -------- 输入数据 --------
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif'); 
IGBP = IGBP';                                  % 注意：你的栅格转置
fllFileName = "G:\Resource use efficiencies new\dataprocessed\CSIF20012022_3D.raw";  % CSIF 数据

fid = fopen(fllFileName,'r');
All = fread(fid,720*360*264,'single'); fclose(fid); 
All = reshape(All,[720,360,264]);               % 读取并调整为 (720x360x264) 的三维数据

%% -------- 参数设置 --------
N = 264;                        % 月序列长度（22年×12月） = 264
L = 180;                        % SSA窗口
valid_classes = 1:11;

% 固定频段（单位：月）
semi_band   = [4, 8];           % 半年 ≈6±2
annual_band = [9, 15];          % 年   ≈12±3

%% -------- 预分配输出 --------
SemiCube    = single(zeros(720,360,N));   % 半年（SSA）
AnnualCube  = single(zeros(720,360,N));   % 年（SSA）
TrendCube   = single(zeros(720,360,N));   % 长期（CEEMDAN 最后IMF）

VarShare3   = single(zeros(720,360,3));   % 三个分量方差占比：Semi/Annual/Trend

count_valid = 0;

%% ================== 主循环 ==================
for i = 1:720
  for j = 1:360

    if ~isnan(All(i,j,1)) && any(IGBP(i,j) == valid_classes)

      temp = reshape(All(i,j,:), [N,1]);        % 原序列 (N×1)
      if ~any(isfinite(temp)) || std(temp(~isnan(temp))) < 1e-12, continue; end
      if any(isnan(temp)), temp = fillmissing(temp,'linear'); end

      count_valid = count_valid + 1;

      %% ===== CEEMDAN（按程序2的写法）：长期 = 最后IMF =====
      % 可选：像元级固定 RNG，确保跨脚本复现（默认关闭）
      % seed = uint32(73856093*uint32(i) + 19349663*uint32(j)); rng(double(seed), 'twister');

      imf = ceemdan(temp, 0.2, 20, 50, 1)';     % ← 与程序2一致的调用与转置
      last_imf = imf(:, end);                   % 长期 = 最后IMF

      %% ===== SSA：提取半年/年分量（保持程序1逻辑不变） =====
      [~,~,~,RC,~] = ssa_decompose(temp, L);
      peakP = estimate_rc_periods(RC);          % 每个RC主导周期（月）

      semi_mask = (peakP >= semi_band(1)   & peakP <= semi_band(2));
      ann_mask  = (peakP >= annual_band(1) & peakP <= annual_band(2));

      Semi   = ssa_reconstruct_groups(RC, find(semi_mask));   % 半年 (N×1)
      Annual = ssa_reconstruct_groups(RC, find(ann_mask));    % 年   (N×1)

      %% ===== 保存三个分量 =====
      SemiCube(i,j,:)   = single(Semi);
      AnnualCube(i,j,:) = single(Annual);
      TrendCube(i,j,:)  = single(last_imf);

      %% ===== 三个分量的方差贡献（raw，不强求和=1） =====
      tv = var(temp, 1); if tv <= 0, tv = eps; end
      VarShare3(i,j,1) = single(var(Semi,   1) / tv);  % 半年
      VarShare3(i,j,2) = single(var(Annual, 1) / tv);  % 年
      VarShare3(i,j,3) = single(var(last_imf,1) / tv); % 长期

    end
  end
  fprintf('Row %d/720 processed. Valid pixels so far = %d\n', i, count_valid);
end

%% -------- 保存结果 --------
fid=fopen('D:\CSIF05_SSA_Semiannual_3comp.raw','wb');  fwrite(fid,SemiCube,'single');   fclose(fid);
fid=fopen('D:\CSIF05_SSA_Annual_3comp.raw','wb');      fwrite(fid,AnnualCube,'single'); fclose(fid);
fid=fopen('D:\CSIF05_CEEMDAN_Trend_3comp.raw','wb');   fwrite(fid,TrendCube,'single');  fclose(fid);

fid=fopen('D:\CSIF05_VarShare3.raw','wb');             fwrite(fid,VarShare3,'single');  fclose(fid);

fprintf('Done. Valid pixels processed: %d\n', count_valid);

%% ================== 本地函数（SSA） ==================
function [U,S,V,RC,lambda] = ssa_decompose(y,L)
% SSA decomposition
y = y(:); N = length(y);
if L < 2 || L > N-1, error('L must be in [2, N-1].'); end
K = N - L + 1;

% 轨迹矩阵
X = zeros(L,K);
for ii = 1:K, X(:,ii) = y(ii:ii+L-1); end

% SVD
[U,S,V] = svd(X,'econ'); lambda = diag(S).^2;

% 对角平均重构 RC
Krc = min(L,K); RC = zeros(N,Krc);
for r = 1:Krc
  Xr = U(:,r)*S(r,r)*V(:,r)'; 
  RC(:,r) = hankel_averaging(Xr);
end
end

function z = hankel_averaging(Xr)
[L,K] = size(Xr); N = L + K - 1;
z = zeros(N,1); w = zeros(N,1);
for ii = 1:L
  for jj = 1:K
    z(ii+jj-1) = z(ii+jj-1) + Xr(ii,jj);
    w(ii+jj-1) = w(ii+jj-1) + 1;
  end
end
z = z ./ max(w,1);
end

function peakPeriod = estimate_rc_periods(RC)
% 估计每个 RC 的主导周期（样本步=月）
[N,K] = size(RC); peakPeriod = zeros(1,K);
for k = 1:K
  x = RC(:,k) - mean(RC(:,k));
  if ~any(isfinite(x)) || std(x) < 1e-10
    peakPeriod(k) = Inf; continue;
  end
  X = fft(x); P2 = abs(X/N).^2; P1 = P2(1:floor(N/2));
  if ~isempty(P1), P1(1)=0; end
  if isempty(P1)
    peakPeriod(k) = Inf;
  else
    [val,idx] = max(P1);
    if val <= 1e-12 || idx <= 1
      peakPeriod(k) = Inf;
    else
      f = (idx-1)/N; 
      if f <= 0, peakPeriod(k) = Inf; else, peakPeriod(k) = 1/f; end
    end
  end
end
end

function Y = ssa_reconstruct_groups(RC, idx)
% 将选定的 RC 索引集合重构为一个分量
[N,~] = size(RC);
if isempty(idx), Y = zeros(N,1);
else, Y = sum(RC(:,idx),2,'omitnan');
end
end
