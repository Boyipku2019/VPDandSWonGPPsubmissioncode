%% ================== run_fluxnet_rf.m ==================
% 仅处理 文件名包含 "FULLSET" 的 HH/DD/MM；每个CSV=一个模型
% Y: GPP_DT_VUT_REF
% X: TA_F_MDS, P_F, SW_IN_F_MDS, SWC_avg（由所有存在且有效的 SWC_F_MDS_# 层平均而得）
% 过滤：Y>0；TA/P/SWIN 非 NaN；SWC_avg 至少由一层有效值参与平均
% 建模：样本数>40；TreeBagger回归；验证集置换重要性
% 统计：仅纳入 R2_val > 0.30 的模型做均值±标准差、作图和Excel导出
% 新增：主导因子统计 + 环状图；经纬度不再从 CSV 读取，改为从 FLUXsitelistnew.xlsx
%       —— 第5列为纬度Lat，第6列为经度Lon（第1行是列标题）

clear; clc; close all;
warning('off','all');
set(0,'DefaultAxesFontName','Arial'); set(0,'DefaultTextFontName','Arial');

%% ---- 路径配置 ----
rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir    = fullfile(rootFolder, 'dataafteruncompression');
siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');   % 1列=站名；5列=Lat；6列=Lon；8列=植被类型
assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);

%% ---- 站点→植被/经纬度 映射（按列序号：5=Lat, 6=Lon）----
site2veg = containers.Map('KeyType','char','ValueType','char');
site2lat = containers.Map('KeyType','char','ValueType','double');
site2lon = containers.Map('KeyType','char','ValueType','double');
hasVegMap = false;

if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);   % 第1行作为表头
        names = string(Tsite{:,1});    % 站名
        latv  = Tsite{:,5};            % 第5列：纬度
        lonv  = Tsite{:,6};            % 第6列：经度
        vegs  = string(Tsite{:,8});    % 第8列：植被类型

        % 统一转数值（若读成文本）
        if ~isnumeric(latv), latv = double(str2double(string(latv))); end
        if ~isnumeric(lonv), lonv = double(str2double(string(lonv))); end

        for i=1:numel(names)
            k = strtrim(names(i));
            if ~isempty(k)
                site2veg(char(k)) = char(upper(strtrim(vegs(i))));
                if isfinite(latv(i)), site2lat(char(k)) = latv(i); end
                if isfinite(lonv(i)), site2lon(char(k)) = lonv(i); end
            end
        end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取/解析 FLUXsitelistnew.xlsx，经纬度与植被类型将为空。\n');
    end
end

%% ---- 必需列（除 SWC 外固定）----
yName   = 'GPP_DT_VUT_REF';
coreX   = {'TA_F_MDS','P_F','SW_IN_F_MDS'};   % 固定三项

%% ---- 仅收集 文件名含 FULLSET 且为 HH/DD/MM ----
allCSV = dir(fullfile(dataDir,'*.csv'));
files = [];
for i = 1:numel(allCSV)
    nm = allCSV(i).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        files = [files; allCSV(i)]; %#ok<AGROW>
    end
end
if isempty(files), error('未找到 文件名包含 FULLSET 的 HH/DD/MM 文件。'); end
if ~isfolder('models'), mkdir models; end
fprintf('发现可用文件 %d 个（文件名包含 FULLSET，且仅 HH/DD/MM）。\n', numel(files));

%% ---- 逐文件：读→筛→建模→重要性百分比 ----
res_header = {'file','site','vegtype','scale','n_obs','rmse_val','R2_val', ...
              'pct_TA','pct_P','pct_SWIN','pct_SWC','lon','lat'};   % 这里 lon/lat 将来自 XLS
rows = {};

for k = 1:numel(files)
    f = fullfile(files(k).folder, files(k).name);
    if ~contains(files(k).name,'FULLSET','IgnoreCase',true), continue; end

    fprintf('\n[%s] %d/%d 处理：%s\n', datestr(now,'HH:MM:SS'), k, numel(files), files(k).name);

    try
        % --- 探测可用列
        opts = detectImportOptions(f);
        varNames = opts.VariableNames;

        % 固定的必需列是否存在
        needFixed  = [ {yName}, coreX ];
        availFixed = intersect(needFixed, varNames, 'stable');
        if ~all(ismember(needFixed, availFixed))
            fprintf('  ↳ 缺少必需列（TA/P/SW_IN/GPP），跳过。\n');
            continue;
        end

        % === 自动收集土壤水各层：SWC_F_MDS_# ===
        swcMask = ~cellfun('isempty', regexp(varNames, '^SWC_F_MDS_\d+$', 'once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols)
            fprintf('  ↳ 未找到任何 SWC_F_MDS_# 层，跳过。\n');
            continue;
        end

        % 只读取固定列 + SWC 层（不再尝试从 CSV 读取 lon/lat）
        opts.SelectedVariableNames = [availFixed, swcCols];
        T = readtable(f, opts);

        % --- 将 -9999/极端异常值 统一转 NaN
        T = sentinel2nan(T, opts.SelectedVariableNames);

        % --- 计算土壤水按层平均（忽略 NaN）
        SWCmat = T{:, swcCols};                 % N x L
        if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SWC_avg = mean(SWCmat, 2, 'omitnan');

        % --- 行筛选
        yv = T.(yName);
        ta = T.TA_F_MDS;  pp = T.P_F;  sw = T.SW_IN_F_MDS;
        mask = ~isnan(yv) & (yv>0) & ~isnan(ta) & ~isnan(pp) & ~isnan(sw) & ~isnan(SWC_avg);
        Tm = T(mask,:);  SWC_avg = SWC_avg(mask);
        nobs = height(Tm);
        if nobs <= 40
            fprintf('  ↳ 有效样本太少(%d ≤ 40)，跳过。\n', nobs);
            continue;
        end

        % --- X / Y
        X = [Tm.TA_F_MDS, Tm.P_F, Tm.SW_IN_F_MDS, SWC_avg];
        Y = Tm.(yName);

        % ===== 训练/验证划分（80/20，可复现）=====
        rng(2025 + k);
        cv   = cvpartition(size(X,1), 'Holdout', 0.2);
        Xtr  = X(training(cv),:);   Ytr = Y(training(cv));
        Xte  = X(test(cv),   :);   Yte = Y(test(cv),   :);

        % ===== 标准化（流程一致性）=====
        [Xtr_n, ps] = mapminmax(Xtr');   Xtr_n = Xtr_n';
        Xte_n       = mapminmax('apply', Xte', ps)';

        % ===== 随机森林 =====
        Mdl = TreeBagger(300, Xtr_n, Ytr, 'Method','regression', ...
                         'OOBPrediction','On','MinLeafSize',5,'NumPredictorsToSample',2);

        % ===== 验证集评估 =====
        y_pred  = predict(Mdl, Xte_n);
        SST     = sum((Yte - mean(Yte)).^2);
        SSE     = sum((Yte - y_pred).^2);
        R2_val  = (SST>0) * (1 - SSE/max(SST,eps));
        rmse_val = sqrt(mean((Yte - y_pred).^2));

        % ===== 验证集置换重要性 → 百分比 =====
        p  = size(Xte_n, 2);
        mse0 = mean((Yte - y_pred).^2);
        variable_importance = zeros(1, p);
        for kk = 1:p
            Xperm = Xte_n;
            Xperm(:, kk) = Xperm(randperm(size(Xperm,1)), kk);
            y_perm = predict(Mdl, Xperm);
            variable_importance(kk) = mean((Yte - y_perm).^2) - mse0;
        end
        w = max(variable_importance, 0);
        s = sum(w);
        if s > 0, pct = 100 * w / s; else, pct = zeros(1,4); end

        % ===== 站点名 / 植被类型 / 时间尺度 / 经纬度（从 XLS 映射）=====
        sitename = parse_site_from_filename(files(k).name);
        vegtype  = '';
        if hasVegMap && isKey(site2veg, sitename), vegtype = site2veg(sitename); end
        scale = detect_scale_from_filename(files(k).name);

        % 经纬度来自 FLUXsitelistnew.xlsx 的第5、6列
        lonVal = NaN; latVal = NaN;
        if isKey(site2lon, sitename), lonVal = site2lon(sitename); end
        if isKey(site2lat, sitename), latVal = site2lat(sitename); end

        fprintf('  ↳ n=%d, Val RMSE=%.3f, R^2=%.3f | pct=[%.1f %.1f %.1f %.1f]\n', ...
                 nobs, rmse_val, R2_val, pct);

        % ===== 保存单站模型 =====
        save(fullfile('models',sprintf('%s_%s_rf.mat',sitename,scale)), ...
             'Mdl','rmse_val','R2_val','pct','sitename','vegtype','scale','nobs','lonVal','latVal');

        % ===== 汇总行 =====
        rows(end+1,:) = {files(k).name, sitename, vegtype, scale, nobs, ...
                         rmse_val, R2_val, pct(1), pct(2), pct(3), pct(4), lonVal, latVal}; %#ok<SAGROW>

    catch ME
        fprintf('  ↳ 失败已跳过。原因：%s\n', ME.message);
    end
end

if isempty(rows), error('没有可用的站点结果。'); end
Tsite_all = cell2table(rows,'VariableNames',res_header);
writetable(Tsite_all,'results_per_site.csv');
fprintf('\n已保存每站点结果（含全部模型，不限 R²）：results_per_site.csv\n');

%% ---- 仅使用 R2_val > 0.30 的有效模型做统计 ----
R2min = 0.30;
Tsite = Tsite_all(Tsite_all.R2_val > R2min, :);
if isempty(Tsite)
    error('没有满足 R2_val > %.2f 的有效模型；无法统计因子重要性。', R2min);
end
fprintf('用于统计的有效模型数：%d（R2_val > %.2f）。\n', height(Tsite), R2min);

%% ---- 汇总：植被类型 × (HH/DD/MM) 的均值±标准差（仅有效模型）----
vegWanted   = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'};
scales      = {'HH','DD','MM'};  
scaleLabels = {'Half-hourly','Daily','Monthly'};

TwithVeg = Tsite(Tsite.vegtype~="",:);
Tall     = Tsite;

stat = struct();
vegPlotList = [vegWanted, {'All biomes'}];
for vi = 1:numel(vegPlotList)
    vname = vegPlotList{vi};
    if strcmp(vname,'All biomes'), Td = Tall; else, Td = TwithVeg(strcmp(TwithVeg.vegtype, vname), :); end
    for si = 1:numel(scales)
        scl = scales{si};
        Ts = Td(strcmp(Td.scale, scl), :);
        if isempty(Ts), m = nan(1,4); s = nan(1,4); n = 0;
        else
            M = [Ts.pct_TA, Ts.pct_P, Ts.pct_SWIN, Ts.pct_SWC];
            m = mean(M,1,'omitnan'); s = std(M,0,1,'omitnan'); n = height(Ts);
        end
        stat(vi).mean(si,:) = m;   %#ok<SAGROW>
        stat(vi).std(si,:)  = s;
        stat(vi).n(si,1)    = n;
        stat(vi).name       = vname;
    end
end

%% ---- 柱状综合图（可选）----
hasData = arrayfun(@(s) any(s.n>0), stat);
stat_plot = stat(hasData);
if ~isempty(stat_plot)
    figure('Color','w','Position',[80 80 1400 760]);
    nV = numel(stat_plot); ncol = 4; nrow = ceil(nV/ncol);
    Ctemp = [0.976, 0.463, 0.431];
    Cprec = [0.235, 0.659, 0.773];
    Cradi = [0.980, 0.686, 0.353];
    Csoil = [0.631, 0.835, 0.439];
    colorsBars = {Ctemp, Cprec, Cradi, Csoil};

    for vi=1:nV
        subplot(nrow, ncol, vi); hold on;
        M = stat_plot(vi).mean;   S = stat_plot(vi).std;
        bh = bar(M, 'grouped');
        for j = 1:4, bh(j).FaceColor = colorsBars{j}; bh(j).EdgeColor = 'none'; end
        for j = 1:numel(bh)
            x = bh(j).XEndPoints; y = bh(j).YEndPoints;
            for r = 1:numel(x)
                if isnan(y(r)) || isnan(S(r,j)), continue; end
                errorbar(x(r), y(r), S(r,j), 'k', 'LineWidth', 1.0, 'CapSize', 8);
            end
        end
        set(gca,'XTick',1:3,'XTickLabel',scaleLabels,'FontSize',11);
        ylim([0 100]); yticks(0:20:100);
        title(sprintf('%s (n: %d/%d/%d)', stat_plot(vi).name, ...
              stat_plot(vi).n(1), stat_plot(vi).n(2), stat_plot(vi).n(3)), 'FontWeight','bold','FontSize',12);
        ylabel('Percentage','FontSize',11);
        box on; grid on;
    end
    legend({'Temperature','Precipitation','Radiation','Soil Moisture'}, ...
           'Orientation','horizontal', 'Location','southoutside','Box','off');
    sgtitle(sprintf('Factor contribution (mean ± SD) by vegetation type — HH / DD / MM (R^2>%.2f)', R2min),'FontSize',13);
    saveas(gcf,'importance_by_veg_HH_DD_MM_grouped_R2gt03.png');
    fprintf('图已保存：importance_by_veg_HH_DD_MM_grouped_R2gt03.png\n');
end

%% ---- 导出 Excel：三个 sheet（HH / DD / MM）----
xlsName = 'factor_contrib_by_scale_R2gt03.xlsx';
if exist(xlsName,'file'), delete(xlsName); end

rowNames = [vegWanted, {'All biomes'}];
for si = 1:numel(scales)
    scl = scales{si}; %#ok<*NASGU>
end
% 修正 MATLAB 索引写法
for si = 1:numel(scales)
    scl = scales{si};
    C = cell(numel(rowNames)+1, 4+2);
    C(1,2:end) = {'Temperature','Precipitation','Radiation','Soil_Moisture','n'};
    for r = 1:numel(rowNames)
        C{r+1,1} = rowNames{r};
        idx = find(strcmp({stat.name}, rowNames{r}), 1);
        if isempty(idx)
            vals = nan(1,4); sds = nan(1,4); n = 0;
        else
            vals = stat(idx).mean(si,:); sds = stat(idx).std(si,:); n = stat(idx).n(si,1);
        end
        for j = 1:4
            if isnan(vals(j)), C{r+1,j+1} = '';
            else, C{r+1,j+1} = sprintf('%.1f±%.1f', vals(j), sds(j));
            end
        end
        C{r+1, 4+2} = n;
    end
    Tcell = cell2table(C(2:end,2:end), 'VariableNames', matlab.lang.makeValidName(C(1,2:end)));
    Tcell = addvars(Tcell, string(C(2:end,1)), 'Before', 1, 'NewVariableNames', "Vegetation");
    writetable(Tcell, xlsName, 'Sheet', scl);
end
fprintf('Excel 已保存：%s （仅统计 R^2>%.2f 的模型；工作表：HH、DD、MM）\n', xlsName, R2min);

%% =============== 主导因子统计与环状图（与遥感一致） ===============
colors = [249,118,110; 60,168,197; 250,174,90; 161,213,112]/255;
labelFontSize = 48;

for si = 1:numel(scales)
    scl = scales{si};
    Ts = Tsite(strcmp(Tsite.scale, scl), :);   % 仅 R^2>0.30
    if isempty(Ts)
        fprintf('尺度 %s 无有效站点，跳过导出与作图。\n', scl);
        continue;
    end

    % 主导因子
    M = [Ts.pct_TA, Ts.pct_P, Ts.pct_SWIN, Ts.pct_SWC];
    [~, domIdx] = max(M, [], 2);   % 1..4

    % —— 输出表：Index / Site / Lon / Lat / DominantFactor
    N = height(Ts);
    idxCol  = (1:N).';
    siteCol = Ts.site;

    % 重新从映射拿经纬度，确保来源一致
    lonColV = nan(N,1); latColV = nan(N,1);
    for ii = 1:N
        key = siteCol{ii};
        if isKey(site2lon, key), lonColV(ii) = site2lon(key); end
        if isKey(site2lat, key), latColV(ii) = site2lat(key); end
    end

    Tout = table(idxCol, siteCol, lonColV, latColV, domIdx, ...
        'VariableNames', {'Index','Site','Longitude','Latitude','DominantFactor'});
    outName = sprintf('dominant_sites_%s.xlsx', scl);
    writetable(Tout, outName);
    fprintf('主导因子表已保存：%s（%s；R^2>%.2f；n=%d）\n', outName, scl, R2min, N);

    % 百分比分布
    counts = arrayfun(@(j) sum(domIdx==j), 1:4);
    pct    = 100 * counts / max(sum(counts),1);

    % 环形图
    switch scl
        case 'HH', figPos = [200 140 560 560];
        case 'DD', figPos = [220 160 560 560];
        otherwise, figPos = [240 180 560 560]; % 'MM'
    end
    figure('Color','w','Position',figPos);
    make_ring_chart_halfhole(pct, colors, labelFontSize);
    saveas(gcf, sprintf('dominant_percent_%s.png', scl));
    fprintf('主导因子环形图已保存：dominant_percent_%s.png\n', scl);
end

disp('✅ 完成：经纬度已改为从 FLUXsitelistnew.xlsx 第5/6列读取，并写入 dominant_sites_*.xlsx。');

%% ================== 辅助函数 ==================
function T = sentinel2nan(T, names)
    for i = 1:numel(names)
        vname = names{i};
        if ~ismember(vname, T.Properties.VariableNames), continue; end
        v = T.(vname);
        if ~isnumeric(v), v = double(str2double(string(v))); end
        v(v<=-9990 | v>=9.9e8) = NaN;
        T.(vname) = v;
    end
end

function site = parse_site_from_filename(fname)
    site = '';
    try
        s = string(fname);
        a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
        if ~isempty(a) && ~isempty(b) && b>a
            site = char(extractBetween(s,a+4,b-1));
        else
            tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
            if ~isempty(tok), site = tok{1}; else, site = fname; end
        end
    catch
        site = fname;
    end
end

function scale = detect_scale_from_filename(fname)
    if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
        scale = 'HH';
    elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
        scale = 'DD';
    elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
        scale = 'MM';
    else
        scale = 'OTHER';
    end
end

%% ---------------- 工具函数：环状图（中空半径=0.316） ----------------
function make_ring_chart_halfhole(pcts, cols, fs)
    K = numel(pcts);
    share = pcts(:)' / max(1, sum(pcts));
    r_outer = 0.70; r_inner = 0.316; nArc = 120;
    clf; ax = axes; hold(ax,'on'); axis(ax,'equal','off');
    theta0 = pi/2;  edges  = [0, cumsum(share)] * 2*pi;
    for k = 1:K
        a1 = theta0 - edges(k+1); a0 = theta0 - edges(k);
        th_outer = linspace(a0, a1, nArc); th_inner = linspace(a1, a0, nArc);
        x_outer = r_outer*cos(th_outer);  y_outer = r_outer*sin(th_outer);
        x_inner = r_inner*cos(th_inner);  y_inner = r_inner*sin(th_inner);
        patch([x_outer x_inner], [y_outer y_inner], cols(k,:), 'EdgeColor','w','LineWidth',1);
        if pcts(k) > 10
            th_mid = (a0 + a1)/2; r_mid = (r_outer + r_inner)/2;
            text(r_mid*cos(th_mid), r_mid*sin(th_mid), sprintf('%.1f%%', pcts(k)), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontName','Arial','FontWeight','bold','FontSize',fs,'Color','k');
        end
    end
end
