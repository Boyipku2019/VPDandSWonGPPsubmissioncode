%% ================== FLUXNET summary plots (R2021a compatible) ==================
% Fig.1: Bar chart = station counts by vegetation type (font ×1.5)
% Fig.2: Sector (fan-shaped) radar = record counts (log10 radius)
% Author: Boyi / ChatGPT helper
% ------------------------------------------------------------------------------

clear; clc; close all;
set(0,'DefaultAxesFontName','Arial');
set(0,'DefaultTextFontName','Arial');

%% -------------------- Data --------------------
types    = {'ENF','EBF','DBF','MF','GRA'};
% records  = [3530623, 562118, 1432848, 583445, 1754794, 56189];   % totals
% stations = [39,       13,     21,      8,      36,      2];      % counts
records  = [3530623, 562118, 1432848, 583445, 1754794];   % totals
stations = [39,       13,     21,      8,      36];      % counts
% Fixed color palette (paper reproducibility)
cmap = [...
    38,115,0;        % dark green
    115,178,115;     % medium green
    76,230,0;        % bright green
    163,255,115;     % light green
    211,255,190] / 255;     % pale green
   % 115,223,255] / 255; % blue-green

%% ================== Figure 1: Bar (stations, font ×1.5) ==================
fig1 = figure('Color','w','Position',[80 80 820 520]);
b = bar(stations,'FaceColor','flat','BarWidth',0.65);
for i = 1:numel(stations), b.CData(i,:) = cmap(i,:); end
set(gca,'XTick',1:numel(types),'XTickLabel',types,'FontSize',round(45));  % 28×1.5
%ylabel('Number of stations','FontSize',round(28*1.5));
box off; grid on; ax = gca; ax.GridAlpha = 0.2;

% value labels
yl = ylim;
for i = 1:numel(stations)
    text(i, stations(i) + 0.02*(yl(2)-yl(1)), sprintf('%d',stations(i)), ...
        'HorizontalAlignment','center','FontSize',round(40));
end

% Optional: save
% exportgraphics(fig1,'stations_bar.pdf','ContentType','vector');
% print(fig1,'stations_bar.png','-dpng','-r300');

%% ================== Figure 2: Sector radar (records, log10 radius) ==================
fig2 = figure('Color','w','Position',[80 80 760 760]); hold on; axis equal off;

% ---- Angle layout ----
N = numel(records);
thetaCenters = linspace(pi/2, pi/2 - 2*pi + 2*pi/N, N); % start at top, clockwise
thetaCenters = wrapTo2Pi(thetaCenters);
gapDeg  = 6;                             % visual gap between sectors (degrees)
halfW   = deg2rad((360/N - gapDeg)/2);   % half angular width of each sector

% ---- Log radii ----
rLog = log10(records);
rMin = floor(min(rLog));                 % e.g., 4
rMax = ceil(max(rLog));                  % e.g., 7
RmaxPlot = rMax + 0.6;                   % plot boundary

% ---- Guide rings (dashed) ----
th = linspace(0, 2*pi, 600);
for r = rMin:rMax
    [xc, yc] = pol2cart(th, r*ones(size(th)));
    plot(xc, yc, ':', 'Color', [0 0 0]+0.7, 'LineWidth', 1);
end
[xo, yo] = pol2cart(th, RmaxPlot*ones(size(th)));
plot(xo, yo, ':', 'Color', [0 0 0]+0.85, 'LineWidth', 1);

% ---- Draw sectors as filled patches ----
for i = 1:N
    th0 = thetaCenters(i) - halfW;
    th1 = thetaCenters(i) + halfW;
    thFill = linspace(th0, th1, 60);
    rFill  = rLog(i) * ones(size(thFill));
    thPoly = [th0, thFill, th1, th0];
    rPoly  = [0,   rFill,  0,   0 ];
    [x,y]  = pol2cart(thPoly, rPoly);
    patch('XData',x,'YData',y, ...
          'FaceColor',cmap(i,:), 'EdgeColor','none', 'FaceAlpha',1.0);
end

% ---- Category labels at outer rim ----
for i = 1:N
    [tx, ty] = pol2cart(thetaCenters(i), rMax + 0.4);
    text(tx, ty, types{i}, 'HorizontalAlignment','center', ...
        'VerticalAlignment','middle','FontSize',round(24*1.3));
end

%% ---- Improved staggered radial tick labels (Nature-style) ----
baseFont = round(32*1.5);   % 字体可以再放大
tickFont = round(baseFont * 0.7);

baseAngle = -20;            % 中心角度
angleStep = 15;              % 每个tick错开角度（关键参数）

for i = 1:(rMax - rMin + 1)
    r = rMin + (i-1);

    % ---- 角度错开 ----
    angle_i = baseAngle + (i-1 - (rMax-rMin)/2) * angleStep;
    th_i = deg2rad(angle_i);

    % ---- 半径微调（避免完全同心）----
    r_offset = r + 0.08 * (-1)^(i);   % 交错内外

    % ---- 计算位置 ----
    [tx, ty] = pol2cart(th_i, r_offset);

    % ---- 文字 ----
    text(tx, ty, sprintf('10^{%d}', r), ...
        'FontSize',tickFont, ...
        'Rotation', angle_i, ...
        'HorizontalAlignment','center', ...
        'Interpreter','tex');
end

% ---- Frame only ----
xlim([-RmaxPlot RmaxPlot]); ylim([-RmaxPlot RmaxPlot]);

% Optional: save
% exportgraphics(fig2,'records_sector_radar.pdf','ContentType','vector');
% print(fig2,'records_sector_radar.png','-dpng','-r300');
