%% ================== run_fluxnet_rf.m ==================
% 仅处理 文件名包含 "FULLSET" 的 HH/DD/MM；每个CSV=一个模型
% Y: GPP_DT_VUT_REF
% X: TA_F_MDS, P_F, SW_IN_F_MDS, SWC_avg（由所有存在且有效的 SWC_F_MDS_# 层平均而得）
% 过滤：Y>0；TA/P/SWIN 非 NaN；SWC_avg 至少由一层有效值参与平均
% 建模：样本数>40；TreeBagger回归；验证集置换重要性
% 统计：仅纳入 R2_val > 0.30 的模型做均值±标准差、作图和Excel导出
% 作图：在图中自动隐藏 “所有尺度 n=0” 的植被类型；其他保持不变

clear; clc;
warning('off','all');   % 静默警告（如需可注释）

%% ---- 路径配置 ----
rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir    = fullfile(rootFolder, 'dataafteruncompression');
siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');   % 第1列=站名；第8列(H列)=植被类型
assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);

%% ---- 站点→植被类型映射 ----
site2veg = containers.Map('KeyType','char','ValueType','char');
hasVegMap = false;
if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);
        names = string(Tsite{:,1});
        vegs  = string(Tsite{:,8});   % H列
        for i=1:numel(names)
            k = strtrim(names(i)); v = strtrim(vegs(i));
            if ~isempty(k); site2veg(char(k)) = char(v); end
        end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx，后续无法按植被类型聚合。\n');
    end
end

%% ---- 必需列（除 SWC 外固定）----
yName   = 'GPP_DT_VUT_REF';
coreX   = {'TA_F_MDS','P_F','SW_IN_F_MDS'};   % 固定三项（温度/降水/短波辐射）

%% ---- 仅收集 文件名含 FULLSET 且为 HH/DD/MM ----
allCSV = dir(fullfile(dataDir,'*.csv'));
files = [];
for i = 1:numel(allCSV)
    nm = allCSV(i).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        files = [files; allCSV(i)]; %#ok<AGROW>
    end
end
if isempty(files), error('未找到 文件名包含 FULLSET 的 HH/DD/MM 文件。'); end
if ~isfolder('models'), mkdir models; end
fprintf('发现可用文件 %d 个（文件名包含 FULLSET，且仅 HH/DD/MM）。\n', numel(files));

%% ---- 逐文件：读→筛→建模→重要性百分比 ----
res_header = {'file','site','vegtype','scale','n_obs','rmse_val','R2_val', ...
              'pct_TA','pct_P','pct_SWIN','pct_SWC'};    % 顺序=温度/降水/辐射/土壤水
rows = {};

for k = 1:numel(files)
    f = fullfile(files(k).folder, files(k).name);

    % 二次保险：若文件名不含 FULLSET，跳过
    if ~contains(files(k).name,'FULLSET','IgnoreCase',true), continue; end

    fprintf('\n[%s] %d/%d 处理：%s\n', datestr(now,'HH:MM:SS'), k, numel(files), files(k).name);

    try
        % --- 探测可用列
        opts = detectImportOptions(f);
        varNames = opts.VariableNames;

        % 固定的必需列是否存在
        needFixed = [ {yName}, coreX ];
        availFixed = intersect(needFixed, varNames, 'stable');
        if ~all(ismember(needFixed, availFixed))
            fprintf('  ↳ 缺少必需列（TA/P/SW_IN/GPP），跳过。\n');
            continue;
        end

        % === 自动收集土壤水各层：SWC_F_MDS_# ===
        swcMask  = ~cellfun('isempty', regexp(varNames, '^SWC_F_MDS_\d+$', 'once'));
        swcCols  = varNames(swcMask);
        if isempty(swcCols)
            fprintf('  ↳ 未找到任何 SWC_F_MDS_# 层，跳过。\n');
            continue;
        end

        % --- 选择要读的列：固定 + 所有 SWC 层
        opts.SelectedVariableNames = [availFixed, swcCols];
        T = readtable(f, opts);

        % --- 将 -9999/极端异常值 统一转 NaN（固定+所有 SWC）
        T = sentinel2nan(T, opts.SelectedVariableNames);

        % --- 计算土壤水按层平均（忽略 NaN）
        SWCmat = T{:, swcCols};                 % N x L
        if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SWC_avg = mean(SWCmat, 2, 'omitnan');  % 若全 NaN → 结果 NaN

        % --- 行筛选：Y>0；3个气象自变量非 NaN；SWC_avg 非 NaN（至少一层有效）
        yv  = T.(yName);
        ta  = T.TA_F_MDS;
        pp  = T.P_F;
        sw  = T.SW_IN_F_MDS;

        mask = ~isnan(yv) & (yv > 0) ...
             & ~isnan(ta) & ~isnan(pp) & ~isnan(sw) ...
             & ~isnan(SWC_avg);
        Tm = T(mask,:);
        SWC_avg = SWC_avg(mask);
        nobs = height(Tm);
        if nobs <= 40
            fprintf('  ↳ 有效样本太少(%d ≤ 40)，跳过。\n', nobs);
            continue;
        end

        % --- X / Y
        X = [Tm.TA_F_MDS, Tm.P_F, Tm.SW_IN_F_MDS, SWC_avg];
        Y = Tm.(yName);

        % ===== 训练/验证划分（80/20，可复现）=====
        rng(2025 + k);
        cv = cvpartition(size(X,1), 'Holdout', 0.2);
        trIdx = training(cv);  teIdx = test(cv);
        Xtr = X(trIdx,:);   Ytr = Y(trIdx,:);
        Xte = X(teIdx,:);   Yte = Y(teIdx,:);

        % ===== 标准化（RF对缩放不敏感；为流程一致保留）=====
        [Xtr_n, ps] = mapminmax(Xtr');   Xtr_n = Xtr_n';
        Xte_n = mapminmax('apply', Xte', ps)';

        % ===== TreeBagger 随机森林（R2021a 兼容）=====
        numTrees = 300;    % 森林规模
        mtry     = 2;      % 每次分裂抽样的自变量数（p=4 → sqrt(4)=2）
        leafMin  = 5;      % 叶节点最小样本

        Mdl = TreeBagger(numTrees, Xtr_n, Ytr, ...
            'Method','regression', ...
            'OOBPrediction','On', ...
            'MinLeafSize', leafMin, ...
            'NumPredictorsToSample', mtry);

        % ===== 验证集评估 =====
        y_pred = predict(Mdl, Xte_n);
        SST = sum((Yte - mean(Yte)).^2);
        SSE = sum((Yte - y_pred).^2);
        if SST > 0
            R2_val = 1 - SSE / SST;
        else
            R2_val = NaN;
        end
        rmse_val = sqrt(mean((Yte - y_pred).^2));

        % ===== 验证集置换重要性 =====
        p = size(Xte_n, 2);
        mse0 = mean((Yte - y_pred).^2);
        variable_importance = zeros(1, p);
        for kk = 1:p
            Xperm = Xte_n;
            Xperm(:, kk) = Xperm(randperm(size(Xperm,1)), kk);   % 仅打乱第 kk 列
            y_perm = predict(Mdl, Xperm);
            variable_importance(kk) = mean((Yte - y_perm).^2) - mse0;  % ΔMSE ↑ → 重要
        end
        % 负值截断+归一化为百分比（温度/降水/辐射/土壤水）
        w = max(variable_importance, 0);
        s = sum(w);
        if s > 0
            pct = 100 * w / s;    % [TA,P,SWIN,SWC]
        else
            pct = zeros(1,4);
        end

        % ===== 站点名 / 植被类型 / 时间尺度 =====
        sitename = parse_site_from_filename(files(k).name);
        veg = ''; if hasVegMap && isKey(site2veg, sitename), veg = site2veg(sitename); end
        scale = detect_scale_from_filename(files(k).name);

        fprintf('  ↳ n=%d, Val RMSE=%.3f, R^2=%.3f | pct=[%.1f %.1f %.1f %.1f]\n', ...
                 nobs, rmse_val, R2_val, pct);

        % ===== 保存单站模型 =====
        save(fullfile('models',sprintf('%s_%s_rf.mat',sitename,scale)), ...
             'Mdl','rmse_val','R2_val','pct','sitename','veg','scale','nobs');

        % ===== 汇总行（保留所有模型，后续统计再按 R2_val>0.3 过滤）=====
        rows(end+1,:) = {files(k).name, sitename, veg, scale, nobs, ...
                         rmse_val, R2_val, pct(1), pct(2), pct(3), pct(4)}; %#ok<SAGROW>

    catch ME
        fprintf('  ↳ 失败已跳过。原因：%s\n', ME.message);
    end
end

if isempty(rows), error('没有可用的站点结果。'); end
Tsite_all = cell2table(rows,'VariableNames',res_header);
writetable(Tsite_all,'results_per_site.csv');
fprintf('\n已保存每站点结果（含全部模型，不限 R²）：results_per_site.csv\n');

%% ---- 仅使用 R2_val > 0.30 的有效模型做统计 ----
R2min = 0.30;
Tsite = Tsite_all(Tsite_all.R2_val > R2min, :);
if isempty(Tsite)
    error('没有满足 R2_val > %.2f 的有效模型；无法统计因子重要性。', R2min);
end
fprintf('用于统计的有效模型数：%d（R2_val > %.2f）。\n', height(Tsite), R2min);

%% ---- 汇总：植被类型 × (HH/DD/MM) 的均值±标准差（仅有效模型）----
%vegWanted = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'};
vegWanted = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA'};
scales = {'HH','DD','MM'};  scaleLabels = {'Half-hourly','Daily','Monthly'};

TwithVeg = Tsite(Tsite.vegtype~="",:);
Tall     = Tsite;           % All biomes 用通过R²阈值的所有站点

stat = struct();   % stat(vi).mean(3,4), std(3,4), n(3,1)
vegPlotList = [vegWanted, {'All biomes'}];
for vi = 1:numel(vegPlotList)
    vname = vegPlotList{vi};
    if strcmp(vname,'All biomes')
        Td = Tall;
    else
        Td = TwithVeg(strcmp(TwithVeg.vegtype, vname), :);
    end
    for si = 1:numel(scales)
        scl = scales{si};
        Ts = Td(strcmp(Td.scale, scl), :);
        if isempty(Ts)
            m = nan(1,4); s = nan(1,4); n = 0;
        else
            M = [Ts.pct_TA, Ts.pct_P, Ts.pct_SWIN, Ts.pct_SWC];
            m = mean(M,1,'omitnan');
            s = std(M,0,1,'omitnan');
            n = height(Ts);
        end
        stat(vi).mean(si,:) = m;   %#ok<SAGROW>
        stat(vi).std(si,:)  = s;
        stat(vi).n(si,1)    = n;
        stat(vi).name       = vname;
    end
end

%% ---- 作图（仅显示“有数据”的植被类型）----
hasData = arrayfun(@(s) any(s.n>0), stat);    % 任一尺度有样本
stat_plot = stat(hasData);
if isempty(stat_plot)
    warning('所有植被类型在图表过滤后为空（n=0）。将不生成图。');
else
    figure('Color','w','Position',[80 80 1400 760]);
    nV = numel(stat_plot); ncol = 4; nrow = ceil(nV/ncol);
    Ctemp = [0.95 0.45 0.45];   % Temperature
    Cprec = [0.20 0.60 0.80];   % Precipitation
    Cradi = [0.98 0.70 0.30];   % Radiation
    Csoil = [0.60 0.85 0.50];   % Soil Moisture
    colors = {Ctemp, Cprec, Cradi, Csoil};

    for vi=1:nV
        subplot(nrow, ncol, vi); hold on;
        M = stat_plot(vi).mean;   % 3x4
        S = stat_plot(vi).std;    % 3x4

        bh = bar(M, 'grouped');
        for j = 1:4
            bh(j).FaceColor = colors{j};
            bh(j).EdgeColor = 'none';
        end

        % 误差线
        for j = 1:numel(bh)
            x = bh(j).XEndPoints;
            y = bh(j).YEndPoints;
            for r = 1:numel(x)
                if isnan(y(r)) || isnan(S(r,j)), continue; end
                errorbar(x(r), y(r), S(r,j), 'k', 'LineWidth', 1.0, 'CapSize', 8);
            end
        end

        set(gca,'XTick',1:3,'XTickLabel',scaleLabels);
        ylim([0 100]); yticks(0:20:100);
        title(sprintf('%s (n: %d/%d/%d)', stat_plot(vi).name, ...
              stat_plot(vi).n(1), stat_plot(vi).n(2), stat_plot(vi).n(3)), 'FontWeight','bold');
        ylabel('Percentage');
        box on; grid on;
    end

    legend({'Temperature','Precipitation','Radiation','Soil Moisture'}, ...
           'Orientation','horizontal', 'Location','southoutside','Box','off');
    sgtitle(sprintf('Factor contribution (mean ± SD) by vegetation type — HH / DD / MM (R^2>%.2f)', R2min));

    saveas(gcf,'importance_by_veg_HH_DD_MM_grouped_R2gt03.png');
    fprintf('图已保存：importance_by_veg_HH_DD_MM_grouped_R2gt03.png\n');
end

%% ---- 导出 Excel：三个 sheet（HH / DD / MM）----
xlsName = 'factor_contrib_by_scale_R2gt03.xlsx';
if exist(xlsName,'file'), delete(xlsName); end

rowNames = [vegWanted, {'All biomes'}];  % 导出仍保持原列表（你之前要求“其它都不要变”）
for si = 1:numel(scales)
    scl = scales{si};
    C = cell(numel(rowNames)+1, 4+2);
    C(1,2:end) = {'Temperature','Precipitation','Radiation','Soil_Moisture','n'};
    for r = 1:numel(rowNames)
        C{r+1,1} = rowNames{r};
        idx = find(strcmp({stat.name}, rowNames{r}), 1);
        if isempty(idx)
            vals = nan(1,4); sds = nan(1,4); n = 0;
        else
            vals = stat(idx).mean(si,:); sds = stat(idx).std(si,:); n = stat(idx).n(si,1);
        end
        for j = 1:4
            if isnan(vals(j))
                C{r+1,j+1} = '';
            else
                C{r+1,j+1} = sprintf('%.1f±%.1f', vals(j), sds(j));
            end
        end
        C{r+1, 4+2} = n;
    end
    Tcell = cell2table(C(2:end,2:end), 'VariableNames', matlab.lang.makeValidName(C(1,2:end)));
    Tcell = addvars(Tcell, string(C(2:end,1)), 'Before', 1, 'NewVariableNames', "Vegetation");
    writetable(Tcell, xlsName, 'Sheet', scl);
end
fprintf('Excel 已保存：%s （仅统计 R^2>%.2f 的模型；工作表：HH、DD、MM）\n', xlsName, R2min);

disp('全部完成。');

%% ================== 辅助函数 ==================
function T = sentinel2nan(T, names)
    % 将 -9999 / 极端异常值 统一转 NaN（便于统一筛选）
    for i = 1:numel(names)
        vname = names{i};
        if ~ismember(vname, T.Properties.VariableNames), continue; end
        v = T.(vname);
        if ~isnumeric(v), v = double(str2double(string(v))); end
        v(v<=-9990 | v>=9.9e8) = NaN;   % -9999 与超大异常值
        T.(vname) = v;
    end
end

function site = parse_site_from_filename(fname)
    site = '';
    try
        s = string(fname);
        a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
        if ~isempty(a) && ~isempty(b) && b>a
            site = char(extractBetween(s,a+4,b-1));
        else
            tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
            if ~isempty(tok), site = tok{1}; else, site = fname; end
        end
    catch
        site = fname;
    end
end

function scale = detect_scale_from_filename(fname)
    if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
        scale = 'HH';
    elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
        scale = 'DD';
    elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
        scale = 'MM';
    else
        scale = 'OTHER';
    end
end
