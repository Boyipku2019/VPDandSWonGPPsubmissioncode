% %% ================== run_fluxnet_rf.m ==================
% % 仅处理 文件名包含 "FULLSET" 的 HH/DD/MM；每个CSV=一个模型
% % Y: GPP_DT_VUT_REF
% % X: TA_F_MDS, P_F, SW_IN_F_MDS, SWC_avg（由所有存在且有效的 SWC_F_MDS_# 层平均而得）
% % 过滤：Y>0；TA/P/SWIN 非 NaN；SWC_avg 至少由一层有效值参与平均
% % 建模：样本数>40；TreeBagger回归；验证集 R²
% % 结果：保存 results_per_site.csv（包含每个文件的 R²）；并画出
% %       HH / DD / MM / All 四个直方图（R² 分布）
% 
% clear; clc;
% warning('off','all');   % 静默警告（如需可注释）
% 
% %% ---- 路径配置 ----
% rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
% dataDir    = fullfile(rootFolder, 'dataafteruncompression');
% siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');   % 第1列=站名；第8列(H列)=植被类型（本版不再使用）
% assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);
% 
% %% ---- 站点→植被类型映射（只为保存信息，绘图中不使用）----
% site2veg = containers.Map('KeyType','char','ValueType','char');
% hasVegMap = false;
% if exist(siteXlsx,'file')
%     try
%         Tsite = readtable(siteXlsx);
%         names = string(Tsite{:,1});
%         vegs  = string(Tsite{:,8});   % H列
%         for i=1:numel(names)
%             k = strtrim(names(i)); v = strtrim(vegs(i));
%             if ~isempty(k); site2veg(char(k)) = char(v); end
%         end
%         hasVegMap = true;
%     catch
%         fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx（仅影响 vegtype 信息）。\n');
%     end
% end
% 
% %% ---- 必需列（除 SWC 外固定）----
% yName   = 'GPP_DT_VUT_REF';
% coreX   = {'TA_F_MDS','P_F','SW_IN_F_MDS'};
% 
% %% ---- 仅收集 文件名含 FULLSET 且为 HH/DD/MM ----
% allCSV = dir(fullfile(dataDir,'*.csv'));
% files = [];
% for i = 1:numel(allCSV)
%     nm = allCSV(i).name;
%     if contains(nm,'FULLSET','IgnoreCase',true) && ...
%        ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
%          contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
%          contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
%         files = [files; allCSV(i)]; %#ok<AGROW>
%     end
% end
% if isempty(files), error('未找到 文件名包含 FULLSET 的 HH/DD/MM 文件。'); end
% fprintf('发现可用文件 %d 个（文件名包含 FULLSET，且仅 HH/DD/MM）。\n', numel(files));
% 
% %% ---- 逐文件：读→筛→建模→R² ----
% res_header = {'file','site','vegtype','scale','n_obs','rmse_val','R2_val'};
% rows = {};
% 
% for k = 1:numel(files)
%     f = fullfile(files(k).folder, files(k).name);
% 
%     % 二次保险：若文件名不含 FULLSET，跳过
%     if ~contains(files(k).name,'FULLSET','IgnoreCase',true), continue; end
% 
%     fprintf('\n[%s] %d/%d 处理：%s\n', datestr(now,'HH:MM:SS'), k, numel(files), files(k).name);
% 
%     try
%         % --- 探测可用列
%         opts = detectImportOptions(f);
%         varNames = opts.VariableNames;
% 
%         % 固定的必需列是否存在
%         needFixed = [ {yName}, coreX ];
%         availFixed = intersect(needFixed, varNames, 'stable');
%         if ~all(ismember(needFixed, availFixed))
%             fprintf('  ↳ 缺少必需列（TA/P/SW_IN/GPP），跳过。\n');
%             continue;
%         end
% 
%         % === 自动收集土壤水各层：SWC_F_MDS_# ===
%         swcMask  = ~cellfun('isempty', regexp(varNames, '^SWC_F_MDS_\d+$', 'once'));
%         swcCols  = varNames(swcMask);
%         if isempty(swcCols)
%             fprintf('  ↳ 未找到任何 SWC_F_MDS_# 层，跳过。\n');
%             continue;
%         end
% 
%         % --- 选择要读的列：固定 + 所有 SWC 层
%         opts.SelectedVariableNames = [availFixed, swcCols];
%         T = readtable(f, opts);
% 
%         % --- 将 -9999/极端异常值 统一转 NaN（固定+所有 SWC）
%         T = sentinel2nan(T, opts.SelectedVariableNames);
% 
%         % --- 计算土壤水按层平均（忽略 NaN）
%         SWCmat = T{:, swcCols};                 % N x L
%         if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
%         SWC_avg = mean(SWCmat, 2, 'omitnan');  % 若全 NaN → 结果 NaN
% 
%         % --- 行筛选：Y>0；3个气象自变量非 NaN；SWC_avg 非 NaN
%         yv  = T.(yName);
%         ta  = T.TA_F_MDS;
%         pp  = T.P_F;
%         sw  = T.SW_IN_F_MDS;
% 
%         mask = ~isnan(yv) & (yv > 0) ...
%              & ~isnan(ta) & ~isnan(pp) & ~isnan(sw) ...
%              & ~isnan(SWC_avg);
%         Tm = T(mask,:);
%         SWC_avg = SWC_avg(mask);
%         nobs = height(Tm);
%         if nobs <= 40
%             fprintf('  ↳ 有效样本太少(%d ≤ 40)，跳过。\n', nobs);
%             continue;
%         end
% 
%         % --- X / Y
%         X = [Tm.TA_F_MDS, Tm.P_F, Tm.SW_IN_F_MDS, SWC_avg];
%         Y = Tm.(yName);
% 
%         % ===== 训练/验证划分（80/20，可复现）=====
%         rng(2025 + k);
%         cv = cvpartition(size(X,1), 'Holdout', 0.2);
%         trIdx = training(cv);  teIdx = test(cv);
%         Xtr = X(trIdx,:);   Ytr = Y(trIdx,:);
%         Xte = X(teIdx,:);   Yte = Y(teIdx,:);
% 
%         % ===== 标准化 =====
%         [Xtr_n, ps] = mapminmax(Xtr');   Xtr_n = Xtr_n';
%         Xte_n = mapminmax('apply', Xte', ps)';
% 
%         % ===== TreeBagger 随机森林 =====
%         numTrees = 300;
%         mtry     = 2;
%         leafMin  = 5;
% 
%         Mdl = TreeBagger(numTrees, Xtr_n, Ytr, ...
%             'Method','regression', ...
%             'OOBPrediction','On', ...
%             'MinLeafSize', leafMin, ...
%             'NumPredictorsToSample', mtry);
% 
%         % ===== 验证集评估 =====
%         y_pred = predict(Mdl, Xte_n);
%         SST = sum((Yte - mean(Yte)).^2);
%         SSE = sum((Yte - y_pred).^2);
%         if SST > 0
%             R2_val = 1 - SSE / SST;
%         else
%             R2_val = NaN;
%         end
%         rmse_val = sqrt(mean((Yte - y_pred).^2));
% 
%         % ===== 站点名 / 植被类型 / 时间尺度 =====
%         sitename = parse_site_from_filename(files(k).name);
%         veg = '';
%         if hasVegMap && isKey(site2veg, sitename)
%             veg = site2veg(sitename);
%         end
%         scale = detect_scale_from_filename(files(k).name);
% 
%         fprintf('  ↳ n=%d, Val RMSE=%.3f, R^2=%.3f\n', nobs, rmse_val, R2_val);
% 
%         % ===== 汇总行 =====
%         rows(end+1,:) = {files(k).name, sitename, veg, scale, nobs, ...
%                          rmse_val, R2_val}; %#ok<SAGROW>
% 
%     catch ME
%         fprintf('  ↳ 失败已跳过。原因：%s\n', ME.message);
%     end
% end
% 
% if isempty(rows), error('没有可用的站点结果。'); end
% Tsite_all = cell2table(rows,'VariableNames',res_header);
% writetable(Tsite_all,'results_per_site.csv');
% fprintf('\n已保存每站点结果（全部模型）：results_per_site.csv\n');

%% ----------- 绘图（xticks 两位小数，yticks 取整） -----------

figure('Color','w','Position',[100 100 800 700]);
set(gcf,'DefaultAxesFontSize',16,'DefaultTextFontSize',16);

tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

%% ========== Half-hourly ==========
nexttile;
h = histogram(R2_HH);
h.NumBins = 50;
h.FaceColor = C_HH;
xlabel('R^2');
ylabel('Frequency');
title('Half-hourly');
xlim([0 1]);
xticks([0 0.5 1]);
xticklabels({'0','0.50','1'});
mx = ceil(max(h.Values));
yticks(round(linspace(0, mx, 4)));

%% ========== Daily ==========
nexttile;
h = histogram(R2_DD);
h.NumBins = 50;
h.FaceColor = C_DD;
xlabel('R^2');
ylabel('');
title('Daily');
xlim([0 1]);
xticks([0 0.5 1]);
xticklabels({'0','0.50','1'});
mx = ceil(max(h.Values));
yticks(round(linspace(0, mx, 4)));

%% ========== Monthly ==========
nexttile;
h = histogram(R2_MM);
h.NumBins = 200;
h.FaceColor = C_MM;
xlabel('R^2');
ylabel('Frequency');
title('Monthly');
xlim([0 1]);
xticks([0 0.5 1]);
xticklabels({'0','0.50','1'});
mx = ceil(max(h.Values));
yticks(round(linspace(0, mx, 4)));

%% ========== All time scales ==========
nexttile;
h = histogram(R2_all);
h.NumBins = 200;
h.FaceColor = C_ALL;
xlabel('R^2');
ylabel('');
title('All time scales');
xlim([0 1]);
xticks([0 0.5 1]);
xticklabels({'0','0.50','1'});
mx = ceil(max(h.Values));
yticks(round(linspace(0, mx, 4)));

saveas(gcf,'fluxnet_RF_R2_histograms.png');
fprintf('R^2 直方图已保存：fluxnet_RF_R2_histograms.png\n');

