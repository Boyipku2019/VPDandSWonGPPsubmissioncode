%% =============== run_fluxnet_RF_statistics_filtered_fixedLatLon.m ===============
% 仅统计（无建模/无作图），并按“站点×尺度 有效样本数 > 40”筛选
% 输出：控制台统计 + Excel: D:\Fluxnet_used_sites.xlsx
% 列：Name, Lat, Lon, VegetationType, TotalRecords
clear; clc; warning('off','all');

%% ---------- 参数 ----------
minNobs   = 40; % 最小有效样本数（每站点×尺度）
rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir    = fullfile(rootFolder, 'dataafteruncompression');
siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');
assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);
assert(exist(siteXlsx,'file')==2, '缺少 FLUXsitelistnew.xlsx');

%% ---------- 读取站点信息（固定列：1=Name, 5=Lat, 6=Lon, 8=Veg） ----------
TsiteInfo = readtable(siteXlsx);
if width(TsiteInfo) < 8
    error('FLUXsitelistnew.xlsx 列数不足，至少需要到第8列（植被类型）。');
end
nm  = string(TsiteInfo{:,1});     % 站点名称
latArr = TsiteInfo{:,5};          % 第5列：纬度
lonArr = TsiteInfo{:,6};          % 第6列：经度
vegCol = 8;                       % 第8列：植被类型（按你之前脚本）
veg = string(TsiteInfo{:,vegCol});

% 若经纬度为文本则转换为数值
if iscell(latArr), latArr = str2double(string(latArr)); end
if iscell(lonArr), lonArr = str2double(string(lonArr)); end

% 站点→植被类型映射
site2veg = containers.Map('KeyType','char','ValueType','char');
for i = 1:numel(nm)
    k = strtrim(nm(i)); v = strtrim(veg(i));
    if ~isempty(k), site2veg(char(k)) = upper(char(v)); end
end

%vegToShow = {'ENF','EBF','DBF','MF','GRA','WET'};
vegToShow = {'ENF','EBF','DBF','MF','GRA'};
scales    = {'HH','DD','MM'};

%% ---------- 搜索文件 ----------
allCSV = dir(fullfile(dataDir,'*.csv'));
files = [];
for i = 1:numel(allCSV)
    nmf = allCSV(i).name;
    if contains(nmf,'FULLSET','IgnoreCase',true) && ...
       (contains(nmf,'_HH_','IgnoreCase',true) || contains(nmf,'_DD_','IgnoreCase',true) || contains(nmf,'_MM_','IgnoreCase',true))
        files = [files; allCSV(i)];
    end
end
assert(~isempty(files),'未找到 FULLSET 的 HH/DD/MM 文件。');
fprintf('发现 FULLSET HH/DD/MM 文件：%d 个。\n', numel(files));

%% ---------- 统计容器 ----------
total_records = 0;                                        % 全部记录数（过滤后）
veg_counts    = containers.Map(vegToShow, num2cell(zeros(1,numel(vegToShow)))); % 各类记录数
veg_sites     = containers.Map(vegToShow, num2cell(zeros(1,numel(vegToShow)))); % 各类站点数（后面填）
used_sites = struct('Name', {}, 'Lat', {}, 'Lon', {}, 'VegetationType', {}, 'TotalRecords', {});

%% ---------- 主循环（含样本筛选） ----------
tic;
for k = 1:numel(files)
    f = fullfile(files(k).folder, files(k).name);
    [~, fname] = fileparts(f);
    sitename = parse_site_from_filename(fname);

    if ~isKey(site2veg, sitename), continue; end
    vegtype = upper(strtrim(site2veg(sitename)));
    if ~ismember(vegtype, vegToShow), continue; end

    scale = detect_scale_from_filename(fname);
    if ~ismember(scale, scales), continue; end

    % 读取并筛选有效样本
    try
        T = readtable(f);
    catch
        fprintf('  ↳ 无法读取文件：%s\n', fname);
        continue;
    end

    needCols = {'GPP_DT_VUT_REF','TA_F_MDS','P_F','SW_IN_F_MDS'};
    if ~all(ismember(needCols, T.Properties.VariableNames))
        % 必要列不全时跳过
        continue;
    end

    yv = T.GPP_DT_VUT_REF;
    ta = T.TA_F_MDS;
    pp = T.P_F;
    sw = T.SW_IN_F_MDS;

    % 查找 SWC_* 列，计算平均
    isSWC = ~cellfun('isempty', regexp(T.Properties.VariableNames,'^SWC_F_MDS_\d+$','once'));
    if any(isSWC)
        SWCmat  = T{:, isSWC};
        if iscell(SWCmat), SWCmat = str2double(string(SWCmat)); end
        SWC_avg = mean(SWCmat, 2, 'omitnan');
    else
        SWC_avg = nan(height(T),1);
    end

    mask = ~isnan(yv) & (yv>0) & ~isnan(ta) & ~isnan(pp) & ~isnan(sw) & ~isnan(SWC_avg);
    nobs = sum(mask);

    if nobs <= minNobs
        fprintf('  ↳ %s/%s 有效样本 %d ≤ %d，跳过。\n', sitename, scale, nobs, minNobs);
        continue;
    end

    % ---- 计入统计 ----
    total_records = total_records + nobs;
    veg_counts(vegtype) = veg_counts(vegtype) + nobs;

    % 站点信息：查索引（可能有多行同名，取第一个）
    idx = find(strcmpi(nm, sitename), 1);
    if isempty(idx)
        latVal = NaN; lonVal = NaN;
    else
        latVal = latArr(idx);
        lonVal = lonArr(idx);
    end

    % 汇总至 used_sites（同一站点多尺度累加）
    existing_idx = find(strcmp({used_sites.Name}, sitename), 1);
    if isempty(existing_idx)
        used_sites(end+1).Name = sitename; %#ok<SAGROW>
        used_sites(end).Lat = latVal;
        used_sites(end).Lon = lonVal;
        used_sites(end).VegetationType = vegtype;
        used_sites(end).TotalRecords   = nobs;
    else
        used_sites(existing_idx).TotalRecords = used_sites(existing_idx).TotalRecords + nobs;
    end
end
toc;

%% ---------- 汇总各植被类型站点数 ----------
if ~isempty(used_sites)
    uniqueVeg = {used_sites.VegetationType};
    for i = 1:numel(vegToShow)
        veg_sites(vegToShow{i}) = sum(strcmp(uniqueVeg, vegToShow{i}));
    end
end

%% ---------- 输出统计结果 ----------
fprintf('\n===== 统计结果 =====\n');
fprintf('总记录数（三个尺度合计）：%d\n', total_records);
fprintf('\n各植被类型记录数 与 站点数：\n');
for i = 1:numel(vegToShow)
    fprintf('  %-3s : %10d 条记录 | %3d 个站点\n', ...
        vegToShow{i}, veg_counts(vegToShow{i}), veg_sites(vegToShow{i}));
end
fprintf('\n共使用站点数：%d\n', numel(used_sites));

%% ---------- 保存使用站点信息到 Excel ----------
if ~isempty(used_sites)
    Name = {used_sites.Name}';
    Lat  = [used_sites.Lat]';
    Lon  = [used_sites.Lon]';
    VegetationType = {used_sites.VegetationType}';
    TotalRecords = [used_sites.TotalRecords]';
    Tsave = table(Name, Lat, Lon, VegetationType, TotalRecords);
    outFile = 'D:\Fluxnet_used_sites.xlsx';
    try
        writetable(Tsave, outFile);
        fprintf('\n已保存站点信息到：%s\n', outFile);
    catch ME
        fprintf('\n[写入失败] %s\n请检查 D: 盘写权限或文件是否被占用。\n', ME.message);
    end
else
    fprintf('\n未检测到符合条件的站点，未生成 Excel 文件。\n');
end

%% ====================== 辅助函数 ======================
function site=parse_site_from_filename(fname)
try
    s=string(fname); a=strfind(s,"FLX_"); b=strfind(s,"_FLUXNET");
    if ~isempty(a)&&~isempty(b)&&b>a
        site=char(extractBetween(s,a+4,b-1));
    else
        tok=regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), site=tok{1}; else, site=fname; end
    end
catch, site=fname; end
end

function scale=detect_scale_from_filename(fname)
if contains(fname,'_HH_','IgnoreCase',true)
    scale='HH';
elseif contains(fname,'_DD_','IgnoreCase',true)
    scale='DD';
elseif contains(fname,'_MM_','IgnoreCase',true)
    scale='MM';
else
    scale='OTHER';
end
end
