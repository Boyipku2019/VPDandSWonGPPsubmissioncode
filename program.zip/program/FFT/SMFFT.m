
clear all;close all;clc;
fllFileName="G:\Resource use efficiencies new\dataresult\CEEMDAN\SM05FirstIMF.raw";
fid = fopen(fllFileName,'r'); %打RAW文件
All = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
data=reshape(All,[720,360,468]);
% 
% 
% % 2. 初始化存储傅里叶变换结果的矩阵
% amplitudes = zeros(1440, 721, 210); % 420个月的数据，傅里叶变换结果对称，取前半部分
powersGPP1=[];
% 3. 对每个像元进行傅里叶变换
for i = 1:720
    for j = 1:360
        if data(i, j, :)~=0
        % 提取每个像元的时间序列
        pixel_series = squeeze(data(i, j, :));
        
        % 计算傅里叶变换
        y = fft(pixel_series);

        n = length(y);
        power = abs(y(1:floor(n/2))).^2; % power of first half of transform data
        powersGPP1=[powersGPP1,power];
        maxfreq = 1/2;                   % maximum frequency
        freq = (1:n/2)/(n/2)*maxfreq;    % equally spaced frequency grid
%         plot(freq,power)
%         xlabel('Cycles/Months')
%         ylabel('Power')
        period = 1./freq;
        
%         plot(period,power);
%         xlim([0 50]); %zoom in on max power
%         xlabel('Months/Cycle')
%         ylabel('Power')
        aa=0;
        end
    end
    i,"FFT1"
end


fllFileName="G:\Resource use efficiencies new\dataresult\CEEMDAN\SM05Innerannual.raw";
fid = fopen(fllFileName,'r'); %打RAW文件
All = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
data=reshape(All,[720,360,468]);
% 
% 
% % 2. 初始化存储傅里叶变换结果的矩阵
% amplitudes = zeros(1440, 721, 210); % 420个月的数据，傅里叶变换结果对称，取前半部分
powersGPP2=[];
% 3. 对每个像元进行傅里叶变换
for i = 1:720
    for j = 1:360
        if data(i, j, :)~=0
        % 提取每个像元的时间序列
        pixel_series = squeeze(data(i, j, :));
        
        % 计算傅里叶变换
        y = fft(pixel_series);

        n = length(y);
        power = abs(y(1:floor(n/2))).^2; % power of first half of transform data
        powersGPP2=[powersGPP2,power];
        maxfreq = 1/2;                   % maximum frequency
        freq = (1:n/2)/(n/2)*maxfreq;    % equally spaced frequency grid
%         plot(freq,power)
%         xlabel('Cycles/Months')
%         ylabel('Power')
        period = 1./freq;
        
%         plot(period,power);
%         xlim([0 50]); %zoom in on max power
%         xlabel('Months/Cycle')
%         ylabel('Power')
        aa=0;
        end
    end
    i,"FFT2"
end



fllFileName="G:\Resource use efficiencies new\dataresult\CEEMDAN\SM05Interannual.raw";
fid = fopen(fllFileName,'r'); %打RAW文件
All = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
data=reshape(All,[720,360,468]);
% 
% 
% % 2. 初始化存储傅里叶变换结果的矩阵
% amplitudes = zeros(1440, 721, 210); % 420个月的数据，傅里叶变换结果对称，取前半部分
powersGPP3=[];
% 3. 对每个像元进行傅里叶变换
for i = 1:720
    for j = 1:360
        if data(i, j, :)~=0
        % 提取每个像元的时间序列
        pixel_series = squeeze(data(i, j, :));
        
        % 计算傅里叶变换
        y = fft(pixel_series);

        n = length(y);
        power = abs(y(1:floor(n/2))).^2; % power of first half of transform data
        powersGPP3=[powersGPP3,power];
        maxfreq = 1/2;                   % maximum frequency
        freq = (1:n/2)/(n/2)*maxfreq;    % equally spaced frequency grid
%         plot(freq,power)
%         xlabel('Cycles/Months')
%         ylabel('Power')
        period = 1./freq;
        
%         plot(period,power);
%         xlim([0 50]); %zoom in on max power
%         xlabel('Months/Cycle')
%         ylabel('Power')
        aa=0;
        end
    end
    i,"FFT3"
end





fllFileName="G:\Resource use efficiencies new\dataresult\CEEMDAN\SM05LastIMF.raw";
fid = fopen(fllFileName,'r'); %打RAW文件
All = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
data=reshape(All,[720,360,468]);
% 
% 
% % 2. 初始化存储傅里叶变换结果的矩阵
% amplitudes = zeros(1440, 721, 210); % 420个月的数据，傅里叶变换结果对称，取前半部分
powersGPP4=[];
% 3. 对每个像元进行傅里叶变换
for i = 1:720
    for j = 1:360
        if data(i, j, :)~=0
        % 提取每个像元的时间序列
        pixel_series = squeeze(data(i, j, :));
        
        % 计算傅里叶变换
        y = fft(pixel_series);

        n = length(y);
        power = abs(y(1:floor(n/2))).^2; % power of first half of transform data
        powersGPP4=[powersGPP4,power];
        maxfreq = 1/2;                   % maximum frequency
        freq = (1:n/2)/(n/2)*maxfreq;    % equally spaced frequency grid
%         plot(freq,power)
%         xlabel('Cycles/Months')
%         ylabel('Power')
        period = 1./freq;
        
%         plot(period,power);
%         xlim([0 50]); %zoom in on max power
%         xlabel('Months/Cycle')
%         ylabel('Power')
        aa=0;
        end
    end
    i,"FFT4"
end





% 创建一个新图形窗口
fig = figure;

% 设置figure的大小和位置
% 格式：[left, bottom, width, height]
% 例如：[100, 100, 1200, 400] 表示从屏幕左下角(100, 100)位置开始，宽度为1200，高度为400
set(fig, 'Position', [100, 100, 1200, 200]);

subplot(1, 4, 1);
average_powers = mean(powersGPP1, 2);  % 按行计算平均值
stdpowers = std(powersGPP1, 0, 2);     % 计算标准差

% 使用误差线绘制平均值
errorbar(period, average_powers, stdpowers, 'k--', 'LineWidth', 0.8);  % 使用黑色虚线表示平均值，添加误差线
xlim([0 50]);  % 设置x轴范围
%xlabel('Months');  % 设置x轴标签
ylabel('Power');  % 设置y轴标签
title("First IMF")
% 获取当前轴
ax = gca;

% 获取y轴的次方标签并调整位置
exponentLabel = get(ax, 'YAxis').SecondaryLabel;
exponentLabel.Units = 'normalized';  % 使用归一化坐标进行位置调整
exponentLabel.Position(1) = exponentLabel.Position(1) - 0.12;  % 向左移动次方标签
exponentLabel.Position(2) = exponentLabel.Position(2) + 0.02;  % 向左移动次方标签
%title('Mean Power Spectrum with Standard Deviation');  % 设置图形标题

subplot(1, 4, 2);
average_powers = mean(powersGPP2, 2);  % 按行计算平均值
stdpowers = std(powersGPP2, 0, 2);     % 计算标准差

% 使用误差线绘制平均值
errorbar(period, average_powers, stdpowers, 'k--', 'LineWidth', 0.8);  % 使用黑色虚线表示平均值，添加误差线
xlim([0 50]);  % 设置x轴范围
%xlabel('Months');  % 设置x轴标签
%ylabel('Power');  % 设置y轴标签
title("Annual composite IMF")
% 获取当前轴
ax = gca;

% 获取y轴的次方标签并调整位置
exponentLabel = get(ax, 'YAxis').SecondaryLabel;
exponentLabel.Units = 'normalized';  % 使用归一化坐标进行位置调整
exponentLabel.Position(1) = exponentLabel.Position(1) - 0.12;  % 向左移动次方标签
exponentLabel.Position(2) = exponentLabel.Position(2) + 0.02;  % 向左移动次方标签
%title('Mean Power Spectrum with Standard Deviation');  % 设置图形标题

subplot(1, 4, 3);
average_powers = mean(powersGPP3, 2);  % 按行计算平均值
stdpowers = std(powersGPP3, 0, 2);     % 计算标准差

% 使用误差线绘制平均值
errorbar(period, average_powers, stdpowers, 'k--', 'LineWidth', 0.8);  % 使用黑色虚线表示平均值，添加误差线
xlim([0 50]);  % 设置x轴范围
%xlabel('Months');  % 设置x轴标签
%ylabel('Power');  % 设置y轴标签
title("Superannual composite IMF")
% 获取当前轴
ax = gca;

% 获取y轴的次方标签并调整位置
exponentLabel = get(ax, 'YAxis').SecondaryLabel;
exponentLabel.Units = 'normalized';  % 使用归一化坐标进行位置调整
exponentLabel.Position(1) = exponentLabel.Position(1) - 0.12;  % 向左移动次方标签
exponentLabel.Position(2) = exponentLabel.Position(2) + 0.02;  % 向左移动次方标签
%title('Mean Power Spectrum with Standard Deviation');  % 设置图形标题

subplot(1, 4, 4);
average_powers = mean(powersGPP4, 2);  % 按行计算平均值
stdpowers = std(powersGPP4, 0, 2);     % 计算标准差

% 使用误差线绘制平均值
errorbar(period, average_powers, stdpowers, 'k--', 'LineWidth', 0.8);  % 使用黑色虚线表示平均值，添加误差线
xlim([0 50]);  % 设置x轴范围
title("Last IMF");

% 获取当前轴
ax = gca;

% 获取y轴的次方标签并调整位置
exponentLabel = get(ax, 'YAxis').SecondaryLabel;
exponentLabel.Units = 'normalized';  % 使用归一化坐标进行位置调整
exponentLabel.Position(1) = exponentLabel.Position(1) - 0.12;  % 向左移动次方标签
exponentLabel.Position(2) = exponentLabel.Position(2) + 0.02;  % 向左移动次方标签


% %保存图片
% % 设置保存文件的名称
% filename = 'GPPFFT.jpg';
% 
% % 使用print函数保存为JPG格式，同时设置分辨率（例如300 dpi）
% print(filename, '-djpeg', '-r300');
