% ========================================================================
% Merge two monthly GPP RAW cubes by year
%
% File A (1984–2018): 720*360*420  (1984-01 ... 2018-12)
%   G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw
%
% File B (2019–2020): 720*360*24   (2019-01 ... 2020-12)
%   G:\Resource use efficiencies new\dataprocessed\2019202005   (NO suffix)
%
% Output (1984–2020): 720*360*444  (1984-01 ... 2020-12)
%   D:\GPP19842020_3D.raw
%
% IMPORTANT:
% - This script does a SAFE binary concatenation (no reshape/transpose),
%   so it preserves the exact data layout (BSQ order) in the original files.
% - It also checks file sizes against expected bytes (float32).
% ========================================================================

clear; clc;

% ---------------- paths ----------------
fileA = 'G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw';
fileB = 'G:\Resource use efficiencies new\dataprocessed\2019202005'; % no extension
outF  = 'D:\GPP19842020_3D.raw';

% ---------------- dimensions ----------------
nx = 720;   % samples (cols)
ny = 360;   % lines   (rows)
ntA = 420;  % 1984-01 .. 2018-12
ntB = 24;   % 2019-01 .. 2020-12
ntO = ntA + ntB;

bytesPerVal = 4; % float32
expectedA = nx * ny * ntA * bytesPerVal;
expectedB = nx * ny * ntB * bytesPerVal;
expectedO = nx * ny * ntO * bytesPerVal;

% ---------------- check existence ----------------
if ~isfile(fileA), error('Missing file A: %s', fileA); end
if ~isfile(fileB), error('Missing file B: %s', fileB); end

% ---------------- check sizes ----------------
infoA = dir(fileA);
infoB = dir(fileB);

fprintf('File A bytes: %d (expected %d)\n', infoA.bytes, expectedA);
fprintf('File B bytes: %d (expected %d)\n', infoB.bytes, expectedB);

if infoA.bytes ~= expectedA
    warning('File A size mismatch. Proceeding anyway (will copy actual bytes).');
end
if infoB.bytes ~= expectedB
    warning('File B size mismatch. Proceeding anyway (will copy actual bytes).');
end

% ---------------- open streams ----------------
fidA = fopen(fileA, 'r');
if fidA < 0, error('Cannot open file A.'); end

fidB = fopen(fileB, 'r');
if fidB < 0, fclose(fidA); error('Cannot open file B.'); end

fidO = fopen(outF, 'w');
if fidO < 0, fclose(fidA); fclose(fidB); error('Cannot open output file.'); end

fprintf('Writing merged output: %s\n', outF);
fprintf('Target dims: %d x %d x %d (float32)\n', nx, ny, ntO);

% ---------------- binary copy in chunks ----------------
chunkBytes = 64 * 1024 * 1024;  % 64 MB
buf = uint8([]);

% --- copy A ---
fprintf('Copying A (1984–2018)...\n');
remaining = infoA.bytes;
while remaining > 0
    nread = min(chunkBytes, remaining);
    buf = fread(fidA, nread, '*uint8');
    if numel(buf) ~= nread
        warning('Short read from A: expected %d, got %d. Stopping copy A.', nread, numel(buf));
        break;
    end
    nw = fwrite(fidO, buf, 'uint8');
    if nw ~= nread
        fclose(fidA); fclose(fidB); fclose(fidO);
        error('Write error while copying A: expected %d, wrote %d.', nread, nw);
    end
    remaining = remaining - nread;
end

% --- copy B ---
fprintf('Copying B (2019–2020)...\n');
remaining = infoB.bytes;
while remaining > 0
    nread = min(chunkBytes, remaining);
    buf = fread(fidB, nread, '*uint8');
    if numel(buf) ~= nread
        warning('Short read from B: expected %d, got %d. Stopping copy B.', nread, numel(buf));
        break;
    end
    nw = fwrite(fidO, buf, 'uint8');
    if nw ~= nread
        fclose(fidA); fclose(fidB); fclose(fidO);
        error('Write error while copying B: expected %d, wrote %d.', nread, nw);
    end
    remaining = remaining - nread;
end

fclose(fidA);
fclose(fidB);
fclose(fidO);

% ---------------- verify output size ----------------
infoO = dir(outF);
fprintf('Output bytes: %d (expected %d)\n', infoO.bytes, expectedO);
if infoO.bytes ~= expectedO
    warning('Output size mismatch vs expected 720*360*444 float32. Please confirm source file sizes/dtype.');
else
    fprintf('Done. Merged cube is 1984-01 .. 2020-12.\n');
end
