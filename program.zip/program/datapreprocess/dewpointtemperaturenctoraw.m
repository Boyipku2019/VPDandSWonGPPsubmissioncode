%% ERA5 d2m NC -> lon shift (0->180) -> imresize bicubic -> 720x360x468 -> float32 RAW
% MATLAB R2021a

clear; clc;

in_nc   = 'G:\GlobalData\ERA5\dewpointtemperature19822020monthly.nc';
varname = 'd2m';
out_raw = 'D:\ERA5_d2m_1982_2020_monthly_720x360x468_f32.raw';

% --- 获取变量信息 ---
info = ncinfo(in_nc, varname);
sz   = info.Size;   % e.g., [1440 721 468]

nx = sz(1);  % lon
ny = sz(2);  % lat
nt = sz(3);  % time

fprintf('Input size: %d x %d x %d\n', nx, ny, nt);

% --- 计算需要平移的列数：把 0E-180E 移到右边，使左边界为 180E ---
if mod(nx,2) ~= 0
    error('nx (lon dimension) must be even to shift by half globe. Current nx=%d', nx);
end
shift_lon = nx/2;   % 1440 -> 720
fprintf('Lon shift columns: %d (half globe)\n', shift_lon);

% --- 打开 RAW 文件 ---
fid = fopen(out_raw, 'w');
if fid < 0
    error('Cannot open output file.');
end

% --- 逐月处理，避免爆内存 ---
for t = 1:nt
    % 读取单个月: size = [nx ny]
    data = ncread(in_nc, varname, [1 1 t], [Inf Inf 1]);
    data = double(data);           % imresize 要 double/single

    % ========= 新增：经度重排，把左边界从 0° 改为 180° =========
    % 沿 lon 维度（第1维）做循环平移：将前半部分移到后半部分
    % 结果：lon 从 [0..360) 变为 [-180..180)
    data = circshift(data, [-shift_lon 0]);  % 向左平移 720 列

    % ERA5 常见维度：1440(lon) x 721(lat)
    % imresize 目标大小写成 [rows cols] = [360 720]
    data_rs = imresize(data.', [360 720], 'bicubic');  % 先转置为 [lat x lon] 再缩放

    % 转回 720 x 360 (lon x lat)
    data_out = single(data_rs.');

    % 写入
    fwrite(fid, data_out, 'single');

    if mod(t, 24) == 0 || t == 1 || t == nt
        fprintf('Written %d / %d months\n', t, nt);
    end
    t
end

fclose(fid);

fprintf('Finished.\nOutput file:\n%s\n', out_raw);

% --- 文件大小自检 ---
expected_bytes = 720 * 360 * nt * 4;
d = dir(out_raw);
fprintf('Expected: %.2f GB | Actual: %.2f GB\n', ...
    expected_bytes/1024^3, d.bytes/1024^3);
