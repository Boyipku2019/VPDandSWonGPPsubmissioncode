% ========================================================================
% 2019–2020 Global monthly GPP GeoTIFF (3600×7200, 2 pages) -> 3D RAW (float32)
% Use page 1 only (GPP); page 2 is QC (ignored)
% Unit conversion: (g C m^-2 mo^-1) -> (g C m^-2 d^-1) by dividing days in month
% NEW: values > 60000 set to 0 BEFORE conversion
%
% Input folder:
%   G:\Resource use efficiencies new\dataprocessed\20192020GPP\
% File name:
%   MaLab_MCD13C2_eLUE_GPP_YYYYMM_001.tif
%
% Output RAW (BSQ; month-by-month):
%   D:\GPP_2019_2020_gCm2d_3600x7200x24_f32.raw
% ========================================================================

clear; clc;

inDir  = 'G:\Resource use efficiencies new\dataprocessed\20192020GPP';
outRaw = 'D:\GPP_2019_2020_gCm2d_3600x7200x24_f32.raw';

nRows = 3600;
nCols = 7200;
nMon  = 24;

% ---- build month list: 2019-01 to 2020-12 ----
ymList = strings(nMon,1);
k = 0;
for yy = 2019:2020
    for mm = 1:12
        k = k + 1;
        ymList(k) = sprintf('%04d%02d', yy, mm);
    end
end

% ---- days in each month (leap year handled) ----
daysInMonth = zeros(nMon,1);
for i = 1:nMon
    yy = str2double(extractBetween(ymList(i), 1, 4));
    mm = str2double(extractBetween(ymList(i), 5, 6));
    daysInMonth(i) = eomday(yy, mm);
end

% ---- open output raw ----
fid = fopen(outRaw, 'w');
if fid < 0
    error('Cannot open output RAW: %s', outRaw);
end

fprintf('Output RAW: %s\n', outRaw);
fprintf('Size (rows x cols x months): %d x %d x %d\n', nRows, nCols, nMon);
fprintf('Writing float32, BSQ (band sequential: month 1..24)\n');

for i = 1:nMon
    ym = ymList(i);
    inTif = fullfile(inDir, sprintf('MaLab_MCD13C2_eLUE_GPP_%s_001.tif', ym));
    if ~isfile(inTif)
        fclose(fid);
        error('Missing file: %s', inTif);
    end

    fprintf('[%02d/%02d] Reading (page 1 only): %s\n', i, nMon, inTif);

    % ---- read only the 1st page/band (GPP) ----
    A = readgeoraster(inTif);   % could be 3600x7200 or 3600x7200x2
    if ndims(A) == 3
        A = A(:,:,1);
    end

    if ~isnumeric(A)
        fclose(fid);
        error('Non-numeric raster in: %s', inTif);
    end
    if ~isequal(size(A,1), nRows) || ~isequal(size(A,2), nCols)
        fclose(fid);
        error('Unexpected size in %s: got %d x %d, expected %d x %d', ...
              inTif, size(A,1), size(A,2), nRows, nCols);
    end

    % ---- convert to float32 ----
    A = single(A);

    % ---- NEW: set invalid high values to 0 BEFORE any conversion ----
    A(A > 60000) = 0;

    % ---- unit conversion: monthly total -> daily mean ----
    A = A ./ single(daysInMonth(i));   % g C m^-2 d^-1

    % ---- write as BSQ band i ----
    cnt = fwrite(fid, A', 'single');   % transpose to match row-major expectation
    if cnt ~= nRows*nCols
        fclose(fid);
        error('Write failed at %s: wrote %d, expected %d.', ym, cnt, nRows*nCols);
    end
end

fclose(fid);
fprintf('Done.\n');
