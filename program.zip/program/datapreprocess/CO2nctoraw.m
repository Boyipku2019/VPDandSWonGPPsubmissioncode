%% ================= 配置 =================
histFile = 'G:\GlobalData\CO2concentration\CO2_1deg_month_1850-2013.nc';  % 历史 1850-2013
histVar  = 'value';     % 历史变量名

sspFile  = 'G:\GlobalData\CO2concentration\CO2_SSP245_2015_2150.nc';      % SSP245 2015-2150
sspVar   = 'CO2';       % SSP 变量名

resizeMethod = 'bicubic';   % 'bicubic' | 'bilinear' | 'nearest'
outRaw  = 'D:\CO2_month_1982-2022_720x360.raw';   % 最终输出 (720x360x492)

%% ============== 读取历史：1982–2013（不翻转） ==============
% 历史文件维度应为 [360 180 1968]，覆盖 1850.01–2013.12
infoH = ncinfo(histFile, histVar);
szH   = infoH.Size;  % 期望 [360 180 1968]
if any(szH(1:2) ~= [360 180]) || szH(3) ~= 1968
    warning('历史文件维度为 [%d %d %d]，期望 [360 180 1968]。', szH(1), szH(2), szH(3));
end

% 仅保留 1982.01–2013.12（384 个月），完全丢弃 1981 及更早
idx_start = (1982-1850)*12 + 1;    % 1982-01 的 1-based 索引 = 1585
T_hist = 384;                      % 1982–2013 的月数
co2_8213 = ncread(histFile, histVar, [1 1 idx_start], [360 180 T_hist]);  % [360x180x384]
co2_8213 = single(co2_8213);       % 不做翻转（按你的要求）

%% ============== 用线性趋势 + 月气候态 填补 2014 ==============
t  = (0:T_hist-1)';          % 1982-01 -> 0
mo = mod(t,12) + 1;          % 1..12
t2014  = (T_hist:(T_hist+11))';
mo2014 = mod(t2014,12) + 1;

T_fill = T_hist + 12;                 % 384 + 12 = 396 (1982–2014)
co2_8214 = NaN(360,180,T_fill,'single');
co2_8214(:,:,1:T_hist) = co2_8213;
clear co2_8213

wb = waitbar(0,'Filling 2014 (linear trend + monthly climatology, 1982–2013)...');
for j = 1:180
    for i = 1:360
        y = double(squeeze(co2_8214(i,j,1:T_hist)));
        valid = ~isnan(y);
        if nnz(valid) < 2
            co2_8214(i,j,T_hist+1:T_fill) = NaN;
            continue
        end
        % 线性拟合
        p = polyfit(t(valid), y(valid), 1);             % y = a + b*t
        trend_all = polyval(p, [t; t2014]);             % 1982–2014 的趋势

        % 去趋势残差（历史段）
        resid = y - trend_all(1:T_hist);

        % 月气候态（去趋势残差按月多年平均）
        clim = NaN(12,1);
        for m = 1:12
            msk = valid & (mo==m);
            if any(msk)
                clim(m) = mean(resid(msk),'omitnan');
            else
                clim(m) = mean(resid(valid),'omitnan'); % 兜底
            end
        end

        % 2014 = 趋势外推 + 对应月份气候态
        y2014 = trend_all(T_hist+1:T_fill) + clim(mo2014);
        co2_8214(i,j,T_hist+1:T_fill) = single(y2014);
    end
    if mod(j,10)==0 || j==180
        waitbar(j/180, wb, sprintf('Lat %d/180', j));
    end
end
close(wb);

%% ============== 读取 SSP：2015–2022，并上下翻转（沿纬度维） ==============
infoS = ncinfo(sspFile, sspVar);
szS   = infoS.Size;   % 期望 [360 180 1632]
if any(szS(1:2) ~= [360 180]) || szS(3) < 96
    error('SSP 文件维度异常：[%d %d %d]，期望 [360 180 >=96]。', szS(1), szS(2), szS(3));
end

% 2015-01 至 2022-12（96 个月）
co2_1522 = ncread(sspFile, sspVar, [1 1 1], [360 180 96]);  % [360x180x96]
% 上下翻转（纬度维，第二维）
co2_1522 = flip(co2_1522, 2);
co2_1522 = single(co2_1522);

%% ============== 拼接：1982–2014 + 2015–2022 ==============
co2_8222_1deg = cat(3, co2_8214, co2_1522);   % [360 x 180 x (396+96)] = [360 x 180 x 492]
clear co2_8214 co2_1522

%% ============== 重采样到 720×360（逐月，NaN 友好） ==============
if exist('imresize','file') ~= 2
    error('未找到 imresize（Image Processing Toolbox）。请安装或改用其他重采样方案。');
end

ni2 = 720; nj2 = 360;
T_final = size(co2_8222_1deg, 3);
co2_8222_720x360 = NaN(ni2, nj2, T_final, 'single');

wb = waitbar(0, 'Resampling each month to 720 x 360 (NaN-aware)...');
for k = 1:T_final
    A = double(co2_8222_1deg(:,:,k));   % [360 x 180]
    mask = ~isnan(A);
    if ~any(mask,'all')
        co2_8222_720x360(:,:,k) = NaN;
    else
        % NaN 友好重采样：数据与掩膜分别重采样，再做加权归一
        A0 = A; A0(~mask) = 0;
        Mr = imresize(single(mask), [ni2 nj2], resizeMethod);
        Ar = imresize(A0,             [ni2 nj2], resizeMethod);

        epsW = 1e-6;
        out = Ar ./ max(Mr, epsW);
        out(Mr < epsW) = NaN;

        co2_8222_720x360(:,:,k) = single(out);
    end

    if mod(k,24)==0 || k==T_final
        waitbar(k/T_final, wb, sprintf('Month %d/%d', k, T_final));
    end
end
close(wb);
clear co2_8222_1deg

%% ============== 写出 RAW (float32, little-endian) ==============
fid = fopen(outRaw, 'w', 'ieee-le');
fwrite(fid, co2_8222_720x360, 'single');
fclose(fid);

fprintf('完成：1982–2022 月尺度 CO2 已重采样并保存。\n');
fprintf('文件：%s\n', outRaw);
fprintf('最终尺寸：[%d x %d x %d] = 720 x 360 x 492（月）\n', size(co2_8222_720x360,1), size(co2_8222_720x360,2), size(co2_8222_720x360,3));
fprintf('时间范围：1982-01 至 2022-12\n');
