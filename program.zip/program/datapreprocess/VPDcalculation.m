%% ================== ERA5 t2m + d2m -> VPD (kPa) | ENVI BSQ float32 ==================
% Inputs (ENVI header):
%   samples = 720, lines = 360, bands = 468
%   data type = 4  (float32)
%   interleave = bsq
%   byte order = 0 (little-endian)
%
% t2m file (K): t2m_1982_2020_resized_shifted.raw
% d2m file (K): ERA5_d2m_1982_2020_monthly_720x360x468_f32.raw
%
% Output:
%   D:\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw  (float32 BSQ, kPa)
%   D:\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.hdr  (ENVI header)

clear; clc;

inDir = 'G:\Resource use efficiencies new\dataprocessed';
fT  = fullfile(inDir,'t2m_1982_2020_resized_shifted.raw');                 
fTd = fullfile(inDir,'ERA5_d2m_1982_2020_monthly_720x360x468_f32.raw');   

outRaw = 'D:\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw';
outHdr = 'D:\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.hdr';

% ENVI dims
nx = 720; ny = 360; nb = 468;
nxy = nx * ny;

% ENVI io settings
machinefmt = 'ieee-le';          % byte order=0
precision  = 'float32=>single';  % data type=4

% ---- open ----
fidT  = fopen(fT ,'r', machinefmt);
if fidT < 0, error('Cannot open t2m file: %s', fT); end

fidTd = fopen(fTd,'r', machinefmt);
if fidTd < 0, fclose(fidT); error('Cannot open d2m file: %s', fTd); end

fidO  = fopen(outRaw,'w', machinefmt);
if fidO < 0, fclose(fidT); fclose(fidTd); error('Cannot create output: %s', outRaw); end

% ---- optional quick sanity check on first band ----
tmpN = min(200000, nxy);
Tchk  = fread(fidT,  tmpN, precision);
Tdchk = fread(fidTd, tmpN, precision);
fprintf('Sanity check (first band sample):\n');
fprintf('  t2m min=%.2f max=%.2f mean=%.2f (K)\n',  min(Tchk),  max(Tchk),  mean(Tchk,'omitnan'));
fprintf('  d2m min=%.2f max=%.2f mean=%.2f (K)\n', min(Tdchk), max(Tdchk), mean(Tdchk,'omitnan'));
% rewind
fseek(fidT,  0, 'bof');
fseek(fidTd, 0, 'bof');

% ---- screening thresholds (Kelvin reasonable range) ----
Kmin = 150; Kmax = 350;
FILL_BIG = 1e10; % catch absurd fill values if any

fprintf('Computing VPD (kPa) and writing:\n  %s\n', outRaw);
t0 = tic;

for ib = 1:nb
    % BSQ read: one band = one full image plane
    T_K  = fread(fidT , nxy, precision);
    Td_K = fread(fidTd, nxy, precision);

    if numel(T_K) < nxy || numel(Td_K) < nxy
        fclose(fidT); fclose(fidTd); fclose(fidO);
        error('Unexpected EOF at band(month) %d. Check files/dtype/interleave.', ib);
    end

    % ---- mask invalid values ----
    bad = isnan(T_K) | isnan(Td_K) | isinf(T_K) | isinf(Td_K) | ...
          abs(T_K)  > FILL_BIG | abs(Td_K) > FILL_BIG | ...
          (T_K < Kmin) | (T_K > Kmax) | (Td_K < Kmin) | (Td_K > Kmax);

    T_K(bad)  = NaN;
    Td_K(bad) = NaN;

    % physical consistency: dew point should not exceed air temperature
    idx = (Td_K > T_K);
    Td_K(idx) = T_K(idx);

    % ---- K -> C ----
    T  = T_K  - 273.15;
    Td = Td_K - 273.15;

    % ---- vapor pressure (kPa), Tetens/FAO ----
    es = 0.6108 .* exp( (17.27 .* T ) ./ (T  + 237.3) );
    ea = 0.6108 .* exp( (17.27 .* Td) ./ (Td + 237.3) );

    % ---- VPD (kPa) ----
    vpd = es - ea;
    vpd(vpd < 0) = 0; % numerical safety
    vpd(isnan(T) | isnan(Td)) = NaN;

    % write float32
    fwrite(fidO, vpd, 'float32');

    if mod(ib, 12) == 0
        fprintf('%3d/%3d months done (%.1f%%) | elapsed %.1fs\n', ib, nb, 100*ib/nb, toc(t0));
    end
end

fclose(fidT);
fclose(fidTd);
fclose(fidO);

fprintf('Done. Output RAW saved:\n  %s\n', outRaw);

% ---- write ENVI header for output ----
fidH = fopen(outHdr, 'w');
if fidH > 0
    fprintf(fidH, 'ENVI\n');
    fprintf(fidH, 'description = {VPD (kPa) computed from ERA5 t2m and d2m (2m temperature & dew point).}\n');
    fprintf(fidH, 'samples = %d\n', nx);
    fprintf(fidH, 'lines   = %d\n', ny);
    fprintf(fidH, 'bands   = %d\n', nb);
    fprintf(fidH, 'header offset = 0\n');
    fprintf(fidH, 'file type = ENVI Standard\n');
    fprintf(fidH, 'data type = 4\n');
    fprintf(fidH, 'interleave = bsq\n');
    fprintf(fidH, 'byte order = 0\n');
    fprintf(fidH, 'wavelength units = Unknown\n');
    fclose(fidH);
    fprintf('ENVI header saved:\n  %s\n', outHdr);
else
    warning('Could not write ENVI header: %s', outHdr);
end
