%% =============== run_fluxnet_rf_AllBiomes_PDP_minimal_R2all_normX_YleftMinMax.m ===============
% 仅保存图片；PDP 按植被×因子×尺度绘制
% 变更点：
% - 每个植被类型在每个尺度，凡 R²>0.30 的全部模型参与（不再限制前三）
% - 横坐标：按各尺度×因子自身的样本 5–95% 分位线性网格做标准化，映射至 [0,1]
% - 纵坐标：仅最左列显示，且仅显示该子图数据对应的 [最小值, 最大值] 两个刻度数值
% - 图幅：宽 1000，高 1150
% 其余：字体 24；无总标题；列标题 T/P/R/SW（含单位）；底部横向图例

clear; clc; warning('off','all');

%% ---------- 参数 ----------
R2min             = 0.30;     % 站点模型入选阈值
gridN             = 30;       % PDP 横轴网格点
pdp_max_val_rows  = 2000;     % 每站点用于 PDP 的验证样本上限
max_pool_per_site = 2000;     % 为构造分位轴而汇入的原始 X 值上限
rng(2025);
xLabelRotateDeg   = 30;       % XTick 标签倾斜角度

%% ---------- 路径 ----------
rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir    = fullfile(rootFolder, 'dataafteruncompression');
siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');
assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);
assert(exist(siteXlsx,'file')==2, '缺少 FLUXsitelistnew.xlsx');

%% ---------- 站点→植被类型 ----------
TsiteInfo = readtable(siteXlsx);
nm  = string(TsiteInfo{:,1});
veg = string(TsiteInfo{:,8});
site2veg = containers.Map('KeyType','char','ValueType','char');
for i = 1:numel(nm)
    k = strtrim(nm(i)); v = strtrim(veg(i));
    if ~isempty(k), site2veg(char(k)) = upper(char(v)); end
end

%% ---------- 名称 ----------
yName   = 'GPP_DT_VUT_REF';
coreX   = {'TA_F_MDS','P_F','SW_IN_F_MDS'};
xLabels = {'T (°C)','P (mm)','R (W m^{-2})','SW (%)'};

scales      = {'HH','DD','MM'};
linestyles  = {'-','--',':'};
vegOrder    = {'ENF','EBF','DBF','MF','GRA','WET','Average'};  % Average 最后绘制
vegToShow   = vegOrder(1:6);   % 输入文件中实际存在的 6 类

%% ---------- 搜索文件 ----------
allCSV = dir(fullfile(dataDir,'*.csv'));
files = [];
for i = 1:numel(allCSV)
    nmf = allCSV(i).name;
    if contains(nmf,'FULLSET','IgnoreCase',true) && ...
       (contains(nmf,'FULLSET_HH','IgnoreCase',true) || contains(nmf,'_HH_','IgnoreCase',true) || ...
        contains(nmf,'FULLSET_DD','IgnoreCase',true) || contains(nmf,'_DD_','IgnoreCase',true) || ...
        contains(nmf,'FULLSET_MM','IgnoreCase',true) || contains(nmf,'_MM_','IgnoreCase',true))
        files = [files; allCSV(i)];
    end
end
assert(~isempty(files),'未找到 FULLSET 的 HH/DD/MM 文件。');
fprintf('发现 FULLSET HH/DD/MM 文件：%d 个。\n', numel(files));

%% ---------- 容器 ----------
template = struct('Models',{{}}, 'Xpool',{cell(1,4)});
VegModels = struct();
for vi = 1:numel(vegToShow)
    tag = vegToShow{vi};
    for si = 1:numel(scales)
        VegModels.(tag).(scales{si}) = template;
    end
end
% Average 不在此处创建，稍后聚合

%% ---------- 主循环：读→筛→建模→暂存 ----------
tic;
for k = 1:numel(files)
    f = fullfile(files(k).folder, files(k).name);
    fprintf('\n[%s] %d/%d 处理：%s\n', datestr(now,'HH:MM:SS'), k, numel(files), files(k).name);
    try
        opts = detectImportOptions(f); varNames = opts.VariableNames;
        needFixed = [{yName}, coreX];
        if ~all(ismember(needFixed, varNames)), continue; end

        isSWC   = ~cellfun('isempty', regexp(varNames,'^SWC_F_MDS_\d+$','once'));
        swcCols = varNames(isSWC);
        if isempty(swcCols), continue; end

        opts.SelectedVariableNames = [needFixed, swcCols];
        T = readtable(f, opts);
        T = sentinel2nan(T, opts.SelectedVariableNames);

        SWCmat  = T{:, swcCols};
        SWC_avg = mean(SWCmat, 2, 'omitnan');

        yv=T.(yName); ta=T.TA_F_MDS; pp=T.P_F; sw=T.SW_IN_F_MDS;
        mask = ~isnan(yv) & (yv>0) & ~isnan(ta) & ~isnan(pp) & ~isnan(sw) & ~isnan(SWC_avg);
        Tm = T(mask,:); SWC_avg = SWC_avg(mask);
        nobs = height(Tm);
        if nobs <= 40, fprintf('  ↳ 有效样本太少(%d ≤ 40)，跳过。\n', nobs); continue; end

        sitename = parse_site_from_filename(files(k).name);
        vegtype = '';
        if isKey(site2veg,sitename), vegtype = site2veg(sitename); end
        vegtype = upper(strtrim(vegtype));
        if ~ismember(vegtype, vegToShow)
            fprintf('  ↳ %s 植被=%s，不在 6 类内。\n', sitename, vegtype); continue;
        end
        scale = detect_scale_from_filename(files(k).name);
        if ~ismember(scale, scales), continue; end

        X_raw = [Tm.TA_F_MDS, Tm.P_F, Tm.SW_IN_F_MDS, SWC_avg];
        Y     = Tm.(yName);

        % 训练/验证（80/20）
        cv   = cvpartition(size(X_raw,1),'Holdout',0.2);
        trId = training(cv); teId = test(cv);
        Xtr  = X_raw(trId,:); Ytr = Y(trId,:);
        Xte  = X_raw(teId,:); Yte = Y(teId,:);

        % 验证集抽样上限
        if size(Xte,1) > pdp_max_val_rows
            idxSub = randsample(size(Xte,1), pdp_max_val_rows);
            Xte = Xte(idxSub,:); 
            Yte = Yte(idxSub,:);
        end

        % 标准化（流程一致性）
        [Xtr_n, ps] = mapminmax(Xtr'); Xtr_n = Xtr_n';
        Xte_n       = mapminmax('apply', Xte', ps)';

        % RF
        Mdl = TreeBagger(300, Xtr_n, Ytr, 'Method','regression', ...
            'OOBPrediction','On','MinLeafSize',5,'NumPredictorsToSample',2);

        % 验证 R²
        yhat = predict(Mdl, Xte_n);
        SST  = sum((Yte - mean(Yte)).^2); 
        SSE  = sum((Yte - yhat).^2);
        if SST <= 0, continue; end
        R2_val = 1 - SSE / SST;

        if R2_val <= R2min
            fprintf('  ↳ %s/%s R²=%.3f≤%.2f，跳过入选。\n', vegtype, scale, R2_val, R2min);
            continue;
        end

        % 累加到对应植被/尺度
        VegModels = append_record(VegModels, vegtype, scale, Mdl, ps, X_raw, Xte, max_pool_per_site, R2_val);

        fprintf('  ↳ 入选 %s/%s：n=%d, R²=%.3f\n', vegtype, scale, size(Xte,1), R2_val);

    catch ME
        fprintf('  ↳ 错误：%s\n', ME.message);
    end
end
toc;

%% ---------- 构建 Average（按尺度聚合所有植被的模型/Xpool） ----------
fprintf('\n计算 Average (All biomes)...\n');
for si = 1:numel(scales)
    scl = scales{si};
    avgStruct = struct('Models', {{}} , 'Xpool', {cell(1,4)});
    for cj = 1:4
        allPools = [];
        allModels = {};
        for vi = 1:numel(vegToShow)
            tag = vegToShow{vi};
            if isfield(VegModels.(tag), scl)
                SM = VegModels.(tag).(scl);
                if ~isempty(SM.Xpool{cj})
                    allPools = [allPools; SM.Xpool{cj}];
                end
                if ~isempty(SM.Models)
                    allModels = [allModels, SM.Models]; %#ok<AGROW>
                end
            end
        end
        avgStruct.Xpool{cj} = allPools;
        avgStruct.Models    = allModels;
    end
    VegModels.Average.(scl) = avgStruct;
end
fprintf('完成 Average 聚合。\n');

%% ---------- 绘图（宽度=1000；底部横向图例；X=0..1；Y 仅左列显示 min/max） ----------
nRows = numel(vegOrder); nCols = 4;

figure('Color','w','Position',[40 40 1000 1150]);  % ★ 宽 1000, 高 1150
set(0,'DefaultAxesFontSize',24);
set(0,'DefaultTextFontSize',24);

tiled = tiledlayout(nRows,nCols,'TileSpacing','compact','Padding','compact');

% —— 捕获一个图例（三条线型代表 HH/DD/MM）——
hLegend = gobjects(1, numel(scales));
legendReady = false;

for ri = 1:nRows
    tag = vegOrder{ri};
    for cj = 1:nCols
        ax = nexttile; hold(ax,'on'); grid(ax,'on'); box(ax,'on');

        % 收集 y 以便设定 min/max 刻度
        allY = [];

        local_h = gobjects(1,numel(scales));

        for si = 1:numel(scales)
            scl  = scales{si};
            if ~isfield(VegModels.(tag),scl), continue; end
            Ms = VegModels.(tag).(scl).Models;
            if isempty(Ms), continue; end
            pool = VegModels.(tag).(scl).Xpool{cj};
            if isempty(pool), continue; end

            % —— x 轴网格（5–95%），并归一化至 [0,1] —— 
            p5 = prctile(pool,5); p95 = prctile(pool,95);
            if ~isfinite(p5) || ~isfinite(p95) || p95<=p5
                rawx = linspace(min(pool),max(pool),gridN);
            else
                rawx = linspace(p5,p95,gridN);
            end
            den = max(p95 - p5, eps);
            xg_norm = (rawx - p5) ./ den;                   % ∈[0,1]（可能轻微越界，后面限幅）
            xg_norm = max(0, min(1, xg_norm));              % 限幅

            % —— 所有满足 R²>R2min 的模型堆叠 —— 
            Ystack = nan(numel(Ms),gridN);
            kept   = 0;
            for m = 1:numel(Ms)
                if ~isfield(Ms{m},'R2') || isnan(Ms{m}.R2) || Ms{m}.R2 <= R2min, continue; end
                kept = kept + 1;
                Mdl = Ms{m}.Mdl; ps = Ms{m}.ps; Xte = Ms{m}.Xte_raw;
                yloc = nan(1,gridN);
                for g = 1:gridN
                    Xperm = Xte; 
                    % 反归一时用 rawx（模型输入仍是原始尺度）
                    Xperm(:,cj) = min(max(rawx(g), min(pool)), max(pool));
                    Xperm_n = mapminmax('apply', Xperm', ps)';
                    ypred   = predict(Mdl, Xperm_n);
                    yloc(g) = mean(ypred,'omitnan');
                end
                Ystack(kept,:) = yloc;
            end
            if kept==0, continue; end
            Ystack = Ystack(1:kept,:);

            ybar = mean(Ystack,1,'omitnan');
            ysd  = std(Ystack,0,1,'omitnan');

            % 画线 + 阴影（用归一化 x）
            hLine = plot(ax,xg_norm,ybar,'LineWidth',2,'LineStyle',linestyles{si});
            col = get(hLine,'Color');
            if numel(xg_norm)>=3
                xv=[xg_norm,fliplr(xg_norm)]; yv=[ybar+ysd,fliplr(ybar-ysd)];
                fill(ax,xv,yv,col,'FaceAlpha',0.15,'EdgeColor','none');
                uistack(hLine,'top');
            end

            local_h(si) = hLine;
            allY = [allY, ybar+ysd, ybar-ysd, ybar]; %#ok<AGROW>
        end

        % 列标题与 y 标签（仅左列显示 y 刻度）
        if ri==1, title(ax, xLabels{cj},'FontWeight','bold','Interpreter','tex'); end
        if cj==1, ylabel(ax,tag,'FontWeight','bold','Rotation',90); end

        % X 轴：统一归一化范围与端点刻度
        set(ax,'XLim',[0 1],'XTick',[0 1]);
        set(ax,'XTickLabel',{'0','1'});
        %set(ax,'XTickLabelRotation', xLabelRotateDeg);

        % Y 轴：仅最左列显示，且仅显示 [min, max] 两个刻度
        if ~isempty(allY) && isfinite(min(allY)) && isfinite(max(allY)) && (max(allY) > min(allY))
            ymin = min(allY); ymax = max(allY);
        else
            yl = ylim(ax); ymin = yl(1); ymax = yl(2);
            if ~(isfinite(ymin) && isfinite(ymax) && ymax>ymin)
                ymin = 0; ymax = 1;
            end
        end
        if cj==1
            set(ax,'YLim',[ymin ymax],'YTick',[ymin ymax]);
            set(ax,'YTickLabel', {num2str(ymin,'%.2f'), num2str(ymax,'%.2f')});
        else
            set(ax,'YLim',[ymin ymax],'YTick',[ymin ymax]);
            set(ax,'YTickLabel', []);  % 隐藏非左列的 Y 标签
        end

        % 抽取一次图例句柄
        if ~legendReady && all(isgraphics(local_h))
            hLegend = local_h;
            legendReady = true;
        end
    end
end

% ---- 最底部横向图例 ----
if legendReady
    lg = legend(hLegend, {'Half-hourly','Daily','Monthly'}, ...
        'Orientation','horizontal', 'NumColumns', numel(scales), 'Box','off');
    lg.Layout.Tile = 'south';
end

saveas(gcf,'PDP_AllBiomes_minimal_R2all_normX_YleftMinMax.png');
fprintf('完成：已保存 PDP_AllBiomes_minimal_R2all_normX_YleftMinMax.png（宽=1000，高=1150；X=0..1；Y仅左列min/max）。\n');

%% ---------- 辅助函数 ----------
function VM = append_record(VM, tag, scale, Mdl, ps, X_raw, Xte, max_pool_per_site, R2_val)
SM = VM.(tag).(scale);
rec.Mdl    = Mdl; 
rec.ps     = ps; 
rec.Xte_raw= Xte;
rec.R2     = R2_val;
SM.Models{end+1} = rec;
idxPool = randsample(size(X_raw,1), min(max_pool_per_site, size(X_raw,1)));
for j=1:4
    if isempty(SM.Xpool{j}), SM.Xpool{j}=X_raw(idxPool,j);
    else, SM.Xpool{j}=[SM.Xpool{j}; X_raw(idxPool,j)];
    end
end
VM.(tag).(scale) = SM;
end

function T=sentinel2nan(T,names)
for i=1:numel(names)
    vname=names{i}; if ~ismember(vname,T.Properties.VariableNames),continue;end
    v=T.(vname); if ~isnumeric(v),v=double(str2double(string(v)));end
    v(v<=-9990|v>=9.9e8)=NaN; T.(vname)=v;
end
end

function site=parse_site_from_filename(fname)
try
    s=string(fname); a=strfind(s,"FLX_"); b=strfind(s,"_FLUXNET");
    if ~isempty(a)&&~isempty(b)&&b>a, site=char(extractBetween(s,a+4,b-1));
    else
        tok=regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), site=tok{1}; else, site=fname; end
    end
catch, site=fname; end
end

function scale=detect_scale_from_filename(fname)
if contains(fname,'FULLSET_HH','IgnoreCase',true)||contains(fname,'_HH_','IgnoreCase',true)
    scale='HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true)||contains(fname,'_DD_','IgnoreCase',true)
    scale='DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true)||contains(fname,'_MM_','IgnoreCase',true)
    scale='MM';
else, scale='OTHER'; end
end
