clear all;close all;
clc;
%读取二氧化碳数据，就一个站点
% 文件路径



IGBP=imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 

%所有y和x都分成短期和长期，短期保存在1中，长期保存在2中
%%读取GPP数据
fllFileName="G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw";

fid = fopen(fllFileName,'r'); %打RAW文件
GPP1 = fread(fid,720*360*420,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GPP1=reshape(GPP1,[720,360,420]);

%%读取T数据
fllFileName="G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";

fid = fopen(fllFileName,'r'); %打RAW文件
T1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
T1=reshape(T1,[720,360,468]);
T1= T1(:,:,25:444);
%%读取P数据
fllFileName="G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";

fid = fopen(fllFileName,'r'); %打RAW文件
P1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
P1=reshape(P1,[720,360,468]);
P1= P1(:,:,25:444);
%%读取R数据
fllFileName="G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";

fid = fopen(fllFileName,'r'); %打RAW文件
R1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
R1=reshape(R1,[720,360,468]);
R1= R1(:,:,25:444);
%%读取SM数据
fllFileName="G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";

fid = fopen(fllFileName,'r'); %打RAW文件
SM1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SM1=reshape(SM1,[720,360,468]);
SM1= SM1(:,:,25:444);



%%读取CO2数据
fllFileName="G:\Resource use efficiencies new\dataprocessed\CO2_month_1982-2022_720x360.raw";

fid = fopen(fllFileName,'r'); %打RAW文件
CO21 = fread(fid,720*360*492,'single'); % 读RAW数据
fclose(fid); % 关闭文件
CO21=reshape(CO21,[720,360,492]);
CO21 = CO21(:,:,25:444);

% % 
% % 存储各种因子的贡献
% % ENFfactorimportancestd=[];
% % DNFfactorimportancestd=[];
% % DBFfactorimportancestd=[];
% % MFfactorimportancestd=[];
% % SHLfactorimportancestd=[];
% % SVAfactorimportancestd=[];
% % GRAfactorimportancestd=[];
% % WETfactorimportancestd=[];
% 
%存储模型拟合的各种参数
shorttermR2=single(zeros(720,360));



shorttermfactorimportanceworld=single(zeros(720,360,4));




shorttermfactorimportance=[];%存储每一个短期结果，无位置




% 



for i=1:720
   for j=1:360
        if ~isnan(GPP1(i,j,1))&&T1(i,j,1)~=0&&P1(i,j,1)~=0&&R1(i,j,1)~=0&&SM1(i,j,1)~=0&&((IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11))   %判断为有效像元，去除无效物候数据和0值环境变量数据
   %if ~isnan(GPP1(i,j,1))&&T1(i,j,1)~=0&&P1(i,j,1)~=0&&R1(i,j,1)~=0&&SM1(i,j,1)~=0&&SPEI1(i,j,1)~=0 &&((IGBP(i,j)==6||IGBP(i,j)==7))   %判断为有效像元，去除无效物候数据和0值环境变量数据
             
              onepixel=GPP1(i,j,:);
             onepixel=reshape(onepixel,420,1);
             y=onepixel;
             
                Tonepixel=T1(i,j,:);
             Tonepixel=reshape(Tonepixel,420,1);
            
             
                Ponepixel=P1(i,j,:);
             Ponepixel=reshape(Ponepixel,420,1);
             
             
                Ronepixel=R1(i,j,:);
             Ronepixel=reshape(Ronepixel,420,1);
            
             
                SMonepixel=SM1(i,j,:);
             SMonepixel=reshape(SMonepixel,420,1);
            
               
            
              CO2onepixel=CO21(i,j,:);
            CO2onepixel=reshape(CO2onepixel,420,1);
              
            
              
 % ===== 构造样本（不做筛选，固定 420×4 与 420×1）=====
x = [Tonepixel, Ponepixel, Ronepixel, SMonepixel];  % 420x4
y = onepixel;                                       % 420x1

% —— 随机 20% 验证集，80% 训练集（可复现）——
rng(i*1000 + j);                 % 或固定 rng(2025) 以像元间一致
cv = cvpartition(420, 'Holdout', 0.2);
trIdx = training(cv);
teIdx = test(cv);

Xtr = x(trIdx, :);  Ytr = y(trIdx, :);
Xte = x(teIdx, :);  Yte = y(teIdx, :);

% —— 标准化：仅用训练集拟合，再应用到验证集（避免泄漏）——
% mapminmax 视“列为变量”，故转置进/出
[Xtr_n, ps] = mapminmax(Xtr');     % (p x n_tr)
Xtr_n = Xtr_n';                    % (n_tr x p)
Xte_n  = mapminmax('apply', Xte', ps)';   % (n_te x p)

% ===== 随机森林（Bagging of Trees；与半年尺度一致）=====
% - Method='Bag' 为袋装法
% - NumVariablesToSample=2 (mtry=√p，p=4时≈2)
% - MinLeafSize/MaxNumSplits 控制单棵树复杂度
t = templateTree('MinLeafSize', 5, 'NumVariablesToSample', 2, 'MaxNumSplits', 20);

model = fitrensemble( ...
    Xtr_n, Ytr, ...
    'Method', 'Bag', ...
    'Learners', t, ...
    'NumLearningCycles', 200 ...
    );

% —— 在验证集上评估 R² —— 
y_pred = predict(model, Xte_n);
SST = sum((Yte - mean(Yte)).^2);
SSE = sum((Yte - y_pred).^2);
if SST > 0
    R_squared = 1 - SSE / SST;
else
    R_squared = NaN;   % 极少见：验证集全常数
end

% —— 变量重要性（与半年尺度一致）——
variable_importance = predictorImportance(model);  % 1 x 4
% （可选）归一化到比例，便于跨像元/跨尺度比较
s = sum(variable_importance);
if s > 0
    variable_importance = variable_importance / s;
else
    variable_importance(:) = NaN;
end

% —— 保留你的打印 —— 
fprintf('R-squared: %.4f\n', R_squared);
for ii = 1:length(variable_importance)
    fprintf('Variable %d importance: %.4f\n', ii, variable_importance(ii));
end

% ===== 写回你的容器（验证集 R² + 重要性）=====
aaa = variable_importance(:)';                       % 1 x 4
shorttermfactorimportance = [shorttermfactorimportance; aaa];
shorttermR2(i, j) = R_squared;

shorttermfactorimportanceworld(i, j, 1) = aaa(1);  % 温度
shorttermfactorimportanceworld(i, j, 2) = aaa(2);  % 降水
shorttermfactorimportanceworld(i, j, 3) = aaa(3);  % 辐射
shorttermfactorimportanceworld(i, j, 4) = aaa(4);  % 土壤水

          

                    
        end
        i,j,"allterms"
    end
   
 


end
%保存
fid=fopen('D:\GPPRFmonthlyfactorimportance.raw','wb');%存为raw
fwrite(fid,shorttermfactorimportanceworld,'single');
fclose(fid);
%保存
fid=fopen('D:\GPPRFmonthlyR2.raw','wb');%存为raw
fwrite(fid,shorttermR2,'single');
fclose(fid);

