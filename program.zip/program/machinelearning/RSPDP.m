%% =============== run_RS_3scales_AllBiomes_PDP_stream_fullsample_normX_small.m ===============
% 目标：遥感 9+1（Average）植被类型；四因子 PDP；三尺度同图对比
% 采样：每个植被类型、每个时间尺度随机 ≤10 像元（先试效果）
% 尺度：Semiannual / Annual / Long-term(Trend)
% 计算：在每个像元训练 RF 并验证 R²>阈值后，即时计算该像元的 PDP（x 轴按 5–95% 分位映射到 [0,1]）
%       以“累加器”方式汇总 {sumY, sumY2, n}，避免保存大数组与重复预测
% 绘图：用累加器得到的均值±标准差作图；x 轴 [0,1] 仅端点 0/1；y 轴仅最左列显示端点值
% 输出：1 张图（主图 + 底部横向图例）；整体尺寸缩小、子图稍微留间距

clear; clc; warning('off','all'); rng(2025);

%% ---------- 基本参数 ----------
R2min             = 0.30;   % 验证集 R² 阈值
gridN             = 30;     % PDP 网格点数
pdp_max_val_rows  = 2000;   % 每像元用于 PDP 的验证样本上限
MinLenPerPixel    = 200;    % 每像元最少有效样本
Nsamp             = 3000;     % ★ 每个植被类型每个时间尺度最多随机 10 像元（先试效果）
xg_norm           = linspace(0,1,gridN); % 统一的归一化横轴网格

scales     = {'Semiannual','ANNUAL','TREND'};
xLabels    = {'T (K)','P (m)','R (J m^{-2})','SW (%)'};
leg_labels = {'Semiannual','Annual','Long-term'};

% 三种时间尺度的颜色（实线）
scaleColors = [ ...
    0.12 0.47 0.71;   % Semiannual
    0.85 0.33 0.10;   % Annual
    0.47 0.67 0.19];  % Long-term

fprintf('开始：三尺度（Semiannual/Annual/Trend）PDP 随机 10 像元采样 + 流式累加。\n');

%% ---------- 路径 ----------
IGBP_path = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
assert(exist(IGBP_path,'file')==2, '缺少 IGBP 文件：%s', IGBP_path);

% ---------- Semiannual ----------
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_SSA_Semiannual_4comp.raw','r'); assert(fid>0); GPP_SA = fread(fid,720*360*420,'single'); fclose(fid); GPP_SA = reshape(GPP_SA,[720,360,420]);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_SSA_Semiannual_4comp.raw','r');  assert(fid>0); T_SA   = fread(fid,720*360*468,'single'); fclose(fid); T_SA   = reshape(T_SA,[720,360,468]); T_SA  = T_SA(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\P05_SSA_Semiannual_4comp.raw','r');  assert(fid>0); P_SA   = fread(fid,720*360*468,'single'); fclose(fid); P_SA   = reshape(P_SA,[720,360,468]); P_SA  = P_SA(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_SSA_Semiannual_4comp.raw','r');  assert(fid>0); R_SA   = fread(fid,720*360*468,'single'); fclose(fid); R_SA   = reshape(R_SA,[720,360,468]); R_SA  = R_SA(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_SSA_Semiannual_4comp.raw','r'); assert(fid>0); SW_SA  = fread(fid,720*360*468,'single'); fclose(fid); SW_SA  = reshape(SW_SA,[720,360,468]); SW_SA = SW_SA(:,:,25:444);

% ---------- Annual ----------
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_SSA_Annual_4comp.raw','r');    assert(fid>0); GPP_AN = fread(fid,720*360*420,'single'); fclose(fid); GPP_AN = reshape(GPP_AN,[720,360,420]);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_SSA_Annual_4comp.raw','r');      assert(fid>0); T_AN   = fread(fid,720*360*468,'single'); fclose(fid); T_AN   = reshape(T_AN,[720,360,468]);   T_AN  = T_AN(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\P05_SSA_Annual_4comp.raw','r');      assert(fid>0); P_AN   = fread(fid,720*360*468,'single'); fclose(fid); P_AN   = reshape(P_AN,[720,360,468]);   P_AN  = P_AN(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_SSA_Annual_4comp.raw','r');      assert(fid>0); R_AN   = fread(fid,720*360*468,'single'); fclose(fid); R_AN   = reshape(R_AN,[720,360,468]);   R_AN  = R_AN(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_SSA_Annual_4comp.raw','r');     assert(fid>0); SW_AN  = fread(fid,720*360*468,'single'); fclose(fid); SW_AN  = reshape(SW_AN,[720,360,468]);  SW_AN = SW_AN(:,:,25:444);

% ---------- Long-term ----------
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_CEEMDAN_Trend_4comp.raw','r'); assert(fid>0); GPP_TR = fread(fid,720*360*420,'single'); fclose(fid); GPP_TR = reshape(GPP_TR,[720,360,420]);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_CEEMDAN_Trend_4comp.raw','r');   assert(fid>0); T_TR   = fread(fid,720*360*468,'single'); fclose(fid); T_TR   = reshape(T_TR,[720,360,468]);   T_TR  = T_TR(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\P05_CEEMDAN_Trend_4comp.raw','r');   assert(fid>0); P_TR   = fread(fid,720*360*468,'single'); fclose(fid); P_TR   = reshape(P_TR,[720,360,468]);   P_TR  = P_TR(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_CEEMDAN_Trend_4comp.raw','r');   assert(fid>0); R_TR   = fread(fid,720*360*468,'single'); fclose(fid); R_TR   = reshape(R_TR,[720,360,468]);   R_TR  = R_TR(:,:,25:444);
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_CEEMDAN_Trend_4comp.raw','r');  assert(fid>0); SW_TR  = fread(fid,720*360*468,'single'); fclose(fid); SW_TR  = reshape(SW_TR,[720,360,468]);  SW_TR = SW_TR(:,:,25:444);

% IGBP
IGBP = imread(IGBP_path)';   % 720×360

%% ---------- 植被类型映射 ----------
vegMap = struct( ...
    'ENF', 1, ...
    'EBF', 2, ...
    'DNF', 3, ...
    'DBF', 4, ...
    'MF',  5, ...
    'SHL', [6 7], ...
    'SVA', [8 9], ...
    'GRA', 10, ...
    'WET', 11 ...
);
vegOrder = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'};
nVeg     = numel(vegOrder);

%% ---------- 初始化累加器 ----------
Acc    = init_accumulators(vegOrder, scales, gridN);      % 各植被
AccAvg = init_accumulators({'Average'}, scales, gridN);   % All biomes

%% ---------- 三尺度依次随机采样 + 流式累加 ----------
fprintf('Semiannual 随机采样...\n');
[Acc, AccAvg] = process_scale_stream(Acc, AccAvg, 'Semiannual', GPP_SA, T_SA, P_SA, R_SA, SW_SA, ...
                                     IGBP, vegOrder, vegMap, R2min, pdp_max_val_rows, ...
                                     MinLenPerPixel, Nsamp, xg_norm);

fprintf('ANNUAL 随机采样...\n');
[Acc, AccAvg] = process_scale_stream(Acc, AccAvg, 'ANNUAL',    GPP_AN, T_AN, P_AN, R_AN, SW_AN, ...
                                     IGBP, vegOrder, vegMap, R2min, pdp_max_val_rows, ...
                                     MinLenPerPixel, Nsamp, xg_norm);

fprintf('TREND 随机采样...\n');
[Acc, AccAvg] = process_scale_stream(Acc, AccAvg, 'TREND',     GPP_TR, T_TR, P_TR, R_TR, SW_TR, ...
                                     IGBP, vegOrder, vegMap, R2min, pdp_max_val_rows, ...
                                     MinLenPerPixel, Nsamp, xg_norm);

% 将 Average 累加器写回 Acc 以统一绘图取值
Acc.Average = AccAvg.Average;

%% ---------- 从累加器得到均值±标准差（用于作图） ----------
PlotData = finalize_plotdata(Acc, vegOrder, scales);

%% ---------- 绘图（缩小尺寸 + 子图稍微有间距） ----------
fig = figure('Color','w','Position',[100 100 800 900]); % 比原来小一圈
set(0,'DefaultAxesFontSize',20);
set(0,'DefaultTextFontSize',20);

% ★ 子图：TileSpacing 改为 'compact'，有一点间距
tiled = tiledlayout(nVeg, 4, 'TileSpacing','compact', 'Padding','compact');

% 捕获一次图例
hLegend = gobjects(1, numel(scales));
legendReady = false;

for ri = 1:nVeg
    tag = vegOrder{ri};
    for cj = 1:4
        ax = nexttile; hold(ax,'on'); grid(ax,'on'); box(ax,'on');
        local_h = gobjects(1, numel(scales));

        % 跨尺度 y 范围（由均值±std 决定）
        ymins = []; ymaxs = [];

        for si = 1:numel(scales)
            scl = scales{si};
            pd  = PlotData.(tag).(scl);
            if isempty(pd.mean{cj}), continue; end

            ybar = pd.mean{cj};
            ysd  = pd.std{cj};

            % 不同时间尺度不同颜色（实线）
            hLine = plot(ax, xg_norm, ybar, ...
                'LineWidth', 1.8, ...
                'Color', scaleColors(si,:));

            col = scaleColors(si,:);
            if numel(xg_norm) >= 3
                xv = [xg_norm, fliplr(xg_norm)];
                yv = [ybar+ysd, fliplr(ybar-ysd)];
                fill(ax, xv, yv, col, 'FaceAlpha', 0.15, 'EdgeColor','none');
                uistack(hLine,'top');
            end
            local_h(si) = hLine;

            ymins = [ymins, min(ybar-ysd)]; %#ok<AGROW>
            ymaxs = [ymaxs, max(ybar+ysd)]; %#ok<AGROW>
        end

        % 列标题 & 行标签
        if ri==1
            title(ax, xLabels{cj},'FontWeight','bold','Interpreter','tex');
        end
        if cj==1
            if strcmp(tag,'Average')
                ylabel(ax,'Average','FontWeight','bold','Rotation',90);
            else
                ylabel(ax,tag,'FontWeight','bold','Rotation',90);
            end
        end

        % X：统一 [0,1] 仅端点刻度
        set(ax,'XLim',[0 1],'XTick',[0 1],'XTickLabel',{'0','1'});

        % Y：仅端点刻度；仅最左列显示刻度值
        if isempty(ymins) || isempty(ymaxs) || ~all(isfinite([ymins ymaxs]))
            ymin=0; ymax=1;
        else
            ymin = min(ymins); ymax = max(ymaxs);
            if ymin==ymax, ymax = ymin + 1; end
        end
        set(ax,'YLim',[ymin ymax], 'YTick',[ymin ymax]);
        if cj==1
            set(ax,'YTickLabel',{num2str(ymin,'%.2f'), num2str(ymax,'%.2f')});
        else
            set(ax,'YTickLabel',[]);
        end
        % 不再 axis square，避免挤压

        if ~legendReady && all(isgraphics(local_h))
            hLegend = local_h;
            legendReady = true;
        end
    end
end

% ---- 底部横向图例 ----
if legendReady
    lg = legend(hLegend, leg_labels, 'Orientation','horizontal', ...
        'NumColumns', numel(scales), 'Box','off');
    lg.Layout.Tile = 'south';  % 放底部
end

saveas(fig,'PDP_RS_3scales_10veg_10sample_stream_normX_compact.png');
fprintf('完成：已保存 PDP_RS_3scales_10veg_10sample_stream_normX_compact.png（800×900，子图紧凑）。\n');

%% ================== 函数区 ==================
function Acc = init_accumulators(vegOrder, scales, gridN)
% 为每个 植被×尺度×因子 建立 {sumY, sumY2, n}
for vi = 1:numel(vegOrder)
    tag = vegOrder{vi};
    for si = 1:numel(scales)
        for j = 1:4
            Acc.(tag).(scales{si}).sumY{j}  = zeros(1,gridN);
            Acc.(tag).(scales{si}).sumY2{j} = zeros(1,gridN);
            Acc.(tag).(scales{si}).n{j}     = 0;
        end
    end
end
end

function [Acc, AccAvg] = process_scale_stream(Acc, AccAvg, scale_tag, GPP, T, P, R, SW, ...
                                              IGBP, vegOrder, vegMap, R2min, pdp_max_val_rows, ...
                                              MinLenPerPixel, Nsamp, xg_norm)
% 对指定尺度，逐植被类型随机采样 ≤Nsamp 像元并流式累加 PDP
for vi = 1:(numel(vegOrder)-1)  % 最后一类是 Average，不在此处遍历
    tag = vegOrder{vi};
    if isfield(vegMap, tag)
        codes = vegMap.(tag);
        maskVeg = ismember(IGBP, codes);
    else
        maskVeg = false(size(IGBP));
    end
    idxList = find(maskVeg);
    if isempty(idxList)
        fprintf('  [%s/%s] 无像元。\n', tag, scale_tag);
        continue;
    end

    % ---- 每类随机 ≤ Nsamp 像元 ----
    if numel(idxList) > Nsamp
        idxList = idxList(randsample(numel(idxList), Nsamp));
    end

    kept = 0;
    for kk = 1:numel(idxList)
        [ii, jj] = ind2sub(size(IGBP), idxList(kk));

        y  = squeeze(GPP(ii,jj,:));
        xT = squeeze(T(ii,jj,:));
        xP = squeeze(P(ii,jj,:));
        xR = squeeze(R(ii,jj,:));
        xS = squeeze(SW(ii,jj,:));
        if any([isempty(y), isempty(xT), isempty(xP), isempty(xR), isempty(xS)]), continue; end

        M = [y, xT, xP, xR, xS];
        valid = all(isfinite(M),2) & y>0;
        if nnz(valid) < MinLenPerPixel, continue; end

        y  = y(valid);
        X  = [xT(valid), xP(valid), xR(valid), xS(valid)];
        n  = size(X,1);
        if n < 60, continue; end

        % 80/20 划分
        cv = cvpartition(n,'Holdout',0.2);
        Xtr = X(training(cv),:);   Ytr = y(training(cv));
        Xte = X(test(cv),:);       Yte = y(test(cv));
        if size(Xte,1) > pdp_max_val_rows
            idxSub = randsample(size(Xte,1), pdp_max_val_rows);
            Xte = Xte(idxSub,:); Yte = Yte(idxSub,:);
        end

        % 标准化拟合/应用
        [Xtr_n, ps] = mapminmax(Xtr'); Xtr_n = Xtr_n';
        Xte_n = mapminmax('apply', Xte', ps)';

        % RF 训练 + 验证 R²
        Mdl = TreeBagger(300, Xtr_n, Ytr, 'Method','regression', ...
            'OOBPrediction','On','MinLeafSize',5,'NumPredictorsToSample',2);
        yhat = predict(Mdl, Xte_n);
        SST = sum((Yte - mean(Yte)).^2); SSE = sum((Yte - yhat).^2);
        if SST<=0, continue; end
        R2_val = 1 - SSE / SST;
        if R2_val <= R2min, continue; end

        % ===== 像元 PDP 即时计算并累加（4 因子 × gridN）=====
        for j = 1:4
            pool = X(:,j);
            pLo = prctile(pool,5); pHi = prctile(pool,95);
            if ~isfinite(pLo) || ~isfinite(pHi) || pHi<=pLo
                pLo = min(pool); pHi = max(pool);
            end
            xg = pLo + xg_norm * max(pHi - pLo, eps);

            % 以验证集为底，逐网格点替换第 j 列，求平均预测
            yloc = nan(1, numel(xg));
            for g = 1:numel(xg)
                Xperm = Xte; Xperm(:,j) = xg(g);
                Xperm_n = mapminmax('apply', Xperm', ps)';  % 应用同一标准化
                ypred = predict(Mdl, Xperm_n);
                yloc(g) = mean(ypred,'omitnan');
            end

            % 植被类型累加
            Acc.(tag).(scale_tag).sumY{j}  = Acc.(tag).(scale_tag).sumY{j}  + yloc;
            Acc.(tag).(scale_tag).sumY2{j} = Acc.(tag).(scale_tag).sumY2{j} + yloc.^2;
            Acc.(tag).(scale_tag).n{j}     = Acc.(tag).(scale_tag).n{j} + 1;

            % Average（全生物群系）同步累加
            AccAvg.Average.(scale_tag).sumY{j}  = AccAvg.Average.(scale_tag).sumY{j}  + yloc;
            AccAvg.Average.(scale_tag).sumY2{j} = AccAvg.Average.(scale_tag).sumY2{j} + yloc.^2;
            AccAvg.Average.(scale_tag).n{j}     = AccAvg.Average.(scale_tag).n{j} + 1;
        end

        kept = kept + 1;
    end
    fprintf('  [%s/%s] 入选像元（R²>%.2f）：%d 个（随机 ≤%d）。\n', ...
        tag, scale_tag, R2min, kept, Nsamp);
end
end

function PlotData = finalize_plotdata(Acc, vegOrder, scales)
% 把累加器转换为可直接绘图的均值/标准差
for vi = 1:numel(vegOrder)
    tag = vegOrder{vi};
    for si = 1:numel(scales)
        scl = scales{si};
        for j = 1:4
            n = Acc.(tag).(scl).n{j};
            if n > 0
                m = Acc.(tag).(scl).sumY{j}  / n;
                v = max(Acc.(tag).(scl).sumY2{j} / n - m.^2, 0);
                PlotData.(tag).(scl).mean{j} = m;
                PlotData.(tag).(scl).std{j}  = sqrt(v);
            else
                PlotData.(tag).(scl).mean{j} = [];
                PlotData.(tag).(scl).std{j}  = [];
            end
        end
    end
end
end
