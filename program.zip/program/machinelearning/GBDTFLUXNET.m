%% ================== FLUXNET Site-level GBDT: HH / DD / MM (Veg-split importance; remove DNF/SHL/SVA) ==================
% 修改点：
%  1) 图1：第二个子图（Daily）也加上 xlabel('R^2')
%  2) 图2：相对因子贡献按植被类型分面板，但去掉 DNF / SHL / SVA 三类（无有效数据）
%     保留：ENF, EBF, DBF, MF, GRA, WET, All biomes（共7个面板），2×4 布局，空 1 个位置
%
% 站点级建模：每站点分别在 HH/DD/MM 三尺度建 GBDT（回归）
%   y = GPP_DT_VUT_REF
%   X = [SWC_avg, P_F, TA_F_MDS, SW_IN_F_MDS]  (顺序固定：SW, P, T, R)
%
% Tested: MATLAB R2021a

clear; clc; close all; warning('off','all');
tAll = tic;

%% ================== 路径（按需修改） ==================
rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
siteXlsx        = fullfile(rootFolder_FLUX, 'FLUXsitelistnew.xlsx');   % 第1列站名；第8列植被类型

assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);

 outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end

%% ================== 通用阈值与变量名 ==================
alpha = 0.05;     %#ok<NASGU> % 这里建模不需要显著性过滤
minN  = 50;      % 每站点每尺度最小样本量阈值（你可改：HH/DD可更大，MM可更小）
testRatio = 0.2;  % 20% holdout

yName = 'GPP_DT_VUT_REF';
vT    = 'TA_F_MDS';
vP    = 'P_F';
vR    = 'SW_IN_F_MDS';

% SWC：SWC_F_MDS_# 多层，取平均作为 “土壤水（SW）”
swcRegex = '^SWC_F_MDS_\d+$';

% 统一展示顺序：SW, P, T, R
featureNames = {'Soil Moisture','Precipitation','Temperature','Radiation'};
xlabels4     = {'SW','P','T','R'}; %#ok<NASGU>

% 绘图字体（参考你程序1的放大风格）
font_title = 14 * 1.5;
font_label = 12 * 1.5;
font_axis  = 10 * 1.5;

%% ================== GBDT 参数（你可微调） ==================
gbdt.NumLearningCycles = 200;   % 树的数量
gbdt.LearnRate         = 0.05;  % 学习率
gbdt.MinLeafSize       = 10;    % 叶子最小样本
gbdt.MaxNumSplits      = 40;    % 控制树深
gbdt.RngSeedBase       = 2025;  % 可复现

%% ================== 读站点→植被类型映射（用于图2分组） ==================
vegRows = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','All biomes'}; % 原始10面板（DNF/SHL/SVA 后续不画）
site2veg = containers.Map('KeyType','char','ValueType','char');
hasVegMap = false;

if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);
        names = string(Tsite{:,1});    % 站名
        vegs  = string(Tsite{:,8});    % 植被类型
        for ii = 1:numel(names)
            k = strtrim(names(ii)); v = strtrim(vegs(ii));
            if ~isempty(k) && ~isempty(v)
                site2veg(char(k)) = char(v);
            end
        end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx，图2将无法按植被类型分组（仅 All biomes）。\n');
        hasVegMap = false;
    end
else
    fprintf('⚠️ 未找到 FLUXsitelistnew.xlsx，图2将无法按植被类型分组（仅 All biomes）。\n');
end

%% ================== 收集目标 CSV（HH/DD/MM FULLSET） ==================
allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
targets = [];
for ii = 1:numel(allCSV)
    nm = allCSV(ii).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        targets = [targets; allCSV(ii)]; %#ok<AGROW>
    end
end
if isempty(targets)
    error('未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
end
fprintf('FLUXNET 可用文件（HH/DD/MM）：%d 个\n', numel(targets));

%% ================== 容器：按尺度存储每站点结果（图1用） ==================
scaleList = {'HH','DD','MM'};
nSc = numel(scaleList);

R2_list  = cell(1,nSc);           % 每尺度：所有站点 R²（图1）
for s=1:nSc
    R2_list{s} = [];
end

%% ================== 容器：按“植被类型 × 尺度”存储每站点贡献（图2用） ==================
% IMP_veg{vegIdx, scaleIdx}：cell，每个元素是一个站点的 1×4 相对贡献
% vegIdx=10 为 All biomes
IMP_veg  = cell(10, nSc);
for v=1:10
    for s=1:nSc
        IMP_veg{v,s} = {};
    end
end

% 可选：记录站点名
SITE_veg = cell(10, nSc);
for v=1:10
    for s=1:nSc
        SITE_veg{v,s} = {};
    end
end

% 为了避免同一站点同一尺度重复
seen = containers.Map('KeyType','char','ValueType','logical');

%% ================== 主循环：逐站点逐尺度训练 GBDT ==================
t0 = tic;
for k = 1:numel(targets)

    fpath = fullfile(targets(k).folder, targets(k).name);
    [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
    si = find(strcmp(scaleList, scaleTag), 1);
    if isempty(si), continue; end

    key = sprintf('%s__%s', siteName, scaleTag);
    if isKey(seen,key), continue; end
    seen(key) = true;

    try
        % ---------- 读取必要列 ----------
        opts = detectImportOptions(fpath);
        varNames = opts.VariableNames;

        needFixed = {yName, vT, vP, vR};
        if ~all(ismember(needFixed, varNames))
            continue;
        end

        swcMask = ~cellfun('isempty', regexp(varNames, swcRegex,'once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols)
            continue;
        end

        opts.SelectedVariableNames = [needFixed, swcCols];
        T = readtable(fpath, opts);

        % sentinel -> NaN
        T = sentinel2nan(T, opts.SelectedVariableNames);

        % ---------- 构造 X,y（顺序：SW, P, T, R） ----------
        Y  = T.(yName);
        TA = T.(vT);
        PP = T.(vP);
        RR = T.(vR);

        SWCmat = T{:, swcCols};
        if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SWC_avg = mean(SWCmat, 2, 'omitnan');

        mask = isfinite(Y) & (Y>0) & isfinite(TA) & isfinite(PP) & isfinite(RR) & isfinite(SWC_avg);
        Y  = Y(mask);
        X  = [SWC_avg(mask), PP(mask), TA(mask), RR(mask)];  % [SW, P, T, R]

        if size(X,1) <= minN
            continue;
        end

        % ---------- 训练 + 测试（holdout 20%） ----------
        rng(gbdt.RngSeedBase + si*1000 + k);
        cv = cvpartition(size(X,1), 'Holdout', testRatio);
        trIdx = training(cv);
        teIdx = test(cv);

        Xtr = X(trIdx,:);  Ytr = Y(trIdx,:);
        Xte = X(teIdx,:);  Yte = Y(teIdx,:);

        % 回归树模板
        tTree = templateTree( ...
            'MinLeafSize', gbdt.MinLeafSize, ...
            'MaxNumSplits', gbdt.MaxNumSplits, ...
            'Surrogate','on' ...
        );

        model = fitrensemble(Xtr, Ytr, ...
            'Method','LSBoost', ...
            'NumLearningCycles', gbdt.NumLearningCycles, ...
            'LearnRate', gbdt.LearnRate, ...
            'Learners', tTree ...
        );

        % ---------- R²（图1用） ----------
        Yhat = predict(model, Xte);
        R2   = rsq(Yte, Yhat);
        R2_list{si} = [R2_list{si}; R2];

        % ---------- 因子贡献：predictorImportance -> 归一化（图2用） ----------
        imp = predictorImportance(model);   % 1×4
        imp = imp(:)';                      % row
        if all(~isfinite(imp)) || sum(imp(isfinite(imp)))==0
            impRel = nan(1,4);
        else
            imp(~isfinite(imp)) = 0;
            impRel = imp / sum(imp);
        end

        % ---------- 归到植被类型 ----------
        vegIdx = 10; % 默认 All biomes
        if hasVegMap && isKey(site2veg, siteName)
            vname = site2veg(siteName);
            ridx  = find(strcmp(vegRows, vname), 1);
            if ~isempty(ridx) && ridx <= 9
                vegIdx = ridx;
            else
                vegIdx = 10;
            end
        end

        % 写入：该植被类型
        IMP_veg{vegIdx, si}{end+1,1}  = single(impRel); %#ok<AGROW>
        SITE_veg{vegIdx, si}{end+1,1} = siteName;       %#ok<AGROW>

        % 同时写入：All biomes（10）
        IMP_veg{10, si}{end+1,1}  = single(impRel); %#ok<AGROW>
        SITE_veg{10, si}{end+1,1} = siteName;       %#ok<AGROW>

    catch
        continue;
    end

    if mod(k,50)==0
        fprintf('进度 %d/%d | 用时 %.1fs\n', k, numel(targets), toc(t0));
        t0 = tic;
    end
end

% 汇总
for si=1:nSc
    fprintf('尺度 %s：有效站点 %d 个\n', scaleList{si}, numel(R2_list{si}));
end

%% ================== 图1：R² 直方图（参考程序1出图方式；Daily也有xlabel） ==================
dataR2 = cell(1,3);
for si=1:3
    dataR2{si} = R2_list{si}(:)';
end

biomename = ["Half-hourly","Daily","Monthly (FLUXNET)"];
colors = lines(4);

binWidth = [0.01, 0.01, 0.01];
xlims    = [0 1.0; 0 1.0; 0 1.0];

fig1 = figure('Color','w');
for k = 1:3
    subplot(2,2,k);

    histogram(dataR2{k}, ...
        'FaceColor',  colors(k,:), ...
        'FaceAlpha',  0.5, ...
        'BinWidth',   binWidth(k));

    title(biomename(k), 'FontSize', font_title);

    if mod(k-1,2)==0
        ylabel('Frequency','FontSize',font_label);
    end

    % 修改点：Daily 也加 xlabel
    if k >= 2
        xlabel('R^2','FontSize',font_label);
    end

    set(gca,'FontSize',font_axis);

    if ~isnan(xlims(k,1))
        xlim(xlims(k,:));
    end
end
set(gcf,'Position',[100,100,800,600]);

out1 = fullfile(outDir,'FLUXNET_site_GBDT_R2_hist_HH_DD_MM.png');
exportgraphics(fig1, out1, 'Resolution', 300);
fprintf('✅ 图1已保存：%s\n', out1);
%% ================== 图2：相对因子贡献（去掉 DNF/SHL/SVA；2×4 布局，空一个位置） ==================
keepIdx = [1 2 4 5 8 9 10];
vegRows_keep = vegRows(keepIdx);
nPanels = numel(keepIdx);

colors4 = [ ...
     161,213,112;  % Soil Moisture
      60,168,197;  % Precipitation
     249,118,110;  % Temperature
     250,174, 90   % Radiation
] / 255;

legend_labels = {'Soil Moisture','Precipitation','Temperature','Radiation'};
countries = {'Half-hourly','Daily','Monthly'};

fig2 = figure('Color','w');
set(fig2,'Position',[100,100,1400,750]);

% ✅ 1) 画 tiledlayout，并给底部/右侧留一点空间放 legend（你也可改）
tl = tiledlayout(fig2, 2, 4, 'Padding','compact','TileSpacing','compact');
tl.Units = 'normalized';
tl.Position = [0.04 0.10 0.92 0.86];   % [left bottom width height]，底部留 0.10

for p = 1:nPanels
    v = keepIdx(p);

    meanImp = nan(3,4);
    semImp  = nan(3,4);

    for si = 1:3
        cellarr = IMP_veg{v,si};
        if isempty(cellarr), continue; end

        stacked = nan(numel(cellarr), 4);
        for kk = 1:numel(cellarr)
            stacked(kk,:) = double(cellarr{kk});
        end

        meanImp(si,:) = mean(stacked, 1, 'omitnan');
        sdv = std(stacked, 0, 1, 'omitnan');
        n_eff = sum(~isnan(stacked), 1);
        sem = sdv ./ sqrt(n_eff);
        sem(n_eff==0) = nan;
        semImp(si,:) = sem;
    end

    ax = nexttile(tl);

    show_ylabel = (p==1 || p==5);
    plot_group(meanImp, semImp, vegRows_keep{p}, countries, colors4, show_ylabel);

    xlim(ax,[0 1]);
    xticks(ax,0:0.2:1);
    xticklabels(ax, arrayfun(@(x) sprintf('%.0f%%', x*100), xticks(ax), 'UniformOutput', false));

    if p <= 4
        xlabel(ax,'');
    else
        xlabel(ax,'Percentage');
    end
end

axEmpty = nexttile(tl);
axis(axEmpty,'off');

%% ================== ✅ 2) 同一 Figure 内放 legend（不占 tile、不发灰） ==================
% 做一个隐藏轴（不属于 tiledlayout），专门放 legend
axLeg = axes(fig2, 'Units','normalized', 'Position',[0 0 1 1], 'Visible','off');
hold(axLeg,'on');

% 关键：dummy 不能 Visible=off，否则 legend 文字会自动变灰
hDummy = gobjects(1,4);
for k = 1:4
    hDummy(k) = plot(axLeg, nan, nan, 's', ...
        'MarkerSize', 14, ...
        'MarkerFaceColor', colors4(k,:), ...
        'MarkerEdgeColor', 'none', ...
        'LineStyle', 'none', ...
        'Visible','on');
end

% 随便放一个位置：这里放右下角（你也可以改 Location 或手动 Position）
lgd2 = legend(axLeg, hDummy, legend_labels, ...
    'Location','southeast', 'Orientation','horizontal');

set(lgd2,'Interpreter','tex','FontName','Arial','FontSize',17);
lgd2.Box = 'off';
lgd2.NumColumns = 2;   % 右下角更紧凑；想一行四个就改成 4

% 如果你想“完全随意位置”，可以手动设置：
% lgd2.Units = 'normalized';
% lgd2.Position = [0.62 0.02 0.36 0.08];   % 自己调

out2 = fullfile(outDir,'FLUXNET_site_GBDT_relative_importance_HH_DD_MM_byVeg_2x4.png');
exportgraphics(fig2, out2, 'Resolution', 300);
fprintf('✅ 图2已保存：%s\n', out2);

%% ================== 保存数值结果 ==================
save(fullfile(outDir,'FLUXNET_site_GBDT_results_byVeg_2x4.mat'), ...
    'R2_list','IMP_veg','SITE_veg','vegRows','scaleList','gbdt','minN','testRatio','featureNames');

fprintf('✅ 全部完成 | 总耗时 %.1f 分钟 | 输出目录：%s\n', toc(tAll)/60, outDir);

%% ================== 辅助函数 ==================
function T = sentinel2nan(T, names)
% 把 -9999/超大异常 值转为 NaN
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v)
        v = double(str2double(string(v)));
    end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
% 从文件名解析尺度标签与站点名
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM';
else
    scaleTag = 'OTHER';
end
end

function r2 = rsq(y, yhat)
% R^2 = 1 - SSE/SST
y = y(:); yhat = yhat(:);
m = isfinite(y) & isfinite(yhat);
y = y(m); yhat = yhat(m);
if numel(y) < 2
    r2 = NaN;
    return;
end
ss_res = sum((y - yhat).^2);
ss_tot = sum((y - mean(y)).^2);
if ss_tot == 0
    r2 = NaN;
else
    r2 = 1 - ss_res/ss_tot;
end
end

function plot_group(data_group, std_dev_group, title_str, countries, colors, show_ylabel)
% 参考你程序2的出图方式（barh grouped + 右侧半边误差线）
% data_group: (3 x 4) 行=尺度(HH/DD/MM), 列=因子(SW/P/T/R)
% std_dev_group: (3 x 4) SEM
[ngroups, nbars] = size(data_group);
groupwidth = min(0.8, nbars/(nbars + 1.5));
errlw = 0.8;

b = barh(data_group,'grouped'); hold on;
for k = 1:length(b)
    b(k).FaceColor = colors(k,:);
    b(k).EdgeColor = 'none';
end
title(title_str,'FontWeight','bold','FontName','Arial');

if show_ylabel
    set(gca,'YTick',1:ngroups,'YTickLabel',countries);
else
    set(gca,'YTick',1:ngroups,'YTickLabel',[]);
end

set(gca,'FontName','Arial','FontSize',17);
box on; grid on;

% 半边误差线：仅在右侧
for k = 1:nbars
    y = (1:ngroups) - groupwidth/2 + (2*k-1) * groupwidth / (2*nbars);
    x  = data_group(:,k);
    xe = std_dev_group(:,k);
    mask = ~isnan(x) & ~isnan(xe);
    for m = find(mask)'
        x_start = x(m);
        x_end   = x(m) + xe(m);
        y_pos   = y(m);

        line([x_start x_end],[y_pos y_pos],'Color','k','LineWidth',errlw);

        cap = 0.1;
        line([x_end x_end],[y_pos-cap y_pos+cap],'Color','k','LineWidth',errlw);
    end
end
hold off;
end
