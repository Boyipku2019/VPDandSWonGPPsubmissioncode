clear all;close all;
clc;
%读取二氧化碳数据，就一个站点
% 文件路径



IGBP=imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP=IGBP';
% fid=fopen('D:\IGBPtest.raw','wb');%存为raw
% fwrite(fid,IGBP,'single');
% fclose(fid); 

%所有y和x都分成短期和长期，短期保存在1中，长期保存在2中
%%读取GPP数据
GPP1=single(zeros(720,360,420));
fid = fopen('G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw','r'); %打RAW文件
GPP1 = fread(fid,720*360*420,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GPP1=reshape(GPP1,[720,360,420]);

%%读取T数据
T1=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw','r'); %打RAW文件
T1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
T1=reshape(T1,[720,360,468]);
T1= T1(:,:,25:444);
%%读取P数据
P1=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw','r'); %打RAW文件
P1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
P1=reshape(P1,[720,360,468]);
P1= P1(:,:,25:444);
%%读取R数据
R1=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw','r'); %打RAW文件
R1 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
R1=reshape(R1,[720,360,468]);
R1= R1(:,:,25:444);
%%读取SM数据
SM1=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw','r'); %打RAW文件
SM1= fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SM1=reshape(SM1,[720,360,468]);
SM1= SM1(:,:,25:444);
% %%读取SPEI数据
% SPEI1=single(zeros(1440,721,420));
% fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\PDSI025FirstIMF.raw','r'); %打RAW文件
% SPEI1 = fread(fid,1440*721*420,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SPEI1=reshape(SPEI1,[1440,721,420]);

%%读取CO2数据
CO21=single(zeros(720,360,492));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CO205_SSA_Semiannual_4comp.raw','r'); %打RAW文件
CO21 = fread(fid,720*360*492,'single'); % 读RAW数据
fclose(fid); % 关闭文件
CO21=reshape(CO21,[720,360,492]);
CO21 = CO21(:,:,25:444);
%%读取GPP数据
GPP2=single(zeros(720,360,420));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_CEEMDAN_Trend_4comp.raw','r'); %打RAW文件
GPP2 = fread(fid,720*360*420,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GPP2=reshape(GPP2,[720,360,420]);




%%读取T数据
T2=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_CEEMDAN_Trend_4comp.raw','r'); %打RAW文件
T2 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
T2=reshape(T2,[720,360,468]);
T2= T2(:,:,25:444);
%%读取P数据
P2=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\P05_CEEMDAN_Trend_4comp.raw','r'); %打RAW文件
P2 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
P2=reshape(P2,[720,360,468]);
P2= P2(:,:,25:444);
%%读取R数据
RR2=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_CEEMDAN_Trend_4comp.raw','r'); %打RAW文件
RR2 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
RR2=reshape(RR2,[720,360,468]);%命名是为了区分相关系数
RR2= RR2(:,:,25:444);
%%读取SM数据
SM2=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_CEEMDAN_Trend_4comp.raw','r'); %打RAW文件
SM2= fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SM2=reshape(SM2,[720,360,468]);
SM2= SM2(:,:,25:444);
% 
% %%读取SPEI数据
% SPEI2=single(zeros(1440,721,420));
% fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\PDSI025LastIMF.raw','r'); %打RAW文件
% SPEI2 = fread(fid,1440*721*420,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SPEI2=reshape(SPEI2,[1440,721,420]);

%%读取CO2数据
CO22=single(zeros(720,360,492));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CO205_CEEMDAN_Trend_4comp.raw','r'); %打RAW文件
CO22 = fread(fid,720*360*492,'single'); % 读RAW数据
fclose(fid); % 关闭文件
CO22=reshape(CO22,[720,360,492]);
CO22 = CO22(:,:,25:444);

% 
%%读取GPP数据
GPP3=single(zeros(720,360,420));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_SSA_Annual_4comp.raw','r'); %打RAW文件
GPP3 = fread(fid,720*360*420,'single'); % 读RAW数据
fclose(fid); % 关闭文件
GPP3=reshape(GPP3,[720,360,420]);




%%读取T数据
T3=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_SSA_Annual_4comp.raw','r'); %打RAW文件
T3 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
T3=reshape(T3,[720,360,468]);
T3= T3(:,:,25:444);
%%读取P数据
P3=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\P05_SSA_Annual_4comp.raw','r'); %打RAW文件
P3 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
P3=reshape(P3,[720,360,468]);
P3= P3(:,:,25:444);
%%读取R数据
RR3=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_SSA_Annual_4comp.raw','r'); %打RAW文件
RR3 = fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
RR3=reshape(RR3,[720,360,468]);%命名是为了区分相关系数
RR3= RR3(:,:,25:444);
%%读取SM数据
SM3=single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_SSA_Annual_4comp.raw','r'); %打RAW文件
SM3= fread(fid,720*360*468,'single'); % 读RAW数据
fclose(fid); % 关闭文件
SM3=reshape(SM3,[720,360,468]);
SM3= SM3(:,:,25:444);
% %%读取SPEI数据
% SPEI3=single(zeros(1440,721,420));
% fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\PDSI025Innerannual.raw','r'); %打RAW文件
% SPEI3 = fread(fid,1440*721*420,'single'); % 读RAW数据
% fclose(fid); % 关闭文件
% SPEI3=reshape(SPEI3,[1440,721,420]);
%%读取CO2数据
CO23=single(zeros(720,360,492));
fid = fopen('G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CO205_SSA_Annual_4comp.raw','r'); %打RAW文件
CO23 = fread(fid,720*360*492,'single'); % 读RAW数据
fclose(fid); % 关闭文件
CO23=reshape(CO23,[720,360,492]);
CO23 = CO23(:,:,25:444);
% 




% % 水分限制掩膜文件路径
% waterLimitPath_Monthly = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\WaterLimited_Monthly.raw';
% waterLimitPath_Annual  = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\WaterLimited_Annual.raw';
% waterLimitPath_Longterm = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\WaterLimited_Longterm.raw';


waterLimitPath_Monthly=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\waterlimitregion\WaterLimited_Monthly.raw','r'); %打RAW文件
waterLimitPath_Monthly = fread(fid,720*360,'single'); % 读RAW数据
fclose(fid); % 关闭文件
waterLimitPath_Monthly=reshape(waterLimitPath_Monthly,[720,360]);


waterLimitPath_Annual=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\waterlimitregion\WaterLimited_Annual.raw','r'); %打RAW文件
waterLimitPath_Annual = fread(fid,720*360,'single'); % 读RAW数据
fclose(fid); % 关闭文件
waterLimitPath_Annual=reshape(waterLimitPath_Annual,[720,360]);


waterLimitPath_Longterm=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\waterlimitregion\WaterLimited_Longterm.raw','r'); %打RAW文件
waterLimitPath_Longterm = fread(fid,720*360,'single'); % 读RAW数据
fclose(fid); % 关闭文件
waterLimitPath_Longterm=reshape(waterLimitPath_Longterm,[720,360]);


%存储模型拟合的各种参数
monthlyR2=single(zeros(720,360));
longtermR2=single(zeros(720,360));
annualR2=single(zeros(720,360));

monthlyfactorimportanceworld=single(zeros(720,360,4));
longtermfactorimportanceworld=single(zeros(720,360,5));
annualfactorimportanceworld=single(zeros(720,360,4));

monthlyfactorimportance=[];%存储每一个短期结果，无位置
longtermfactorimportance=[];%存储每一个长期结果，无位置
annualfactorimportance=[];%存储每一个长期结果，无位置

for i=1:720
   for j=1:360
         if waterLimitPath_Longterm(i,j)>0&&~isnan(GPP2(i,j,1))&&T2(i,j,1)~=0&&P2(i,j,1)~=0&&RR2(i,j,1)~=0&&SM2(i,j,1)~=0&&((IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11))   %判断为有效像元，去除无效物候数据和0值环境变量数据
            %if ~isnan(GPP1(i,j,1))&&T1(i,j,1)~=0&&P1(i,j,1)~=0&&R1(i,j,1)~=0&&SM1(i,j,1)~=0&&SPEI1(i,j,1)~=0 &&((IGBP(i,j)==6||IGBP(i,j)==7))    %判断为有效像元，去除无效物候数据和0值环境变量数据
             
              onepixel=GPP2(i,j,:);
             onepixel=reshape(onepixel,420,1);
             y=onepixel;
             
                Tonepixel=T2(i,j,:);
             Tonepixel=reshape(Tonepixel,420,1);
            
             
                Ponepixel=P2(i,j,:);
             Ponepixel=reshape(Ponepixel,420,1);
             
             
                Ronepixel=RR2(i,j,:);
             Ronepixel=reshape(Ronepixel,420,1);
            
             
                SMonepixel=SM2(i,j,:);
             SMonepixel=reshape(SMonepixel,420,1);
            
   
            
               CO2onepixel=CO22(i,j,:);
            CO2onepixel=reshape(CO2onepixel,420,1);
             
% ===== 构造样本（不做筛选，固定 420×5 与 420×1）=====
x = [SMonepixel,Ponepixel,Tonepixel,  Ronepixel,  CO2onepixel];  % 420x5
y = onepixel;                                                    % 420x1

% —— 随机 20% 验证集，80% 训练集（可复现）——
rng(i*1000 + j);                 % 或固定 rng(2025) 以像元间一致
cv = cvpartition(420, 'Holdout', 0.2);
trIdx = training(cv);
teIdx = test(cv);

Xtr = x(trIdx, :);  Ytr = y(trIdx, :);
Xte = x(teIdx, :);  Yte = y(teIdx, :);

% —— 标准化：仅用训练集拟合，再应用到验证集（避免泄漏）——
[Xtr_n, ps] = mapminmax(Xtr');           % (p x n_tr)
Xtr_n = Xtr_n';                          % (n_tr x p)
Xte_n = mapminmax('apply', Xte', ps)';   % (n_te x p)

% ===== BRT 回归（Boosted Regression Trees）=====
% 核心：弱树（浅树） + 多轮 boosting + 小学习率
% MaxNumSplits 控制树深（越小越“弱”）；MinLeafSize 越大越平滑、稳健
t = templateTree( ...
    'MinLeafSize', 10, ...        % 建议 5~20 之间
    'MaxNumSplits', 6, ...        % 建议 4~10 之间（BRT 常用浅树）
    'Surrogate','off' ...         % 关闭替代分裂，提高速度/稳定性
    );

model = fitrensemble( ...
    Xtr_n, Ytr, ...
    'Method', 'LSBoost', ...      % 回归 boosting（平方误差），即常说的 BRT/GBDT 框架
    'Learners', t, ...
    'NumLearningCycles', 50, ... % BRT 通常需要更多树（例如 300~1500）
    'LearnRate', 0.05 ...         % 小学习率更稳（例如 0.01~0.1）
    );

% —— 在验证集上评估 R² —— 
y_pred = predict(model, Xte_n);
SST = sum((Yte - mean(Yte)).^2);
SSE = sum((Yte - y_pred).^2);
if SST > 0
    R_squared = 1 - SSE / SST;
else
    R_squared = NaN;   % 极少见：验证集全常数
end

% —— 变量重要性（BRT：基于分裂带来的误差下降累计）——
variable_importance = predictorImportance(model);  % 1 x 5

% —— 保留你的打印 —— 
fprintf('R-squared: %.4f\n', R_squared);
for ii = 1:length(variable_importance)
    fprintf('Variable %d importance: %.4f\n', ii, variable_importance(ii));
end

% ===== 写回你的容器（验证集 R² + 重要性）=====
aaa = variable_importance(:)';                       % 1 x 5
longtermfactorimportance = [longtermfactorimportance; aaa];
longtermR2(i, j) = R_squared;

longtermfactorimportanceworld(i, j, 1) = aaa(1);  % 土壤水
longtermfactorimportanceworld(i, j, 2) = aaa(2);  % 降水
longtermfactorimportanceworld(i, j, 3) = aaa(3);  % 温度
longtermfactorimportanceworld(i, j, 4) = aaa(4);  % 辐射
longtermfactorimportanceworld(i, j, 5) = aaa(5);  % CO2


           aa=0;
                    
        end
        i,j,"longterm"
    end
   
 


end
%保存
fid=fopen('D:\GPPBRTlongtermfactorimportance.raw','wb');%存为raw
fwrite(fid,longtermfactorimportanceworld,'single');
fclose(fid);
%保存
fid=fopen('D:\GPPBRTlongtermR2.raw','wb');%存为raw
fwrite(fid,longtermR2,'single');
fclose(fid);


for i=1:720
   for j=1:360
        if waterLimitPath_Monthly(i,j)>0&&~isnan(GPP1(i,j,1))&&T1(i,j,1)~=0&&P1(i,j,1)~=0&&R1(i,j,1)~=0&&SM1(i,j,1)~=0&&((IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11))   %判断为有效像元，去除无效物候数据和0值环境变量数据
   %if ~isnan(GPP1(i,j,1))&&T1(i,j,1)~=0&&P1(i,j,1)~=0&&R1(i,j,1)~=0&&SM1(i,j,1)~=0&&SPEI1(i,j,1)~=0 &&((IGBP(i,j)==6||IGBP(i,j)==7))   %判断为有效像元，去除无效物候数据和0值环境变量数据
             
              onepixel=GPP1(i,j,:);
             onepixel=reshape(onepixel,420,1);
             y=onepixel;
             
                Tonepixel=T1(i,j,:);
             Tonepixel=reshape(Tonepixel,420,1);
            
             
                Ponepixel=P1(i,j,:);
             Ponepixel=reshape(Ponepixel,420,1);
             
             
                Ronepixel=R1(i,j,:);
             Ronepixel=reshape(Ronepixel,420,1);
            
             
                SMonepixel=SM1(i,j,:);
             SMonepixel=reshape(SMonepixel,420,1);
            
     
            
                   
                CO2onepixel=CO21(i,j,:);
             CO2onepixel=reshape(CO2onepixel,420,1);
              
            
              
      % ===== 构造样本（不做筛选，固定 420×5 与 420×1）=====
% ===== 构造样本（不做筛选，固定 420×4 与 420×1）=====
x = [SMonepixel, Ponepixel, Tonepixel, Ronepixel];  % 420x4
y = onepixel;                                       % 420x1

% —— 随机 20% 验证集，80% 训练集（可复现）——
rng(i*1000 + j);                 % 或固定 rng(2025) 以像元间一致
cv = cvpartition(420, 'Holdout', 0.2);
trIdx = training(cv);
teIdx = test(cv);

Xtr = x(trIdx, :);  Ytr = y(trIdx, :);
Xte = x(teIdx, :);  Yte = y(teIdx, :);

% —— 标准化：仅用训练集拟合，再应用到验证集（避免泄漏）——
% mapminmax 视“列为变量”，故转置进/出
[Xtr_n, ps] = mapminmax(Xtr');          % (p x n_tr)
Xtr_n = Xtr_n';                         % (n_tr x p)
Xte_n = mapminmax('apply', Xte', ps)';  % (n_te x p)

% ===== BRT（Boosted Regression Trees）=====
% 核心：弱树（浅树） + 多轮 boosting + 小学习率
% MaxNumSplits 越小树越浅；MinLeafSize 越大越平滑、更稳健
t = templateTree( ...
    'MinLeafSize', 10, ...        % 建议 5~20
    'MaxNumSplits', 6, ...        % 建议 4~10（BRT 常用浅树）
    'Surrogate','off' ...         % 关闭替代分裂（更快/更稳）
    );

model = fitrensemble( ...
    Xtr_n, Ytr, ...
    'Method', 'LSBoost', ...      % 回归 boosting（平方误差），即 BRT/GBDT 框架
    'Learners', t, ...
    'NumLearningCycles', 500, ... % 建议 300~1500（配合小学习率）
    'LearnRate', 0.05 ...         % 建议 0.01~0.1
    );

% —— 在验证集上评估 R² —— 
y_pred = predict(model, Xte_n);
SST = sum((Yte - mean(Yte)).^2);
SSE = sum((Yte - y_pred).^2);
if SST > 0
    R_squared = 1 - SSE / SST;
else
    R_squared = NaN;   % 极少见：验证集全常数
end

% —— 变量重要性（BRT：基于分裂带来的误差下降累计）——
variable_importance = predictorImportance(model);  % 1 x 4

% —— 保留你的打印 —— 
fprintf('R-squared: %.4f\n', R_squared);
for ii = 1:length(variable_importance)
    fprintf('Variable %d importance: %.4f\n', ii, variable_importance(ii));
end

% ===== 写回你的容器（验证集 R² + 重要性）=====
aaa = variable_importance(:)';                       % 1 x 4
monthlyfactorimportance = [monthlyfactorimportance; aaa];
monthlyR2(i, j) = R_squared;

monthlyfactorimportanceworld(i, j, 1) = aaa(1);  % 土壤水
monthlyfactorimportanceworld(i, j, 2) = aaa(2);  % 降水
monthlyfactorimportanceworld(i, j, 3) = aaa(3);  % 温度
monthlyfactorimportanceworld(i, j, 4) = aaa(4);  % 辐射




                    
        end
        i,j,"monthly"
    end
   
 


end
%保存
fid=fopen('D:\GPPBRTmonthlyfactorimportance.raw','wb');%存为raw
fwrite(fid,monthlyfactorimportanceworld,'single');
fclose(fid);
%保存
fid=fopen('D:\GPPBRTmonthlyR2.raw','wb');%存为raw
fwrite(fid,monthlyR2,'single');
fclose(fid);




% 
% 
for i=1:720
   for j=1:360
        if waterLimitPath_Annual(i,j)>0&&~isnan(GPP3(i,j,1))&&T3(i,j,1)~=0&&P3(i,j,1)~=0&&RR3(i,j,1)~=0&&SM3(i,j,1)~=0&&((IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11))   %判断为有效像元，去除无效物候数据和0值环境变量数据
   %if ~isnan(GPP1(i,j,1))&&T1(i,j,1)~=0&&P1(i,j,1)~=0&&R1(i,j,1)~=0&&SM1(i,j,1)~=0&&SPEI1(i,j,1)~=0 &&((IGBP(i,j)==6||IGBP(i,j)==7))   %判断为有效像元，去除无效物候数据和0值环境变量数据
             
              onepixel=GPP3(i,j,:);
             onepixel=reshape(onepixel,420,1);
             y=onepixel;
             
                Tonepixel=T3(i,j,:);
             Tonepixel=reshape(Tonepixel,420,1);
            
             
                Ponepixel=P3(i,j,:);
             Ponepixel=reshape(Ponepixel,420,1);
             
             
                Ronepixel=RR3(i,j,:);
             Ronepixel=reshape(Ronepixel,420,1);
            
             
                SMonepixel=SM3(i,j,:);
             SMonepixel=reshape(SMonepixel,420,1);
            
        
            
             CO2onepixel=CO23(i,j,:);
             CO2onepixel=reshape(CO2onepixel,420,1);
              
            
              
   % ===== 构造样本（不做筛选，固定 420×4 与 420×1）=====
x = [SMonepixel, Ponepixel, Tonepixel, Ronepixel];  % 420x4
y = onepixel;                                       % 420x1

% —— 随机 20% 验证集，80% 训练集（可复现）——
rng(i*1000 + j);                 % 或固定 rng(2025) 以像元间一致
cv = cvpartition(420, 'Holdout', 0.2);
trIdx = training(cv);
teIdx = test(cv);

Xtr = x(trIdx, :);  Ytr = y(trIdx, :);
Xte = x(teIdx, :);  Yte = y(teIdx, :);

% —— 标准化：仅用训练集拟合，再应用到验证集（避免泄漏）——
[Xtr_n, ps] = mapminmax(Xtr');           % (p x n_tr)
Xtr_n = Xtr_n';                          % (n_tr x p)
Xte_n = mapminmax('apply', Xte', ps)';   % (n_te x p)

% ===== BRT（Boosted Regression Trees）=====
% 核心：弱树（浅树） + 多轮 boosting + 小学习率
% 注：BRT 不做“NumVariablesToSample”随机子特征抽样（那是 RF 的概念）
t = templateTree( ...
    'MinLeafSize', 10, ...        % 建议 5~20；更大更稳健
    'MaxNumSplits', 6, ...        % 建议 4~10；浅树更符合 BRT
    'Surrogate','off' ...         % 更快/更稳
    );

model = fitrensemble( ...
    Xtr_n, Ytr, ...
    'Method', 'LSBoost', ...      % 回归 boosting（平方误差），即 BRT/GBDT 框架
    'Learners', t, ...
    'NumLearningCycles', 500, ... % 建议 300~1500（配合小学习率）
    'LearnRate', 0.05 ...         % 建议 0.01~0.1
    );

% —— 在验证集上评估 R² —— 
y_pred = predict(model, Xte_n);
SST = sum((Yte - mean(Yte)).^2);
SSE = sum((Yte - y_pred).^2);
if SST > 0
    R_squared = 1 - SSE / SST;
else
    R_squared = NaN;   % 极少见：验证集全常数
end

% —— 变量重要性（BRT：基于分裂带来的误差下降累计）——
variable_importance = predictorImportance(model);  % 1 x 4

% —— 保留你的打印 —— 
fprintf('R-squared: %.4f\n', R_squared);
for ii = 1:length(variable_importance)
    fprintf('Variable %d importance: %.4f\n', ii, variable_importance(ii));
end

% ===== 写回你的容器（验证集 R² + 重要性）=====
aaa = variable_importance(:)';                       % 1 x 4
annualfactorimportance = [annualfactorimportance; aaa];
annualR2(i, j) = R_squared;

annualfactorimportanceworld(i, j, 1) = aaa(1);  % 土壤水
annualfactorimportanceworld(i, j, 2) = aaa(2);  % 降水
annualfactorimportanceworld(i, j, 3) = aaa(3);  % 温度
annualfactorimportanceworld(i, j, 4) = aaa(4);  % 辐射


                    
        end
        i,j,"annual"
    end
   
 


end

%保存
fid=fopen('D:\GPPBRTannualfactorimportance.raw','wb');%存为raw
fwrite(fid,annualfactorimportanceworld,'single');
fclose(fid);
%保存
fid=fopen('D:\GPPBRTannualR2.raw','wb');%存为raw
fwrite(fid,annualR2,'single');
fclose(fid);




