%% =========================================================================================
% 6 scales (Fluxnet HH/DD/MM + RS Monthly/Annual/Long-term)
% GBDT (LSBoost) + ONE FIGURE (1×3) stacked contributions:
%   Col1: SW-limited | Col2: VPD-limited | Col3: Co-limited
%   Y-axis groups (TOP->BOTTOM): RS LT, RS AN, RS MO, FLUX MM, FLUX DD, FLUX HH
%   Each group: relative factor contribution (%) of [SW, VPD, T, P, R, CO2]
%     - CO2 only exists for RS Long-term; other scales CO2=0 (renormalized to 100)
%
% WL classification:
%   - FLUX: EXACTLY follows your WL-screening program (q75 high-VPD test + pcor sign; q25 low-SW test + pcor sign)
%   - RS: read your precomputed WL maps
%
% GBDT:
%   - Blocked K-fold CV, keep models with CV-R2 > R2_keep_for_imp
%   - importance = predictorImportance(model), normalized to sum=100 per model
%   - report mean±SEM across kept models for each (scale, WL type)
%
% UPDATE:
%   1) Remove "n=..." text annotations in FIG1
%   2) Add FIG2: CV-R2 histograms (2×3), one subplot per timescale
%   3) FIG1: add value labels on each stacked block (1 decimal)
%   4) ALL fonts (including legend) = 1.5× previous
%
% Tested: MATLAB R2021a
% -----------------------------------------------------------------------------------------

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
rng(2025);

tAll = tic;

%% ===================== Global font scale (1.5x) =====================
fontScale = 1.5;

%% ===================== GBDT settings =====================
Kfold_outer = 5;
R2_keep_for_imp = 0;  % threshold for keeping models in importance summary (same as your code)

gbdt_numTrees  = 200;     % NumLearningCycles
gbdt_learnRate = 0.01;    % LearnRate
gbdt_maxSplits = 20;      % MaxNumSplits
gbdt_minLeaf   = 5;       % MinLeafSize

minN_flux = struct('HH',40,'DD',40,'MM',40);  % keep consistent with your WL minN_total_map
minN_rs   = 40;

%% ===================== WL screening settings (same as your program) =====================
alpha = 0.05;
qLow  = 25;
qHigh = 75;

% RS Monthly GS filter
useMonthlyGS = true;
gsFracP90_RS = 0.2;

% Optional GS filter for FLUXNET MM (keep same default OFF)
useGS_for_MM_flux = false;
gsFracP90_flux = 0.2;

%% ===================== RS Paths (same as your program) =====================
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw"; % 720x360x420
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";  % 468
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";   % 468
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw"; % 468
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw"; % 468
VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468

GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');

GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 492

% WL maps already computed by your WL program (we directly read them)
WL_MO_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw';
WL_AN_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_Annual_q25_ttest_pcor_f32_720x360.raw';
WL_LT_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw';

%% ===================== FLUXNET Paths (exactly your program) =====================
rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);

%% ===================== Outputs =====================
outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end
outFig1 = fullfile(outDir, sprintf('FIG_GBDT_RelativeFactorContribution_1x3_CVR2gt%.1f.png', R2_keep_for_imp));
outFig2 = fullfile(outDir, sprintf('FIG_GBDT_CVR2_Hist_2x3.png'));

%% ===================== Basic RS dims =====================
nx = 720; ny = 360;

%% ===================== Check RS files =====================
mustFiles_RS = {lulcPath,hfpPath,...
    GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path,...
    GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path,...
    GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path,CO2_LT_path,...
    WL_MO_path, WL_AN_path, WL_LT_path};

for k=1:numel(mustFiles_RS)
    assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
end

%% ===================== RS mask =====================
IGBP = imread(lulcPath)'; 
HFP  = imread(hfpPath)';

assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
valid_mask = ismember(IGBP,1:10) & (HFP<=25);
fprintf('RS valid pixels (veg & HFP<=25): %d\n', nnz(valid_mask));

%% ===================== Read RS WL maps =====================
WL_MO = read_raw_2d_single(WL_MO_path,[nx ny]);
WL_AN = read_raw_2d_single(WL_AN_path,[nx ny]);
WL_LT = read_raw_2d_single(WL_LT_path,[nx ny]);

WL_MO(~ismember(WL_MO,[0 1 2 3 4])) = 0;
WL_AN(~ismember(WL_AN,[0 1 2 3 4])) = 0;
WL_LT(~ismember(WL_LT,[0 1 2 3 4])) = 0;

%% ===================== Read RS data blocks (auto-detect 420 vs 468) =====================
fprintf('Reading RS data blocks...\n');
Tlen   = 420;
rawLen = 468;
sFrom  = 25;
sTo    = 444;

% Monthly
GPP_MO = read_raw_3d_auto(GPP_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_MO   = read_raw_3d_auto(T_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_MO   = read_raw_3d_auto(P_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_MO   = read_raw_3d_auto(R_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_MO  = read_raw_3d_auto(SW_MO_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_MO = read_raw_3d_auto(VPD_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

% Annual
GPP_AN = read_raw_3d_auto(GPP_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_AN   = read_raw_3d_auto(T_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_AN   = read_raw_3d_auto(P_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_AN   = read_raw_3d_auto(R_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_AN  = read_raw_3d_auto(SW_AN_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_AN = read_raw_3d_auto(VPD_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

% Long-term
GPP_LT = read_raw_3d_auto(GPP_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_LT   = read_raw_3d_auto(T_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_LT   = read_raw_3d_auto(P_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_LT   = read_raw_3d_auto(R_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_LT  = read_raw_3d_auto(SW_LT_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_LT = read_raw_3d_auto(VPD_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

% CO2 (492 -> 420)
CO2_LT = read_raw_3d_fixed492_slice420(CO2_LT_path, nx, ny, 492, 25, 444);

fprintf('RS data loaded.\n');

%% =========================================================================================
%% ===================== Containers (6 scales × 3 WL types) ================================
% WL types: 1 SW, 2 VPD, 3 Co
% importance aligned to: [SW, VPD, T, P, R, CO2]
impCell = cell(6,3);     % each: [nModels × 6]
nKeep   = zeros(6,3);    % kept models count (CV-R2 > threshold)

% store CV-R2 for histogram per scale
R2Cell = cell(6,1);      % each: [nModels × 1]

plotScaleNames = {'RS Long-term','RS Annual','RS Monthly','FLUX Monthly','FLUX Daily','FLUX Half-hourly'};

%% =========================================================================================
%% ===================== PART 1: FLUXNET read + WL class + GBDT ============================
fprintf('\n================== FLUXNET | read CSV + WL class + GBDT ==================\n');

yName = 'GPP_DT_VUT_REF';
vT    = 'TA_F_MDS';
vP    = 'P_F';
vR    = 'SW_IN_F_MDS';
vVPD  = 'VPD_F';
swcRegex = '^SWC_F_MDS_\d+$';

scaleList = {'HH','DD','MM'};
minN_total_map = containers.Map(scaleList, [300, 100, 40]);
minN_group_map = containers.Map(scaleList, [50,  20,  10]);

allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
targets = [];
for ii = 1:numel(allCSV)
    nm = allCSV(ii).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        targets = [targets; allCSV(ii)]; %#ok<AGROW>
    end
end
assert(~isempty(targets), '未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
fprintf('FLUXNET 可用文件（HH/DD/MM）：%d 个\n', numel(targets));

seen = containers.Map('KeyType','char','ValueType','logical');
t0 = tic;

for k = 1:numel(targets)
    fpath = fullfile(targets(k).folder, targets(k).name);
    [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
    if ~ismember(scaleTag, scaleList), continue; end

    key = sprintf('%s__%s', siteName, scaleTag);
    if isKey(seen,key), continue; end
    seen(key) = true;

    try
        opts = detectImportOptions(fpath);
        varNames = opts.VariableNames;

        needFixed = {yName, vT, vP, vR, vVPD};
        if ~all(ismember(needFixed, varNames))
            continue;
        end

        swcMask = ~cellfun('isempty', regexp(varNames, swcRegex,'once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols)
            continue;
        end

        selectVars = [needFixed, swcCols];
        opts.SelectedVariableNames = selectVars;
        Ttab = readtable(fpath, opts);
        Ttab = sentinel2nan(Ttab, opts.SelectedVariableNames);

        Y   = Ttab.(yName);
        TA  = Ttab.(vT);
        PP  = Ttab.(vP);
        RR  = Ttab.(vR);
        VPD = Ttab.(vVPD);

        SWCmat = Ttab{:, swcCols};
        if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SW = mean(SWCmat, 2, 'omitnan');

        if useGS_for_MM_flux && strcmp(scaleTag,'MM')
            ytmp = double(Y(:));
            ok0 = isfinite(ytmp) & (ytmp > 0);
            if nnz(ok0) >= 5
                P90 = prctile(ytmp(ok0), 90);
                thr = gsFracP90_flux * P90;
                gsMask = (ytmp > thr);
            else
                gsMask = false(size(ytmp));
            end
            Y(~gsMask)   = NaN;
            TA(~gsMask)  = NaN;
            PP(~gsMask)  = NaN;
            RR(~gsMask)  = NaN;
            SW(~gsMask)  = NaN;
            VPD(~gsMask) = NaN;
        end

        mask = isfinite(Y) & (Y>0) & isfinite(TA) & isfinite(PP) & isfinite(RR) & isfinite(SW) & isfinite(VPD);
        Y   = double(Y(mask));
        TA  = double(TA(mask));
        PP  = double(PP(mask));
        RR  = double(RR(mask));
        SW  = double(SW(mask));
        VPD = double(VPD(mask));

        minN_total = minN_total_map(scaleTag);
        minN_group = minN_group_map(scaleTag);

        if numel(Y) < minN_total
            continue;
        end

        % ---- WL classification (exactly your WL program) ----
        vpd_group_ok = is_highX_limits_gpp(Y, VPD, qHigh, alpha, minN_total, minN_group);
        Z_vpd = [TA, PP, RR, SW];
        [rv, pv2] = partialcorr_fast(Y, VPD, Z_vpd);
        pv1 = p_one_sided_from_two(pv2, rv, -1);
        vpd_pcor_ok = isfinite(pv1) && (pv1 < alpha) && (rv < 0);
        vpd_lim = vpd_group_ok && vpd_pcor_ok;

        sw_group_ok = is_lowX_limits_gpp(Y, SW, qLow, alpha, minN_total, minN_group);
        Z_sw = [TA, PP, RR, VPD];
        [rsw, psw2] = partialcorr_fast(Y, SW, Z_sw);
        psw1 = p_one_sided_from_two(psw2, rsw, +1);
        sw_pcor_ok = isfinite(psw1) && (psw1 < alpha) && (rsw > 0);
        sw_lim = sw_group_ok && sw_pcor_ok;

        if sw_lim && ~vpd_lim
            cls = 1;
        elseif vpd_lim && ~sw_lim
            cls = 2;
        elseif sw_lim && vpd_lim
            cls = 3;
        else
            cls = 4;
        end

        if cls<1 || cls>3
            continue;
        end

        % ---- GBDT importance ----
        rowPlot = fluxScale_to_plotRow(scaleTag); % MM->4 DD->5 HH->6
        Xraw = [SW, VPD, TA, PP, RR];
        yraw = Y;

        [okM, imp6, R2cv] = gbdt_one_series_importance(yraw, Xraw, false, [], minN_total, Kfold_outer, ...
            gbdt_numTrees, gbdt_learnRate, gbdt_maxSplits, gbdt_minLeaf);

        if okM && isfinite(R2cv)
            R2Cell{rowPlot} = [R2Cell{rowPlot}; R2cv]; %#ok<AGROW>
        end

        if okM && isfinite(R2cv) && (R2cv > R2_keep_for_imp)
            impCell{rowPlot, cls} = [impCell{rowPlot, cls}; imp6]; %#ok<AGROW>
            nKeep(rowPlot, cls) = nKeep(rowPlot, cls) + 1;
        end

    catch
        continue;
    end

    if mod(k,50)==0
        fprintf('FLUX progress %d/%d | elapsed %.1fs\n', k, numel(targets), toc(t0));
        t0 = tic;
    end
end

fprintf('FLUXNET GBDT done.\n');

%% =========================================================================================
%% ===================== PART 2: RS GBDT by WL maps =======================================
fprintf('\n================== RS | GBDT by WL maps ==================\n');

tRow = tic;
nVisited = 0;
nValidBase = nnz(valid_mask);

for i = 1:nx
    for j = 1:ny
        if ~valid_mask(i,j), continue; end
        nVisited = nVisited + 1;

        % ---------- RS Monthly (plot row 3) ----------
        c = WL_MO(i,j);
        if c>=1 && c<=3
            y  = squeeze(GPP_MO(i,j,:));
            sw = squeeze(SW_MO(i,j,:));
            vpd= squeeze(VPD_MO(i,j,:));
            tt = squeeze(T_MO(i,j,:));
            pp = squeeze(P_MO(i,j,:));
            rr = squeeze(R_MO(i,j,:));

            if useMonthlyGS
                [y, sw, vpd, tt, pp, rr, ~] = apply_gs_filter(y, sw, vpd, tt, pp, rr, [], gsFracP90_RS);
            end

            Xraw = [sw(:), vpd(:), tt(:), pp(:), rr(:)];
            [okM, imp6, R2cv] = gbdt_one_series_importance(y, Xraw, false, [], minN_rs, Kfold_outer, ...
                gbdt_numTrees, gbdt_learnRate, gbdt_maxSplits, gbdt_minLeaf);

            if okM && isfinite(R2cv)
                R2Cell{3} = [R2Cell{3}; R2cv]; %#ok<AGROW>
            end

            if okM && isfinite(R2cv) && (R2cv > R2_keep_for_imp)
                impCell{3, c} = [impCell{3, c}; imp6]; %#ok<AGROW>
                nKeep(3, c) = nKeep(3, c) + 1;
            end
        end

        % ---------- RS Annual (plot row 2) ----------
        c = WL_AN(i,j);
        if c>=1 && c<=3
            y  = squeeze(GPP_AN(i,j,:));
            sw = squeeze(SW_AN(i,j,:));
            vpd= squeeze(VPD_AN(i,j,:));
            tt = squeeze(T_AN(i,j,:));
            pp = squeeze(P_AN(i,j,:));
            rr = squeeze(R_AN(i,j,:));

            Xraw = [sw(:), vpd(:), tt(:), pp(:), rr(:)];
            [okM, imp6, R2cv] = gbdt_one_series_importance(y, Xraw, false, [], minN_rs, Kfold_outer, ...
                gbdt_numTrees, gbdt_learnRate, gbdt_maxSplits, gbdt_minLeaf);

            if okM && isfinite(R2cv)
                R2Cell{2} = [R2Cell{2}; R2cv]; %#ok<AGROW>
            end

            if okM && isfinite(R2cv) && (R2cv > R2_keep_for_imp)
                impCell{2, c} = [impCell{2, c}; imp6]; %#ok<AGROW>
                nKeep(2, c) = nKeep(2, c) + 1;
            end
        end

        % ---------- RS Long-term (plot row 1; include CO2) ----------
        c = WL_LT(i,j);
        if c>=1 && c<=3
            y  = squeeze(GPP_LT(i,j,:));
            sw = squeeze(SW_LT(i,j,:));
            vpd= squeeze(VPD_LT(i,j,:));
            tt = squeeze(T_LT(i,j,:));
            pp = squeeze(P_LT(i,j,:));
            rr = squeeze(R_LT(i,j,:));
            co2= squeeze(CO2_LT(i,j,:));

            Xraw = [sw(:), vpd(:), tt(:), pp(:), rr(:)];
            [okM, imp6, R2cv] = gbdt_one_series_importance(y, Xraw, true, co2, minN_rs, Kfold_outer, ...
                gbdt_numTrees, gbdt_learnRate, gbdt_maxSplits, gbdt_minLeaf);

            if okM && isfinite(R2cv)
                R2Cell{1} = [R2Cell{1}; R2cv]; %#ok<AGROW>
            end

            if okM && isfinite(R2cv) && (R2cv > R2_keep_for_imp)
                impCell{1, c} = [impCell{1, c}; imp6]; %#ok<AGROW>
                nKeep(1, c) = nKeep(1, c) + 1;
            end
        end
    end

    if mod(i,40)==0
        pct = 100*(nVisited/max(nValidBase,1));
        fprintf('  RS row %3d/720 | visited %d/%d (%.1f%%) | elapsed %.1fs\n', ...
            i, nVisited, nValidBase, pct, toc(tRow));
        tRow = tic;
    end
end

fprintf('RS GBDT done.\n');

%% =========================================================================================
%% ===================== Make summary matrices (mean %; also SEM) ==========================
predNames = {'SW','VPD','T','P','R','CO2'};

meanMat = nan(6,3,6);
semMat  = nan(6,3,6);

for si = 1:6
    for ci = 1:3
        A = impCell{si,ci};
        if isempty(A)
            continue;
        end
        m = mean(A,1,'omitnan');
        sd = std(A,0,1,'omitnan');
        n  = size(A,1);
        se = sd ./ sqrt(max(n,1));

        m(m<0) = 0;
        ssum = sum(m);
        if ssum>0
            m  = 100 * (m./ssum);
            se = 100 * (se./ssum);
        end

        meanMat(si,ci,:) = m;
        semMat(si,ci,:)  = se;
    end
end

%% =========================================================================================
%% ===================== Plot FIG1 (1×3) contributions + value labels =====================
col_SW  = [0.63 0.82 0.45];
col_VPD = [0.55 0.40 0.74];
col_T   = [0.96 0.51 0.49];
col_P   = [0.25 0.63 0.76];
col_R   = [0.96 0.72 0.36];
col_CO2 = [0.70 0.70 0.70];
C = [col_SW; col_VPD; col_T; col_P; col_R; col_CO2];

classNames = {'SW-limited','VPD-limited','Co-limited'};

figure('Color','w','Position',[50 80 1600 650]);
tiledlayout(1,3,'Padding','compact','TileSpacing','compact');

yLabels = plotScaleNames;

baseTickFS = 11;
baseTitleFS = 13;
baseLabelFS = 12;
baseLegendFS = 11;

tickFS   = round(baseTickFS  * fontScale);
titleFS  = round(baseTitleFS * fontScale);
labelFS  = round(baseLabelFS * fontScale);
legendFS = round(baseLegendFS* fontScale);
valFS    = round(10 * fontScale);

for ci = 1:3
    ax = nexttile(ci); hold(ax,'on');

    M = squeeze(meanMat(:,ci,:)); % 6x6
    if all(~isfinite(M(:)))
        axis(ax,'off');
        title(ax, sprintf('%s', classNames{ci}), 'FontWeight','bold', 'FontSize',titleFS);
        continue;
    end

    M(~isfinite(M)) = 0;

    bh = barh(ax, M, 'stacked', 'BarWidth', 0.72);
    for k = 1:numel(bh)
        bh(k).FaceColor = C(k,:);
        bh(k).EdgeColor = 'none';
    end

    set(ax,'YDir','reverse');
    set(ax,'YTick',1:6,'YTickLabel',yLabels,'TickDir','out','FontSize',tickFS);
    xlim(ax,[0 100]);
    xlabel(ax,'Relative factor contribution (%)','FontSize',labelFS);
    grid(ax,'on'); box(ax,'off');

    title(ax, sprintf('%s', classNames{ci}), 'FontWeight','bold','FontSize',titleFS);

    % --------- VALUE LABELS on each stacked block (1 decimal) ----------
    % For each row (bar), place text at the center of each segment
    for r = 1:6
        cumL = 0;
        for k = 1:6
            v = M(r,k);
            if v <= 0
                continue;
            end
            xCenter = cumL + v/2;
            yCenter = r;

            % show only if block wide enough to avoid clutter
            if v >= 10.0
                text(ax, xCenter, yCenter, sprintf('%.1f', v), ...
                    'HorizontalAlignment','center', ...
                    'VerticalAlignment','middle', ...
                    'FontSize', valFS, ...
                    'FontName','Arial', ...
                    'Color','k', ...
                    'Clipping','on');
            end
            cumL = cumL + v;
        end
    end

    if ci==3
        lgd = legend(ax, predNames, 'Location','southoutside', 'NumColumns',6, 'FontSize',legendFS);
        lgd.Box = 'off';
    end
end

exportgraphics(gcf, outFig1, 'Resolution', 300);
fprintf('✅ Saved: %s\n', outFig1);

%% =========================================================================================
%% ===================== Plot FIG2 (2×3) CV-R2 histograms (fonts 1.5x) =====================
figure('Color','w','Position',[50 50 1600 800]);
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

edges = linspace(-1, 1, 41);

for si = 1:6
    ax = nexttile(si); hold(ax,'on');
    r2v = R2Cell{si};
    if isempty(r2v)
        axis(ax,'off');
        title(ax, sprintf('%s (no models)', plotScaleNames{si}), 'FontWeight','bold', 'FontSize',titleFS);
        continue;
    end
    r2v = r2v(isfinite(r2v));
    if isempty(r2v)
        axis(ax,'off');
        title(ax, sprintf('%s (no models)', plotScaleNames{si}), 'FontWeight','bold', 'FontSize',titleFS);
        continue;
    end

    histogram(ax, r2v, edges);
    xline(ax, R2_keep_for_imp, '--', 'LineWidth', 1.2);

    xlim(ax, [-1 1]);
    grid(ax,'on'); box(ax,'off');
    set(ax,'FontSize',tickFS,'TickDir','out');
    xlabel(ax,'CV-R^2','FontSize',labelFS);
    ylabel(ax,'Count','FontSize',labelFS);
    title(ax, sprintf('%s', plotScaleNames{si}), 'FontWeight','bold','FontSize',titleFS);
end

exportgraphics(gcf, outFig2, 'Resolution', 300);
fprintf('✅ Saved: %s\n', outFig2);

fprintf('\nALL DONE. Total time: %.1f s\n', toc(tAll));

%% =========================================================================================
%% ===================================== HELPERS ==========================================
function rowPlot = fluxScale_to_plotRow(scaleTag)
switch upper(scaleTag)
    case 'MM', rowPlot = 4;
    case 'DD', rowPlot = 5;
    case 'HH', rowPlot = 6;
    otherwise, rowPlot = NaN;
end
end

function [ok, imp6, R2cv] = gbdt_one_series_importance(y, X5, useCO2, co2, minN, Kfold_outer, ...
    numTrees, learnRate, maxSplits, minLeaf)

ok=false; imp6=nan(1,6); R2cv=NaN;

y = y(:);
X5 = double(X5);

if useCO2
    co2 = co2(:);
    M = [y X5 co2];
else
    M = [y X5];
end
mk0 = all(isfinite(M),2) & (y>0);
if nnz(mk0) < minN, return; end

y  = double(y(mk0));
X5 = double(X5(mk0,:));
if useCO2
    co2 = double(co2(mk0));
    Xraw = [X5 co2];
else
    Xraw = X5;
end

n = size(Xraw,1);
if n < minN, return; end

K = min(Kfold_outer, n);
folds = blocked_kfold(n, K);

yhat = nan(n,1);
ytrue= nan(n,1);

for k=1:K
    te = folds{k};
    tr = true(n,1); tr(te)=false;

    Xtr0 = Xraw(tr,:); ytr0 = y(tr);
    Xte0 = Xraw(te,:); yte0 = y(te);

    [Xtr, muX, sigX] = zscore_train_apply(Xtr0);
    Xte = (Xte0 - muX) ./ sigX;

    [ytr, muy, sigy] = zscore_train_apply(ytr0);
    yte = (yte0 - muy) ./ sigy;

    if any(~isfinite(Xtr(:))) || any(~isfinite(Xte(:))) || any(~isfinite(ytr)) || any(~isfinite(yte))
        continue;
    end

    try
        tTree = templateTree('MaxNumSplits', maxSplits, 'MinLeafSize', minLeaf);
        mdl = fitrensemble(Xtr, ytr, ...
            'Method','LSBoost', ...
            'NumLearningCycles', numTrees, ...
            'LearnRate', learnRate, ...
            'Learners', tTree);
        yhat(te)  = predict(mdl, Xte);
        ytrue(te) = yte;
    catch
    end
end

good = isfinite(yhat) & isfinite(ytrue);
if nnz(good) < max(10, round(0.6*n)), return; end

ssRes = sum((ytrue(good) - yhat(good)).^2);
ssTot = sum((ytrue(good) - mean(ytrue(good))).^2);
if ssTot <= 0, return; end
R2cv = 1 - ssRes/ssTot;

Xfull = zscore(Xraw);
yfull = zscore(y);
mkF = all(isfinite([yfull Xfull]),2);
Xfull = Xfull(mkF,:); yfull = yfull(mkF);
if size(Xfull,1) < minN, return; end

try
    tTree = templateTree('MaxNumSplits', maxSplits, 'MinLeafSize', minLeaf);
    mdlF = fitrensemble(Xfull, yfull, ...
        'Method','LSBoost', ...
        'NumLearningCycles', numTrees, ...
        'LearnRate', learnRate, ...
        'Learners', tTree);

    imp = predictorImportance(mdlF);
    imp = double(imp(:))';
catch
    return;
end

if any(~isfinite(imp)) || all(imp<=0)
    return;
end

if size(Xraw,2)==5
    imp6 = [imp(:)' 0];
else
    imp6 = imp(:)';
end

imp6(imp6<0) = 0;
ss = sum(imp6);
if ss>0
    imp6 = 100*(imp6./ss);
end

ok=true;
end

function A = read_raw_3d_auto(path, shape2, Tlen, rawLen, sFrom, sTo)
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);
nTot = numel(dat);
n1 = nx*ny*Tlen;
n2 = nx*ny*rawLen;

if nTot == n1
    A = reshape(dat, [nx, ny, Tlen]);
elseif nTot == n2
    A = reshape(dat, [nx, ny, rawLen]);
    A = A(:,:,sFrom:sTo);
else
    error('Unexpected file size for %s: got %d floats; expected %d (420) or %d (468).', path, nTot, n1, n2);
end
end

function A = read_raw_2d_single(path, shape2)
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end

function CO2 = read_raw_3d_fixed492_slice420(path, nx, ny, co2Len, sFrom, sTo)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s', path);
tmp = fread(fid, nx*ny*co2Len, 'single');
fclose(fid);
tmp = reshape(tmp, [nx, ny, co2Len]);
CO2 = tmp(:,:,sFrom:sTo);
end

function folds = blocked_kfold(n, K)
edges = round(linspace(0, n, K+1));
folds = cell(K,1);
for k=1:K
    a = edges(k)+1; b = edges(k+1);
    folds{k} = (a:b)';
end
end

function [Z, mu, sig] = zscore_train_apply(X)
mu  = mean(X,1,'omitnan');
sig = std(X,0,1,'omitnan');
sig(sig < 1e-12) = 1;
Z = (X - mu) ./ sig;
end

function [y, sw, vpd, tt, pp, rr, co2] = apply_gs_filter(y, sw, vpd, tt, pp, rr, co2, fracP90)
y = y(:); sw=sw(:); vpd=vpd(:); tt=tt(:); pp=pp(:); rr=rr(:);
if ~isempty(co2), co2=co2(:); end

yd = double(y);
ok0 = isfinite(yd) & (yd>0);
if nnz(ok0) < 5
    y(:)=NaN; sw(:)=NaN; vpd(:)=NaN; tt(:)=NaN; pp(:)=NaN; rr(:)=NaN;
    if ~isempty(co2), co2(:)=NaN; end
    return;
end
P90 = prctile(yd(ok0), 90);
thr = fracP90 * P90;
gsMask = (yd > thr);

y(~gsMask)=NaN; sw(~gsMask)=NaN; vpd(~gsMask)=NaN; tt(~gsMask)=NaN; pp(~gsMask)=NaN; rr(~gsMask)=NaN;
if ~isempty(co2), co2(~gsMask)=NaN; end
end

function Tout = sentinel2nan(T, names)
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v)
        v = double(str2double(string(v)));
    else
        v = double(v);
    end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
Tout = T;
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM';
else
    scaleTag = 'OTHER';
end
end

function ok = is_lowX_limits_gpp(gpp, X, qPercent, alpha, minN_total, minN_group)
ok = false;
gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total, return; end
gpp = gpp(mask); X = X(mask);

q = prctile(X, qPercent);
idx_low  = (X <= q);
idx_high = (X >  q);

nL = nnz(idx_low); nH = nnz(idx_high);
if (nL < minN_group) || (nH < minN_group), return; end

gL = gpp(idx_low);
gH = gpp(idx_high);

if mean(gL) >= mean(gH), return; end

try
    [h, p] = ttest2(gL, gH, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function ok = is_highX_limits_gpp(gpp, X, qPercentHigh, alpha, minN_total, minN_group)
ok = false;
gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total, return; end
gpp = gpp(mask); X = X(mask);

qH = prctile(X, qPercentHigh);
idx_high = (X >= qH);
idx_low  = (X <  qH);

nH = nnz(idx_high); nL = nnz(idx_low);
if (nH < minN_group) || (nL < minN_group), return; end

gH = gpp(idx_high);
gL = gpp(idx_low);

if mean(gH) >= mean(gL), return; end

try
    [h, p] = ttest2(gH, gL, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function p1 = p_one_sided_from_two(p2, r, expectSign)
if ~isfinite(p2) || ~isfinite(r)
    p1 = NaN; return;
end
if expectSign > 0
    if r > 0, p1 = p2/2; else, p1 = 1; end
else
    if r < 0, p1 = p2/2; else, p1 = 1; end
end
end

function [r, p] = partialcorr_fast(y, x, Z)
r = NaN; p = NaN;
y = y(:); x = x(:);
if isempty(Z)
    M = [y x];
else
    Z = double(Z);
    M = [y x Z];
end
good = all(isfinite(M),2);
M = M(good,:);

n = size(M,1);
k = size(M,2) - 2;
df = n - k - 2;
if df < 3, return; end

yy = M(:,1);
xx = M(:,2);

if k==0
    ry = yy - mean(yy);
    rx = xx - mean(xx);
else
    ZZ = M(:,3:end);
    A  = [ones(n,1), ZZ];
    by = A \ yy;  ry = yy - A*by;
    bx = A \ xx;  rx = xx - A*bx;
end

ry = ry - mean(ry);
rx = rx - mean(rx);
den = sqrt(sum(ry.^2) * sum(rx.^2));
if den==0, return; end

r = sum(ry .* rx) / den;
t = r * sqrt(df / max(1e-12, (1 - r^2)));
p = 2 * (1 - tcdf(abs(t), df));
end
