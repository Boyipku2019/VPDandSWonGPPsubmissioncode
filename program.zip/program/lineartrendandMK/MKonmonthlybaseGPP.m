clc;clear all;close all;
% 读取用地类型数据
IGBP=imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP=IGBP';

HFP=imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');
HFP=HFP';

% 读取GPP月尺度数据（1984-2018，420期）
All=single(zeros(720,360,420));
fid = fopen('G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw','r');
All = fread(fid,720*360*420,'single');
fclose(fid);
All=reshape(All,[720,360,420]);

% 统计结果：1=显著升高，2=不显著升高，3=不显著下降，4=显著下降
ENF=single(zeros(4,1));ENFcount=0;
EBF=single(zeros(4,1));EBFcount=0;
DNF=single(zeros(4,1));DNFcount=0;
DBF=single(zeros(4,1));DBFcount=0;
MF =single(zeros(4,1));MFcount =0;
SHL=single(zeros(4,1));SHLcount=0;
SVA=single(zeros(4,1));SVAcount=0;
GRA=single(zeros(4,1));GRAcount=0;
WET=single(zeros(4,1));WETcount=0;

countall=0;
MKstat = single(zeros(720,360));
MKp    = single(zeros(720,360));
senslope = single(zeros(720,360));

nMonths = 420;
nYears  = 35;        % 1984–2018
monthsPerYear = 12;

for i=1:720
    for j=1:360
        % 先筛选植被类型与人类活动阈值
        if (IGBP(i,j)==1||IGBP(i,j)==2||IGBP(i,j)==3||IGBP(i,j)==4|| ...
            IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8|| ...
            IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11) && HFP(i,j)<=25

            % 取该像元的月序列
            tempMonthly = reshape(All(i,j,:), [nMonths,1]);  % 420x1
            tempMonthly = tempMonthly*0.01; % 产品系数

            % 若整条月序列全NaN则跳过
            if all(isnan(tempMonthly)), continue; end

            % ==== 按年平均：每12个月求一次年均 ====
            tempMonthly2D = reshape(tempMonthly, [monthsPerYear, nYears]); % 12x35
            tempAnnual    = mean(tempMonthly2D, 1, 'omitnan');             % 1x35（含NaN）

            % 至少需要3个有效年份才能做MK和Theil–Sen
            validMask = ~isnan(tempAnnual);
            if sum(validMask) < 3
                continue;
            end

            countall = countall + 1;

            % 取有效年份的序列与时间索引
            y = tempAnnual(validMask)';             % 列向量
            x = (1:numel(y))';                      % 用等间隔年份索引即可

            % ==== 年尺度 MK 检验 ====
            [h, p, mk_stat] = mann_kendall(y);     %#ok<ASGLU>

            % ==== 年尺度 Theil–Sen 斜率 ====
            slopetemp = theil_sen_slope(x, y);

            senslope(i,j) = slopetemp;   % 斜率单位：每年
            MKstat(i,j)   = mk_stat;
            MKp(i,j)      = p;

            % ==== 分类统计 ====
            if mk_stat>0 && p<0.05       % 显著升高
                if IGBP(i,j)==1,  ENF(1)=ENF(1)+1; ENFcount=ENFcount+1; end
                if IGBP(i,j)==2,  EBF(1)=EBF(1)+1; EBFcount=EBFcount+1; end
                if IGBP(i,j)==3,  DNF(1)=DNF(1)+1; DNFcount=DNFcount+1; end
                if IGBP(i,j)==4,  DBF(1)=DBF(1)+1; DBFcount=DBFcount+1; end
                if IGBP(i,j)==5,  MF(1) =MF(1) +1; MFcount =MFcount +1; end
                if IGBP(i,j)==6||IGBP(i,j)==7, SHL(1)=SHL(1)+1; SHLcount=SHLcount+1; end
                if IGBP(i,j)==8||IGBP(i,j)==9, SVA(1)=SVA(1)+1; SVAcount=SVAcount+1; end
                if IGBP(i,j)==10, GRA(1)=GRA(1)+1; GRAcount=GRAcount+1; end
                if IGBP(i,j)==11, WET(1)=WET(1)+1; WETcount=WETcount+1; end
            elseif mk_stat>0 && p>=0.05  % 不显著升高
                if IGBP(i,j)==1,  ENF(2)=ENF(2)+1; ENFcount=ENFcount+1; end
                if IGBP(i,j)==2,  EBF(2)=EBF(2)+1; EBFcount=EBFcount+1; end
                if IGBP(i,j)==3,  DNF(2)=DNF(2)+1; DNFcount=DNFcount+1; end
                if IGBP(i,j)==4,  DBF(2)=DBF(2)+1; DBFcount=DBFcount+1; end
                if IGBP(i,j)==5,  MF(2) =MF(2) +1; MFcount =MFcount +1; end
                if IGBP(i,j)==6||IGBP(i,j)==7, SHL(2)=SHL(2)+1; SHLcount=SHLcount+1; end
                if IGBP(i,j)==8||IGBP(i,j)==9, SVA(2)=SVA(2)+1; SVAcount=SVAcount+1; end
                if IGBP(i,j)==10, GRA(2)=GRA(2)+1; GRAcount=GRAcount+1; end
                if IGBP(i,j)==11, WET(2)=WET(2)+1; WETcount=WETcount+1; end
            elseif mk_stat<0 && p>=0.05  % 不显著下降
                if IGBP(i,j)==1,  ENF(3)=ENF(3)+1; ENFcount=ENFcount+1; end
                if IGBP(i,j)==2,  EBF(3)=EBF(3)+1; EBFcount=EBFcount+1; end
                if IGBP(i,j)==3,  DNF(3)=DNF(3)+1; DNFcount=DNFcount+1; end
                if IGBP(i,j)==4,  DBF(3)=DBF(3)+1; DBFcount=DBFcount+1; end
                if IGBP(i,j)==5,  MF(3) =MF(3) +1; MFcount =MFcount +1; end
                if IGBP(i,j)==6||IGBP(i,j)==7, SHL(3)=SHL(3)+1; SHLcount=SHLcount+1; end
                if IGBP(i,j)==8||IGBP(i,j)==9, SVA(3)=SVA(3)+1; SVAcount=SVAcount+1; end
                if IGBP(i,j)==10, GRA(3)=GRA(3)+1; GRAcount=GRAcount+1; end
                if IGBP(i,j)==11, WET(3)=WET(3)+1; WETcount=WETcount+1; end
            elseif mk_stat<0 && p<0.05   % 显著下降
                if IGBP(i,j)==1,  ENF(4)=ENF(4)+1; ENFcount=ENFcount+1; end
                if IGBP(i,j)==2,  EBF(4)=EBF(4)+1; EBFcount=EBFcount+1; end
                if IGBP(i,j)==3,  DNF(4)=DNF(4)+1; DNFcount=DNFcount+1; end
                if IGBP(i,j)==4,  DBF(4)=DBF(4)+1; DBFcount=DBFcount+1; end
                if IGBP(i,j)==5,  MF(4) =MF(4) +1; MFcount =MFcount +1; end
                if IGBP(i,j)==6||IGBP(i,j)==7, SHL(4)=SHL(4)+1; SHLcount=SHLcount+1; end
                if IGBP(i,j)==8||IGBP(i,j)==9, SVA(4)=SVA(4)+1; SVAcount=SVAcount+1; end
                if IGBP(i,j)==10, GRA(4)=GRA(4)+1; GRAcount=GRAcount+1; end
                if IGBP(i,j)==11, WET(4)=WET(4)+1; WETcount=WETcount+1; end
            end
        end
    end
    i
end

% 归一化为比例
ENF=ENF/max(ENFcount,1); EBF=EBF/max(EBFcount,1);
DNF=DNF/max(DNFcount,1); DBF=DBF/max(DBFcount,1);
MF =MF /max(MFcount,1);  SHL=SHL/max(SHLcount,1);
SVA=SVA/max(SVAcount,1); GRA=GRA/max(GRAcount,1);
WET=WET/max(WETcount,1);

% 组合绘图矩阵（百分比 0–100）
data = [ENF'; EBF'; DNF'; DBF'; MF'; SHL'; SVA'; GRA'; WET'] * 100;

%% ===== 出图：统一风格（无 ylabel，图例两行） =====
labels = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'};
colors = [ 0.12,0.47,0.71; 0.68,0.85,0.90; 1.00,0.60,0.20; 0.90,0.33,0.05 ];

FS_axis   = 18;
FS_text   = 24;  % 条内数字
FS_legend = 18;

fig_main = figure('Position',[100,100,800,600],'Color','w'); 
clf;

% 手动创建 axes，预留底部空间给 legend + xticks
ax = axes('Parent',fig_main);
ax.Units    = 'normalized';
ax.Position = [0.10 0.18 0.88 0.75];   % bottom=0.18，xticks 不被挡

% 绘图
hBar = bar(ax, data,'stacked');
for k = 1:length(hBar)
    hBar(k).FaceColor = colors(k,:);
end

set(ax,'XTick',1:size(data,1),'XTickLabel',labels, ...
    'FontSize',FS_axis,'FontName','Arial');

% 取消 ylabel（方便后期拼图）
% ylabel(ax,'Proportion (%)','FontSize',18);

ylim(ax,[0 100]);
yticks(ax,0:20:100);
yticklabels(ax,{'0%','20%','40%','60%','80%','100%'});

grid(ax,'on'); 
set(ax,'Box','on','LineWidth',1.5, ...
    'GridLineStyle','--','GridColor','k','GridAlpha',0.3);

% 条内数字（>10%的才标），整数
for ii=1:size(data,1)
    cumulativeData = cumsum(data(ii,:));
    for jj=1:size(data,2)
        if data(ii,jj) > 10
            xpos = ii;
            ypos = cumulativeData(jj) - data(ii,jj)/2;
            col  = colors(jj,:);
            luminance = 0.299*col(1)+0.587*col(2)+0.114*col(3);
            textColor = 'black'; 
            if luminance < 0.5, textColor='white'; end
            text(ax, xpos, ypos, sprintf('%.0f',data(ii,jj)), ...
                'FontSize',FS_text,'HorizontalAlignment','center', ...
                'Color',textColor,'FontName','Arial');
        end
    end
end

% 图例 —— 两行、底部中间
lgd = legend({'Significant increase','Non-significant increase', ...
              'Non-significant decrease','Significant decrease'}, ...
    'Orientation','horizontal','FontSize',FS_legend, ...
    'FontName','Arial','Box','off','NumColumns',2);

lgd.Units    = 'normalized';
lgd.Position = [0.25 0.02 0.55 0.10];   % 两行，高度略大

print(fig_main, 'D:\GPP_MK_trend_statistics.png', '-dpng', '-r300');

%% ===== 保存栅格结果 =====
fid=fopen('D:\GPPMKp05.raw','wb'); fwrite(fid,MKp,'single'); fclose(fid);
fid=fopen('D:\GPPsenslope_year.raw','wb'); fwrite(fid,senslope,'single'); fclose(fid);

%% ======= 函数：年尺度MK（不处理ties的简化版）=======
function [h, p, mk_stat] = mann_kendall(data)
    n = length(data);
    s = 0;
    for k = 1:n-1
        for j = k+1:n
            s = s + sign(data(j) - data(k));
        end
    end
    var_s = n*(n-1)*(2*n+5)/18;
    z = s / sqrt(var_s);
    p = 2 * (1 - normcdf(abs(z), 0, 1));
    alpha = 0.05;
    h = abs(z) > norminv(1 - alpha/2, 0, 1);
    mk_stat = s;
end

%% ======= 函数：Theil–Sen斜率（对x,y无NaN）=======
function slope = theil_sen_slope(x, y)
    % x,y 列向量；无 NaN
    x = x(:); y = y(:);
    n = numel(x);

    % 生成上三角索引（j>i）
    [I,J] = ndgrid(1:n, 1:n);
    mask = J > I;

    % 取配对差分并求所有成对斜率
    dx = x(J(mask)) - x(I(mask));
    dy = y(J(mask)) - y(I(mask));
    slopes = dy ./ dx;

    % 中位数即 Theil–Sen 估计
    slope = median(slopes);
end
