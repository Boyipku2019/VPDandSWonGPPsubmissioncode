%% ================== FLUXNET + RS 相关：5 面板热力图（紧凑；仅 Long-term 显示 CO2） ==================
% 面板：Half-hourly | Daily | Monthly | Annual | Long-term
% 数据来源：
%   - Half-hourly：FLUXNET（HH）
%   - Daily：      FLUXNET（DD）
%   - Monthly：    遥感（月尺度原始序列 raw；1984–2018）
%   - Annual：     遥感（SSA Annual）
%   - Long-term：  遥感（CEEMDAN Trend + 仅此面板显示 CO2 简单相关）
%
% 行：9类植被 + Average（10行）
% 列：
%   - 前 4 个面板：{T, P, R, SW}（4列）
%   - 最后一个面板（Long-term）：{T, P, R, SW, CO2}（5列，仅此面板显示 CO2）
%
% 规则：
%   - 仅计入 p < 0.05 的相关系数进行统计（未显著直接置 NaN，不计入均值）
%   - 样本量 > 40
%   - FLUXNET：要求 Y>0 且四自变量非 NaN（含 SWC 平均）
%   - 遥感：像元仅在 IGBP∈[1..11] 且 HFP<=25 时有效
%
% 输出：D:\corr_FLUXNET_RS_6panels_CO2_onlyLT_compact.png（300 dpi；1500×600像素）
% Tested: MATLAB R2021a

clear; clc; close all; warning('off','all');
tAll = tic;

%% ================== 路径配置（请按需修改） ==================
% ---- FLUXNET ----
rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
siteXlsx        = fullfile(rootFolder_FLUX, 'FLUXsitelistnew.xlsx');   % 第1列站名；第8列植被类型

% ---- 遥感（SSA/CEEMDAN 分解结果）----
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';   % IGBP 0.5°
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';    % HFP 掩膜

% ---- 遥感：Monthly（raw 原始序列）----
GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw";
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";

% ---- 遥感：Annual（SSA）----
GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');

% ---- 遥感：Long-term（Trend）----
GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % ← 如不同请改名

% ---- 断言 ----
assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);
assert(isfile(lulcPath),       'LULC 文件不存在：%s', lulcPath);
assert(isfile(hfpPath),        'HFP  文件不存在：%s', hfpPath);

assert(isfile(GPP_MO_path), 'Monthly GPP 文件不存在：%s', GPP_MO_path);
assert(isfile(T_MO_path),   'Monthly T 文件不存在：%s',   T_MO_path);
assert(isfile(P_MO_path),   'Monthly P 文件不存在：%s',   P_MO_path);
assert(isfile(R_MO_path),   'Monthly R 文件不存在：%s',   R_MO_path);
assert(isfile(SW_MO_path),  'Monthly SW 文件不存在：%s',  SW_MO_path);

assert(isfile(GPP_AN_path), 'AN GPP 文件不存在：%s', GPP_AN_path);
assert(isfile(T_AN_path),   'AN T 文件不存在：%s',   T_AN_path);
assert(isfile(P_AN_path),   'AN P 文件不存在：%s',   P_AN_path);
assert(isfile(R_AN_path),   'AN R 文件不存在：%s',   R_AN_path);
assert(isfile(SW_AN_path),  'AN SW 文件不存在：%s',  SW_AN_path);

assert(isfile(GPP_LT_path), 'LT GPP 文件不存在：%s', GPP_LT_path);
assert(isfile(T_LT_path),   'LT T 文件不存在：%s',   T_LT_path);
assert(isfile(P_LT_path),   'LT P 文件不存在：%s',   P_LT_path);
assert(isfile(R_LT_path),   'LT R 文件不存在：%s',   R_LT_path);
assert(isfile(SW_LT_path),  'LT SW 文件不存在：%s',  SW_LT_path);
assert(isfile(CO2_LT_path), 'LT CO2 文件不存在：%s', CO2_LT_path);

%% ================== 通用配置 ==================
alpha       = 0.05;                          % 显著性阈值
minN        = 40;                            % 样本量阈值
xlabels4    = {'T','P','R','SW'};            % 前面板使用
xlabels5    = {'T','P','R','SW','CO2'};      % Long-term 使用
vegRows     = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'}; % 10 行

panelTitles = {'Half-hourly','Daily','Monthly','Annual','Long-term'};
nPanels     = numel(panelTitles);

% —— 字体 ——（与前版一致）
baseAxisFont  = 15;
labelFont     = 16;
titleFont     = 18;
cellTextFont  = 14;

set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
set(groot,'DefaultAxesFontSize', baseAxisFont);

%% ================== Part A：FLUXNET 两尺度（HH/DD） ==================
% 读站点→植被类型映射
site2veg = containers.Map('KeyType','char','ValueType','char'); hasVegMap = false;
if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);
        names = string(Tsite{:,1});    % 站名
        vegs  = string(Tsite{:,8});    % 植被类型
        for ii = 1:numel(names)
            k = strtrim(names(ii)); v = strtrim(vegs(ii));
            if ~isempty(k); site2veg(char(k)) = char(v); end
        end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx，FLUXNET 端将无法按植被聚合。\n');
    end
end

% 容器：FLUXNET 两面板（每面板 10×4）
SUM_F = cell(1,2); COUNT_F = cell(1,2);
for s=1:2
    SUM_F{s}   = nan(10,4,'single');
    COUNT_F{s} = zeros(10,4,'uint32');
end

% 收集目标 CSV（必须包含 FULLSET 与 HH/DD）
allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
targets = [];
for ii = 1:numel(allCSV)
    nm = allCSV(ii).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) )
        targets = [targets; allCSV(ii)]; %#ok<AGROW>
    end
end
if isempty(targets)
    error('未找到 文件名包含 FULLSET 的 HH/DD CSV。');
else
    fprintf('FLUXNET 可用文件（HH/DD）：%d 个\n', numel(targets));
end

% 逐文件计算相关并聚合（只统计 p<alpha 的 r；其余置 NaN 不计入）
yName = 'GPP_DT_VUT_REF';
coreX = {'TA_F_MDS','P_F','SW_IN_F_MDS'};   % + SWC 平均
t0 = tic;
for k = 1:numel(targets)
    f = fullfile(targets(k).folder, targets(k).name);
    [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
    si = find(strcmp({'HH','DD'}, scaleTag), 1);    % 1..2
    if isempty(si), continue; end

    try
        % — 读取需要的列 —
        opts = detectImportOptions(f);
        varNames = opts.VariableNames;
        needFixed = [ {yName}, coreX ];
        if ~all(ismember(needFixed, varNames))
            fprintf('  ↳ 缺少 GPP/TA/P/SW_IN 列，跳过：%s\n', targets(k).name);
            continue;
        end

        % SWC_F_MDS_# 层
        swcMask = ~cellfun('isempty', regexp(varNames,'^SWC_F_MDS_\d+$','once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols)
            fprintf('  ↳ 无 SWC_F_MDS_# 层，跳过：%s\n', targets(k).name);
            continue;
        end

        opts.SelectedVariableNames = [needFixed, swcCols];
        T = readtable(f, opts);
        T = sentinel2nan(T, opts.SelectedVariableNames);

        % 计算 SWC 平均
        SWCmat  = T{:, swcCols}; if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SWC_avg = mean(SWCmat, 2, 'omitnan');

        % 取变量
        Y  = T.(yName); TA = T.TA_F_MDS; PP = T.P_F; SW = T.SW_IN_F_MDS;
        mask = ~isnan(Y) & Y>0 & ~isnan(TA) & ~isnan(PP) & ~isnan(SW) & ~isnan(SWC_avg);
        Y  = Y(mask);
        X4 = [TA(mask), PP(mask), SW(mask), SWC_avg(mask)];
        nobs = size(X4,1);
        if nobs <= minN, continue; end

        % 简单相关（并在函数内做显著性过滤：p>=alpha 的 r 置 NaN）
        [r4, p4] = corr_vec_sigonly(Y, X4, alpha);
        if isempty(r4), continue; end

        % 植被行号（默认 Average=10）
        ri = 10;
        if hasVegMap && isKey(site2veg, siteName)
            vname = site2veg(siteName);
            ridx  = find(strcmp(vegRows, vname),1);
            if ~isempty(ridx), ri = ridx; end
        end

        % 累加：只对 r 非 NaN 的条目
        SUM_F{si}   = add_into_sigonly(SUM_F{si}, ri, r4);
        COUNT_F{si} = add_count_sigonly(COUNT_F{si}, ri, r4);

        % Average 行同样累加（如果 ri 不是 10）
        if ri ~= 10
            SUM_F{si}   = add_into_sigonly(SUM_F{si}, 10, r4);
            COUNT_F{si} = add_count_sigonly(COUNT_F{si}, 10, r4);
        end

    catch ME
        fprintf('  ↳ 失败已跳过：%s | %s\n', targets(k).name, ME.message);
    end

    if mod(k,50)==0
        fprintf('  站点进度 %d/%d | 用时 %.1fs\n', k, numel(targets), toc(t0)); t0 = tic;
    end
end

% 计算 FLUXNET 两面板均值（只来自显著 r 的统计）
MEAN_F = cell(1,2);
for si = 1:2
    S = SUM_F{si}; C = COUNT_F{si};
    M = nan(size(S),'single');
    mk = C>0;
    M(mk) = S(mk) ./ single(C(mk));
    MEAN_F{si} = M;          % 每面板 10×4
end

%% ================== Part B：遥感 三尺度（Monthly raw + Annual + LT；HFP≤25） ==================
% 读 LULC 与 HFP 并设有效类
IGBP = imread(lulcPath); IGBP = IGBP';
HFP  = imread(hfpPath);  HFP  = HFP';
[nx, ny] = size(IGBP);                           % 720 × 360
valid_mask = ismember(IGBP, 1:11) & (HFP <= 25); % 联合掩膜

% ---- 读 Monthly raw（420）+ 气象（468→25:444=420）----
GPP_MO = read_raw(GPP_MO_path, [720,360,420]);   % 1984–2018 monthly
T_MO   = read_raw(T_MO_path,   [720,360,468]);   T_MO  = T_MO(:,:,25:444);
P_MO   = read_raw(P_MO_path,   [720,360,468]);   P_MO  = P_MO(:,:,25:444);
R_MO   = read_raw(R_MO_path,   [720,360,468]);   R_MO  = R_MO(:,:,25:444);
SW_MO  = read_raw(SW_MO_path,  [720,360,468]);   SW_MO = SW_MO(:,:,25:444);

% ---- 读 Annual（SSA）----
GPP_AN = read_raw(GPP_AN_path, [720,360,420]);
T_AN   = read_raw(T_AN_path,   [720,360,468]); T_AN=T_AN(:,:,25:444);
P_AN   = read_raw(P_AN_path,   [720,360,468]); P_AN=P_AN(:,:,25:444);
R_AN   = read_raw(R_AN_path,   [720,360,468]); R_AN=R_AN(:,:,25:444);
SW_AN  = read_raw(SW_AN_path,  [720,360,468]); SW_AN=SW_AN(:,:,25:444);

% ---- 读 Long-term（Trend）+ CO2（仅 LT 用）----
GPP_LT = read_raw(GPP_LT_path, [720,360,420]);
T_LT   = read_raw(T_LT_path,   [720,360,468]); T_LT=T_LT(:,:,25:444);
P_LT   = read_raw(P_LT_path,   [720,360,468]); P_LT=P_LT(:,:,25:444);
R_LT   = read_raw(R_LT_path,   [720,360,468]); R_LT=R_LT(:,:,25:444);
SW_LT  = read_raw(SW_LT_path,  [720,360,468]); SW_LT=SW_LT(:,:,25:444);
CO2_LT = read_raw(CO2_LT_path, [720,360,468]); CO2_LT=CO2_LT(:,:,25:444);

% 累加器：RS 三面板：Monthly(4) + Annual(4) + Long-term(5)
SUM_R   = {nan(10,4,'single'), nan(10,4,'single'), nan(10,5,'single')};
COUNT_R = {zeros(10,4,'uint32'), zeros(10,4,'uint32'), zeros(10,5,'uint32')};

fprintf('开始逐像元相关（720×360，含 HFP≤25 掩膜）...\n');
tRow = tic;

for i = 1:nx
    for j = 1:ny
        if ~valid_mask(i,j), continue; end
        ri = igbp_to_row(IGBP(i,j));   % 1..9；0=跳过
        if ri==0, continue; end

        % 1) Monthly（raw，4列）—— 只保留显著相关（p<alpha）
        y  = squeeze(GPP_MO(i,j,:));
        X4 = [squeeze(T_MO(i,j,:)), squeeze(P_MO(i,j,:)), squeeze(R_MO(i,j,:)), squeeze(SW_MO(i,j,:))];
        r4 = corr_vec_sigonly_minN(y, X4, minN, alpha);  % 未显著置 NaN
        if ~isempty(r4)
            SUM_R{1}   = add_into_sigonly(SUM_R{1}, ri, r4);
            COUNT_R{1} = add_count_sigonly(COUNT_R{1}, ri, r4);
            SUM_R{1}   = add_into_sigonly(SUM_R{1}, 10, r4);
            COUNT_R{1} = add_count_sigonly(COUNT_R{1}, 10, r4);
        end

        % 2) Annual（SSA，4列）
        y  = squeeze(GPP_AN(i,j,:));
        X4 = [squeeze(T_AN(i,j,:)), squeeze(P_AN(i,j,:)), squeeze(R_AN(i,j,:)), squeeze(SW_AN(i,j,:))];
        r4 = corr_vec_sigonly_minN(y, X4, minN, alpha);
        if ~isempty(r4)
            SUM_R{2}   = add_into_sigonly(SUM_R{2}, ri, r4);
            COUNT_R{2} = add_count_sigonly(COUNT_R{2}, ri, r4);
            SUM_R{2}   = add_into_sigonly(SUM_R{2}, 10, r4);
            COUNT_R{2} = add_count_sigonly(COUNT_R{2}, 10, r4);
        end

        % 3) Long-term：前4列（T/P/R/SW）显著相关；第5列 CO2 也按 p<alpha 过滤
        y  = squeeze(GPP_LT(i,j,:));
        X4 = [squeeze(T_LT(i,j,:)), squeeze(P_LT(i,j,:)), squeeze(R_LT(i,j,:)), squeeze(SW_LT(i,j,:))];
        r4 = corr_vec_sigonly_minN(y, X4, minN, alpha);

        % CO2 与 y 的简单相关（仅 LT）—— 同样只统计 p<alpha
        r_co2 = NaN;
        Mco2 = [y, squeeze(CO2_LT(i,j,:))];
        Mco2 = Mco2(all(isfinite(Mco2),2), :);
        if size(Mco2,1) > minN
            try
                [rc, pc] = corr(Mco2(:,1), Mco2(:,2), 'Rows','complete');
                if ~isnan(pc) && pc < alpha
                    r_co2 = rc;
                else
                    r_co2 = NaN;
                end
            catch
                r_co2 = NaN;
            end
        end

        r5 = [r4, r_co2];

        if ~isempty(r5)
            SUM_R{3}   = add_into_sigonly(SUM_R{3}, ri, r5);
            COUNT_R{3} = add_count_sigonly(COUNT_R{3}, ri, r5);
            SUM_R{3}   = add_into_sigonly(SUM_R{3}, 10, r5);
            COUNT_R{3} = add_count_sigonly(COUNT_R{3}, 10, r5);
        end
    end

    if mod(i,40)==0
        fprintf('  行进度 %3d/720 | 累计耗时 %.1fs\n', i, toc(tRow));
        tRow = tic;
    end
end

% 计算遥感三面板均值（只来自显著 r 的统计）
MEAN_R = cell(1,3);
for p = 1:3
    S = SUM_R{p}; C = COUNT_R{p};
    M = nan(size(S),'single');
    mk = C>0;
    M(mk) = S(mk) ./ single(C(mk));
    MEAN_R{p} = M;
end

%% ================== 合并 5 面板并绘图（紧凑布局；仅最后面板含 CO2） ==================
% 面板顺序：FLUX(HH,DD) + RS(MO,AN,LT)
MEAN_ALL = [MEAN_F, MEAN_R];   % {10x4,10x4,10x4,10x4,10x5}

cmap    = bwr_nature(255);           % 蓝→白→红
grayRGB = [150 150 150]/255;

% —— 紧凑布局设置（减少左右间距与内部间距）——
figW=1500; figH=600;
fig = figure('Color','w','Units','pixels','Position',[80 80 figW figH]);

leftPad=0.035; rightPad=0.006; topPad=0.06; bottomPad=0.23;  % 较小外边距
innerGap=0.005;                                              % 子图间距更小
tileW = (1 - leftPad - rightPad - innerGap*(nPanels-1)) / nPanels;
axH   = 1 - topPad - bottomPad;

for p = 1:nPanels
    axL = leftPad + (p-1)*(tileW + innerGap);
    ax  = axes('Position',[axL bottomPad tileW axH]); %#ok<LAXES>

    M = MEAN_ALL{p};

    % 先铺灰底显示 NaN
    gimg = repmat(reshape(grayRGB,1,1,3), [size(M,1), size(M,2), 1]);
    image(ax, 1:size(M,2), 1:size(M,1), gimg);
    set(ax,'YDir','normal'); axis(ax,'image'); hold(ax,'on');

    % 覆盖有效值（显著的均值）
    h = imagesc(ax, M, [-1 1]);
    set(h,'AlphaData',~isnan(M));
    colormap(ax, cmap);
    box(ax,'off'); ax.TickDir='out'; ax.LineWidth=0.75;

    % 坐标轴与标签（根据列数自适应）
    if p==1
        set(ax,'YTick',1:10,'YTickLabel',vegRows);
    else
        set(ax,'YTick',1:10,'YTickLabel',[]);
    end
    if size(M,2)==4
        set(ax,'XTick',1:4,'XTickLabel',xlabels4,'FontName','Arial');
    else
        set(ax,'XTick',1:5,'XTickLabel',xlabels5,'FontName','Arial');
    end
    ax.XTickLabelRotation = 45;
    ax.FontSize = baseAxisFont;

    title(ax, panelTitles{p}, 'FontWeight','bold','FontSize',titleFont-1,'FontName','Arial');

    % 在每格叠加均值（%.2f）—— 只有统计到显著相关时该格才非 NaN
    [nr, nc] = size(M);
    for r = 1:nr
        for c = 1:nc
            val = M(r,c);
            if ~isnan(val)
                if abs(val) >= 0.5, tColor=[1 1 1]; else, tColor=[0 0 0]; end
                text(c, r, sprintf('%.2f', fix(val*100) / 100), ...
                    'HorizontalAlignment','center', 'VerticalAlignment','middle', ...
                    'FontSize', cellTextFont, 'FontWeight','bold', ...
                    'FontName','Arial', 'Color', tColor);
            end
        end
    end
end

% —— 底部共享色条（紧贴下方）——
cbLeft = 0.12; cbWidth = 0.76; cbHeight = 0.035; cbBottom = 0.10;
cbAx = axes('Position',[cbLeft cbBottom cbWidth cbHeight]); %#ok<LAXES>
xx = linspace(-1,1,512); Cbar = [xx; xx];
imagesc(cbAx, [-1 1], [0 1], Cbar); colormap(cbAx, cmap); caxis(cbAx, [-1 1]);
set(cbAx,'YTick',[],'YColor','none','TickDir','out','LineWidth',0.75, ...
    'XTick',-1:0.2:1,'FontName','Arial','FontSize',baseAxisFont);
xlabel(cbAx,'Correlation coefficient','FontSize',labelFont,'FontName','Arial');

% 导出到 D 盘根目录，300 dpi
outPath = 'D:\corr_FLUXNET_RS_6panels_CO2_onlyLT_compact.png';
exportgraphics(fig, outPath, 'Resolution', 300);
fprintf('✅ 已保存：%s | 尺寸 %dx%d | 300dpi | 总耗时 %.1f 分钟\n', outPath, figW, figH, toc(tAll)/60);

%% ================== 辅助函数 ==================
function T = sentinel2nan(T, names)
% 把 -9999/超大异常 值转为 NaN
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v), v = double(str2double(string(v))); end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
% 从文件名解析尺度标签与站点名
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM'; % 这里保留，但主程序已不再使用 MM
else
    scaleTag = 'OTHER';
end
end

function [r, p] = corr_vec_sigonly(Y, X, alpha)
% 单变量相关：Y vs X(:,k)，并把 p>=alpha 的 r 置 NaN（只保留显著相关用于统计）
r = []; p = [];
M = [Y(:), X];
M = M(all(isfinite(M),2), :);
if size(M,1) <= 3, return; end
y = M(:,1); X = M(:,2:end);
pnum = size(X,2);
r = nan(1,pnum); p = nan(1,pnum);
for k=1:pnum
    try
        [rk, pk] = corr(y, X(:,k), 'Rows','complete');
    catch
        rk = NaN; pk = NaN;
    end
    if ~isnan(pk) && pk < alpha
        r(k) = rk;
        p(k) = pk;
    else
        r(k) = NaN;  % 未显著：直接剔除
        p(k) = pk;
    end
end
end

function r = corr_vec_sigonly_minN(y, X, minN, alpha)
% 同上：要求样本量 > minN；并仅保留显著相关（p<alpha）
r = [];
M = [y(:), X];
M = M(all(isfinite(M),2), :);
if size(M,1) <= minN, return; end
yy = M(:,1); XX = M(:,2:end);
pnum = size(XX,2);
r = nan(1,pnum);
for k = 1:pnum
    try
        [rk, pk] = corr(yy, XX(:,k), 'Rows','complete');
    catch
        rk = NaN; pk = NaN;
    end
    if ~isnan(pk) && pk < alpha
        r(k) = rk;
    else
        r(k) = NaN; % 未显著：剔除
    end
end
end

function A = read_raw(path, shape)
% 读 single RAW → reshape
fid = fopen(path,'r'); assert(fid>0, '无法打开：%s', path);
A = fread(fid, prod(shape), 'single'); fclose(fid);
A = reshape(A, shape);
end

function ri = igbp_to_row(code)
% IGBP 1..11 → 9 类植被行号（ENF/EBF/DNF/DBF/MF/SHL/SVA/GRA/WET）
% 6/7 合并为 SHL；8/9 合并为 SVA
switch code
    case 1,  ri = 1;  % ENF
    case 2,  ri = 2;  % EBF
    case 3,  ri = 3;  % DNF
    case 4,  ri = 4;  % DBF
    case 5,  ri = 5;  % MF
    case {6,7}, ri = 6; % SHL
    case {8,9}, ri = 7; % SVA
    case 10, ri = 8;    % GRA
    case 11, ri = 9;    % WET
    otherwise, ri = 0;
end
end

function SUM = add_into_sigonly(SUM, ri, r)
% 只对“显著保留下来的 r”（非 NaN）累加
ncol = size(SUM,2);
for c = 1:min(ncol, numel(r))
    if ~isnan(r(c))
        if isnan(SUM(ri,c)), SUM(ri,c) = 0; end
        SUM(ri,c) = SUM(ri,c) + r(c);
    end
end
end

function COUNT = add_count_sigonly(COUNT, ri, r)
% 只对“显著保留下来的 r”（非 NaN）计数 +1
ncol = size(COUNT,2);
for c = 1:min(ncol, numel(r))
    if ~isnan(r(c))
        COUNT(ri,c) = COUNT(ri,c) + 1;
    end
end
end

function cmap = bwr_nature(n)
% 深蓝 → 白 → 砖红（对称，接近 Nature 冷暖配色）
if nargin==0, n=255; end
cpts = [0.02 0.12 0.45; 0.28 0.50 0.78; 1 1 1; 0.93 0.68 0.62; 0.60 0 0];
half=floor(n/2);
neg = interp1([0 0.5 1],[cpts(1,:);cpts(2,:);cpts(3,:)], linspace(0,1,half), 'linear');
pos = interp1([0 0.5 1],[cpts(3,:);cpts(4,:);cpts(5,:)], linspace(0,1,half+1), 'linear');
cmap=[neg; pos(2:end,:)];
if size(cmap,1)~=n
    x=linspace(1,n,size(cmap,1)); cmap=interp1(x,cmap,1:n,'linear');
end
end
