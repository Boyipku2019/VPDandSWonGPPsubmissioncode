% %% ================== RS + FLUXNET | Water-limitation screening (VPD vs SW) + partial correlation ==================
% % Merge of Program-1 (RS pixel-wise) + Program-2 (FLUXNET site-wise)
% %
% % UPDATE (GPP筛选条件):
% %   - RS 月尺度原来的 Growing-season 筛选（GPP > 0.2*P90）已移除
% %   - 现在统一改为：仅保留 GPP > 0 的时间步（并把其它变量在同一时间步同步置为 NaN）
% %   - 其他均不变
% %
% % UPDATE (FLUX lat/lon 映射):
% %   - 明确使用 FLUXsitelistnew.xlsx：
% %       第1列=站名，第5列=纬度，第6列=经度
% %   - 站名做 trim + string->char，映射失败时再尝试 CSV 内 lat/lon
% %
% % UPDATE (THIS EDIT):
% %   - RS 月尺度 GPP 改回 1984–2018：读取 GPP19842018_3D.raw (720x360x420)
% %   - 其它 ERA5 月尺度变量与其对齐：从 468(月,1982–2020) 裁剪到 1984–2018 => 25:444 (长度=420)
% %   - 输出文件名保持不变
% %
% % UPDATE (FIGURE EDIT):
% %   - 原来的 6 个 stacked bar / 6 子图 pie 改为 6 个独立 pie figures
% %   - 仅显示 SW-limited / VPD-limited / Co-limited 三类
% %   - 三类内部重新归一化为 100%
% %   - N = 受限制的站点或像元总数 = SW + VPD + Both
% %   - 百分比放到对应扇形色块中间位置
% %   - 标题仅保留 N=...，并且更靠近饼图
% %   - 不加图例，不加尺度文字
% %
% % Tested: MATLAB R2021a
% % ----------------------------------------------------------------------------------
% 
% clear; clc; close all; warning('off','all');
% tAll = tic;
% 
% set(groot,'DefaultAxesFontName','Arial');
% set(groot,'DefaultTextFontName','Arial');
% 
% %% ================== Paths (RS) ==================
% rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
% lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
% hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';
% 
% % --- Monthly (GPP=420 for 1984–2018; met=468 for 1982–2020 -> clip 25:444 => 420) ---
% GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw"; % 720x360x420  (1984–2018)
% T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";  % 468
% P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";   % 468
% R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw"; % 468
% SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw"; % 468
% VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468
% 
% % --- Annual (SSA) ---
% GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_3compnew.raw');
% T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
% P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
% R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
% SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
% VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');
% 
% % --- Long-term (CEEMDAN Trend) + CO2 (1982–2022, 492) ---
% GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_3compnew.raw');
% T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
% P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
% R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
% SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
% VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
% CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 1982–2022 (492)
% 
% %% ================== Outputs (RS) float32 RAW (unchanged names) ==================
% out_MO = 'D:\WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw';
% out_AN = 'D:\WLclass_Annual_q25_ttest_pcor_f32_720x360.raw';
% out_LT = 'D:\WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw';
% 
% %% ================== Paths (FLUXNET) ==================
% rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
% dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
% siteXlsx        = fullfile(rootFolder_FLUX, 'FLUXsitelistnew.xlsx'); % 第1列站名，第5列纬度，第6列经度
% 
% assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);
% 
% outDir = 'D:\';
% if ~exist(outDir,'dir'), mkdir(outDir); end
% 
% % FLUX outputs (unchanged)
% outXLS_HH = fullfile(outDir, 'FLUXNET_WLclass_HH.xlsx');
% outXLS_DD = fullfile(outDir, 'FLUXNET_WLclass_DD.xlsx');
% outXLS_MM = fullfile(outDir, 'FLUXNET_WLclass_MM.xlsx');
% 
% %% ================== Single pie figure outputs ==================
% outPieFiles = { ...
%     fullfile(outDir,'WLpie_01_HH_Fluxnet.png'), ...
%     fullfile(outDir,'WLpie_02_DD_Fluxnet.png'), ...
%     fullfile(outDir,'WLpie_03_MM_Fluxnet.png'), ...
%     fullfile(outDir,'WLpie_04_Monthly_RS.png'), ...
%     fullfile(outDir,'WLpie_05_Annual_RS.png'), ...
%     fullfile(outDir,'WLpie_06_LongTerm_RS.png')};
% 
% %% ================== Global config ==================
% nx = 720; ny = 360;
% 
% alpha         = 0.05;
% minN_total_RS = 40;
% minN_group_RS = 10;
% 
% qLow  = 25;
% qHigh = 75;
% 
% %% ================== Checks (RS required files) ==================
% mustFiles_RS = {lulcPath,hfpPath,...
%     GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path,...
%     GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path,...
%     GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path,CO2_LT_path};
% 
% for k=1:numel(mustFiles_RS)
%     assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
% end
% 
% %% ================== RS Mask ==================
% IGBP = imread(lulcPath)';
% HFP  = imread(hfpPath)';
% 
% assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
% valid_mask = ismember(IGBP,1:10) & (HFP<=25);
% nValid_RS = nnz(valid_mask);
% fprintf('RS valid pixels (veg & HFP<=25): %d\n', nValid_RS);
% 
% %% ================== RS Scale configs ==================
% scalesRS = { ...
%     struct('name','Monthly (RS)', ...
%         'GPP',GPP_MO_path,'T',T_MO_path,'P',P_MO_path,'R',R_MO_path,'SW',SW_MO_path,'VPD',VPD_MO_path,'CO2','', ...
%         'out',out_MO, 'useCO2',false), ...
%     struct('name','Annual (RS)', ...
%         'GPP',GPP_AN_path,'T',T_AN_path,'P',P_AN_path,'R',R_AN_path,'SW',SW_AN_path,'VPD',VPD_AN_path,'CO2','', ...
%         'out',out_AN, 'useCO2',false), ...
%     struct('name','Long-term (RS)', ...
%         'GPP',GPP_LT_path,'T',T_LT_path,'P',P_LT_path,'R',R_LT_path,'SW',SW_LT_path,'VPD',VPD_LT_path,'CO2',CO2_LT_path, ...
%         'out',out_LT, 'useCO2',true) ...
%     };
% 
% propRS = nan(numel(scalesRS), 4); % [SW VPD Both Neither]
% countRS_limited = nan(numel(scalesRS),1); % SW+VPD+Both
% 
% %% =========================================================================================
% %% ===================================== PART A: RS =======================================
% %% =========================================================================================
% for s = 1:numel(scalesRS)
%     S = scalesRS{s};
%     fprintf('\n=== RS | %s ===\n', S.name);
% 
%     nt_gpp = detect_nt(S.GPP, nx, ny);
%     nt_t   = detect_nt(S.T,   nx, ny);
%     nt_p   = detect_nt(S.P,   nx, ny);
%     nt_r   = detect_nt(S.R,   nx, ny);
%     nt_sw  = detect_nt(S.SW,  nx, ny);
%     nt_vpd = detect_nt(S.VPD, nx, ny);
% 
%     % ---- time indices: align everything to GPP length ----
%     tIdx_gpp = choose_time_index_align_to_gpp(nt_gpp, nt_gpp);
%     tIdx_t   = choose_time_index_align_to_gpp(nt_t,   nt_gpp);
%     tIdx_p   = choose_time_index_align_to_gpp(nt_p,   nt_gpp);
%     tIdx_r   = choose_time_index_align_to_gpp(nt_r,   nt_gpp);
%     tIdx_sw  = choose_time_index_align_to_gpp(nt_sw,  nt_gpp);
%     tIdx_vpd = choose_time_index_align_to_gpp(nt_vpd, nt_gpp);
% 
%     nt = numel(tIdx_gpp);
%     assert(numel(tIdx_t)==nt && numel(tIdx_p)==nt && numel(tIdx_r)==nt && numel(tIdx_sw)==nt && numel(tIdx_vpd)==nt, ...
%         'Time clip length mismatch.');
% 
%     if S.useCO2
%         nt_co2   = detect_nt(S.CO2, nx, ny);
%         tIdx_co2 = choose_time_index_align_to_gpp(nt_co2, nt_gpp);
%         assert(numel(tIdx_co2)==nt, 'CO2 time clip length mismatch.');
%         map_co2  = memmapfile(S.CO2,'Format',{'single',[nx*ny*nt_co2 1],'x'});
%     else
%         nt_co2 = 0; tIdx_co2 = [];
%         map_co2 = [];
%     end
% 
%     fprintf('nt(clipped)=%d | nt_gpp=%d nt_t=%d nt_p=%d nt_r=%d nt_sw=%d nt_vpd=%d', ...
%         nt, nt_gpp, nt_t, nt_p, nt_r, nt_sw, nt_vpd);
%     if S.useCO2, fprintf(' nt_co2=%d', nt_co2); end
%     fprintf(' | Filter: GPP > 0\n');
% 
%     map_gpp = memmapfile(S.GPP,'Format',{'single',[nx*ny*nt_gpp 1],'x'});
%     map_t   = memmapfile(S.T,  'Format',{'single',[nx*ny*nt_t   1],'x'});
%     map_p   = memmapfile(S.P,  'Format',{'single',[nx*ny*nt_p   1],'x'});
%     map_r   = memmapfile(S.R,  'Format',{'single',[nx*ny*nt_r   1],'x'});
%     map_sw  = memmapfile(S.SW, 'Format',{'single',[nx*ny*nt_sw  1],'x'});
%     map_vpd = memmapfile(S.VPD,'Format',{'single',[nx*ny*nt_vpd 1],'x'});
% 
%     cls = zeros(nx, ny, 'single');
% 
%     tRow = tic;
%     for i = 1:nx
%         for j = 1:ny
%             if ~valid_mask(i,j), continue; end
% 
%             gpp = get_pixel_ts(map_gpp, i, j, nx, ny, nt_gpp, tIdx_gpp);
%             tt  = get_pixel_ts(map_t,   i, j, nx, ny, nt_t,   tIdx_t);
%             pp  = get_pixel_ts(map_p,   i, j, nx, ny, nt_p,   tIdx_p);
%             rr  = get_pixel_ts(map_r,   i, j, nx, ny, nt_r,   tIdx_r);
%             sw  = get_pixel_ts(map_sw,  i, j, nx, ny, nt_sw,  tIdx_sw);
%             vpd = get_pixel_ts(map_vpd, i, j, nx, ny, nt_vpd, tIdx_vpd);
% 
%             if S.useCO2
%                 co2 = get_pixel_ts(map_co2, i, j, nx, ny, nt_co2, tIdx_co2);
%             else
%                 co2 = [];
%             end
% 
%             % ===== Filter: keep only GPP > 0 timesteps =====
%             gpp_d = double(gpp(:));
%             posMask = isfinite(gpp_d) & (gpp_d > 0);
% 
%             if ~any(posMask)
%                 cls(i,j) = single(4);
%                 continue;
%             end
% 
%             gpp(~posMask) = NaN;
%             tt(~posMask)  = NaN;
%             pp(~posMask)  = NaN;
%             rr(~posMask)  = NaN;
%             sw(~posMask)  = NaN;
%             vpd(~posMask) = NaN;
%             if S.useCO2, co2(~posMask) = NaN; end
% 
%             % -------- VPD limitation --------
%             vpd_group_ok = is_highX_limits_gpp(gpp, vpd, qHigh, alpha, minN_total_RS, minN_group_RS);
%             if S.useCO2
%                 Z_vpd = [tt, pp, rr, sw, co2];
%             else
%                 Z_vpd = [tt, pp, rr, sw];
%             end
%             [rv, pv2] = partialcorr_fast(double(gpp), double(vpd), double(Z_vpd));
%             pv1 = p_one_sided_from_two(pv2, rv, -1);
%             vpd_pcor_ok = isfinite(pv1) && (pv1 < alpha) && (rv < 0);
%             vpd_lim = vpd_group_ok && vpd_pcor_ok;
% 
%             % -------- SW limitation --------
%             sw_group_ok = is_lowX_limits_gpp(gpp, sw, qLow, alpha, minN_total_RS, minN_group_RS);
%             if S.useCO2
%                 Z_sw = [tt, pp, rr, vpd, co2];
%             else
%                 Z_sw = [tt, pp, rr, vpd];
%             end
%             [rsw, psw2] = partialcorr_fast(double(gpp), double(sw), double(Z_sw));
%             psw1 = p_one_sided_from_two(psw2, rsw, +1);
%             sw_pcor_ok = isfinite(psw1) && (psw1 < alpha) && (rsw > 0);
%             sw_lim = sw_group_ok && sw_pcor_ok;
% 
%             if sw_lim && ~vpd_lim
%                 cls(i,j) = single(1);
%             elseif vpd_lim && ~sw_lim
%                 cls(i,j) = single(2);
%             elseif sw_lim && vpd_lim
%                 cls(i,j) = single(3);
%             else
%                 cls(i,j) = single(4);
%             end
%         end
% 
%         if mod(i,40)==0
%             fprintf('  RS row %3d/720 | elapsed %.1fs\n', i, toc(tRow));
%             tRow = tic;
%         end
%     end
% 
%     fid = fopen(S.out,'w');
%     assert(fid>0, 'Cannot open output: %s', S.out);
%     fwrite(fid, cls, 'single');
%     fclose(fid);
% 
%     n1 = nnz(cls==1);
%     n2 = nnz(cls==2);
%     n3 = nnz(cls==3);
%     n4 = nnz(cls==4);
% 
%     propRS(s,1) = n1 / nValid_RS;
%     propRS(s,2) = n2 / nValid_RS;
%     propRS(s,3) = n3 / nValid_RS;
%     propRS(s,4) = n4 / nValid_RS;
% 
%     countRS_limited(s) = n1 + n2 + n3;
% 
%     pWL = (n1+n2+n3)/nValid_RS;
% 
%     fprintf('Saved RS: %s\n', S.out);
%     fprintf('RS Percent (of valid veg pixels): SW=%.2f%% | VPD=%.2f%% | Both=%.2f%% | Neither=%.2f%% | WL(any)=%.2f%%\n', ...
%         100*propRS(s,1), 100*propRS(s,2), 100*propRS(s,3), 100*propRS(s,4), 100*pWL);
% end
% 
% %% =========================================================================================
% %% =================================== PART B: FLUXNET ====================================
% %% =========================================================================================
% fprintf('\n================== FLUXNET screening (HH/DD/MM) ==================\n');
% 
% yName = 'GPP_DT_VUT_REF';
% vT    = 'TA_F_MDS';
% vP    = 'P_F';
% vR    = 'SW_IN_F_MDS';
% vVPD  = 'VPD_F';
% swcRegex = '^SWC_F_MDS_\d+$';
% 
% scaleList = {'HH','DD','MM'};
% minN_total_map = containers.Map(scaleList, [300, 100, 40]);
% minN_group_map = containers.Map(scaleList, [50,  20,  10]);
% 
% useGS_for_MM = false;
% gsFracP90_flux = 0.2;
% 
% site2lat = containers.Map('KeyType','char','ValueType','double');
% site2lon = containers.Map('KeyType','char','ValueType','double');
% hasSiteLatLon = false;
% 
% if exist(siteXlsx,'file')
%     try
%         Ts = readtable(siteXlsx, 'ReadVariableNames', true);
%         siteCol = 1;
%         latCol  = 5;
%         lonCol  = 6;
% 
%         assert(width(Ts) >= lonCol, 'FLUXsitelistnew.xlsx 列数不足，至少需要第6列(经度)。');
% 
%         names = string(Ts{:,siteCol});
%         lats  = Ts{:,latCol};
%         lons  = Ts{:,lonCol};
% 
%         for i = 1:numel(names)
%             k = char(strtrim(names(i)));
%             if isempty(k), continue; end
%             latv = double(lats(i));
%             lonv = double(lons(i));
%             if isfinite(latv) && isfinite(lonv)
%                 site2lat(k) = latv;
%                 site2lon(k) = lonv;
%             end
%         end
% 
%         hasSiteLatLon = ~isempty(site2lat.keys);
%         fprintf('✅ FLUX: 从 FLUXsitelistnew.xlsx 固定列(1/5/6)读取到 %d 个站点 lat/lon。\n', numel(site2lat.keys));
%     catch ME
%         fprintf('⚠️ FLUX: 读取 FLUXsitelistnew.xlsx 失败（%s），将尝试从 CSV 读取 lat/lon。\n', ME.message);
%         hasSiteLatLon = false;
%     end
% else
%     fprintf('⚠️ FLUX: 未找到 FLUXsitelistnew.xlsx，将尝试从 CSV 读取 lat/lon。\n');
% end
% 
% allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
% targets = [];
% for ii = 1:numel(allCSV)
%     nm = allCSV(ii).name;
%     if contains(nm,'FULLSET','IgnoreCase',true) && ...
%        ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
%          contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
%          contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
%         targets = [targets; allCSV(ii)]; %#ok<AGROW>
%     end
% end
% assert(~isempty(targets), '未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
% fprintf('FLUXNET 可用文件（HH/DD/MM）：%d 个\n', numel(targets));
% 
% RES = struct();
% for s=1:numel(scaleList)
%     sc = scaleList{s};
%     RES.(sc).Site  = {};
%     RES.(sc).Lat   = [];
%     RES.(sc).Lon   = [];
%     RES.(sc).Class = [];
% end
% 
% seen = containers.Map('KeyType','char','ValueType','logical');
% 
% t0 = tic;
% for k = 1:numel(targets)
% 
%     fpath = fullfile(targets(k).folder, targets(k).name);
%     [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
%     if ~ismember(scaleTag, scaleList), continue; end
% 
%     key = sprintf('%s__%s', siteName, scaleTag);
%     if isKey(seen,key), continue; end
%     seen(key) = true;
% 
%     try
%         opts = detectImportOptions(fpath);
%         varNames = opts.VariableNames;
% 
%         needFixed = {yName, vT, vP, vR, vVPD};
%         if ~all(ismember(needFixed, varNames))
%             continue;
%         end
% 
%         swcMask = ~cellfun('isempty', regexp(varNames, swcRegex,'once'));
%         swcCols = varNames(swcMask);
%         if isempty(swcCols)
%             continue;
%         end
% 
%         latCandidates = {'LAT','SITE_LAT','latitude','LAT_F','LOCATION_LAT'};
%         lonCandidates = {'LON','SITE_LON','longitude','LON_F','LOCATION_LON'};
%         latColCSV = '';
%         lonColCSV = '';
%         for ii=1:numel(latCandidates)
%             if ismember(latCandidates{ii}, varNames), latColCSV = latCandidates{ii}; break; end
%         end
%         for ii=1:numel(lonCandidates)
%             if ismember(lonCandidates{ii}, varNames), lonColCSV = lonCandidates{ii}; break; end
%         end
% 
%         selectVars = [needFixed, swcCols];
%         if ~isempty(latColCSV) && ~isempty(lonColCSV)
%             selectVars = [selectVars, {latColCSV, lonColCSV}];
%         end
% 
%         opts.SelectedVariableNames = selectVars;
%         Ttab = readtable(fpath, opts);
% 
%         Ttab = sentinel2nan(Ttab, opts.SelectedVariableNames);
% 
%         Y   = Ttab.(yName);
%         TA  = Ttab.(vT);
%         PP  = Ttab.(vP);
%         RR  = Ttab.(vR);
%         VPD = Ttab.(vVPD);
% 
%         SWCmat = Ttab{:, swcCols};
%         if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
%         SW = mean(SWCmat, 2, 'omitnan');
% 
%         if useGS_for_MM && strcmp(scaleTag,'MM')
%             ytmp = double(Y(:));
%             ok0 = isfinite(ytmp) & (ytmp > 0);
%             if nnz(ok0) >= 5
%                 P90 = prctile(ytmp(ok0), 90);
%                 thr = gsFracP90_flux * P90;
%                 gsMask = (ytmp > thr);
%             else
%                 gsMask = false(size(ytmp));
%             end
%             Y(~gsMask)   = NaN;
%             TA(~gsMask)  = NaN;
%             PP(~gsMask)  = NaN;
%             RR(~gsMask)  = NaN;
%             SW(~gsMask)  = NaN;
%             VPD(~gsMask) = NaN;
%         end
% 
%         mask = isfinite(Y) & (Y>0) & isfinite(TA) & isfinite(PP) & isfinite(RR) & isfinite(SW) & isfinite(VPD);
%         Y   = Y(mask);
%         TA  = TA(mask);
%         PP  = PP(mask);
%         RR  = RR(mask);
%         SW  = SW(mask);
%         VPD = VPD(mask);
% 
%         minN_total = minN_total_map(scaleTag);
%         minN_group = minN_group_map(scaleTag);
% 
%         if numel(Y) < minN_total
%             cls = 0;
%         else
%             vpd_group_ok = is_highX_limits_gpp(Y, VPD, qHigh, alpha, minN_total, minN_group);
%             Z_vpd = [TA, PP, RR, SW];
%             [rv, pv2] = partialcorr_fast(double(Y), double(VPD), double(Z_vpd));
%             pv1 = p_one_sided_from_two(pv2, rv, -1);
%             vpd_pcor_ok = isfinite(pv1) && (pv1 < alpha) && (rv < 0);
%             vpd_lim = vpd_group_ok && vpd_pcor_ok;
% 
%             sw_group_ok = is_lowX_limits_gpp(Y, SW, qLow, alpha, minN_total, minN_group);
%             Z_sw = [TA, PP, RR, VPD];
%             [rsw, psw2] = partialcorr_fast(double(Y), double(SW), double(Z_sw));
%             psw1 = p_one_sided_from_two(psw2, rsw, +1);
%             sw_pcor_ok = isfinite(psw1) && (psw1 < alpha) && (rsw > 0);
%             sw_lim = sw_group_ok && sw_pcor_ok;
% 
%             if sw_lim && ~vpd_lim
%                 cls = 1;
%             elseif vpd_lim && ~sw_lim
%                 cls = 2;
%             elseif sw_lim && vpd_lim
%                 cls = 3;
%             else
%                 cls = 4;
%             end
%         end
% 
%         latv = NaN; lonv = NaN;
% 
%         if hasSiteLatLon
%             if isKey(site2lat, siteName)
%                 latv = site2lat(siteName);
%                 lonv = site2lon(siteName);
%             else
%                 st = char(strtrim(string(siteName)));
%                 if isKey(site2lat, st)
%                     latv = site2lat(st);
%                     lonv = site2lon(st);
%                 else
%                     st2 = upper(st);
%                     if isKey(site2lat, st2)
%                         latv = site2lat(st2);
%                         lonv = site2lon(st2);
%                     end
%                 end
%             end
%         end
% 
%         if ~(isfinite(latv) && isfinite(lonv))
%             if ~isempty(latColCSV) && ~isempty(lonColCSV) && ismember(latColCSV, Ttab.Properties.VariableNames)
%                 latcand = double(Ttab.(latColCSV)); loncand = double(Ttab.(lonColCSV));
%                 latcand = latcand(isfinite(latcand));
%                 loncand = loncand(isfinite(loncand));
%                 if ~isempty(latcand) && ~isempty(loncand)
%                     latv = latcand(1); lonv = loncand(1);
%                 end
%             end
%         end
% 
%         RES.(scaleTag).Site{end+1,1}  = siteName; %#ok<AGROW>
%         RES.(scaleTag).Lat(end+1,1)   = latv; %#ok<AGROW>
%         RES.(scaleTag).Lon(end+1,1)   = lonv; %#ok<AGROW>
%         RES.(scaleTag).Class(end+1,1) = cls;  %#ok<AGROW>
% 
%     catch
%         continue;
%     end
% 
%     if mod(k,50)==0
%         fprintf('FLUX 进度 %d/%d | 用时 %.1fs\n', k, numel(targets), toc(t0));
%         t0 = tic;
%     end
% end
% 
% T_HH = pack_table(RES.HH);
% T_DD = pack_table(RES.DD);
% T_MM = pack_table(RES.MM);
% 
% writetable(T_HH, outXLS_HH);
% writetable(T_DD, outXLS_DD);
% writetable(T_MM, outXLS_MM);
% 
% fprintf('✅ FLUX Excel 已保存：\n  %s\n  %s\n  %s\n', outXLS_HH, outXLS_DD, outXLS_MM);
% 
% propFlux = nan(3,4);
% nFluxValid = nan(3,1);
% countFlux_limited = nan(3,1);
% 
% for si=1:3
%     sc = scaleList{si};
%     cls = RES.(sc).Class(:);
%     clsValid = cls(cls>=1 & cls<=4);
%     nValid = numel(clsValid);
%     nFluxValid(si) = nValid;
% 
%     if nValid>0
%         n1 = sum(clsValid==1);
%         n2 = sum(clsValid==2);
%         n3 = sum(clsValid==3);
%         n4 = sum(clsValid==4);
% 
%         propFlux(si,1) = n1/nValid;
%         propFlux(si,2) = n2/nValid;
%         propFlux(si,3) = n3/nValid;
%         propFlux(si,4) = n4/nValid;
% 
%         countFlux_limited(si) = n1+n2+n3;
%     end
% 
%     fprintf('FLUX %s | Nvalid=%d | Nlimited=%d | SW=%.2f%% VPD=%.2f%% Both=%.2f%% Neither=%.2f%%\n', ...
%         sc, nValid, round(countFlux_limited(si)), ...
%         100*propFlux(si,1), 100*propFlux(si,2), 100*propFlux(si,3), 100*propFlux(si,4));
% end

%% =========================================================================================
%% ============================ PART C: six separate pie figures ============================
%% =========================================================================================
Pall = nan(6,4);
Pall(1,:) = propFlux(1,:);
Pall(2,:) = propFlux(2,:);
Pall(3,:) = propFlux(3,:);
Pall(4,:) = propRS(1,:);
Pall(5,:) = propRS(2,:);
Pall(6,:) = propRS(3,:);

Nlimited = nan(6,1);
Nlimited(1:3) = countFlux_limited(:);
Nlimited(4:6) = countRS_limited(:);

cSW   = [0.55 0.74 0.68];
cVPD  = [0.90 0.62 0.54];
cBoth = [0.63 0.66 0.86];
C3 = [cSW; cVPD; cBoth];

for i = 1:6
    vals = Pall(i,1:3); % [SW VPD Both]

    fig = figure('Color','w','Position',[200,120,720,720]);

    if any(~isfinite(vals)) || sum(vals)<=0 || ~isfinite(Nlimited(i)) || Nlimited(i)<=0
        axis off;
        text(0.5,0.5,'No limited pixels/sites', ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontName','Arial','FontSize',24,'FontWeight','bold');
        ht = title(sprintf('N=%d', 0), ...
            'FontName','Arial','FontSize',28,'FontWeight','bold');
        set(ht,'Units','normalized');
        posT = get(ht,'Position');
        posT(2) = 0.96;
        set(ht,'Position',posT);

        exportgraphics(fig, outPieFiles{i}, 'Resolution', 300);
        fprintf('✅ Saved figure: %s\n', outPieFiles{i});
        close(fig);
        continue;
    end

    vals3 = vals ./ sum(vals);

    h = pie(vals3);
    axis equal off;

    patchHandles = [];
    for k = 1:numel(h)
        if isa(h(k),'matlab.graphics.primitive.Patch')
            patchHandles = [patchHandles; h(k)]; %#ok<AGROW>
        end
    end

    for k = 1:numel(h)
        if isa(h(k),'matlab.graphics.primitive.Text')
            delete(h(k));
        end
    end

    for k = 1:numel(patchHandles)
        set(patchHandles(k), ...
            'FaceColor', C3(k,:), ...
            'EdgeColor', 'w', ...
            'LineWidth', 1.8);
    end

    % 百分比放在对应扇形色块中间位置
    for k = 1:3
        xv = get(patchHandles(k),'XData');
        yv = get(patchHandles(k),'YData');

        % 去掉第一个中心点 (0,0)
        idx = ~(abs(xv)<1e-12 & abs(yv)<1e-12);
        xb = xv(idx);
        yb = yv(idx);

        % 用边界点均值估计扇形中部位置
        xText = mean(xb);
        yText = mean(yb);

        % 稍微往中心收一点，避免太靠边
        xText = 0.92 * xText;
        yText = 0.92 * yText;

        text(xText, yText, sprintf('%.1f%%', vals3(k)*100), ...
            'HorizontalAlignment','center', ...
            'VerticalAlignment','middle', ...
            'FontName','Arial', ...
            'FontSize',48, ...
            'FontWeight','bold', ...
            'Color',[0.08 0.08 0.08]);
    end

    ht = title(sprintf('N=%d', round(Nlimited(i))), ...
        'FontName','Arial','FontSize',50,'FontWeight','bold');

    % N 更靠近饼图
    set(ht,'Units','normalized');
    posT = get(ht,'Position');
    posT(2) = 0.90;
    set(ht,'Position',posT);

    exportgraphics(fig, outPieFiles{i}, 'Resolution', 300);
    fprintf('✅ Saved figure: %s\n', outPieFiles{i});
    close(fig);
end

fprintf('\n✅ ALL DONE | Total time %.1f min\n', toc(tAll)/60);

%% =========================================================================================
%% ===================================== Helper functions ==================================
%% =========================================================================================
function nt = detect_nt(path, nx, ny)
d = dir(path);
assert(~isempty(d), 'Cannot read file info: %s', path);
bytes = d.bytes;
assert(mod(bytes,4)==0, 'Bytes not multiple of 4: %s', path);
nFloat = bytes/4;
assert(mod(nFloat, nx*ny)==0, 'File size not divisible by nx*ny: %s', path);
nt = nFloat/(nx*ny);
end

function tIdx = choose_time_index_align_to_gpp(nt0, nt_gpp)
if nt0 == nt_gpp
    tIdx = 1:nt_gpp;
    return;
end

if nt0 >= 468
    if nt_gpp == 444
        tIdx = 25:468;
        return;
    elseif nt_gpp == 420
        tIdx = 25:444;
        return;
    end
end

error('Unsupported time alignment: nt0=%d to nt_gpp=%d. Verify file periods.', nt0, nt_gpp);
end

function ts = get_pixel_ts(mmap, i, j, nx, ny, nt0, tIdx)
base   = i + (j-1)*nx;
stride = nx*ny;
idx    = base + (tIdx-1)*stride;
ts     = mmap.Data.x(idx);
end

function Tout = pack_table(R)
Site = string(R.Site(:));
Lat  = R.Lat(:);
Lon  = R.Lon(:);
Cls  = R.Class(:);

m = Site ~= "";
Site = Site(m); Lat = Lat(m); Lon = Lon(m); Cls = Cls(m);

Tout = table(Site, Lat, Lon, Cls, 'VariableNames', {'Site','Lat','Lon','Class'});
end

function T = sentinel2nan(T, names)
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v)
        v = double(str2double(string(v)));
    else
        v = double(v);
    end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_");
    b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok)
            siteName = tok{1};
        else
            siteName = fname;
        end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM';
else
    scaleTag = 'OTHER';
end
end

function ok = is_lowX_limits_gpp(gpp, X, qPercent, alpha, minN_total, minN_group)
ok = false;

gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total
    return;
end
gpp = gpp(mask);
X   = X(mask);

q = prctile(X, qPercent);
idx_low  = (X <= q);
idx_high = (X >  q);

nL = nnz(idx_low);
nH = nnz(idx_high);
if (nL < minN_group) || (nH < minN_group)
    return;
end

gL = gpp(idx_low);
gH = gpp(idx_high);

if mean(gL) >= mean(gH)
    return;
end

try
    [h, p] = ttest2(gL, gH, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function ok = is_highX_limits_gpp(gpp, X, qPercentHigh, alpha, minN_total, minN_group)
ok = false;

gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total
    return;
end
gpp = gpp(mask);
X   = X(mask);

qH = prctile(X, qPercentHigh);
idx_high = (X >= qH);
idx_low  = (X <  qH);

nH = nnz(idx_high);
nL = nnz(idx_low);
if (nH < minN_group) || (nL < minN_group)
    return;
end

gH = gpp(idx_high);
gL = gpp(idx_low);

if mean(gH) >= mean(gL)
    return;
end

try
    [h, p] = ttest2(gH, gL, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function p1 = p_one_sided_from_two(p2, r, expectSign)
if ~isfinite(p2) || ~isfinite(r)
    p1 = NaN;
    return;
end
if expectSign > 0
    if r > 0
        p1 = p2/2;
    else
        p1 = 1;
    end
else
    if r < 0
        p1 = p2/2;
    else
        p1 = 1;
    end
end
end

function [r, p] = partialcorr_fast(y, x, Z)
r = NaN;
p = NaN;

y = y(:);
x = x(:);
if isempty(Z)
    M = [y x];
else
    Z = double(Z);
    M = [y x Z];
end

good = all(isfinite(M),2);
M = M(good,:);

n = size(M,1);
k = size(M,2) - 2;
df = n - k - 2;
if df < 3
    return;
end

yy = M(:,1);
xx = M(:,2);

if k==0
    ry = yy - mean(yy);
    rx = xx - mean(xx);
else
    ZZ = M(:,3:end);
    A  = [ones(n,1), ZZ];
    by = A \ yy;
    ry = yy - A*by;
    bx = A \ xx;
    rx = xx - A*bx;
end

ry = ry - mean(ry);
rx = rx - mean(rx);
den = sqrt(sum(ry.^2) * sum(rx.^2));
if den==0
    return;
end

r = sum(ry .* rx) / den;

t = r * sqrt(df / max(1e-12, (1 - r^2)));
p = 2 * (1 - tcdf(abs(t), df));
end