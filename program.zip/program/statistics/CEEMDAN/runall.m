
clear all;
close all;
clc;
run('LastIMFstatisticsmonotrendGPP.m');
run('LastIMFstatisticstippingGPP.m');
run('LastIMFstatisticsmonoandtippingGPP.m');
run('LastIMFstatisticsmonotrendLAI.m');
run('LastIMFstatisticstippingLAI.m');
run('LastIMFstatisticsmonoandtippingLAI.m');
run('LastIMFstatisticsmonotrendNDVI.m');
run('LastIMFstatisticstippingNDVI.m');
run('LastIMFstatisticsmonoandtippingNDVI.m');