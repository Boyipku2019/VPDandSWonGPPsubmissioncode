clear all; close all; clc;

%% ====== 输入与参数 ======
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');  IGBP = IGBP';
HFP  = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');   HFP  = HFP';

alpha_uddu = 1e-3;   % 只检验拐点的显著性（两段 MK 都要显著）
minSegFrac = 0.10;   % 拟合切点两侧最少样本占比（可调）

%% 读取 GPP 数据（LastIMF）
GPP2 = single(zeros(720,360,420));
fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\GPP05LastIMF.raw','r');
GPP2 = fread(fid,720*360*420,'single'); fclose(fid);
GPP2 = reshape(GPP2,[720,360,420]);

%% ====== 计数器（仅 3 类：UD/DU/无）======
% 列顺序固定：1=UD, 2=DU, 3=No
ENF = single(zeros(1,3)); EBF = single(zeros(1,3));
DNF = single(zeros(1,3)); DBF = single(zeros(1,3));
MF  = single(zeros(1,3)); SHL = single(zeros(1,3));
SVA = single(zeros(1,3)); GRA = single(zeros(1,3));
WET = single(zeros(1,3)); ALL = single(zeros(1,3));

tippingworld = single(zeros(720,360));  % 保存 4/2/5 代码

%% ====== 主循环 ======
for i = 1:720
    for j = 1:360
        if any(GPP2(i,j,:)) && (IGBP(i,j)>=1 && IGBP(i,j)<=11) && (HFP(i,j) <= 25)
            x = reshape(GPP2(i,j,:), 420, 1);

            % ======== 只检测拐点 ========
            [code, detail] = classify_trend_uddu_only(x, alpha_uddu, minSegFrac);
            tippingworld(i,j) = code;

            % 把 code → 列索引：UD=4→1，DU=2→2，无=5→3
            if code == 4
                idx = 1;  % UD
            elseif code == 2
                idx = 2;  % DU
            else
                idx = 3;  % 无显著
            end

            % 累加到各 biome
            c = IGBP(i,j);
            switch c
                case 1,  ENF(idx) = ENF(idx) + 1;
                case 2,  EBF(idx) = EBF(idx) + 1;
                case 3,  DNF(idx) = DNF(idx) + 1;
                case 4,  DBF(idx) = DBF(idx) + 1;
                case 5,  MF(idx)  = MF(idx)  + 1;
                case {6,7}, SHL(idx) = SHL(idx) + 1;
                case {8,9}, SVA(idx) = SVA(idx) + 1;
                case 10, GRA(idx) = GRA(idx) + 1;
                case 11, WET(idx) = WET(idx) + 1;
            end
            ALL(idx) = ALL(idx) + 1;
        end
    end
    i
end

%% ====== 画 10 个 stacked bar（9 类 + 全局），风格对齐参考程序 ======
sizes = [
    ENF; EBF; DNF; DBF; MF; SHL; SVA; GRA; WET; ALL
];

% 列顺序：UD / DU / No  —— 颜色保持不变（蓝/橙/灰）
colors = [
        
    255, 102,   0;   % DU: 先升后降 -> 橙
     0, 102, 204; % UD: 先降后升 -> 蓝
    160, 160, 160    % No: 无显著 -> 灰
] / 255;

biome_names = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'};

totals = sum(sizes,2);
prop   = sizes ./ max(totals,1);   % 比例

FS_axis   = 18;
FS_text   = 24;
FS_legend = 18;

fig_main = figure('Position',[100 100 800 600],'Color','w');
clf;

% 关键：手动创建 axes，预留下方空间给 legend 和 xticks
ax = axes('Parent',fig_main);
ax.Units    = 'normalized';
ax.Position = [0.10 0.18 0.88 0.75];   % bottom = 0.18，xticks 不会被挡

% 绘制 stacked bar
hBar = bar(ax, prop, 'stacked', 'BarWidth', 0.8); hold(ax, 'on');
for k = 1:3
    hBar(k).FaceColor = colors(k,:);
end

set(ax,'XTick',1:10,'XTickLabel',biome_names, ...
    'FontSize',FS_axis, 'FontName','Arial');

% 不要 ylabel，方便后期拼接
% ylabel(ax,'Percentage','FontSize',FS_axis,'FontName','Arial');

ylim(ax,[0 1]);
yticks(ax,0:0.2:1);
yticklabels(ax,{'0%','20%','40%','60%','80%','100%'});

grid(ax,'on'); box(ax,'on');
set(ax,'GridLineStyle','--','GridColor',[0.3 0.3 0.3], ...
        'GridAlpha',0.3,'LineWidth',1.5);

% 百分比数字（>5% 才标注），字体 24
for r = 1:size(prop,1)
    bottom = 0;
    for c = 1:size(prop,2)
        if prop(r,c) > 0.05
            pct = 100*prop(r,c);
            col = colors(c,:);
            luminance = 0.299*col(1)+0.587*col(2)+0.114*col(3);
            txt_color = 'k'; if luminance < 0.5, txt_color = 'w'; end
            text(ax, r, bottom + prop(r,c)/2, sprintf('%.0f', pct), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontSize',FS_text,'FontName','Arial','Color',txt_color);
        end
        bottom = bottom + prop(r,c);
    end
end

% 自己画 legend（不依附 axes，不挤压 axes），颜色保持原 bar 颜色
lgd = legend({'UD (up-then-down)','DU (down-then-up)','No significant'}, ...
    'Orientation','horizontal', ...
    'FontName','Arial','FontSize',FS_legend, ...
    'Box','off');

% 手动放在 figure 下方居中，避免挡住 xticks
lgd.Units    = 'normalized';
lgd.Position = [0.30 0.02 0.40 0.05];   % bottom=0.02，不挡 xTick

% ====== 导出结果地图（保留 4/2/5 代码）======
fid = fopen('D:\tippingworldGPP.raw','wb');
fwrite(fid, tippingworld, 'single');
fclose(fid);

print(fig_main, 'D:\tippingGPP.png', '-dpng', '-r300');   % 300 dpi

%% ====================== FUNCTIONS ======================

function [code, detail] = classify_trend_uddu_only(x, alpha_uddu, minSegFrac)
    % 只判断是否存在显著拐点（UD/DU）。
    % code: 4=UD, 2=DU, 5=无显著
    x = x(:); n = numel(x); assert(n>=5,'序列长度至少 5');
    minSeg = max(3, ceil(n * minSegFrac));

    [cp, dir, segL, segR, score] = find_uddu_cp_mk(x, alpha_uddu, minSeg);

    if ~isempty(cp)
        if strcmp(dir,'UD'), code = 4; else, code = 2; end
        detail = struct('type',dir,'cp',cp,'score',score,'SegLeft',segL,'SegRight',segR, ...
                        'final',sprintf('%s @ %d',dir,cp));
    else
        code = 5;
        detail = struct('type','No breakpoint','final','无显著拐点');
    end
end

function [cp_best, dir, segL, segR, bestScore] = find_uddu_cp_mk(x, alpha, minSeg)
    % 穷举切点 k=minSeg..n-minSeg：
    % 左右两侧分别做 MK，若 p1<alpha & p2<alpha 且 tau1*tau2<0，则候选。
    x = x(:); n = numel(x);
    cp_best = []; dir = ''; bestScore = -Inf;
    segL = struct(); segR = struct();

    for k = minSeg:(n-minSeg)
        [tau1, Z1, p1, lab1] = mk_test(x(1:k), alpha);
        [tau2, Z2, p2, lab2] = mk_test(x(k+1:end), alpha);
        if (p1 < alpha) && (p2 < alpha) && (tau1 * tau2 < 0)
            score = abs(tau1) + abs(tau2);  % 强度打分
            if score > bestScore
                bestScore = score;
                cp_best   = k;
                dir       = ternary(tau1>0,'UD','DU');
                segL      = struct('tau',tau1,'Z',Z1,'p',p1,'label',lab1);
                segR      = struct('tau',tau2,'Z',Z2,'p',p2,'label',lab2);
            end
        end
    end

    if isempty(cp_best)
        dir = ''; bestScore = NaN;
    end
end

function [tau, Z, p, trend] = mk_test(x, alpha)
    % 标准 Mann–Kendall（不含并列/季节修正）
    x = x(:); n = numel(x); S = 0;
    for i = 1:n-1
        S = S + sum(sign(x(i+1:end) - x(i)));
    end
    VarS = n*(n-1)*(2*n+5)/18;
    Z = S / sqrt(VarS + eps);
    p = 2*(1 - normcdf(abs(Z)));
    tau = 2*S/(n*(n-1));
    if p < alpha
        trend = ternary(tau>0,'Significant up','Significant down');
    else
        trend = 'Not significant';
    end
end

function y = ternary(cond,a,b)
    if cond, y=a; else, y=b; end
end
