%% ================= 合并判别：条件分解统计与绘图 =================
clear; close all; clc;

%% ---- 输入与参数 ----
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif'); IGBP = IGBP';
HFP  = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');  HFP  = HFP';
alpha_mono = 1e-3;                 % 单调检验显著性
alpha_uddu = 1e-3;                 % 拐点两段显著性
minSegFrac = 0.10;                 % 拐点两侧最少长度占比

% 读取 CEEMDAN 最低频（趋势/LastIMF 或你要检的那一分量）
GPP2 = single(zeros(720,360,420));
fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\GPP05LastIMF.raw','r');
GPP2 = fread(fid,720*360*420,'single'); fclose(fid);
GPP2 = reshape(GPP2,[720,360,420]);

%% ---- 结果计数器（每类生物群系 × 2 面板 × 3 段）----
% 面板顺序：1=Inc(显著单调上升)、2=Dec(显著单调下降)
% 段顺序： 1=UD(上-下)，2=DU(下-上)，3=No(无拐点)
K = 10;   % 9 biome + All
panel_inc = single(zeros(K,3));
panel_dec = single(zeros(K,3));
den_inc   = single(zeros(K,1));   % 分母（显著单调上升的像元数）
den_dec   = single(zeros(K,1));   % 分母（显著单调下降的像元数）

%% ---- 主循环：同时计算 mono 与 UDDU ----
for i = 1:720
    for j = 1:360
        if ~any(GPP2(i,j,:)), continue; end
        if ~(IGBP(i,j)>=1 && IGBP(i,j)<=11), continue; end
        if HFP(i,j) > 25, continue; end

        x = reshape(GPP2(i,j,:), 420, 1);

        % 1) 单调判别
        [mono_code, ~] = classify_trend_mono_only(x, alpha_mono);
        % mono_code: 1=单调减, 3=单调增, 5=无显著

        % 2) 拐点判别（只要左右两段都显著且符号相反才算 UD/DU）
        [uddu_code, ~] = classify_trend_uddu_only(x, alpha_uddu, minSegFrac);
        % uddu_code: 4=UD, 2=DU, 5=无显著拐点

        % biome 行索引
        c = IGBP(i,j);
        switch c
            case 1, row = 1;     % ENF
            case 2, row = 2;     % EBF
            case 3, row = 3;     % DNF
            case 4, row = 4;     % DBF
            case 5, row = 5;     % MF
            case {6,7}, row = 6; % SHL
            case {8,9}, row = 7; % SVA
            case 10, row = 8;    % GRA
            case 11, row = 9;    % WET
            otherwise, continue;
        end

        % 把拐点 code 映射到列：1=UD, 2=DU, 3=No
        if uddu_code == 4
            segIdx = 1;
        elseif uddu_code == 2
            segIdx = 2;
        else
            segIdx = 3;
        end

        % 条件分解：分别落入 Inc 面板或 Dec 面板
        if mono_code == 3      % 显著单调上升
            panel_inc(row, segIdx) = panel_inc(row, segIdx) + 1;
            den_inc(row) = den_inc(row) + 1;
            panel_inc(10, segIdx) = panel_inc(10, segIdx) + 1; % All
            den_inc(10) = den_inc(10) + 1;
        elseif mono_code == 1  % 显著单调下降
            panel_dec(row, segIdx) = panel_dec(row, segIdx) + 1;
            den_dec(row) = den_dec(row) + 1;
            panel_dec(10, segIdx) = panel_dec(10, segIdx) + 1; % All
            den_dec(10) = den_dec(10) + 1;
        else
            % 单调不显著者不计入本次两面板统计
        end
    end
    i
end

%% ---- 转百分比（面板内各行按分母归一）----
P_inc = panel_inc ./ max(den_inc,1);
P_dec = panel_dec ./ max(den_dec,1);

%% ---- 绘图（两面板堆叠条形图，风格对齐程序2）----
biome_names = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'};
colors = [ ...
       255, 102,   0;   % DU: 先升后降 -> 橙
     0, 102, 204; % UD: 先降后升 -> 蓝
    160, 160, 160   ];  % No  灰  #A0A0A0
colors = colors/255;

FS_axis   = 18;   % 坐标轴与刻度字号（与程序2一致）
FS_title  = 18;   % 标题字号
FS_text   = 18;   % 条内数字字号

% 图大小与程序2一致
fig_main = figure('Position',[100 100 800 600]);
tl = tiledlayout(1,2,'TileSpacing','compact','Padding','compact');

%% ================= 左面板：显著单调上升 =================
ax1 = nexttile;
hb1 = bar(P_inc,'stacked','BarWidth',0.8); hold(ax1,'on');

for k = 1:3
    hb1(k).FaceColor = colors(k,:);
end

set(ax1,'XTick',1:10,'XTickLabel',biome_names, ...
    'FontSize',FS_axis,'FontName','Arial');
ylim(ax1,[0 1]);
yticks(ax1,0:0.2:1);
yticklabels(ax1,{'0%','20%','40%','60%','80%','100%'});

% 按要求：不加 ylabel
title(ax1,'Monotonic Increase (significant)', ...
    'FontSize',FS_title,'FontName','Arial');

grid(ax1,'on'); box(ax1,'on');
set(ax1,'GridLineStyle','--','GridColor',[0.3 0.3 0.3], ...
    'GridAlpha',0.3,'LineWidth',1.5);

% 百分比数字（>5%）
for r = 1:size(P_inc,1)
    base = 0;
    for c = 1:3
        if P_inc(r,c) > 0.05
            col = colors(c,:);
            L   = 0.299*col(1)+0.587*col(2)+0.114*col(3);
            txtc = 'k'; if L < 0.5, txtc = 'w'; end
            text(ax1, r, base + P_inc(r,c)/2, sprintf('%.0f',100*P_inc(r,c)), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontName','Arial','FontSize',FS_text,'Color',txtc);
        end
        base = base + P_inc(r,c);
    end
end

%% ================= 右面板：显著单调下降 =================
ax2 = nexttile;
hb2 = bar(P_dec,'stacked','BarWidth',0.8); hold(ax2,'on');

for k = 1:3
    hb2(k).FaceColor = colors(k,:);
end

set(ax2,'XTick',1:10,'XTickLabel',biome_names, ...
    'FontSize',FS_axis,'FontName','Arial');
ylim(ax2,[0 1]);
yticks(ax2,0:0.2:1);
yticklabels(ax2,{'0%','20%','40%','60%','80%','100%'});

title(ax2,'Monotonic Decrease (significant)', ...
    'FontSize',FS_title,'FontName','Arial');

grid(ax2,'on'); box(ax2,'on');
set(ax2,'GridLineStyle','--','GridColor',[0.3 0.3 0.3], ...
    'GridAlpha',0.3,'LineWidth',1.5);

for r = 1:size(P_dec,1)
    base = 0;
    for c = 1:3
        if P_dec(r,c) > 0.05
            col = colors(c,:);
            L   = 0.299*col(1)+0.587*col(2)+0.114*col(3);
            txtc = 'k'; if L < 0.5, txtc = 'w'; end
            text(ax2, r, base + P_dec(r,c)/2, sprintf('%.0f',100*P_dec(r,c)), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontName','Arial','FontSize',FS_text,'Color',txtc);
        end
        base = base + P_dec(r,c);
    end
end

%% ========== 图例放在同一张图底部中央 ==========
% 在第二个子图上创建 legend，然后把它挪到整个 tiledlayout 底部
lgd = legend(ax2, ...
    {'UD (up then down)', 'DU (down then up)', 'NS'}, ...
    'Orientation','horizontal','FontSize',18,'FontName','Arial');
lgd.Layout.Tile = 'south';   % 关键：让图例占据整个布局的底部 Tile

% 保存
print(fig_main, 'D:\monoandtippingGPP.png', '-dpng', '-r300');
%% ====================== FUNCTIONS ======================

function [code, detail] = classify_trend_mono_only(x, alpha_mono)
    % 单调趋势判别（全序列）：
    % code: 1=显著单调减, 3=显著单调增, 5=无显著
    x = x(:);
    n = numel(x);
    assert(n >= 5, '序列长度至少 5');

    [p, sgn, slope] = lintrend_test(x);

    if p < alpha_mono && sgn > 0
        code = 3;   % 单调上升
        tstr = 'Inc';
    elseif p < alpha_mono && sgn < 0
        code = 1;   % 单调下降
        tstr = 'Dec';
    else
        code = 5;   % 无显著单调
        tstr = 'NS';
    end

    detail = struct( ...
        'p',     p, ...
        'slope', slope, ...
        'sign',  sgn, ...
        'type',  tstr, ...
        'final', sprintf('%s (slope = %.4g, p = %.3g)', tstr, slope, p));
end

% --------------------------------------------------------
function [code, detail] = classify_trend_uddu_only(x, alpha_uddu, minSegFrac)
    % 只判断是否存在显著拐点（UD/DU）。
    % code: 4=UD (上-下), 2=DU (下-上), 5=无显著
    x  = x(:);
    n  = numel(x);
    assert(n >= 5, '序列长度至少 5');

    minSeg = max(3, ceil(n * minSegFrac));

    [cp, dir, segL, segR, score] = find_uddu_cp_mk(x, alpha_uddu, minSeg);

    if ~isempty(cp)
        if strcmp(dir, 'UD')
            code = 4;
        elseif strcmp(dir, 'DU')
            code = 2;
        else
            code = 5;   % 理论上不会到这里
        end

        detail = struct( ...
            'type',     dir, ...
            'cp',       cp, ...
            'score',    score, ...
            'SegLeft',  segL, ...
            'SegRight', segR, ...
            'final',    sprintf('%s @ %d', dir, cp));
    else
        code = 5;
        detail = struct( ...
            'type',  'No breakpoint', ...
            'final', '无显著拐点');
    end
end

% --------------------------------------------------------
function [cp_best, dir, segL, segR, score_best] = find_uddu_cp_mk(x, alpha, minSeg)
    % 利用线性趋势检验，在所有可能的分割点中寻找：
    % 左、右两段均显著单调且符号相反的 cp
    % dir: 'UD' = 先升后降(上-下), 'DU' = 先降后升(下-上)
    x = x(:);
    n = numel(x);

    cp_best   = [];
    dir       = '';
    segL      = [];
    segR      = [];
    score_best = -inf;   % 越大越好（用左右两段斜率绝对值之和）

    % 搜索所有可能的分割点
    for cp = minSeg : (n - minSeg)
        xL = x(1:cp);
        xR = x(cp+1:end);

        [pL, sgnL, slopeL] = lintrend_test(xL);
        [pR, sgnR, slopeR] = lintrend_test(xR);

        if pL < alpha && pR < alpha && (sgnL * sgnR == -1)
            % 左右两段显著，且符号相反
            score_now = abs(slopeL) + abs(slopeR);  % 简单打分：斜率越大越好

            if score_now > score_best
                score_best = score_now;
                cp_best    = cp;
                segL       = [1, cp];
                segR       = [cp+1, n];

                if sgnL > 0 && sgnR < 0
                    dir = 'UD';   % up then down (上-下)
                elseif sgnL < 0 && sgnR > 0
                    dir = 'DU';   % down then up (下-上)
                else
                    dir = '';
                end
            end
        end
    end

    if isempty(cp_best)
        cp_best    = [];
        dir        = '';
        segL       = [];
        segR       = [];
        score_best = [];
    end
end

% --------------------------------------------------------
function [p, sgn, slope] = lintrend_test(x)
    % 简单线性趋势检验：用时间 t = 1:n 与 x 做相关，给出 p 值和斜率符号
    % 返回：
    %   p     - 双侧显著性
    %   sgn   - 斜率符号 (1 / -1 / 0)
    %   slope - 简单线性回归斜率（用于打分）
    x = x(:);
    mask = ~isnan(x);
    x = x(mask);
    n = numel(x);

    if n < 5
        p     = 1;
        sgn   = 0;
        slope = 0;
        return;
    end

    t = (1:n)';

    C = corrcoef(t, x);
    if numel(C) < 4 || isnan(C(1,2))
        p     = 1;
        sgn   = 0;
        slope = 0;
        return;
    end

    r = C(1,2);
    % 用相关系数近似斜率（也可以改成 polyfit）
    slope = r * (std(x) / std(t));

    if abs(r) >= 1
        % 完全线性相关
        p = 0;
    else
        tstat = r * sqrt((n-2) / (1 - r^2));
        % 需要 Statistics Toolbox 的 tcdf；一般都有
        p = 2 * (1 - tcdf(abs(tstat), n-2));
    end

    sgn = sign(slope);
end
