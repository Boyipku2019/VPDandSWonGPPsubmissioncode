
clear all;close all;clc;
IGBP=imread('G:\Resource use efficiencies\Data\LULC\IGBP0.25.tif');
IGBP=IGBP';
HFP=imread('G:\Resource use efficiencies\Data\Humanfootprint\HFP2018includingsouthpole.tif');
HFP=HFP';


%%��ȡGPP����
GPP2=single(zeros(1440,721,420));
fid = fopen('G:\Resource use efficiencies\dataresult\CEEMDAN\GPP025LastIMF.raw','r'); %��RAW�ļ�
GPP2 = fread(fid,1440*721*420,'single'); % ��RAW����
fclose(fid); % �ر��ļ�
GPP2=reshape(GPP2,[1440,721,420]);

ENFIncDec=[];
EBFIncDec=[];
DNFIncDec=[];
DBFIncDec=[];
MFIncDec=[];
SHLIncDec=[];
SVAIncDec=[];
GRAIncDec=[];
WETIncDec=[];

ENFDecInc=[];
EBFDecInc=[];
DNFDecInc=[];
DBFDecInc=[];
MFDecInc=[];
SHLDecInc=[];
SVADecInc=[];
GRADecInc=[];
WETDecInc=[];

countall=single(zeros(1,5));
tippingworld=single(zeros(1440,721));
%����ͳ�����ڱ仯
for i=1:1440
    for j=1:721
        if any(GPP2(i,j,:))&&((IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11)) &&HFP(i,j)<=25  %�ж�Ϊ��Ч��Ԫ��ȥ����Ч������ݺ�0ֵ������������
        GPPonepixel= GPP2(i,j,:);
        GPPonepixel=reshape(GPPonepixel,420,1);
        
           first_derivative = diff(GPPonepixel);

            % Ѱ�ҵ������ű仯��λ��
            sign_change = find(diff(sign(first_derivative)) ~= 0);
            
            % �жϹյ�����
            if isempty(sign_change)
%                 %disp('���һ��IMFû�е�һ�յ㡣');
%                 if all(first_derivative > 0)
%                     %disp('���һ��IMF�ǵ������ġ�');
%                     tippingworld(i,j)=3;countall(3)=countall(3)+1;
%                 elseif all(first_derivative < 0)
%                     %disp('���һ��IMF�ǵ������ġ�');
%                     tippingworld(i,j)=1;countall(1)=countall(1)+1;
%                 else
%                     %disp('���һ��IMF�Ȳ�������Ҳ����������');
%                 end
            else
                if length(sign_change) == 1
                    %disp(['�յ�λ���ڣ�', num2str(sign_change)]);
                    location=sign_change;
                    if first_derivative(sign_change) < 0
                        %disp('�յ����ͣ��Ƚ�����');
                        %tippingworld(i,j)=2;countall(2)=countall(2)+1;
                        
                           if IGBP(i,j)==1
                               ENFDecInc=[ENFDecInc;location];
                           end
                           if IGBP(i,j)==2
                               EBFDecInc=[EBFDecInc;location];
                           end
                           if IGBP(i,j)==3
                               DNFDecInc=[DNFDecInc;location];
                           end
                           if IGBP(i,j)==4
                                DBFDecInc=[DBFDecInc;location];
                           end
                           if IGBP(i,j)==5
                                MFDecInc=[MFDecInc;location];
                           end
                           if (IGBP(i,j)==6||IGBP(i,j)==7)
                               SHLDecInc=[SHLDecInc;location];
                           end
                           if (IGBP(i,j)==8||IGBP(i,j)==9)
                               SVADecInc=[SVADecInc;location];
                           end
                           if IGBP(i,j)==10
                               GRADecInc=[GRADecInc;location];
                           end
                           if IGBP(i,j)==11
                                WETDecInc=[WETDecInc;location];
                           end
                    else
                       % disp('�յ����ͣ�������');
                       %tippingworld(i,j)=4;countall(4)=countall(4)+1;
                           if IGBP(i,j)==1
                                ENFIncDec=[ENFIncDec;location];
                           end
                           if IGBP(i,j)==2
                               EBFIncDec=[EBFIncDec;location];
                           end
                           if IGBP(i,j)==3
                               DNFIncDec=[DNFIncDec;location];
                           end
                           if IGBP(i,j)==4
                                DBFIncDec=[DBFIncDec;location];
                           end
                           if IGBP(i,j)==5
                                MFIncDec=[MFIncDec;location];
                           end
                           if (IGBP(i,j)==6||IGBP(i,j)==7)
                               SHLIncDec=[SHLIncDec;location];
                           end
                           if (IGBP(i,j)==8||IGBP(i,j)==9)
                               SVAIncDec=[SVAIncDec;location];
                           end
                           if IGBP(i,j)==10
                               GRAIncDec=[GRAIncDec;location];
                           end
                           if IGBP(i,j)==11
                                WETIncDec=[WETIncDec;location];
                           end
                    end
                else
%                     %disp('���һ��IMF�ж���յ㡣');
%                     tippingworld(i,j)=5;countall(5)=countall(5)+1;
                end
            end
            
         
            end


       
    end
    i
end
IncDecgroup={ENFIncDec;
EBFIncDec;
DNFIncDec;
DBFIncDec;
MFIncDec;
SHLIncDec;
SVAIncDec;
GRAIncDec;
WETIncDec};
DecIncgroup={ENFDecInc;
EBFDecInc;
DNFDecInc;
DBFDecInc;
MFDecInc;
SHLDecInc;
SVADecInc;
GRADecInc;
WETDecInc};

biomename=["ENF","EBF","DNF","DBF","MF","SHL","SVA","GRA","WET"];
% % Set up the figure
% % Set up the figure
figure;
set(gcf, 'Position', [100, 100, 900, 700]);

% Data
% Assuming DecIncgroup and IncDecgroup are cell arrays with 9 elements each
% Each element contains data for each subplot

for i = 1:9
    subplot(3, 3, i);
    
    % Plot the histogram for DecIncgroup
    h1 = histogram(DecIncgroup{i}, 'Normalization', 'pdf', 'FaceColor', [0.6 0.6 1]);
    hold on;
    
    % Plot the fitted curve for DecIncgroup
    pd1 = fitdist(DecIncgroup{i}, 'Normal');
    x1 = linspace(min(DecIncgroup{i}), max(DecIncgroup{i}), 100);
    y1 = pdf(pd1, x1);
    p1 = plot(x1, y1, 'b-', 'LineWidth', 2); % Capture the handle for the line
    
    % Plot the histogram for IncDecgroup
    h2 = histogram(IncDecgroup{i}, 'Normalization', 'pdf', 'FaceColor', [1 0.6 0.6]);
    
    % Plot the fitted curve for IncDecgroup
    pd2 = fitdist(IncDecgroup{i}, 'Normal');
    x2 = linspace(min(IncDecgroup{i}), max(IncDecgroup{i}), 100);
    y2 = pdf(pd2, x2);
    p2 = plot(x2, y2, 'r-', 'LineWidth', 2); % Capture the handle for the line
    
    % Set titles for subplots instead of xlabels
    title(biomename{i}); % You can customize titles as needed
    
    % Only show xticks on the bottom row
    if i >= 7
        % Set xticks for every 5 years (12 months per year, so every 60 months)
        xticks(1:60:420);
        % Label as 198401, 198901, etc., starting from 198401
        xticklabels({'198401', '198901', '199401', '199901', '200401', '200901', '201401'});
    else
        set(gca, 'XTickLabel', []); % Remove xticks for other subplots
    end
    
    % Show y-ticks for all subplots
    yticks('auto');
    
    % Only show ylabels on the left column
    if mod(i, 3) == 1
        ylabel('Density');
    end
    
    hold off;
end

% Add a global legend with increased font size
legend_handle = legend([h1, h2], {'Dec-Inc', 'Inc-Dec'}, ...
       'Orientation', 'horizontal', 'Location', 'southoutside');

% Increase the font size of the legend
set(legend_handle, 'FontSize', 10);  % Adjust the font size as needed
