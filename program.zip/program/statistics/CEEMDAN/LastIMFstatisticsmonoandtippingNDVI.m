%% ================= 合并判别：条件分解统计与绘图 =================
clear; close all; clc;

%% ---- 输入与参数 ----
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif'); IGBP = IGBP';
HFP  = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');  HFP  = HFP';
alpha_mono = 1e-3;                 % 单调检验显著性
alpha_uddu = 1e-3;                 % 拐点两段显著性
minSegFrac = 0.10;                 % 拐点两侧最少长度占比

% 读取 CEEMDAN 最低频（趋势/LastIMF 或你要检的那一分量）
GPP2 = single(zeros(720,360,468));
fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\NDVI05LastIMF.raw','r');
GPP2 = fread(fid,720*360*468,'single'); fclose(fid);
GPP2 = reshape(GPP2,[720,360,468]);

%% ---- 结果计数器（每类生物群系 × 2 面板 × 3 段）----
% 面板顺序：1=Inc(显著单调上升)、2=Dec(显著单调下降)
% 段顺序： 1=UD(上-下)，2=DU(下-上)，3=No(无拐点)
K = 10;   % 9 biome + All
panel_inc = single(zeros(K,3));
panel_dec = single(zeros(K,3));
den_inc   = single(zeros(K,1));   % 分母（显著单调上升的像元数）
den_dec   = single(zeros(K,1));   % 分母（显著单调下降的像元数）

%% ---- 主循环：同时计算 mono 与 UDDU ----
for i = 1:720
    for j = 1:360
        if ~any(GPP2(i,j,:)), continue; end
        if ~(IGBP(i,j)>=1 && IGBP(i,j)<=11), continue; end
        if HFP(i,j) > 25, continue; end

        x = reshape(GPP2(i,j,:), 468, 1);

        % 1) 单调判别
        [mono_code, ~] = classify_trend_mono_only(x, alpha_mono);
        % mono_code: 1=单调减, 3=单调增, 5=无显著

        % 2) 拐点判别（只要左右两段都显著且符号相反才算 UD/DU）
        [uddu_code, ~] = classify_trend_uddu_only(x, alpha_uddu, minSegFrac);
        % uddu_code: 4=UD, 2=DU, 5=无显著拐点

        % biome 行索引
        c = IGBP(i,j);
        switch c
            case 1, row = 1;     % ENF
            case 2, row = 2;     % EBF
            case 3, row = 3;     % DNF
            case 4, row = 4;     % DBF
            case 5, row = 5;     % MF
            case {6,7}, row = 6; % SHL
            case {8,9}, row = 7; % SVA
            case 10, row = 8;    % GRA
            case 11, row = 9;    % WET
            otherwise, continue;
        end

        % 把拐点 code 映射到列：1=UD, 2=DU, 3=No
        if uddu_code == 4
            segIdx = 1;
        elseif uddu_code == 2
            segIdx = 2;
        else
            segIdx = 3;
        end

        % 条件分解：分别落入 Inc 面板或 Dec 面板
        if mono_code == 3      % 显著单调上升
            panel_inc(row, segIdx) = panel_inc(row, segIdx) + 1;
            den_inc(row) = den_inc(row) + 1;
            panel_inc(10, segIdx) = panel_inc(10, segIdx) + 1; % All
            den_inc(10) = den_inc(10) + 1;
        elseif mono_code == 1  % 显著单调下降
            panel_dec(row, segIdx) = panel_dec(row, segIdx) + 1;
            den_dec(row) = den_dec(row) + 1;
            panel_dec(10, segIdx) = panel_dec(10, segIdx) + 1; % All
            den_dec(10) = den_dec(10) + 1;
        else
            % 单调不显著者不计入本次两面板统计
        end
    end
    i
end

%% ---- 转百分比（面板内各行按分母归一）----
P_inc = panel_inc ./ max(den_inc,1);
P_dec = panel_dec ./ max(den_dec,1);

%% ---- 绘图（两面板堆叠条形图）----
%% ---- 绘图（两面板堆叠条形图，不含图例）----
biome_names = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','All'};
colors = [ ...
    230, 159,   0;   % UD  橙 #E69F00
     86, 180, 233;   % DU  天蓝 #56B4E9
    160, 160, 160];  % No  灰  #A0A0A0
colors = colors/255;

fig_main = figure('Position',[80 80 600 300]);  % 主图
tiledlayout(1,2,'TileSpacing','compact','Padding','compact');

% 左：显著单调上升
nexttile;
hb1 = bar(P_inc,'stacked','BarWidth',0.8); hold on;
for k=1:3, hb1(k).FaceColor = colors(k,:); end
set(gca,'XTick',1:10,'XTickLabel',biome_names,'FontSize',12,'FontName','Arial');
ylim([0 1]); yticks(0:0.2:1); yticklabels({'0%','20%','40%','60%','80%','100%'});
ylabel('Percentage within significant monotonic group','FontSize',12,'FontName','Arial');
title('Monotonic Increase (significant)','FontSize',12,'FontName','Arial');
grid on; box on;
% 百分比数字（>5%）
for r=1:size(P_inc,1)
    base=0;
    for c=1:3
        if P_inc(r,c)>0.05
            col = colors(c,:);
            L = 0.299*col(1)+0.587*col(2)+0.114*col(3);
            txtc = 'k'; if L<0.5, txtc='w'; end
            text(r, base+P_inc(r,c)/2, sprintf('%.0f',100*P_inc(r,c)), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontName','Arial','FontSize',10,'Color',txtc);
        end
        base = base + P_inc(r,c);
    end
end
% 不添加 legend

% 右：显著单调下降
nexttile;
hb2 = bar(P_dec,'stacked','BarWidth',0.8); hold on;
for k=1:3, hb2(k).FaceColor = colors(k,:); end
set(gca,'XTick',1:10,'XTickLabel',biome_names,'FontSize',12,'FontName','Arial');
ylim([0 1]); yticks(0:0.2:1); yticklabels({'0%','20%','40%','60%','80%','100%'});
title('Monotonic Decrease (significant)','FontSize',12,'FontName','Arial');
grid on; box on;
for r=1:size(P_dec,1)
    base=0;
    for c=1:3
        if P_dec(r,c)>0.05
            col = colors(c,:);
            L = 0.299*col(1)+0.587*col(2)+0.114*col(3);
            txtc = 'k'; if L<0.5, txtc='w'; end
            text(r, base+P_dec(r,c)/2, sprintf('%.0f',100*P_dec(r,c)), ...
                'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontName','Arial','FontSize',10,'Color',txtc);
        end
        base = base + P_dec(r,c);
    end
end
% 不添加 legend
print(fig_main, 'D:\monoandtippingNDVI.png', '-dpng', '-r300');   % 300 dpi
%% ---- 单独绘制并保存图例（300 dpi 到 D 盘根目录）----
fig_leg = figure('Position',[100 100 360 140]); clf; hold on;
% 用 NaN 柱创建图例句柄
h1 = bar(nan, nan, 'FaceColor', colors(1,:));
h2 = bar(nan, nan, 'FaceColor', colors(2,:));
h3 = bar(nan, nan, 'FaceColor', colors(3,:));
leg = legend([h1 h2 h3], ...
    {'UD (up then down)','DU (down then up)','No breakpoint'}, ...
    'FontName','Arial','FontSize',12,'Orientation','horizontal','Location','southoutside');
axis off; set(gca,'Visible','off');

% 保存 300 dpi PNG（也可切换 tiff/pdf）
set(fig_leg,'PaperPositionMode','auto');
print(fig_leg, 'D:\legendmonoandtippingNDVI.png', '-dpng', '-r300');   % 300 dpi
% 可选：
% print(fig_leg, 'D:\legend_uddu.tif', '-dtiff', '-r300');
% print(fig_leg, 'D:\legend_uddu.pdf', '-dpdf');  % 矢量


%% ====================== FUNCTIONS ======================

function [result_code, detail] = classify_trend_mono_only(x, alpha_mono)
% 功能：判断整个序列是否显著单调趋势
% 输入：
%   x - 时间序列 (列向量)
%   alpha_mono - 显著性阈值
% 输出：
%   result_code - 1=显著单调下降, 3=显著单调上升, 5=无显著
%   detail - 结构体，保存 tau/Z/p 等细节

    x = x(:);
    n = numel(x);
    assert(n>=5,'序列长度至少 5');

    [tau_all, Z_all, p_all, label_all] = mk_test(x, alpha_mono);

    detail = struct('tau',tau_all,'Z',Z_all,'p',p_all,'label',label_all);

    if p_all < alpha_mono
        if tau_all > 0
            result_code = 3; % 单调上升
        else
            result_code = 1; % 单调下降
        end
    else
        result_code = 5;     % 无显著
    end
end

function [code, detail] = classify_trend_uddu_only(x, alpha_uddu, minSegFrac)
% 功能：判断是否存在显著拐点（先升后降 UD / 先降后升 DU）
% 输入：
%   x - 时间序列 (列向量)
%   alpha_uddu - 显著性阈值（两段都要显著）
%   minSegFrac - 拟合切点两侧最少样本占比
% 输出：
%   code - 4=UD, 2=DU, 5=无显著拐点
%   detail - 结构体，包含拐点位置和检验结果

    x = x(:);
    n = numel(x);
    assert(n>=5,'序列长度至少 5');

    minSeg = max(3, ceil(n * minSegFrac));
    [cp, dir, segL, segR, score] = find_uddu_cp_mk(x, alpha_uddu, minSeg);

    if ~isempty(cp)
        if strcmp(dir,'UD')
            code = 4;
        else
            code = 2;
        end
        detail = struct('type',dir,'cp',cp,'score',score, ...
                        'SegLeft',segL,'SegRight',segR, ...
                        'final',sprintf('%s @ %d',dir,cp));
    else
        code = 5;
        detail = struct('type','No breakpoint','final','无显著拐点');
    end
end

function [cp_best, dir, segL, segR, bestScore] = find_uddu_cp_mk(x, alpha, minSeg)
% 穷举切点，判断左右两段 MK 是否显著且方向相反
    x = x(:); n = numel(x);
    cp_best = []; dir = ''; bestScore = -Inf;
    segL = struct(); segR = struct();

    for k = minSeg:(n-minSeg)
        [tau1, Z1, p1, lab1] = mk_test(x(1:k), alpha);
        [tau2, Z2, p2, lab2] = mk_test(x(k+1:end), alpha);
        if (p1 < alpha) && (p2 < alpha) && (tau1 * tau2 < 0)
            score = abs(tau1) + abs(tau2); % 打分
            if score > bestScore
                bestScore = score; cp_best = k;
                dir = ternary(tau1>0,'UD','DU');
                segL = struct('tau',tau1,'Z',Z1,'p',p1,'label',lab1);
                segR = struct('tau',tau2,'Z',Z2,'p',p2,'label',lab2);
            end
        end
    end

    if isempty(cp_best)
        dir = ''; bestScore = NaN;
    end
end

function [tau, Z, p, trend] = mk_test(x, alpha)
% 标准 Mann-Kendall 检验
    x = x(:); n = numel(x);
    S = 0;
    for i = 1:n-1
        S = S + sum(sign(x(i+1:end) - x(i)));
    end
    VarS = n*(n-1)*(2*n+5)/18;
    Z = S / sqrt(VarS + eps);
    p = 2*(1 - normcdf(abs(Z)));
    tau = 2*S/(n*(n-1));
    if p < alpha
        trend = ternary(tau>0,'Significant up','Significant down');
    else
        trend = 'Not significant';
    end
end

function y = ternary(cond,a,b)
    if cond, y=a; else, y=b; end
end

