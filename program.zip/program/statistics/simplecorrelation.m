%% ================== FLUXNET + RS 相关：6 面板热力图（紧凑；仅 Long-term 显示 CO2） ==================
% 面板：Half-hourly | Daily | Monthly | Semiannual | Annual | Long-term
% 行：9类植被 + All biomes（10行）
% 列：
%   - 前 5 个面板：{T, P, R, SW}（4列）
%   - 最后一个面板（Long-term）：{T, P, R, SW, CO2}（5列，仅此面板显示 CO2）
% 规则：仅计入 p<0.05；样本量 > 40；FLUXNET 端要求 Y>0 且四自变量非 NaN
% 新增：遥感端像元仅在 HFP <= 25 时有效；LT 面板新增 CO2 的“简单相关”（其余面板不显示 CO2）
% 输出：D:\corr_FLUXNET_RS_6panels_CO2_onlyLT_compact.png（300 dpi，2000×600 像素）
% Tested: MATLAB R2021a
clear; clc; close all; warning('off','all');
tAll = tic;

%% ================== 路径配置（请按需修改） ==================
% ---- FLUXNET ----
rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
siteXlsx        = fullfile(rootFolder_FLUX, 'FLUXsitelistnew.xlsx');   % 第1列站名；第8列植被类型

% ---- 遥感（SSA/CEEMDAN 分解结果）----
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';   % IGBP 0.5°
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';    % HFP 掩膜

% Semiannual
GPP_SA = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Semiannual_4comp.raw');
T_SA   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Semiannual_4comp.raw');
P_SA   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Semiannual_4comp.raw');
R_SA   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Semiannual_4comp.raw');
SW_SA  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Semiannual_4comp.raw');

% Annual
GPP_AN = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');

% Long-term（Trend）
GPP_LT = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
CO2_LT = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw');   % ← 如文件名不同请修改

assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);
assert(isfile(lulcPath),       'LULC 文件不存在：%s', lulcPath);
assert(isfile(hfpPath),        'HFP  文件不存在：%s', hfpPath);

%% ================== 通用配置 ==================
alpha       = 0.05;                          % 显著性阈值
minN        = 40;                            % 样本量阈值
xlabels4    = {'T','P','R','SW'};            % 前 5 个面板使用
xlabels5    = {'T','P','R','SW','CO2'};      % Long-term 使用
vegRows     = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'}; % 10 行

panelTitles = {'Half-hourly','Daily','Monthly','Semiannual','Annual','Long-term'};
nPanels     = numel(panelTitles);

% —— 字体 ——（与前版一致）
baseAxisFont  = 15;
labelFont     = 16;
titleFont     = 18;
cellTextFont  = 14;

set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
set(groot,'DefaultAxesFontSize', baseAxisFont);

%% ================== Part A：FLUXNET 三尺度 ==================
% 读站点→植被类型映射
site2veg = containers.Map('KeyType','char','ValueType','char'); hasVegMap = false;
if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);
        names = string(Tsite{:,1});    % 站名
        vegs  = string(Tsite{:,8});    % 植被类型
        for i = 1:numel(names)
            k = strtrim(names(i)); v = strtrim(vegs(i));
            if ~isempty(k); site2veg(char(k)) = char(v); end
        end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx，FLUXNET 端将无法按植被聚合。\n');
    end
end

% 容器：FLUXNET 三面板（每面板 10×4）
SUM_F = cell(1,3); COUNT_F = cell(1,3);
for s=1:3
    SUM_F{s}   = nan(10,4,'single');
    COUNT_F{s} = zeros(10,4,'uint32');
end

% 收集目标 CSV（必须包含 FULLSET 与 HH/DD/MM）
allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
targets = [];
for i = 1:numel(allCSV)
    nm = allCSV(i).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        targets = [targets; allCSV(i)]; %#ok<AGROW>
    end
end
if isempty(targets)
    error('未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
else
    fprintf('FLUXNET 可用文件：%d 个\n', numel(targets));
end

% 逐文件计算相关并聚合（仅 p<alpha）
yName = 'GPP_DT_VUT_REF';
coreX = {'TA_F_MDS','P_F','SW_IN_F_MDS'};   % + SWC 平均
t0 = tic;
for k = 1:numel(targets)
    f = fullfile(targets(k).folder, targets(k).name);
    [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
    si = find(strcmp({'HH','DD','MM'}, scaleTag), 1);    % 1..3
    if isempty(si), continue; end

    try
        % — 读取需要的列 —
        opts = detectImportOptions(f);
        varNames = opts.VariableNames;
        needFixed = [ {yName}, coreX ];
        if ~all(ismember(needFixed, varNames))
            fprintf('  ↳ 缺少 GPP/TA/P/SW_IN 列，跳过：%s\n', targets(k).name);
            continue;
        end
        % SWC_F_MDS_# 层
        swcMask = ~cellfun('isempty', regexp(varNames,'^SWC_F_MDS_\d+$','once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols)
            fprintf('  ↳ 无 SWC_F_MDS_# 层，跳过：%s\n', targets(k).name);
            continue;
        end

        opts.SelectedVariableNames = [needFixed, swcCols];
        T = readtable(f, opts);
        T = sentinel2nan(T, opts.SelectedVariableNames);

        % 计算 SWC 平均
        SWCmat  = T{:, swcCols}; if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SWC_avg = mean(SWCmat, 2, 'omitnan');

        % 取变量
        Y  = T.(yName); TA = T.TA_F_MDS; PP = T.P_F; SW = T.SW_IN_F_MDS;
        mask = ~isnan(Y) & Y>0 & ~isnan(TA) & ~isnan(PP) & ~isnan(SW) & ~isnan(SWC_avg);
        Y  = Y(mask);
        X4 = [TA(mask), PP(mask), SW(mask), SWC_avg(mask)];
        nobs = size(X4,1);
        if nobs <= minN, continue; end

        % 简单相关（单变量相关）
        [r4, p4] = pcorr_vec(Y, X4);
        if isempty(r4), continue; end

        % 植被行号（默认 All=10）
        ri = 10;
        if hasVegMap && isKey(site2veg, siteName)
            vname = site2veg(siteName);
            ridx  = find(strcmp(vegRows, vname),1);
            if ~isempty(ridx), ri = ridx; end
        end

        % 累加：仅 p<alpha 的条目；同时给 All biomes 行加一遍
        for c = 1:4
            if ~isnan(r4(c)) && ~isnan(p4(c)) && p4(c) < alpha
                if isnan(SUM_F{si}(ri,c)), SUM_F{si}(ri,c) = 0; end
                SUM_F{si}(ri,c)   = SUM_F{si}(ri,c)   + r4(c);
                COUNT_F{si}(ri,c) = COUNT_F{si}(ri,c) + 1;

                if ri ~= 10
                    if isnan(SUM_F{si}(10,c)), SUM_F{si}(10,c) = 0; end
                    SUM_F{si}(10,c)   = SUM_F{si}(10,c)   + r4(c);
                    COUNT_F{si}(10,c) = COUNT_F{si}(10,c) + 1;
                end
            end
        end

    catch ME
        fprintf('  ↳ 失败已跳过：%s | %s\n', targets(k).name, ME.message);
    end

    if mod(k,50)==0
        fprintf('  站点进度 %d/%d | 用时 %.1fs\n', k, numel(targets), toc(t0)); t0 = tic;
    end
end

% 计算 FLUXNET 三面板均值
MEAN_F = cell(1,3);
for si = 1:3
    S = SUM_F{si}; C = COUNT_F{si};
    M = nan(size(S),'single');
    mk = C>0;
    M(mk) = S(mk) ./ single(C(mk));
    MEAN_F{si} = M;          % 每面板 10×4
end

%% ================== Part B：遥感 三尺度（去除 4-month + HFP≤25） ==================
% 读 LULC 与 HFP 并设有效类
IGBP = imread(lulcPath); IGBP = IGBP';
HFP  = imread(hfpPath);  HFP  = HFP';
[nx, ny] = size(IGBP);                           % 720 × 360
valid_mask = ismember(IGBP, 1:11) & (HFP <= 25); % 联合掩膜

% 读 RAW 并裁剪时间（25:444）
GPP1 = read_raw(GPP_SA, [720,360,420]);
T1   = read_raw(T_SA,   [720,360,468]); T1=T1(:,:,25:444);
P1   = read_raw(P_SA,   [720,360,468]); P1=P1(:,:,25:444);
R1   = read_raw(R_SA,   [720,360,468]); R1=R1(:,:,25:444);
SW1  = read_raw(SW_SA,  [720,360,468]); SW1=SW1(:,:,25:444);

GPP3 = read_raw(GPP_AN, [720,360,420]);
T3   = read_raw(T_AN,   [720,360,468]); T3=T3(:,:,25:444);
P3   = read_raw(P_AN,   [720,360,468]); P3=P3(:,:,25:444);
R3   = read_raw(R_AN,   [720,360,468]); R3=R3(:,:,25:444);
SW3  = read_raw(SW_AN,  [720,360,468]); SW3=SW3(:,:,25:444);

GPP2 = read_raw(GPP_LT, [720,360,420]);
T2   = read_raw(T_LT,   [720,360,468]); T2=T2(:,:,25:444);
P2   = read_raw(P_LT,   [720,360,468]); P2=P2(:,:,25:444);
R2   = read_raw(R_LT,   [720,360,468]); R2=R2(:,:,25:444);
SW2  = read_raw(SW_LT,  [720,360,468]); SW2=SW2(:,:,25:444);
CO2  = read_raw(CO2_LT, [720,360,468]); CO2=CO2(:,:,25:444);   % 仅 LT 面板使用

% 累加器：RS 的前两个面板 10×4，LT 面板 10×5
SUM_R   = {nan(10,4,'single'), nan(10,4,'single'), nan(10,5,'single')};
COUNT_R = {zeros(10,4,'uint32'), zeros(10,4,'uint32'), zeros(10,5,'uint32')};

fprintf('开始逐像元相关（720×360，含 HFP≤25 掩膜）...\n');
tRow = tic;
for i = 1:nx
    for j = 1:ny
        if ~valid_mask(i,j), continue; end
        ri = igbp_to_row(IGBP(i,j));   % 1..9；0=跳过
        if ri==0, continue; end

        % 1) Semiannual（4列）
        y  = squeeze(GPP1(i,j,:));
        X4 = [squeeze(T1(i,j,:)), squeeze(P1(i,j,:)), squeeze(R1(i,j,:)), squeeze(SW1(i,j,:))];
        [r, p] = pcorr_vec_with_minN(y, X4, minN);
        if ~isempty(r)
            SUM_R{1}   = add_into(SUM_R{1}, COUNT_R{1}, ri, r, p, alpha);
            COUNT_R{1} = add_count(COUNT_R{1}, ri, r, p, alpha);
            SUM_R{1}   = add_into(SUM_R{1}, COUNT_R{1}, 10, r, p, alpha);
            COUNT_R{1} = add_count(COUNT_R{1}, 10, r, p, alpha);
        end

        % 2) Annual（4列）
        y  = squeeze(GPP3(i,j,:));
        X4 = [squeeze(T3(i,j,:)), squeeze(P3(i,j,:)), squeeze(R3(i,j,:)), squeeze(SW3(i,j,:))];
        [r, p] = pcorr_vec_with_minN(y, X4, minN);
        if ~isempty(r)
            SUM_R{2}   = add_into(SUM_R{2}, COUNT_R{2}, ri, r, p, alpha);
            COUNT_R{2} = add_count(COUNT_R{2}, ri, r, p, alpha);
            SUM_R{2}   = add_into(SUM_R{2}, COUNT_R{2}, 10, r, p, alpha);
            COUNT_R{2} = add_count(COUNT_R{2}, 10, r, p, alpha);
        end

        % 3) Long-term（5列：前4列为 T/P/R/SW，第5列为 CO2）
        y  = squeeze(GPP2(i,j,:));
        X4 = [squeeze(T2(i,j,:)), squeeze(P2(i,j,:)), squeeze(R2(i,j,:)), squeeze(SW2(i,j,:))];
        [r4, p4] = pcorr_vec_with_minN(y, X4, minN);

        % CO2 与 y 的简单相关
        Mco2 = [y, squeeze(CO2(i,j,:))];
        Mco2 = Mco2(all(isfinite(Mco2),2), :);
        r_co2 = NaN; p_co2 = NaN;
        if size(Mco2,1) > minN
            try
                [r_co2, p_co2] = corr(Mco2(:,1), Mco2(:,2), 'Rows','complete');
            catch
                r_co2 = NaN; p_co2 = NaN;
            end
        end

        r5 = [r4, r_co2];
        p5 = [p4, p_co2];

        if ~isempty(r5)
            SUM_R{3}   = add_into(SUM_R{3}, COUNT_R{3}, ri, r5, p5, alpha);
            COUNT_R{3} = add_count(COUNT_R{3}, ri, r5, p5, alpha);   % 保持类型一致（uint32）
            SUM_R{3}   = add_into(SUM_R{3}, COUNT_R{3}, 10, r5, p5, alpha);
            COUNT_R{3} = add_count(COUNT_R{3}, 10, r5, p5, alpha);
        end
    end

    if mod(i,40)==0
        fprintf('  行进度 %3d/720 | 累计耗时 %.1fs\n', i, toc(tRow));
        tRow = tic;
    end
end

% 计算遥感三面板均值（第 1/2 面板 10×4；第 3 面板 10×5）
MEAN_R = cell(1,3);
for p = 1:3
    S = SUM_R{p}; C = COUNT_R{p};
    M = nan(size(S),'single');
    mk = C>0;
    M(mk) = S(mk) ./ single(C(mk));
    MEAN_R{p} = M;
end

%% ================== 合并 6 面板并绘图（紧凑布局；仅最后面板含 CO2） ==================
MEAN_ALL = [MEAN_F, MEAN_R];   % {10x4,10x4,10x4,10x4,10x4,10x5}

cmap    = bwr_nature(255);           % 蓝→白→红
grayRGB = [150 150 150]/255;

% —— 紧凑布局设置（减少左右间距与内部间距）——
figW=1500; figH=600;
fig = figure('Color','w','Units','pixels','Position',[80 80 figW figH]);

leftPad=0.035; rightPad=0.006; topPad=0.06; bottomPad=0.23;  % 较小外边距
innerGap=0.005;                                              % 子图间距更小
tileW = (1 - leftPad - rightPad - innerGap*(nPanels-1)) / nPanels;
axH   = 1 - topPad - bottomPad;

for p = 1:nPanels
    axL = leftPad + (p-1)*(tileW + innerGap);
    ax  = axes('Position',[axL bottomPad tileW axH]); %#ok<LAXES>

    M = MEAN_ALL{p};
    % 先铺灰底显示 NaN
    gimg = repmat(reshape(grayRGB,1,1,3), [size(M,1), size(M,2), 1]);
    image(ax, 1:size(M,2), 1:size(M,1), gimg);
    set(ax,'YDir','normal'); axis(ax,'image'); hold(ax,'on');

    % 覆盖有效值
    h = imagesc(ax, M, [-1 1]); set(h,'AlphaData',~isnan(M)); colormap(ax, cmap);
    box(ax,'off'); ax.TickDir='out'; ax.LineWidth=0.75;

    % 坐标轴与标签（根据列数自适应）
    if p==1
        set(ax,'YTick',1:10,'YTickLabel',vegRows);
    else
        set(ax,'YTick',1:10,'YTickLabel',[]);
    end
    if size(M,2)==4
        set(ax,'XTick',1:4,'XTickLabel',xlabels4,'FontName','Arial');
    else
        set(ax,'XTick',1:5,'XTickLabel',xlabels5,'FontName','Arial');
    end
    ax.XTickLabelRotation = 45;
    ax.FontSize = baseAxisFont;

    % 标题稍小以避免遮挡
    title(ax, panelTitles{p}, 'FontWeight','bold','FontSize',titleFont-1,'FontName','Arial');

    % 在每格叠加均值（%.2f）
    [nr, nc] = size(M);
    for r = 1:nr
        for c = 1:nc
            val = M(r,c);
            if ~isnan(val)
                if abs(val) >= 0.5, tColor=[1 1 1]; else, tColor=[0 0 0]; end
                text(c, r, sprintf('%.2f', fix(val*100) / 100), 'HorizontalAlignment','center', ...
                     'VerticalAlignment','middle', 'FontSize', cellTextFont, ...
                     'FontWeight','bold', 'FontName','Arial', 'Color', tColor);
            end
        end
    end
end

% —— 底部共享色条（紧贴下方）——
cbLeft = 0.12; cbWidth = 0.76; cbHeight = 0.035; cbBottom = 0.10;
cbAx = axes('Position',[cbLeft cbBottom cbWidth cbHeight]); %#ok<LAXES>
xx = linspace(-1,1,512); Cbar = [xx; xx];
imagesc(cbAx, [-1 1], [0 1], Cbar); colormap(cbAx, cmap); caxis(cbAx, [-1 1]);
set(cbAx,'YTick',[],'YColor','none','TickDir','out','LineWidth',0.75, ...
          'XTick',-1:0.2:1,'FontName','Arial','FontSize',baseAxisFont);
xlabel(cbAx,'Correlation coefficient','FontSize',labelFont,'FontName','Arial');

% 导出到 D 盘根目录，300 dpi
outPath = 'D:\corr_FLUXNET_RS_6panels_CO2_onlyLT_compact.png';
exportgraphics(fig, outPath, 'Resolution', 300);
fprintf('✅ 已保存紧凑布局版本：%s | 尺寸 %dx%d | 分辨率 300dpi | 总耗时 %.1f 分钟\n', outPath, figW, figH, toc(tAll)/60);

%% ================== 辅助函数 ==================
function T = sentinel2nan(T, names)
% 把 -9999/超大异常 值转为 NaN
    for i = 1:numel(names)
        vname = names{i};
        if ~ismember(vname, T.Properties.VariableNames), continue; end
        v = T.(vname);
        if ~isnumeric(v), v = double(str2double(string(v))); end
        v(v<=-9990 | v>=9.9e8) = NaN;
        T.(vname) = v;
    end
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
% 从文件名解析尺度标签与站点名
    siteName = '';
    try
        s = string(fname);
        a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
        if ~isempty(a) && ~isempty(b) && b>a
            siteName = char(extractBetween(s,a+4,b-1));
        else
            tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
            if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
        end
    catch
        siteName = fname;
    end

    if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
        scaleTag = 'HH';
    elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
        scaleTag = 'DD';
    elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
        scaleTag = 'MM';
    else
        scaleTag = 'OTHER';
    end
end

function [r, p] = pcorr_vec(Y, X4)
% 对一个对象：Y vs X(:,k) 的单变量相关（返回 1×4）
    r = []; p = [];
    M = [Y(:), X4];
    M = M(all(isfinite(M),2), :);
    if size(M,1) <= 3, return; end
    y = M(:,1); X = M(:,2:end);
    r = nan(1,4); p = nan(1,4);
    for k=1:4
        try
            [rk, pk] = corr(y, X(:,k), 'Rows','complete');
        catch
            rk = NaN; pk = NaN;
        end
        r(k) = rk; p(k) = pk;
    end
end

function [r, p] = pcorr_vec_with_minN(y, X, minN)
% 同上，但要求最少样本量（> minN）
    r = []; p = [];
    M = [y(:), X];
    M = M(all(isfinite(M),2), :);
    if size(M,1) <= minN, return; end
    y = M(:,1); X = M(:,2:end);
    pnum = size(X,2);
    r = nan(1,pnum); p = nan(1,pnum);
    for k = 1:pnum
        try
            [rk, pk] = corr(y, X(:,k), 'Rows','complete');
        catch
            rk = NaN; pk = NaN;
        end
        r(k) = rk; p(k) = pk;
    end
end

function A = read_raw(path, shape)
% 读 single RAW → reshape
    fid = fopen(path,'r'); assert(fid>0, '无法打开：%s', path);
    A = fread(fid, prod(shape), 'single'); fclose(fid);
    A = reshape(A, shape);
end

function ri = igbp_to_row(code)
% IGBP 1..11 → 9 类植被行号（ENF/EBF/DNF/DBF/MF/SHL/SVA/GRA/WET）
% 6/7 合并为 SHL；8/9 合并为 SVA
    switch code
        case 1,  ri = 1;  % ENF
        case 2,  ri = 2;  % EBF
        case 3,  ri = 3;  % DNF
        case 4,  ri = 4;  % DBF
        case 5,  ri = 5;  % MF
        case {6,7}, ri = 6; % SHL
        case {8,9}, ri = 7; % SVA
        case 10, ri = 8;    % GRA
        case 11, ri = 9;    % WET
        otherwise, ri = 0;
    end
end

function SUM = add_into(SUM, COUNT, ri, r, p, alpha)
% 对 p<alpha 的条目累加到 SUM
    ncol = size(SUM,2);
    for c = 1:min(ncol, numel(r))
        if ~isnan(r(c)) && ~isnan(p(c)) && p(c) < alpha
            if isnan(SUM(ri,c)), SUM(ri,c) = 0; end
            SUM(ri,c) = SUM(ri,c) + r(c);
        end
    end
end

function COUNT = add_count(COUNT, ri, r, p, alpha)
% 对 p<alpha 的条目计数 +1
    ncol = size(COUNT,2);
    for c = 1:min(ncol, numel(r))
        if ~isnan(r(c)) && ~isnan(p(c)) && p(c) < alpha
            COUNT(ri,c) = COUNT(ri,c) + 1;   % COUNT 为 uint32，安全自增
        end
    end
end

function cmap = bwr_nature(n)
% 深蓝 → 白 → 砖红（对称，接近 Nature 冷暖配色）
    if nargin==0, n=255; end
    cpts = [0.02 0.12 0.45; 0.28 0.50 0.78; 1 1 1; 0.93 0.68 0.62; 0.60 0 0];
    half=floor(n/2);
    neg = interp1([0 0.5 1],[cpts(1,:);cpts(2,:);cpts(3,:)], linspace(0,1,half), 'linear');
    pos = interp1([0 0.5 1],[cpts(3,:);cpts(4,:);cpts(5,:)], linspace(0,1,half+1), 'linear');
    cmap=[neg; pos(2:end,:)];
    if size(cmap,1)~=n
        x=linspace(1,n,size(cmap,1)); cmap=interp1(x,cmap,1:n,'linear');
    end
end
