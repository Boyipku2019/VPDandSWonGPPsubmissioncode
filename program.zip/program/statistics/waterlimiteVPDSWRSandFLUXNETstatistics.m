%% =========================================================================================
% RS + FLUXNET | Water-limitation screening (VPD vs SW) + partial correlation
% + NEW FIG (UPDATED as requested):
%   RS 3 scales | For each WL condition (SW/VPD/Co) and each scale (MO/AN/LT),
%   each stacked block = (% of pixels within THAT vegetation type that are WL)
%   i.e.,  ng(veg & WL) / Nveg_total   * 100
%
% Figure layout (same as before):
%   1×3 subplots (Monthly/Annual/Long-term)
%   each subplot: 3 stacked bars (SW-limited / VPD-limited / Co-limited)
%   each stacked bar: 9 vegetation groups (ENF,EBF,DNF,DBF,MF,SHL,SVA,GRA,WET)
%   NOTE: stacked bars will NOT sum to 100 (like your attached figure)
%
% Colors:
%   - Use a muted/pastel palette (low saturation) inspired by Nature-style
%   - (not using the attached-figure palette)
%
% Tested: MATLAB R2021a
% ----------------------------------------------------------------------------------

clear; clc; close all; warning('off','all');
tAll = tic;

set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');

%% ================== Paths (RS) ==================
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

% --- Monthly (GPP=420 for 1984–2018; met=468 for 1982–2020 -> clip 25:444 => 420) ---
GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw"; % 720x360x420  (1984–2018)
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";  % 468
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";   % 468
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw"; % 468
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw"; % 468
VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468

% --- Annual (SSA) ---
GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_3compnew.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');

% --- Long-term (CEEMDAN Trend) + CO2 (1982–2022, 492) ---
GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_3compnew.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 1982–2022 (492)

%% ================== Outputs (RS) float32 RAW (unchanged names) ==================
out_MO = 'D:\WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw';
out_AN = 'D:\WLclass_Annual_q25_ttest_pcor_f32_720x360.raw';
out_LT = 'D:\WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw';

%% ================== Paths (FLUXNET) ==================
rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
siteXlsx        = fullfile(rootFolder_FLUX, 'FLUXsitelistnew.xlsx'); % 第1列站名，第5列纬度，第6列经度
assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);

outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end

outXLS_HH = fullfile(outDir, 'FLUXNET_WLclass_HH.xlsx');
outXLS_DD = fullfile(outDir, 'FLUXNET_WLclass_DD.xlsx');
outXLS_MM = fullfile(outDir, 'FLUXNET_WLclass_MM.xlsx');

outFigMerged = fullfile(outDir, 'WLclass_proportions_StackedBar_Fluxnet_RS.png');

% UPDATED figure output
outFig_RSveg = fullfile(outDir, 'RS_WLclass_byVeg_withinVegPercent_3scales_3bars.png');

%% ================== Global config ==================
nx = 720; ny = 360;

alpha        = 0.05;
minN_total_RS = 40;
minN_group_RS = 10;

qLow  = 25;
qHigh = 75;

%% ================== Checks (RS required files) ==================
mustFiles_RS = {lulcPath,hfpPath,...
    GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path,...
    GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path,...
    GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path,CO2_LT_path};

for k=1:numel(mustFiles_RS)
    assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
end

%% ================== RS Mask ==================
IGBP = imread(lulcPath)';   % 注意：转置
HFP  = imread(hfpPath)';    % 注意：转置
assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');

valid_mask = ismember(IGBP,1:10) & (HFP<=25);
nValid_RS = nnz(valid_mask);
fprintf('RS valid pixels (veg & HFP<=25): %d\n', nValid_RS);

%% ================== RS Scale configs ==================
scalesRS = { ...
    struct('name','Monthly (RS)', ...
        'GPP',GPP_MO_path,'T',T_MO_path,'P',P_MO_path,'R',R_MO_path,'SW',SW_MO_path,'VPD',VPD_MO_path,'CO2','', ...
        'out',out_MO, 'useCO2',false), ...
    struct('name','Annual (RS)', ...
        'GPP',GPP_AN_path,'T',T_AN_path,'P',P_AN_path,'R',R_AN_path,'SW',SW_AN_path,'VPD',VPD_AN_path,'CO2','', ...
        'out',out_AN, 'useCO2',false), ...
    struct('name','Long-term (RS)', ...
        'GPP',GPP_LT_path,'T',T_LT_path,'P',P_LT_path,'R',R_LT_path,'SW',SW_LT_path,'VPD',VPD_LT_path,'CO2',CO2_LT_path, ...
        'out',out_LT, 'useCO2',true) ...
    };

propRS = nan(numel(scalesRS), 4); % [SW VPD Both Neither]
clsRS  = cell(1, numel(scalesRS)); % store RS class maps for UPDATED FIG

%% =========================================================================================
%% ===================================== PART A: RS =======================================
%% =========================================================================================
for s = 1:numel(scalesRS)
    S = scalesRS{s};
    fprintf('\n=== RS | %s ===\n', S.name);

    nt_gpp = detect_nt(S.GPP, nx, ny);
    nt_t   = detect_nt(S.T,   nx, ny);
    nt_p   = detect_nt(S.P,   nx, ny);
    nt_r   = detect_nt(S.R,   nx, ny);
    nt_sw  = detect_nt(S.SW,  nx, ny);
    nt_vpd = detect_nt(S.VPD, nx, ny);

    tIdx_gpp = choose_time_index_align_to_gpp(nt_gpp, nt_gpp);
    tIdx_t   = choose_time_index_align_to_gpp(nt_t,   nt_gpp);
    tIdx_p   = choose_time_index_align_to_gpp(nt_p,   nt_gpp);
    tIdx_r   = choose_time_index_align_to_gpp(nt_r,   nt_gpp);
    tIdx_sw  = choose_time_index_align_to_gpp(nt_sw,  nt_gpp);
    tIdx_vpd = choose_time_index_align_to_gpp(nt_vpd, nt_gpp);

    nt = numel(tIdx_gpp);
    assert(numel(tIdx_t)==nt && numel(tIdx_p)==nt && numel(tIdx_r)==nt && numel(tIdx_sw)==nt && numel(tIdx_vpd)==nt, ...
        'Time clip length mismatch.');

    if S.useCO2
        nt_co2   = detect_nt(S.CO2, nx, ny);
        tIdx_co2 = choose_time_index_align_to_gpp(nt_co2, nt_gpp);
        assert(numel(tIdx_co2)==nt, 'CO2 time clip length mismatch.');
        map_co2  = memmapfile(S.CO2,'Format',{'single',[nx*ny*nt_co2 1],'x'});
    else
        nt_co2 = 0; tIdx_co2 = [];
        map_co2 = [];
    end

    fprintf('nt(clipped)=%d | nt_gpp=%d nt_t=%d nt_p=%d nt_r=%d nt_sw=%d nt_vpd=%d', ...
        nt, nt_gpp, nt_t, nt_p, nt_r, nt_sw, nt_vpd);
    if S.useCO2, fprintf(' nt_co2=%d', nt_co2); end
    fprintf(' | Filter: GPP > 0\n');

    map_gpp = memmapfile(S.GPP,'Format',{'single',[nx*ny*nt_gpp 1],'x'});
    map_t   = memmapfile(S.T,  'Format',{'single',[nx*ny*nt_t   1],'x'});
    map_p   = memmapfile(S.P,  'Format',{'single',[nx*ny*nt_p   1],'x'});
    map_r   = memmapfile(S.R,  'Format',{'single',[nx*ny*nt_r   1],'x'});
    map_sw  = memmapfile(S.SW, 'Format',{'single',[nx*ny*nt_sw  1],'x'});
    map_vpd = memmapfile(S.VPD,'Format',{'single',[nx*ny*nt_vpd 1],'x'});

    cls = zeros(nx, ny, 'single');

    tRow = tic;
    for i = 1:nx
        for j = 1:ny
            if ~valid_mask(i,j), continue; end

            gpp = get_pixel_ts(map_gpp, i, j, nx, ny, nt_gpp, tIdx_gpp);
            tt  = get_pixel_ts(map_t,   i, j, nx, ny, nt_t,   tIdx_t);
            pp  = get_pixel_ts(map_p,   i, j, nx, ny, nt_p,   tIdx_p);
            rr  = get_pixel_ts(map_r,   i, j, nx, ny, nt_r,   tIdx_r);
            sw  = get_pixel_ts(map_sw,  i, j, nx, ny, nt_sw,  tIdx_sw);
            vpd = get_pixel_ts(map_vpd, i, j, nx, ny, nt_vpd, tIdx_vpd);

            if S.useCO2
                co2 = get_pixel_ts(map_co2, i, j, nx, ny, nt_co2, tIdx_co2);
            else
                co2 = [];
            end

            gpp_d = double(gpp(:));
            posMask = isfinite(gpp_d) & (gpp_d > 0);

            if ~any(posMask)
                cls(i,j) = single(4);
                continue;
            end

            gpp(~posMask) = NaN;
            tt(~posMask)  = NaN;
            pp(~posMask)  = NaN;
            rr(~posMask)  = NaN;
            sw(~posMask)  = NaN;
            vpd(~posMask) = NaN;
            if S.useCO2, co2(~posMask) = NaN; end

            vpd_group_ok = is_highX_limits_gpp(gpp, vpd, qHigh, alpha, minN_total_RS, minN_group_RS);
            if S.useCO2
                Z_vpd = [tt, pp, rr, sw, co2];
            else
                Z_vpd = [tt, pp, rr, sw];
            end
            [rv, pv2] = partialcorr_fast(double(gpp), double(vpd), double(Z_vpd));
            pv1 = p_one_sided_from_two(pv2, rv, -1);
            vpd_pcor_ok = isfinite(pv1) && (pv1 < alpha) && (rv < 0);
            vpd_lim = vpd_group_ok && vpd_pcor_ok;

            sw_group_ok = is_lowX_limits_gpp(gpp, sw, qLow, alpha, minN_total_RS, minN_group_RS);
            if S.useCO2
                Z_sw = [tt, pp, rr, vpd, co2];
            else
                Z_sw = [tt, pp, rr, vpd];
            end
            [rsw, psw2] = partialcorr_fast(double(gpp), double(sw), double(Z_sw));
            psw1 = p_one_sided_from_two(psw2, rsw, +1);
            sw_pcor_ok = isfinite(psw1) && (psw1 < alpha) && (rsw > 0);
            sw_lim = sw_group_ok && sw_pcor_ok;

            if sw_lim && ~vpd_lim
                cls(i,j) = single(1);
            elseif vpd_lim && ~sw_lim
                cls(i,j) = single(2);
            elseif sw_lim && vpd_lim
                cls(i,j) = single(3);
            else
                cls(i,j) = single(4);
            end
        end

        if mod(i,40)==0
            fprintf('  RS row %3d/720 | elapsed %.1fs\n', i, toc(tRow));
            tRow = tic;
        end
    end

    fid = fopen(S.out,'w');
    assert(fid>0, 'Cannot open output: %s', S.out);
    fwrite(fid, cls, 'single');
    fclose(fid);

    clsRS{s} = cls;

    n1 = nnz(cls==1); n2 = nnz(cls==2); n3 = nnz(cls==3); n4 = nnz(cls==4);
    propRS(s,1) = n1 / nValid_RS;
    propRS(s,2) = n2 / nValid_RS;
    propRS(s,3) = n3 / nValid_RS;
    propRS(s,4) = n4 / nValid_RS;

    pWL = (n1+n2+n3)/nValid_RS;

    fprintf('Saved RS: %s\n', S.out);
    fprintf('RS Percent (of valid veg pixels): SW=%.2f%% | VPD=%.2f%% | Both=%.2f%% | Neither=%.2f%% | WL(any)=%.2f%%\n', ...
        100*propRS(s,1), 100*propRS(s,2), 100*propRS(s,3), 100*propRS(s,4), 100*pWL);
end

%% =========================================================================================
%% =================================== PART B: FLUXNET ====================================
%% =========================================================================================
fprintf('\n================== FLUXNET screening (HH/DD/MM) ==================\n');

yName = 'GPP_DT_VUT_REF';
vT    = 'TA_F_MDS';
vP    = 'P_F';
vR    = 'SW_IN_F_MDS';
vVPD  = 'VPD_F';
swcRegex = '^SWC_F_MDS_\d+$';

scaleList = {'HH','DD','MM'};
minN_total_map = containers.Map(scaleList, [300, 100, 40]);
minN_group_map = containers.Map(scaleList, [50,  20,  10]);

useGS_for_MM = false;
gsFracP90_flux = 0.2;

site2lat = containers.Map('KeyType','char','ValueType','double');
site2lon = containers.Map('KeyType','char','ValueType','double');
hasSiteLatLon = false;

if exist(siteXlsx,'file')
    try
        Ts = readtable(siteXlsx, 'ReadVariableNames', true);
        siteCol = 1; latCol = 5; lonCol = 6;
        assert(width(Ts) >= lonCol, 'FLUXsitelistnew.xlsx 列数不足，至少需要第6列(经度)。');

        names = string(Ts{:,siteCol});
        lats  = Ts{:,latCol};
        lons  = Ts{:,lonCol};

        for i = 1:numel(names)
            k = char(strtrim(names(i)));
            if isempty(k), continue; end
            latv = double(lats(i));
            lonv = double(lons(i));
            if isfinite(latv) && isfinite(lonv)
                site2lat(k) = latv;
                site2lon(k) = lonv;
            end
        end
        hasSiteLatLon = ~isempty(site2lat.keys);
        fprintf('✅ FLUX: 从 FLUXsitelistnew.xlsx 固定列(1/5/6)读取到 %d 个站点 lat/lon。\n', numel(site2lat.keys));
    catch ME
        fprintf('⚠️ FLUX: 读取 FLUXsitelistnew.xlsx 失败（%s），将尝试从 CSV 读取 lat/lon。\n', ME.message);
        hasSiteLatLon = false;
    end
else
    fprintf('⚠️ FLUX: 未找到 FLUXsitelistnew.xlsx，将尝试从 CSV 读取 lat/lon。\n');
end

allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
targets = [];
for ii = 1:numel(allCSV)
    nm = allCSV(ii).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        targets = [targets; allCSV(ii)]; %#ok<AGROW>
    end
end
assert(~isempty(targets), '未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
fprintf('FLUXNET 可用文件（HH/DD/MM）：%d 个\n', numel(targets));

RES = struct();
for s=1:numel(scaleList)
    sc = scaleList{s};
    RES.(sc).Site  = {};
    RES.(sc).Lat   = [];
    RES.(sc).Lon   = [];
    RES.(sc).Class = [];
end

seen = containers.Map('KeyType','char','ValueType','logical');

t0 = tic;
for k = 1:numel(targets)

    fpath = fullfile(targets(k).folder, targets(k).name);
    [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
    if ~ismember(scaleTag, scaleList), continue; end

    key = sprintf('%s__%s', siteName, scaleTag);
    if isKey(seen,key), continue; end
    seen(key) = true;

    try
        opts = detectImportOptions(fpath);
        varNames = opts.VariableNames;

        needFixed = {yName, vT, vP, vR, vVPD};
        if ~all(ismember(needFixed, varNames)), continue; end

        swcMask = ~cellfun('isempty', regexp(varNames, swcRegex,'once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols), continue; end

        latCandidates = {'LAT','SITE_LAT','latitude','LAT_F','LOCATION_LAT'};
        lonCandidates = {'LON','SITE_LON','longitude','LON_F','LOCATION_LON'};
        latColCSV = ''; lonColCSV = '';
        for ii=1:numel(latCandidates)
            if ismember(latCandidates{ii}, varNames), latColCSV = latCandidates{ii}; break; end
        end
        for ii=1:numel(lonCandidates)
            if ismember(lonCandidates{ii}, varNames), lonColCSV = lonCandidates{ii}; break; end
        end

        selectVars = [needFixed, swcCols];
        if ~isempty(latColCSV) && ~isempty(lonColCSV)
            selectVars = [selectVars, {latColCSV, lonColCSV}];
        end

        opts.SelectedVariableNames = selectVars;
        Ttab = readtable(fpath, opts);
        Ttab = sentinel2nan(Ttab, opts.SelectedVariableNames);

        Y   = Ttab.(yName);
        TA  = Ttab.(vT);
        PP  = Ttab.(vP);
        RR  = Ttab.(vR);
        VPD = Ttab.(vVPD);

        SWCmat = Ttab{:, swcCols};
        if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SW = mean(SWCmat, 2, 'omitnan');

        if useGS_for_MM && strcmp(scaleTag,'MM')
            ytmp = double(Y(:));
            ok0 = isfinite(ytmp) & (ytmp > 0);
            if nnz(ok0) >= 5
                P90 = prctile(ytmp(ok0), 90);
                thr = gsFracP90_flux * P90;
                gsMask = (ytmp > thr);
            else
                gsMask = false(size(ytmp));
            end
            Y(~gsMask)   = NaN; TA(~gsMask)  = NaN; PP(~gsMask)  = NaN;
            RR(~gsMask)  = NaN; SW(~gsMask)  = NaN; VPD(~gsMask) = NaN;
        end

        mask = isfinite(Y) & (Y>0) & isfinite(TA) & isfinite(PP) & isfinite(RR) & isfinite(SW) & isfinite(VPD);
        Y   = Y(mask); TA  = TA(mask); PP  = PP(mask);
        RR  = RR(mask); SW  = SW(mask); VPD = VPD(mask);

        minN_total = minN_total_map(scaleTag);
        minN_group = minN_group_map(scaleTag);

        if numel(Y) < minN_total
            cls = 0;
        else
            vpd_group_ok = is_highX_limits_gpp(Y, VPD, qHigh, alpha, minN_total, minN_group);
            Z_vpd = [TA, PP, RR, SW];
            [rv, pv2] = partialcorr_fast(double(Y), double(VPD), double(Z_vpd));
            pv1 = p_one_sided_from_two(pv2, rv, -1);
            vpd_pcor_ok = isfinite(pv1) && (pv1 < alpha) && (rv < 0);
            vpd_lim = vpd_group_ok && vpd_pcor_ok;

            sw_group_ok = is_lowX_limits_gpp(Y, SW, qLow, alpha, minN_total, minN_group);
            Z_sw = [TA, PP, RR, VPD];
            [rsw, psw2] = partialcorr_fast(double(Y), double(SW), double(Z_sw));
            psw1 = p_one_sided_from_two(psw2, rsw, +1);
            sw_pcor_ok = isfinite(psw1) && (psw1 < alpha) && (rsw > 0);
            sw_lim = sw_group_ok && sw_pcor_ok;

            if sw_lim && ~vpd_lim
                cls = 1;
            elseif vpd_lim && ~sw_lim
                cls = 2;
            elseif sw_lim && vpd_lim
                cls = 3;
            else
                cls = 4;
            end
        end

        latv = NaN; lonv = NaN;
        if hasSiteLatLon
            if isKey(site2lat, siteName)
                latv = site2lat(siteName);
                lonv = site2lon(siteName);
            else
                st = char(strtrim(string(siteName)));
                if isKey(site2lat, st)
                    latv = site2lat(st); lonv = site2lon(st);
                else
                    st2 = upper(st);
                    if isKey(site2lat, st2)
                        latv = site2lat(st2); lonv = site2lon(st2);
                    end
                end
            end
        end
        if ~(isfinite(latv) && isfinite(lonv))
            if ~isempty(latColCSV) && ~isempty(lonColCSV) && ismember(latColCSV, Ttab.Properties.VariableNames)
                latcand = double(Ttab.(latColCSV)); loncand = double(Ttab.(lonColCSV));
                latcand = latcand(isfinite(latcand));
                loncand = loncand(isfinite(loncand));
                if ~isempty(latcand) && ~isempty(loncand)
                    latv = latcand(1); lonv = loncand(1);
                end
            end
        end

        RES.(scaleTag).Site{end+1,1}  = siteName; %#ok<AGROW>
        RES.(scaleTag).Lat(end+1,1)   = latv; %#ok<AGROW>
        RES.(scaleTag).Lon(end+1,1)   = lonv; %#ok<AGROW>
        RES.(scaleTag).Class(end+1,1) = cls;  %#ok<AGROW>

    catch
        continue;
    end

    if mod(k,50)==0
        fprintf('FLUX 进度 %d/%d | 用时 %.1fs\n', k, numel(targets), toc(t0));
        t0 = tic;
    end
end

T_HH = pack_table(RES.HH);
T_DD = pack_table(RES.DD);
T_MM = pack_table(RES.MM);

writetable(T_HH, outXLS_HH);
writetable(T_DD, outXLS_DD);
writetable(T_MM, outXLS_MM);

fprintf('✅ FLUX Excel 已保存：\n  %s\n  %s\n  %s\n', outXLS_HH, outXLS_DD, outXLS_MM);

propFlux = nan(3,4);
nFluxValid = nan(3,1);

for si=1:3
    sc = scaleList{si};
    cls = RES.(sc).Class(:);
    clsValid = cls(cls>=1 & cls<=4);
    nValid = numel(clsValid);
    nFluxValid(si) = nValid;

    if nValid>0
        propFlux(si,1) = sum(clsValid==1)/nValid;
        propFlux(si,2) = sum(clsValid==2)/nValid;
        propFlux(si,3) = sum(clsValid==3)/nValid;
        propFlux(si,4) = sum(clsValid==4)/nValid;
    end

    fprintf('FLUX %s | N=%d | SW=%.2f%% VPD=%.2f%% Both=%.2f%% Neither=%.2f%%\n', ...
        sc, nValid, 100*propFlux(si,1), 100*propFlux(si,2), 100*propFlux(si,3), 100*propFlux(si,4));
end

%% =========================================================================================
%% ============================ PART C: ONE stacked bar figure =============================
labels = {'Half-hourly (Fluxnet)','Daily (Fluxnet)','Monthly (Fluxnet)',...
          'Monthly (RS)','Annual (RS)','Long-term (RS)'};

Pall = nan(6,4);
Pall(1,:) = propFlux(1,:);
Pall(2,:) = propFlux(2,:);
Pall(3,:) = propFlux(3,:);
Pall(4,:) = propRS(1,:);
Pall(5,:) = propRS(2,:);
Pall(6,:) = propRS(3,:);

Nvec = nan(6,1);
Nvec(1:3) = nFluxValid(:);
Nvec(4:6) = nValid_RS;

cSW   = [0.55 0.74 0.68];
cVPD  = [0.90 0.62 0.54];
cBoth = [0.63 0.66 0.86];
cNei  = [0.82 0.82 0.82];
C = [cSW; cVPD; cBoth; cNei];

baseFS = 12;
FS = baseFS * 1.5;
FS_small = 10 * 2;
LW = 1.2;

fig = figure('Color','w');
set(fig,'Position',[80,120,1400,520]);

bh = bar(Pall, 'stacked', 'LineStyle','none');
for k=1:4
    bh(k).FaceColor = C(k,:);
end

ylim([0 1]);
xlim([0.4 6.6]);

ax = gca;
ax.FontSize = FS;
ax.LineWidth = LW;

set(ax,'XTick',1:6,'XTickLabel',labels,'TickLabelInterpreter','none');
xtickangle(25);

yt = ax.YTick;
ax.YTickLabel = compose('%.0f%%', yt*100);
ylabel('Percentage', 'FontSize', FS);

grid on; box off;

lg = legend({'SW-limited','VPD-limited','Co-limited','Neither'}, 'Location','eastoutside');
set(lg,'Box','off','FontSize',FS);

for i=1:6
    if isfinite(Nvec(i))
        text(i, 1.02, sprintf('N=%d', round(Nvec(i))), ...
            'HorizontalAlignment','center','FontSize',FS_small);
    end
end

for i=1:6
    if any(isnan(Pall(i,:))), continue; end
    y0 = 0;
    for k=1:4
        pk = Pall(i,k);
        if pk > 0.10
            text(i, y0 + pk/2, sprintf('%.0f%%', 100*pk), ...
                'HorizontalAlignment','center', 'FontSize',FS_small, 'Color',[0.15 0.15 0.15]);
        end
        y0 = y0 + pk;
    end
end

exportgraphics(fig, outFigMerged, 'Resolution', 300);
fprintf('✅ Merged stacked-bar figure saved: %s\n', outFigMerged);

%% =========================================================================================
%% ================= PART D (UPDATED): RS veg-type % within-veg for each WL =================
% Veg groups (9):
%   ENF(1), EBF(2), DNF(3), DBF(4), MF(5), SHL(6/7), SVA(8/9), GRA(10), WET(11)

vegNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA'};

vegMask = cell(1,8);
vegMask{1} = (IGBP==1);
vegMask{2} = (IGBP==2);
vegMask{3} = (IGBP==3);
vegMask{4} = (IGBP==4);
vegMask{5} = (IGBP==5);
vegMask{6} = (IGBP==6 | IGBP==7);
vegMask{7} = (IGBP==8 | IGBP==9);
vegMask{8} = (IGBP==10);
%vegMask{9} = (IGBP==11);

% Total pixels per veg (within valid_mask)
Nveg = zeros(1,8);
for g=1:8
    Nveg(g) = nnz(valid_mask & vegMask{g});
end

% Updated color palette based on your provided image
vegCols = [
    0.0000, 0.3922, 0.0000;  % ENF: dark green (#006400)
    0.4784, 0.6196, 0.4314;  % EBF: olive green (#7a9e6e)
    0.6078, 0.3922, 0.6510;  % DNF: purple (#9b64a6)
    0.8275, 0.1882, 0.1882;  % DBF: red (#d32f2f)
    0.4000, 1.0000, 0.4000;  % MF: light green (#66ff66)
    0.9451, 0.9020, 0.7019;  % SHL: light yellow (#f1e6b3)
    0.7529, 0.6235, 0.9490;  % SVA: light purple (#c09ff2)
    0.5569, 0.8431, 0.4784;  % GRA: light green (#8ed67a)
    % 0.4941, 0.7882, 0.8471;  % WET: light blue (#7ec8d8)
];
   

% pctWithinVeg(s, wl, g) = 100 * n(veg & wl)/Nveg(g)
pctWithinVeg = nan(3,3,8);
N_wl_veg = zeros(3,3,8);

for s=1:3
    cls = clsRS{s};
    for wl=1:3
        for g=1:8
            if Nveg(g) == 0
                pctWithinVeg(s,wl,g) = NaN;
                N_wl_veg(s,wl,g) = 0;
                continue;
            end
            nwl = nnz(valid_mask & vegMask{g} & (cls==wl));
            N_wl_veg(s,wl,g) = nwl;
            pctWithinVeg(s,wl,g) = 100 * nwl / Nveg(g);
        end
    end
end

% Plot: 1×3 subplots; each subplot has 3 stacked bars (SW/VPD/Co)
scaleTitles = {'Monthly (RS)','Annual (RS)','Long-term (RS)'};
wlLabels    = {'SW-limited','VPD-limited','Co-limited'};

fig2 = figure('Color','w');
set(fig2,'Position',[60,120,1700,520]);
tiledlayout(1,3,'Padding','compact','TileSpacing','compact');

FS2 = 12*1.5;

maxY = 0;
for s=1:3
    tmp = squeeze(nansum(pctWithinVeg(s,:,:),3)); % 3×1 (sum over veg, not 100)
    maxY = max(maxY, max(tmp));
end
maxY = max(120, ceil(maxY/10)*10);  % reasonable upper limit

for s=1:3
    ax = nexttile(s); hold(ax,'on');

    % Y: 3 (WL) × 9 (veg), each entry is % within that veg type
    Y = squeeze(pctWithinVeg(s,:,:)); % 3×9
    Y(~isfinite(Y)) = 0;

    b = bar(ax, Y, 'stacked', 'LineStyle','none');
    for g=1:8
        b(g).FaceColor = vegCols(g,:);  % Use updated color palette
    end

    ylim(ax,[0 maxY]);
    set(ax,'XTick',1:3,'XTickLabel',wlLabels,'TickLabelInterpreter','none');
    xtickangle(ax,15);

    % --- UPDATED: ylabel + % ticks ---
   % ylabel(ax,'Percentage', 'FontSize', FS2);
%     yt = ax.YTick;
%     ax.YTickLabel = compose('%.0f%%', yt);

    title(ax, scaleTitles{s}, 'FontWeight','bold');

    ax.FontSize = FS2;
    ax.LineWidth = 1.2;
    grid(ax,'on'); box(ax,'off');

    % label segments: show if >= 6%
    for wl=1:3
        y0 = 0;
        for g=1:8
            val = pctWithinVeg(s,wl,g);
            if ~isfinite(val) || val<=0, continue; end
            if val >= 6
                text(ax, wl, y0 + val/2, sprintf('%.1f%%', val), ...
                    'HorizontalAlignment','center','FontSize',FS2-1, 'Color',[0.10 0.10 0.10]);
            end
            y0 = y0 + val;
        end
    end
    ax.YTickLabel = [];
end

lg2 = legend(vegNames, 'Location','eastoutside');
set(lg2,'Box','off','FontSize',FS2);

exportgraphics(fig2, outFig_RSveg, 'Resolution', 300);
fprintf('✅ UPDATED RS veg-type WL figure saved: %s\n', outFig_RSveg);

fprintf('\n✅ ALL DONE | Total time %.1f min\n', toc(tAll)/60);


%% =========================================================================================
%% ===================================== Helper functions ==================================
function nt = detect_nt(path, nx, ny)
d = dir(path);
assert(~isempty(d), 'Cannot read file info: %s', path);
bytes = d.bytes;
assert(mod(bytes,4)==0, 'Bytes not multiple of 4: %s', path);
nFloat = bytes/4;
assert(mod(nFloat, nx*ny)==0, 'File size not divisible by nx*ny: %s', path);
nt = nFloat/(nx*ny);
end

function tIdx = choose_time_index_align_to_gpp(nt0, nt_gpp)
if nt0 == nt_gpp
    tIdx = 1:nt_gpp;
    return;
end
if nt0 >= 468
    if nt_gpp == 444
        tIdx = 25:468; % 444
        return;
    elseif nt_gpp == 420
        tIdx = 25:444; % 420
        return;
    end
end
error('Unsupported time alignment: nt0=%d to nt_gpp=%d. Verify file periods.', nt0, nt_gpp);
end

function ts = get_pixel_ts(mmap, i, j, nx, ny, nt0, tIdx)
base   = i + (j-1)*nx;
stride = nx*ny;
idx    = base + (tIdx-1)*stride;
ts     = mmap.Data.x(idx);
end

function Tout = pack_table(R)
Site = string(R.Site(:));
Lat  = R.Lat(:);
Lon  = R.Lon(:);
Cls  = R.Class(:);

m = Site ~= "";
Site = Site(m); Lat = Lat(m); Lon = Lon(m); Cls = Cls(m);

Tout = table(Site, Lat, Lon, Cls, 'VariableNames', {'Site','Lat','Lon','Class'});
end

function T = sentinel2nan(T, names)
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v)
        v = double(str2double(string(v)));
    else
        v = double(v);
    end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM';
else
    scaleTag = 'OTHER';
end
end

function ok = is_lowX_limits_gpp(gpp, X, qPercent, alpha, minN_total, minN_group)
ok = false;

gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total, return; end
gpp = gpp(mask);
X   = X(mask);

q = prctile(X, qPercent);
idx_low  = (X <= q);
idx_high = (X >  q);

nL = nnz(idx_low);
nH = nnz(idx_high);
if (nL < minN_group) || (nH < minN_group), return; end

gL = gpp(idx_low);
gH = gpp(idx_high);

if mean(gL) >= mean(gH), return; end

try
    [h, p] = ttest2(gL, gH, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function ok = is_highX_limits_gpp(gpp, X, qPercentHigh, alpha, minN_total, minN_group)
ok = false;

gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total, return; end
gpp = gpp(mask);
X   = X(mask);

qH = prctile(X, qPercentHigh);
idx_high = (X >= qH);
idx_low  = (X <  qH);

nH = nnz(idx_high);
nL = nnz(idx_low);
if (nH < minN_group) || (nL < minN_group), return; end

gH = gpp(idx_high);
gL = gpp(idx_low);

if mean(gH) >= mean(gL), return; end

try
    [h, p] = ttest2(gH, gL, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function p1 = p_one_sided_from_two(p2, r, expectSign)
if ~isfinite(p2) || ~isfinite(r)
    p1 = NaN; return;
end
if expectSign > 0
    if r > 0, p1 = p2/2; else, p1 = 1; end
else
    if r < 0, p1 = p2/2; else, p1 = 1; end
end
end

function [r, p] = partialcorr_fast(y, x, Z)
r = NaN; p = NaN;

y = y(:); x = x(:);
if isempty(Z)
    M = [y x];
else
    Z = double(Z);
    M = [y x Z];
end

good = all(isfinite(M),2);
M = M(good,:);

n = size(M,1);
k = size(M,2) - 2;
df = n - k - 2;
if df < 3, return; end

yy = M(:,1);
xx = M(:,2);

if k==0
    ry = yy - mean(yy);
    rx = xx - mean(xx);
else
    ZZ = M(:,3:end);
    A  = [ones(n,1), ZZ];
    by = A \ yy;  ry = yy - A*by;
    bx = A \ xx;  rx = xx - A*bx;
end

ry = ry - mean(ry);
rx = rx - mean(rx);
den = sqrt(sum(ry.^2) * sum(rx.^2));
if den==0, return; end

r = sum(ry .* rx) / den;

t = r * sqrt(df / max(1e-12, (1 - r^2)));
p = 2 * (1 - tcdf(abs(t), df));
end
