%% =========================================================================================
% 6 scales (Fluxnet HH/DD/MM + RS Monthly/Annual/Long-term)
% UPDATE:
%   (1) Figure fonts = 1.5× (titles/axes/ticks/cell text/colorbar)
%   (2) FLUXNET Excel: add 1st column = SiteName
%       Columns: Site, Lon, Lat, r_SW_VPD
%   (3) FLUXNET lon/lat from:
%       G:\GlobalData\FLUXNET2015Tier2Data\FLUXsitelistnew.xlsx
%       Col1 = site name, Col5 = lat, Col6 = lon (match by parsed siteName)
%
% OUTPUTS:
%   - Figure (2×3): pooled ENV correlation matrices (T,P,SW,VPD,R,(CO2))
%   - FLUXNET: 3 Excel files (HH/DD/MM): Site, Lon, Lat, r_SW_VPD
%   - RS: 3 RAW maps (720×360×1, float32): r(SW,VPD) per pixel for Monthly/Annual/Long-term
%
% Inclusion:
%   - RS: vegetation (IGBP 1..11) & HFP<=25; time records require GPP>0 and needed vars finite.
%   - FLUXNET: time records require GPP>0 and needed vars finite; site must exist in sitelist for lon/lat.
%
% Tested: MATLAB R2021a
%% =========================================================================================

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
rng(2025);

tAll = tic;

%% ===================== Settings =====================
scaleList = {'HH','DD','MM'};

% For ENV pooling (figure)
minN_total_map = containers.Map(scaleList, [300, 100, 40]); % per site per scale
minN_rs_env = 40;                                           % per pixel per scale

% For saving SW-VPD correlation per site/pixel
minN_flux_r = containers.Map(scaleList, [80, 30, 15]);      % per site
minN_rs_r   = 20;                                           % per pixel

% RS Monthly GS filter
useMonthlyGS = true;
gsFracP90_RS = 0.2;

% Optional GS for FLUXNET MM
useGS_for_MM_flux = false;
gsFracP90_flux = 0.2;

% Figure font multiplier
fontMul = 1.5;

%% ===================== Paths (RS) =====================
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw"; % 720x360x420
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";
VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw";

GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');

GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 492->slice420

%% ===================== Paths (FLUXNET) =====================
rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);

% Site list Excel (for lon/lat)
siteListXLS = 'G:\GlobalData\FLUXNET2015Tier2Data\FLUXsitelistnew.xlsx';
assert(isfile(siteListXLS), '站点经纬度表不存在：%s', siteListXLS);

% FLUX variable names
yName = 'GPP_DT_VUT_REF';
vT    = 'TA_F_MDS';
vP    = 'P_F';
vR    = 'SW_IN_F_MDS';
vVPD  = 'VPD_F';
swcRegex = '^SWC_F_MDS_\d+$';

%% ===================== Outputs =====================
outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end

outFig = fullfile(outDir, 'FIG_corrMatrices_ENVonly_6scales_2x3_RedWhiteGreen_sharedCB.png');

outXLS_HH = fullfile(outDir, 'FLUXNET_HH_SWVPD_corr.xlsx');
outXLS_DD = fullfile(outDir, 'FLUXNET_DD_SWVPD_corr.xlsx');
outXLS_MM = fullfile(outDir, 'FLUXNET_MM_SWVPD_corr.xlsx');

outRAW_RS_MO = fullfile(outDir, 'RS_Monthly_SWVPD_corr_720x360_f32.raw');
outRAW_RS_AN = fullfile(outDir, 'RS_Annual_SWVPD_corr_720x360_f32.raw');
outRAW_RS_LT = fullfile(outDir, 'RS_LongTerm_SWVPD_corr_720x360_f32.raw');

%% ===================== RS dims & time slice =====================
nx = 720; ny = 360;

Tlen   = 420;   % 1984-01..2018-12
rawLen = 468;   % 1982-01..2020-12
sFrom  = 25;    % 1984-01 index in 468
sTo    = 444;   % 2018-12 index in 468

%% ===================== Check required RS files =====================
mustFiles_RS = {lulcPath,hfpPath,...
    GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path,...
    GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path,...
    GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path,CO2_LT_path};

for k=1:numel(mustFiles_RS)
    assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
end

%% ===================== Read FLUX site list (build map: site -> [lon,lat]) =====================
fprintf('Reading FLUX site list: %s\n', siteListXLS);

Tsite = readtable(siteListXLS, 'ReadVariableNames', true);
if width(Tsite) < 6
    Tsite = readtable(siteListXLS, 'ReadVariableNames', false);
end
assert(width(Tsite) >= 6, 'FLUXsitelistnew.xlsx 至少需要6列：Col1站点名, Col5纬度, Col6经度');

siteCol = Tsite{:,1};
latCol  = Tsite{:,5};
lonCol  = Tsite{:,6};

siteStr = string(siteCol);
latVal  = double(latCol);
lonVal  = double(lonCol);

siteStr = upper(strtrim(siteStr));

site2lonlat = containers.Map('KeyType','char','ValueType','any');
for i = 1:numel(siteStr)
    if strlength(siteStr(i))==0, continue; end
    if ~isfinite(latVal(i)) || ~isfinite(lonVal(i)), continue; end
    key = char(siteStr(i));
    if ~isKey(site2lonlat, key)
        site2lonlat(key) = [lonVal(i), latVal(i)];
    end
end
fprintf('Loaded site lon/lat entries: %d\n', site2lonlat.Count);

%% ===================== RS base mask (veg + HFP<=25) =====================
IGBP = imread(lulcPath)'; 
HFP  = imread(hfpPath)';

assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
valid_mask = ismember(IGBP,1:11) & (HFP<=25);
fprintf('RS valid pixels (veg & HFP<=25): %d\n', nnz(valid_mask));

%% ===================== Read RS data =====================
fprintf('Reading RS data blocks...\n');

T_MO   = read_raw_3d_auto(T_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_MO   = read_raw_3d_auto(P_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_MO   = read_raw_3d_auto(R_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_MO  = read_raw_3d_auto(SW_MO_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_MO = read_raw_3d_auto(VPD_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
GPP_MO = read_raw_3d_auto(GPP_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

T_AN   = read_raw_3d_auto(T_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_AN   = read_raw_3d_auto(P_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_AN   = read_raw_3d_auto(R_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_AN  = read_raw_3d_auto(SW_AN_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_AN = read_raw_3d_auto(VPD_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
GPP_AN = read_raw_3d_auto(GPP_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

T_LT   = read_raw_3d_auto(T_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_LT   = read_raw_3d_auto(P_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_LT   = read_raw_3d_auto(R_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_LT  = read_raw_3d_auto(SW_LT_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_LT = read_raw_3d_auto(VPD_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
GPP_LT = read_raw_3d_auto(GPP_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

CO2_LT = read_raw_3d_fixed492_slice420(CO2_LT_path, nx, ny, 492, sFrom, sTo);

fprintf('RS data loaded.\n');

%% =========================================================================================
%% ===================== Online stats containers (ENV-only; pooled) =========================
stats = repmat(struct('n',0,'sum',zeros(1,6),'Sxx',zeros(6,6)), 1, 6);

SC_HH   = 1;
SC_DD   = 2;
SC_MM   = 3;
SC_RSMO = 4;
SC_RSAN = 5;
SC_RSLT = 6;

%% ===================== Containers for saving SW-VPD correlations =========================
fluxSite_HH = strings(0,1); fluxLon_HH = []; fluxLat_HH = []; fluxR_HH = [];
fluxSite_DD = strings(0,1); fluxLon_DD = []; fluxLat_DD = []; fluxR_DD = [];
fluxSite_MM = strings(0,1); fluxLon_MM = []; fluxLat_MM = []; fluxR_MM = [];

RS_r_MO = nan(nx,ny,'single');
RS_r_AN = nan(nx,ny,'single');
RS_r_LT = nan(nx,ny,'single');

%% =========================================================================================
%% ===================== PART A: FLUXNET ================================================
fprintf('\n================== FLUXNET | basic filter + ENV pooling + save r(SW,VPD) ==================\n');

allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
targets = [];
for ii = 1:numel(allCSV)
    nm = allCSV(ii).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        targets = [targets; allCSV(ii)]; %#ok<AGROW>
    end
end
assert(~isempty(targets), '未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
fprintf('FLUXNET 可用文件（HH/DD/MM）：%d 个\n', numel(targets));

seen = containers.Map('KeyType','char','ValueType','logical');
t0 = tic;

for k = 1:numel(targets)
    fpath = fullfile(targets(k).folder, targets(k).name);
    [scaleTag, siteName_raw] = parse_scale_site_from_filename(targets(k).name);
    if ~ismember(scaleTag, scaleList), continue; end

    % ---- lon/lat from sitelist ----
    siteKey = upper(strtrim(string(siteName_raw)));
    if ~isKey(site2lonlat, char(siteKey))
        siteKey2 = regexprep(siteKey, '\s+', '');
        if isKey(site2lonlat, char(siteKey2))
            siteKey = siteKey2;
        else
            continue; % no lon/lat -> skip
        end
    end
    lonlat = site2lonlat(char(siteKey));
    lon0 = lonlat(1);
    lat0 = lonlat(2);

    key = sprintf('%s__%s', char(siteKey), scaleTag);
    if isKey(seen,key), continue; end
    seen(key) = true;

    try
        opts = detectImportOptions(fpath);
        varNames = opts.VariableNames;

        needFixed = {yName, vT, vP, vR, vVPD};
        if ~all(ismember(needFixed, varNames)), continue; end

        swcMask = ~cellfun('isempty', regexp(varNames, swcRegex,'once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols), continue; end

        selectVars = [needFixed, swcCols];
        opts.SelectedVariableNames = selectVars;
        Ttab = readtable(fpath, opts);
        Ttab = sentinel2nan(Ttab, opts.SelectedVariableNames);

        Y   = Ttab.(yName);
        TA  = Ttab.(vT);
        PP  = Ttab.(vP);
        RR  = Ttab.(vR);
        VPD = Ttab.(vVPD);

        SWCmat = Ttab{:, swcCols};
        if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SW = mean(SWCmat, 2, 'omitnan');

        if useGS_for_MM_flux && strcmp(scaleTag,'MM')
            [Y, SW, VPD, TA, PP, RR] = apply_gs_filter_flux(Y, SW, VPD, TA, PP, RR, gsFracP90_flux);
        end

        % ---- ENV pooling ----
        mask_env = isfinite(Y) & (Y>0) & isfinite(TA) & isfinite(PP) & isfinite(RR) & isfinite(SW) & isfinite(VPD);
        if nnz(mask_env) >= minN_total_map(scaleTag)
            Xenv = [double(TA(mask_env)), double(PP(mask_env)), double(SW(mask_env)), double(VPD(mask_env)), double(RR(mask_env))];
            sc = scale2col_flux(scaleTag);
            stats(sc) = online_add(stats(sc), Xenv);
        end

        % ---- r(SW,VPD) saving (per site) ----
        mask_r = isfinite(Y) & (Y>0) & isfinite(SW) & isfinite(VPD);
        if nnz(mask_r) >= minN_flux_r(scaleTag)
            rr_swvpd = corr_fast(double(SW(mask_r)), double(VPD(mask_r)));
            if isfinite(rr_swvpd)
                switch upper(scaleTag)
                    case 'HH'
                        fluxSite_HH(end+1,1) = siteKey; %#ok<SAGROW>
                        fluxLon_HH(end+1,1)  = lon0;    %#ok<SAGROW>
                        fluxLat_HH(end+1,1)  = lat0;    %#ok<SAGROW>
                        fluxR_HH(end+1,1)    = rr_swvpd; %#ok<SAGROW>
                    case 'DD'
                        fluxSite_DD(end+1,1) = siteKey;
                        fluxLon_DD(end+1,1)  = lon0;
                        fluxLat_DD(end+1,1)  = lat0;
                        fluxR_DD(end+1,1)    = rr_swvpd;
                    case 'MM'
                        fluxSite_MM(end+1,1) = siteKey;
                        fluxLon_MM(end+1,1)  = lon0;
                        fluxLat_MM(end+1,1)  = lat0;
                        fluxR_MM(end+1,1)    = rr_swvpd;
                end
            end
        end

    catch
        continue;
    end

    if mod(k,50)==0
        fprintf('FLUX progress %d/%d | elapsed %.1fs\n', k, numel(targets), toc(t0));
        t0 = tic;
    end
end

fprintf('FLUX done. Saving EXCEL...\n');

save_flux_excel(outXLS_HH, fluxSite_HH, fluxLon_HH, fluxLat_HH, fluxR_HH);
save_flux_excel(outXLS_DD, fluxSite_DD, fluxLon_DD, fluxLat_DD, fluxR_DD);
save_flux_excel(outXLS_MM, fluxSite_MM, fluxLon_MM, fluxLat_MM, fluxR_MM);

fprintf('✅ Saved:\n  %s\n  %s\n  %s\n', outXLS_HH, outXLS_DD, outXLS_MM);

%% =========================================================================================
%% ===================== PART B: RS ================================================
fprintf('\n================== RS | env pooling + save per-pixel r(SW,VPD) ==================\n');

tRow = tic;
nVisited = 0;
nValidBase = nnz(valid_mask);

for i = 1:nx
    for j = 1:ny
        if ~valid_mask(i,j), continue; end
        nVisited = nVisited + 1;

        % ================= RS Monthly (panel 4) =================
        y  = squeeze(GPP_MO(i,j,:));
        tt = squeeze(T_MO(i,j,:));
        pp = squeeze(P_MO(i,j,:));
        sw = squeeze(SW_MO(i,j,:));
        vpd= squeeze(VPD_MO(i,j,:));
        rr = squeeze(R_MO(i,j,:));

        if useMonthlyGS
            [y, sw, vpd, tt, pp, rr, ~] = apply_gs_filter(y, sw, vpd, tt, pp, rr, [], gsFracP90_RS);
        end

        mk_env = isfinite(y)&(y>0)&isfinite(tt)&isfinite(pp)&isfinite(sw)&isfinite(vpd)&isfinite(rr);
        if nnz(mk_env) >= minN_rs_env
            Xenv = [double(tt(mk_env)), double(pp(mk_env)), double(sw(mk_env)), double(vpd(mk_env)), double(rr(mk_env))];
            stats(SC_RSMO) = online_add(stats(SC_RSMO), Xenv);
        end

        mk_r = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd);
        if nnz(mk_r) >= minN_rs_r
            RS_r_MO(i,j) = single(corr_fast(double(sw(mk_r)), double(vpd(mk_r))));
        end

        % ================= RS Annual (panel 5) =================
        y  = squeeze(GPP_AN(i,j,:));
        tt = squeeze(T_AN(i,j,:));
        pp = squeeze(P_AN(i,j,:));
        sw = squeeze(SW_AN(i,j,:));
        vpd= squeeze(VPD_AN(i,j,:));
        rr = squeeze(R_AN(i,j,:));

        mk_env = isfinite(y)&(y>0)&isfinite(tt)&isfinite(pp)&isfinite(sw)&isfinite(vpd)&isfinite(rr);
        if nnz(mk_env) >= minN_rs_env
            Xenv = [double(tt(mk_env)), double(pp(mk_env)), double(sw(mk_env)), double(vpd(mk_env)), double(rr(mk_env))];
            stats(SC_RSAN) = online_add(stats(SC_RSAN), Xenv);
        end

        mk_r = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd);
        if nnz(mk_r) >= minN_rs_r
            RS_r_AN(i,j) = single(corr_fast(double(sw(mk_r)), double(vpd(mk_r))));
        end

        % ================= RS Long-term (panel 6) =================
        y  = squeeze(GPP_LT(i,j,:));
        tt = squeeze(T_LT(i,j,:));
        pp = squeeze(P_LT(i,j,:));
        sw = squeeze(SW_LT(i,j,:));
        vpd= squeeze(VPD_LT(i,j,:));
        rr = squeeze(R_LT(i,j,:));
        co2= squeeze(CO2_LT(i,j,:));

        mk_env = isfinite(y)&(y>0)&isfinite(tt)&isfinite(pp)&isfinite(sw)&isfinite(vpd)&isfinite(rr)&isfinite(co2);
        if nnz(mk_env) >= minN_rs_env
            Xenv6 = [double(tt(mk_env)), double(pp(mk_env)), double(sw(mk_env)), double(vpd(mk_env)), double(rr(mk_env)), double(co2(mk_env))];
            stats(SC_RSLT) = online_add(stats(SC_RSLT), Xenv6);
        end

        mk_r = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd);
        if nnz(mk_r) >= minN_rs_r
            RS_r_LT(i,j) = single(corr_fast(double(sw(mk_r)), double(vpd(mk_r))));
        end
    end

    if mod(i,40)==0
        pct = 100*(nVisited/max(nValidBase,1));
        fprintf('  RS row %3d/720 | visited %d/%d (%.1f%%) | elapsed %.1fs\n', ...
            i, nVisited, nValidBase, pct, toc(tRow));
        tRow = tic;
    end
end

fprintf('RS done. Saving RAW...\n');

write_raw_f32(outRAW_RS_MO, RS_r_MO);
write_raw_f32(outRAW_RS_AN, RS_r_AN);
write_raw_f32(outRAW_RS_LT, RS_r_LT);

fprintf('✅ Saved:\n  %s\n  %s\n  %s\n', outRAW_RS_MO, outRAW_RS_AN, outRAW_RS_LT);

%% =========================================================================================
%% ===================== Build correlation matrices for figure =============================
Ccell = cell(1,6);
for sc = 1:6
    if sc == SC_RSLT
        C = corr_from_online_stats(stats(sc), 6);
    else
        C = corr_from_online_stats(stats(sc), 5);
    end
    Ccell{sc} = C;
end

%% =========================================================================================
%% ===================== Plot 2×3 corr matrices with shared colorbar (font×1.5) ============
scNames = {'Flux HH','Flux DD','Flux MM','RS Monthly','RS Annual','RS Long-term'};
varNames_short = {'T','P','SW','VPD','R'};
varNames_long  = {'T','P','SW','VPD','R','CO2'};

baseTickFS  = 9;      tickFS  = baseTickFS  * fontMul;
baseTitleFS = 11;     titleFS = baseTitleFS * fontMul;
baseCellFS  = 8;      cellFS  = baseCellFS  * fontMul;
baseCBFS    = 10;     cbFS    = baseCBFS    * fontMul;

% --- red-white-green colormap (-1..1) ---
nCol = 256;
cmap = zeros(nCol,3);
cmap(1:nCol/2,1) = linspace(0.80,1.00,nCol/2);
cmap(1:nCol/2,2) = linspace(0.00,1.00,nCol/2);
cmap(1:nCol/2,3) = linspace(0.00,1.00,nCol/2);
cmap(nCol/2+1:end,1) = linspace(1.00,0.00,nCol/2);
cmap(nCol/2+1:end,2) = linspace(1.00,0.60,nCol/2);
cmap(nCol/2+1:end,3) = linspace(1.00,0.00,nCol/2);

figure('Color','w','Position',[80 80 1250 780]);
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

for sc = 1:6
    ax = nexttile(sc);
    C  = Ccell{sc};

    if isempty(C) || all(~isfinite(C(:))) || size(C,1) < 2
        axis(ax,'off');
        title(ax, scNames{sc}, 'FontWeight','bold','FontSize',titleFS);
        continue;
    end

    % ==================== ONLY show LOWER TRIANGLE (incl. diag) ====================
    Cshow = tril(C);
    imagesc(ax, Cshow);
    hImg = findobj(ax,'Type','image');
    if ~isempty(hImg)
        set(hImg, 'AlphaData', isfinite(Cshow));  % hide upper triangle (NaN) as transparent
    end
    set(ax, 'Color', 'w');  % background for hidden cells

    axis(ax,'image');
    set(ax,'TickDir','out','FontSize',tickFS);
    caxis(ax,[-1 1]);
    colormap(ax,cmap);

    if sc == 6
        vnames = varNames_long;
    else
        vnames = varNames_short;
    end
    set(ax,'XTick',1:numel(vnames),'XTickLabel',vnames, ...
           'YTick',1:numel(vnames),'YTickLabel',vnames);
    xtickangle(ax,45);
    grid(ax,'on'); box(ax,'off');

    title(ax, scNames{sc}, 'FontWeight','bold','FontSize',titleFS);

    p = size(Cshow,1);
    for ii = 1:p
        for jj = 1:p
            if jj > ii
                continue; % remove upper triangle text
            end
            if isfinite(Cshow(ii,jj))
                txt = sprintf('%.2f', Cshow(ii,jj));
            else
                txt = 'NaN';
            end
            if isfinite(Cshow(ii,jj)) && abs(Cshow(ii,jj)) > 0.6
                tc = 'w';
            else
                tc = 'k';
            end
            text(ax, jj, ii, txt, 'HorizontalAlignment','center', ...
                'VerticalAlignment','middle', 'FontSize',cellFS, 'Color',tc);
        end
    end
end

cb = colorbar;
cb.Layout.Tile = 'east';
cb.Ticks = [-1 -0.5 0 0.5 1];
cb.Label.String = 'Pearson r';
cb.Label.FontWeight = 'bold';
cb.Label.FontSize = cbFS;
cb.FontSize = cbFS;

exportgraphics(gcf,outFig,'Resolution',300);
fprintf('✅ Saved figure: %s\n', outFig);
fprintf('All done. Total time = %.1f s\n', toc(tAll));

%% =========================================================================================
%% ===================================== HELPERS ==========================================

function st = online_add(st, X)
X = double(X);
good = all(isfinite(X),2);
X = X(good,:);
if isempty(X), return; end
[n,p] = size(X);

st.n = st.n + n;
st.sum(1:p) = st.sum(1:p) + sum(X,1);
st.Sxx(1:p,1:p) = st.Sxx(1:p,1:p) + (X'*X);
end

function C = corr_from_online_stats(st, p)
nEff = st.n;
if nEff < 5
    C = nan(p,p); return;
end
mu = st.sum(1:p)' / nEff;
Cov = (st.Sxx(1:p,1:p) - nEff*(mu*mu')) / max(nEff-1,1);
sd = sqrt(diag(Cov));
sd(sd<=0) = NaN;
C = Cov ./ (sd*sd');
C(1:p+1:end) = 1;
C(C>1)=1; C(C<-1)=-1;
end

function r = corr_fast(x, y)
x = x(:); y = y(:);
m = isfinite(x) & isfinite(y);
x = x(m); y = y(m);
n = numel(x);
if n < 3
    r = NaN; return;
end
x = x - mean(x);
y = y - mean(y);
den = sqrt(sum(x.^2) * sum(y.^2));
if den <= 0
    r = NaN; return;
end
r = sum(x.*y) / den;
r = max(-1, min(1, r));
end

function [y, sw, vpd, tt, pp, rr, co2] = apply_gs_filter(y, sw, vpd, tt, pp, rr, co2, fracP90)
y = y(:); sw=sw(:); vpd=vpd(:); tt=tt(:); pp=pp(:); rr=rr(:);
if ~isempty(co2), co2=co2(:); end

yd = double(y);
ok0 = isfinite(yd) & (yd>0);
if nnz(ok0) < 5
    y(:)=NaN; sw(:)=NaN; vpd(:)=NaN; tt(:)=NaN; pp(:)=NaN; rr(:)=NaN;
    if ~isempty(co2), co2(:)=NaN; end
    return;
end
P90 = prctile(yd(ok0), 90);
thr = fracP90 * P90;
gsMask = (yd > thr);

y(~gsMask)=NaN; sw(~gsMask)=NaN; vpd(~gsMask)=NaN; tt(~gsMask)=NaN; pp(~gsMask)=NaN; rr(~gsMask)=NaN;
if ~isempty(co2), co2(~gsMask)=NaN; end
end

function [Y, SW, VPD, TA, PP, RR] = apply_gs_filter_flux(Y, SW, VPD, TA, PP, RR, fracP90)
Y=Y(:); SW=SW(:); VPD=VPD(:); TA=TA(:); PP=PP(:); RR=RR(:);
yd = double(Y);
ok0 = isfinite(yd) & (yd>0);
if nnz(ok0) < 5
    Y(:)=NaN; SW(:)=NaN; VPD(:)=NaN; TA(:)=NaN; PP(:)=NaN; RR(:)=NaN;
    return;
end
P90 = prctile(yd(ok0), 90);
thr = fracP90 * P90;
gsMask = (yd > thr);

Y(~gsMask)=NaN; SW(~gsMask)=NaN; VPD(~gsMask)=NaN; TA(~gsMask)=NaN; PP(~gsMask)=NaN; RR(~gsMask)=NaN;
end

function A = read_raw_3d_auto(path, shape2, Tlen, rawLen, sFrom, sTo)
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);
nTot = numel(dat);
n1 = nx*ny*Tlen;
n2 = nx*ny*rawLen;
if nTot == n1
    A = reshape(dat, [nx, ny, Tlen]);
elseif nTot == n2
    A = reshape(dat, [nx, ny, rawLen]);
    A = A(:,:,sFrom:sTo);
else
    error('Unexpected file size for %s: got %d floats; expected %d (420) or %d (468).', path, nTot, n1, n2);
end
end

function CO2 = read_raw_3d_fixed492_slice420(path, nx, ny, co2Len, sFrom, sTo)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s', path);
tmp = fread(fid, nx*ny*co2Len, 'single');
fclose(fid);
tmp = reshape(tmp, [nx, ny, co2Len]);
CO2 = tmp(:,:,sFrom:sTo);
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM';
else
    scaleTag = 'OTHER';
end
end

function sc = scale2col_flux(scaleTag)
switch upper(scaleTag)
    case 'HH', sc = 1;
    case 'DD', sc = 2;
    case 'MM', sc = 3;
    otherwise, sc = NaN;
end
end

function Tout = sentinel2nan(T, names)
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v)
        v = double(str2double(string(v)));
    else
        v = double(v);
    end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
Tout = T;
end

function save_flux_excel(xlsPath, siteVec, lonVec, latVec, rVec)
if isempty(rVec)
    T = table(string(missing), nan, nan, nan, 'VariableNames', {'Site','Lon','Lat','r_SW_VPD'});
else
    T = table(string(siteVec(:)), lonVec(:), latVec(:), rVec(:), ...
        'VariableNames', {'Site','Lon','Lat','r_SW_VPD'});
end
try
    writetable(T, xlsPath, 'FileType','spreadsheet');
catch
    [p,n,~] = fileparts(xlsPath);
    csvPath = fullfile(p, [n '.csv']);
    writetable(T, csvPath);
    fprintf('⚠️ Excel write failed, saved CSV instead: %s\n', csvPath);
end
end

function write_raw_f32(path, A)
if ~isa(A,'single'), A = single(A); end
fid = fopen(path,'w'); assert(fid>0, 'Cannot write: %s', path);
fwrite(fid, A, 'single');
fclose(fid);
end
