%% ================== Long-term WL pixels -> GPPrisk share by vegetation type (BAR ONLY) ==================
% 目标：
%   1) 在长期尺度（CEEMDAN Trend）上重新计算 water-limited (WL) 像元
%   2) 在 WL 区域内统计 GPPrisk（mono decrease OR UD）在不同植被类型中的比例
%   3) 仅输出柱状图（无地图、无 riskMap raw）
%
% Water-limited (SW & P co-limited) screening:
%   A) valid_base: IGBP in [1..11] AND HFP<=25
%   B) N > MinN; Y>0; all finite
%   C) OLS (standardized): z(Y) ~ z(SW)+z(P)+z(T)+z(R)   require beta_SW > 0 AND beta_P > 0
%   D) Low-SW test: SW < 25% quantile => mean(GPP_lowSW) < mean(GPP_highSW) AND ttest2 p<alpha
%   E) Low-P  test: P  < 25% quantile => mean(GPP_lowP ) < mean(GPP_highP ) AND ttest2 p<alpha
%
% GPPrisk mask:
%   risk = (mono==1) OR (tipping==4)    % mono decrease OR UD
%
% Output:
%   D:\Longterm_WL_Risk_byVeg_barOnly.png
%
% Tested: MATLAB R2021a

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
tAll = tic;

%% ------------------ Paths ------------------
lulcPath = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath  = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');

monoPath    = 'G:\Resource use efficiencies new\dataresult\CEEMDANstatistics\monoworld_monoGPP.raw';
tippingPath = 'G:\Resource use efficiencies new\dataresult\CEEMDANstatistics\tippingworldGPP.raw';

outFigBar  = 'D:\Longterm_WL_Risk_byVeg_barOnly.png';

%% ------------------ Assertions ------------------
assert(isfile(lulcPath), 'LULC not found: %s', lulcPath);
assert(isfile(hfpPath),  'HFP not found: %s',  hfpPath);

assert(isfile(GPP_LT_path), 'Long-term Trend GPP not found');
assert(isfile(T_LT_path) && isfile(P_LT_path) && isfile(R_LT_path) && isfile(SW_LT_path), 'Long-term Trend met files missing');

assert(isfile(monoPath),    'monoGPP file missing: %s', monoPath);
assert(isfile(tippingPath), 'tippingGPP file missing: %s', tippingPath);

%% ------------------ Parameters ------------------
alpha = 0.05;
MinN  = 60;
qLow  = 0.25;
HFPth = 25;

nx = 720; ny = 360;
Tlen   = 420;
rawLen = 468;
sFrom  = 25;
sTo    = 444;

vegNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'};
vegCodeSets = { [1],[2],[3],[4],[5],[6 7],[8 9],[10],[11], 1:11 };
nVeg = numel(vegNames);

%% ------------------ Read IGBP/HFP ------------------
IGBP = imread(lulcPath); IGBP = IGBP';
HFP  = imread(hfpPath);  HFP  = HFP';
assert(all(size(IGBP)==[nx ny]), 'IGBP size mismatch (need 720x360).');
assert(all(size(HFP )==[nx ny]), 'HFP size mismatch (need 720x360).');

valid_base = (IGBP>=1 & IGBP<=11) & (HFP<=HFPth);

%% ------------------ Read GPPrisk masks ------------------
mono    = read_raw_2d(monoPath,   [nx,ny]);  % single
tipping = read_raw_2d(tippingPath,[nx,ny]);  % single
risk    = (mono==1) | (tipping==4);

%% ------------------ Read Long-term Trend data blocks ------------------
fprintf('Reading long-term (CEEMDAN Trend) data...\n');
GPP = read_raw_3d_auto(GPP_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T   = read_raw_3d_auto(T_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P   = read_raw_3d_auto(P_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R   = read_raw_3d_auto(R_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW  = read_raw_3d_auto(SW_LT_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);

%% ------------------ Step-1: Recompute long-term water-limited mask ------------------
fprintf('Computing long-term water-limited pixels...\n');
mask_longterm = false(nx,ny);

tRow = tic;
for i = 1:nx
    for j = 1:ny
        if ~valid_base(i,j), continue; end

        y  = squeeze(GPP(i,j,:));
        sw = squeeze(SW(i,j,:));
        pp = squeeze(P(i,j,:));
        tt = squeeze(T(i,j,:));
        rr = squeeze(R(i,j,:));

        if is_water_limited_pixel(y, sw, pp, tt, rr, MinN, alpha, qLow)
            mask_longterm(i,j) = true;
        end
    end

    if mod(i,40)==0
        fprintf('  row %3d/720 | elapsed %.1fs\n', i, toc(tRow));
        tRow = tic;
    end
end

wl_valid = mask_longterm & valid_base;
fprintf('WL pixels (valid_base): %d\n', nnz(wl_valid));

%% ------------------ Step-2: Veg-type risk share within WL ------------------
pctVeg = nan(nVeg,1);

for v = 1:nVeg
    mv = wl_valid & ismember(IGBP, vegCodeSets{v});
    pctVeg(v) = 100 * nnz(mv & risk) ./ max(nnz(mv),1);
end

fprintf('\n=== Risk share within long-term WL by vegetation type ===\n');
for v=1:nVeg
    fprintf('%-8s  %6.2f%%\n', vegNames{v}, pctVeg(v));
end

%% ------------------ Figure: BAR ONLY (bigger; % label centered; ylabel=percentage) ------------------
% 图尺寸：460x180 的 1.5 倍 -> 690x270
figW = round(460*1.5);
figH = round(180*1.5);

% 单色低饱和（论文风格）
barColor = [0.18 0.32 0.50];

% 标注字体 = 原 11 的 1.5 倍
baseFS = 11;
labelFS = round(baseFS * 1.1);

figure('Color','w','Position',[120 120 figW figH]);
x = 1:nVeg;

b = bar(x, pctVeg, 0.72);
b.FaceColor = barColor;
b.EdgeColor = 'none';

grid on; box off;
set(gca,'XTick',x,'XTickLabel',vegNames,'FontSize',baseFS,'TickDir','out');
xtickangle(20);

ylabel('Percentage (%)','FontSize',baseFS);
title('');

% y 范围留一点顶空，避免柱顶压线
ymax = max(pctVeg(~isnan(pctVeg)));
if isempty(ymax) || ~isfinite(ymax), ymax = 0; end
ylim([0, max(5, ymax + 4)]);

% 文本颜色自动适配（深柱子 -> 白字）
txtColor = auto_text_color(barColor);

% -------- 在每个柱子“中间位置”标注百分比 --------
for k = 1:nVeg
    if ~isfinite(pctVeg(k)), continue; end
    yv = pctVeg(k);

    % 柱子中间：y = yv/2；但太矮会看不清，设最小高度 0.6
    yText = max(0.6, yv/2);

    text(k, yText, sprintf('%.0f', yv), ...
        'HorizontalAlignment','center', ...
        'VerticalAlignment','middle', ...
        'FontSize',labelFS, ...
        'FontWeight','bold', ...
        'Color',txtColor);
end

exportgraphics(gcf, outFigBar, 'Resolution', 300);
fprintf('✅ Saved: %s\n', outFigBar);
fprintf('✅ Done | total time %.1f min\n', toc(tAll)/60);

%% ================== Helper functions ==================
function ok = is_water_limited_pixel(y, sw, p, t, r, MinN, alpha, qLow)
ok = false;
y = y(:); sw = sw(:); p = p(:); t = t(:); r = r(:);

m = isfinite(y) & isfinite(sw) & isfinite(p) & isfinite(t) & isfinite(r) & (y>0);
if sum(m) <= MinN, return; end

y = y(m); sw = sw(m); p = p(m); t = t(m); r = r(m);

X = zscore([sw, p, t, r]);
if any(~isfinite(X(:))), return; end
yz = zscore(y);

try
    mdl = fitlm(X, yz, 'Intercept', true);
catch
    return;
end

b = mdl.Coefficients.Estimate;  % [intercept, sw, p, t, r]
if numel(b) < 5, return; end

beta_sw = b(2);
beta_p  = b(3);
if ~(beta_sw > 0 && beta_p > 0), return; end

% Low SW test
thr_sw = quantile(sw, qLow);
low = (sw <= thr_sw); high = ~low;
if sum(low) < 10 || sum(high) < 10, return; end
if mean(y(low),'omitnan') >= mean(y(high),'omitnan'), return; end
try
    [~, p_sw] = ttest2(y(low), y(high), 'Vartype','unequal');
catch
    p_sw = 1;
end
if ~(p_sw < alpha), return; end

% Low P test
thr_p = quantile(p, qLow);
low = (p <= thr_p); high = ~low;
if sum(low) < 10 || sum(high) < 10, return; end
if mean(y(low),'omitnan') >= mean(y(high),'omitnan'), return; end
try
    [~, p_pp] = ttest2(y(low), y(high), 'Vartype','unequal');
catch
    p_pp = 1;
end
if ~(p_pp < alpha), return; end

ok = true;
end

function A = read_raw_3d_auto(path, shape2, Tlen, rawLen, sFrom, sTo)
nx = shape2(1); ny = shape2(2);

fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);

nTot = numel(dat);
n1 = nx*ny*Tlen;
n2 = nx*ny*rawLen;

if nTot == n1
    A = reshape(dat, [nx, ny, Tlen]);
elseif nTot == n2
    A = reshape(dat, [nx, ny, rawLen]);
    A = A(:,:,sFrom:sTo);
else
    error('Unexpected file size for %s: got %d floats; expected %d (420) or %d (468).', path, nTot, n1, n2);
end
end

function A = read_raw_2d(path, shape2)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s',path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end

function c = auto_text_color(rgb)
% 根据背景色亮度决定文字用黑/白
% luminance: ITU-R BT.709
L = 0.2126*rgb(1) + 0.7152*rgb(2) + 0.0722*rgb(3);
if L < 0.55
    c = [1 1 1];   % 深色背景 -> 白字
else
    c = [0 0 0];   % 浅色背景 -> 黑字
end
end
