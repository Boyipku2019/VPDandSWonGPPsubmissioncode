%% ================== Scatter: RS vs FLUXNET (Monthly) + Linear regression ==================
% 特点：
%  - 不使用引线
%  - 保持“文字在点旁边”
%  - 加强文字自动避让，尽量消除遮挡
%
% Tested: MATLAB R2021a

clear; clc; close all;

%% ---------- Path ----------
inXlsx = 'G:\Resource use efficiencies new\dataresult\monthlyFLUXandRScorrelation.xlsx';
assert(isfile(inXlsx), '找不到文件：%s', inXlsx);

outPng = 'G:\Resource use efficiencies new\dataresult\monthlyFLUXandRScorrelation_scatter_RS_vs_FLUXNET.png';

%% ---------- Read ----------
T = readtable(inXlsx);

nameCol = T.Properties.VariableNames{1};
vns = lower(string(T.Properties.VariableNames));
rsCol = find(contains(vns,'rs') & contains(vns,'monthly'), 1);
fxCol = find(contains(vns,'fluxnet') & contains(vns,'monthly'), 1);

labels = string(T.(nameCol));
x = double(T{:, rsCol});
y = double(T{:, fxCol});

ok = isfinite(x) & isfinite(y);
x = x(ok); y = y(ok); labels = labels(ok);

%% ---------- Linear regression ----------
mdl = fitlm(x, y);
b0 = mdl.Coefficients.Estimate(1);
b1 = mdl.Coefficients.Estimate(2);
pSlope = mdl.Coefficients.pValue(2);
R2 = mdl.Rsquared.Ordinary;

[rPear, pPear] = corr(x, y, 'Rows','complete');

sigStars = p_to_stars(pSlope);

xLine = linspace(min(x), max(x), 200)';
[yHat, yCI] = predict(mdl, xLine);

%% ---------- Plot ----------
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');

fig = figure('Color','w','Position',[120 120 900 720]);
ax = axes(fig); hold(ax,'on');
plot(ax, [-0.5 1], [-0.5 1], '-', ...
    'Color', [0.75 0.75 0.75], ...   % 浅灰
    'LineWidth', 1.2);
pad = 0.08;
lims = [ ...
    max(-1, min([x;y])-pad), ...
    min( 1, max([x;y])+pad) ];

% CI band
patch(ax,[xLine; flipud(xLine)], ...
          [yCI(:,1); flipud(yCI(:,2))], ...
          [0.2 0.2 0.2],'FaceAlpha',0.12,'EdgeColor','none');

% regression line
plot(ax,xLine,yHat,'k-','LineWidth',2.5);

% scatter
scatter(ax,x,y,80,'filled', ...
    'MarkerFaceAlpha',0.85,'MarkerEdgeColor',[0.2 0.2 0.2]);

% zero lines
plot(ax,lims,[0 0],':','Color',[.7 .7 .7]);
plot(ax,[0 0],lims,':','Color',[.7 .7 .7]);

axis square;
xlim(lims); ylim(lims);

grid on; ax.GridAlpha=0.18;
ax.XMinorGrid='on'; ax.YMinorGrid='on';
ax.MinorGridAlpha=0.1;

xlabel('Correlation with GPP (RS, Monthly)','FontSize',18);
ylabel('Correlation with GPP (FLUXNET, Monthly)','FontSize',18);
%title('Monthly correlations: RS vs FLUXNET','FontSize',18,'FontWeight','bold');

% stats box
txt = sprintf(['Linear fit: y = %.3f + %.3f x\n', ...
               'R^2 = %.3f,  p = %.2g %s\n', ...
               'Pearson r = %.3f, p = %.2g'], ...
               b0,b1,R2,pSlope,sigStars,rPear,pPear);

text(lims(1)+0.05*range(lims), ...
     lims(2)-0.07*range(lims), txt, ...
     'FontSize',13,'BackgroundColor','w', ...
     'EdgeColor',[.85 .85 .85],'Margin',8);

%% ---------- Labels (stronger repel, no lines) ----------
dx0 = 0.018 * range(lims);   % 初始偏移更大一点
dy0 = 0.018 * range(lims);

ht = gobjects(numel(x),1);

for i = 1:numel(x)
    % 初始偏移：远离中心
    v = [x(i)-mean(lims), y(i)-mean(lims)];
    if norm(v)<eps, v=[1 0.5]; end
    v = v/norm(v);

    ht(i) = text(ax, ...
        x(i)+v(1)*dx0, y(i)+v(2)*dy0, labels(i), ...
        'FontSize',12,'Interpreter','none','Clipping','on');
end

drawnow;
repel_text_only(ht, x, y, lims);
lims = [-0.5 1];

axis square;
xlim(lims);
ylim(lims);
%% ---------- Export ----------
exportgraphics(fig,outPng,'Resolution',600);
fprintf('✅ Saved: %s\n',outPng);

%% ================== helpers ==================
function s = p_to_stars(p)
if p<0.001, s='***';
elseif p<0.01, s='**';
elseif p<0.05, s='*';
else, s='n.s.';
end
end

function repel_text_only(ht, x, y, lims)
N = numel(ht);
R = range(lims);
pad = 0.004 * R;
step = 0.015 * R;
maxIter = 300;

for it = 1:maxIter
    moved = false;
    ext = reshape([ht.Extent],4,[])';

    % text–text repel
    for i=1:N
        for j=i+1:N
            if overlap(ext(i,:),ext(j,:),pad)
                ci = [ext(i,1)+ext(i,3)/2, ext(i,2)+ext(i,4)/2];
                cj = [ext(j,1)+ext(j,3)/2, ext(j,2)+ext(j,4)/2];
                v = ci-cj;
                if norm(v)<eps, v=[1 0.3]; end
                v = v/norm(v);

                ht(i).Position(1:2)=ht(i).Position(1:2)+0.5*step*v;
                ht(j).Position(1:2)=ht(j).Position(1:2)-0.5*step*v;
                moved = true;
            end
        end
    end

    % text–point repel
    for i=1:N
        e = ht(i).Extent;
        if x(i)>e(1)-pad && x(i)<e(1)+e(3)+pad && ...
           y(i)>e(2)-pad && y(i)<e(2)+e(4)+pad
            v=[ht(i).Position(1)-x(i), ht(i).Position(2)-y(i)];
            if norm(v)<eps, v=[1 0.5]; end
            v=v/norm(v);
            ht(i).Position(1:2)=ht(i).Position(1:2)+step*v;
            moved=true;
        end
    end

    if ~moved, break; end
end
end

function tf = overlap(a,b,pad)
tf = a(1)-pad < b(1)+b(3)+pad && ...
     a(1)+a(3)+pad > b(1)-pad && ...
     a(2)-pad < b(2)+b(4)+pad && ...
     a(2)+a(4)+pad > b(2)-pad;
end
