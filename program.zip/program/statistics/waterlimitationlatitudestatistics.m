%% =========================================================================
% FINAL FINAL VERSION
% - 不要 xlabel / ylabel
% - 保留 y 轴刻度（纬度）
% - 去掉 x ticks
% - 去掉上/右边框
% - 字体 ×1.5
% - 图缩小一半
% - 保存为 D:\ 300dpi JPG
% - 图不关闭
%% =========================================================================

clear; clc; close all;

%% ===================== 路径 =====================
basePath = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018';

xlsxFiles = { ...
    'FLUXNET_WLclass_HH.xlsx', ...
    'FLUXNET_WLclass_DD.xlsx', ...
    'FLUXNET_WLclass_MM.xlsx'};

rawFiles = { ...
    'WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw', ...
    'WLclass_Annual_q25_ttest_pcor_f32_720x360.raw', ...
    'WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw'};

savePath = 'D:\';

%% ===================== ENVI参数 =====================
ncols = 720;
nrows = 360;
datatype = 'float32';
byteOrder = 'ieee-le';

% 根据头文件：
% 左上角边界 (-180, 90)，分辨率 0.5°
% 第1行像元中心纬度 = 89.75
% 第360行像元中心纬度 = -89.75
latCenters_raw = 89.75:-0.5:-89.75;

%% ===================== 纬度区间 =====================
latBinStep = 5;

latEdges = 90:-latBinStep:-90;
if latEdges(end) ~= -90
    latEdges = [latEdges, -90];
end

nBins = length(latEdges) - 1;
latCenters_bin = (latEdges(1:end-1) + latEdges(2:end)) / 2;

%% ===================== 分类颜色 =====================
classVals = [1, 2, 3];
classColors = [...
    0.58, 0.79, 0.74;   % class 1
    0.89, 0.64, 0.57;   % class 2
    0.63, 0.66, 0.86];  % class 3

%% ===================== 绘图参数 =====================
fontName = 'Arial';
fontSizeAxis = 26;   % 放大1.5倍
lineWidth = 2.8;

% 图缩小一半
figW = 180;
figH = 460;

smoothWindow = 5;

%% =========================================================================
% ===================== Excel =====================
%% =========================================================================
for i = 1:numel(xlsxFiles)
    
    fileName = xlsxFiles{i};
    filePath = fullfile(basePath, fileName);
    T = readtable(filePath);
    
    % 默认第2列为纬度，最后1列为类别
    lat = T{:,2};
    cls = T{:,end};
    
    % 去除无效值
    valid = ~isnan(lat) & ~isnan(cls);
    lat = lat(valid);
    cls = cls(valid);
    
    % 仅保留 1/2/3
    validClass = ismember(cls, classVals);
    lat = lat(validClass);
    cls = cls(validClass);
    
    % 按纬度带统计绝对数量
    counts_bin = zeros(nBins, 3);
    for k = 1:nBins
        upper = latEdges(k);
        lower = latEdges(k+1);
        idx = (lat <= upper) & (lat > lower);
        
        for c = 1:3
            counts_bin(k,c) = sum(idx & (cls == classVals(c)));
        end
    end
    
    % 平滑
    counts_smooth = smoothdata(counts_bin, 1, 'gaussian', smoothWindow);
    
    %% 绘图
    figure('Color', 'w', 'Position', [100 + (i-1)*25, 100, figW, figH]);
    hold on;
    
    for c = 1:3
        plot(counts_smooth(:,c), latCenters_bin, ...
            'Color', classColors(c,:), ...
            'LineWidth', lineWidth);
    end
    
    ylim([-90 90]);
    
    % 只保留 y 轴刻度（纬度）
    yticks([-90 -60 -30 0 30 60 90]);
    yticklabels({'90°S','60°S','30°S','0°','30°N','60°N','90°N'});
    
    set(gca, ...
        'FontName', fontName, ...
        'FontSize', fontSizeAxis, ...
        'LineWidth', 1.3, ...
        'Box', 'off', ...
        'Layer', 'top', ...
        'YDir', 'normal');
    
    % 去掉 x ticks
    xticks([]);
    set(gca, 'TickLength', [0 0]);
    
    % 保存为 300 dpi JPG
    [~, baseName, ~] = fileparts(fileName);
    print(gcf, fullfile(savePath, [baseName, '.jpg']), '-djpeg', '-r300');
end

%% =========================================================================
% ===================== RAW =====================
%% =========================================================================
for i = 1:numel(rawFiles)
    
    fileName = rawFiles{i};
    filePath = fullfile(basePath, fileName);
    
    fid = fopen(filePath, 'r', byteOrder);
    if fid < 0
        error('无法打开文件: %s', filePath);
    end
    data = fread(fid, [ncols, nrows], datatype);
    fclose(fid);
    
    data = data';
    
    % 每个原始0.5°纬线上统计绝对数量
    counts_raw = zeros(nrows, 3);
    for r = 1:nrows
        rowData = data(r,:);
        for c = 1:3
            counts_raw(r,c) = sum(rowData == classVals(c));
        end
    end
    
    % 聚合到较粗纬度带
    counts_bin = zeros(nBins, 3);
    for k = 1:nBins
        upper = latEdges(k);
        lower = latEdges(k+1);
        idx = (latCenters_raw <= upper) & (latCenters_raw > lower);
        
        for c = 1:3
            counts_bin(k,c) = sum(counts_raw(idx,c));
        end
    end
    
    % 平滑
    counts_smooth = smoothdata(counts_bin, 1, 'gaussian', smoothWindow);
    
    %% 绘图
    figure('Color', 'w', 'Position', [260 + (i-1)*25, 120, figW, figH]);
    hold on;
    
    for c = 1:3
        plot(counts_smooth(:,c), latCenters_bin, ...
            'Color', classColors(c,:), ...
            'LineWidth', lineWidth);
    end
    
    ylim([-90 90]);
    
    % 保留 y 轴刻度（纬度）
    yticks([-90 -60 -30 0 30 60 90]);
    yticklabels({'90°S','60°S','30°S','0°','30°N','60°N','90°N'});
    
    set(gca, ...
        'FontName', fontName, ...
        'FontSize', fontSizeAxis, ...
        'LineWidth', 1.3, ...
        'Box', 'off', ...
        'Layer', 'top', ...
        'YDir', 'normal');
    
    % 去掉 x ticks
    xticks([]);
    set(gca, 'TickLength', [0 0]);
    
    % 保存为 300 dpi JPG
    [~, baseName, ~] = fileparts(fileName);
    print(gcf, fullfile(savePath, [baseName, '.jpg']), '-djpeg', '-r300');
end

disp('完成。所有图片已保存到 D:\ 根目录。');