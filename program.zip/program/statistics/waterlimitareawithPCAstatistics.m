% %% ================== Water-limited pixels across 4 scales + Veg-type % stacked bars + PCA diagnostics figure ==================
% % Scales:
% %   (1) Monthly raw (420)
% %   (2) Annual SSA (420)
% %   (3) Long-term CEEMDAN Trend (420)   <-- NO trend risk filter
% %   (4) Long-term (risk): Long-term water-limited AND (mono-decrease OR UD turning)
% %
% % Water-limited (SW & P co-limited) screening (pixel-wise):
% %   A) Base valid: IGBP in [1..11] AND HFP<=25
% %   B) Sample size: N > MinN; Y>0; all finite
% %   C) Ridge regression on standardized predictors:
% %        z(GPP) ~ z(W) + z(T) + z(R) + z(W)*z(T) + z(W)*z(R)
% %        require beta_W > 0
% %   D) Low-SW test: SW < qLow quantile => mean(GPP_lowSW) < mean(GPP_highSW) AND ttest2 p<alpha
% %   E) Low-P  test: P  < qLow quantile => mean(GPP_lowP ) < mean(GPP_highP ) AND ttest2 p<alpha
% %
% % Outputs (single raw, 720x360, 1=water-limited else 0):
% %   D:\WaterLimited_Monthly.raw
% %   D:\WaterLimited_Annual.raw
% %   D:\WaterLimited_Longterm.raw
% %   D:\WaterLimited_LongtermRisk.raw
% %
% % Extra outputs:
% %   - Veg-type percentages (% water-limited among valid pixels) for each scale
% %   - One stacked bar chart (4 bars) + dashed boundary links + white seams + labels (>5%)
% %   - NEW: One PCA diagnostics figure (3x3 panels) for water-limited pixels
% %
% % Tested: MATLAB R2021a
% 
% clear; clc; close all; warning('off','all');
% tAll = tic;
% set(groot,'DefaultAxesFontName','Arial');
% set(groot,'DefaultTextFontName','Arial');
% 
% %% ================== Paths ==================
% % Masks
% lulcPath = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
% hfpPath  = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';
% 
% % Monthly raw
% GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw";
% T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";
% P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";
% R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";
% SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";
% 
% % Annual SSA
% rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
% GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
% T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
% P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
% R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
% SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
% 
% % Long-term Trend (CEEMDAN Trend)
% GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
% T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
% P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
% R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
% SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
% 
% % Risk masks (global GPP turning statistics)
% monoPath    = 'G:\Resource use efficiencies new\dataresult\CEEMDANstatistics\monoworld_monoGPP.raw';  % mono decrease: value==1
% tippingPath = 'G:\Resource use efficiencies new\dataresult\CEEMDANstatistics\tippingworldGPP.raw';    % UD: value==4
% 
% %% ================== Assertions ==================
% assert(isfile(lulcPath), 'LULC not found');
% assert(isfile(hfpPath),  'HFP not found');
% 
% assert(isfile(GPP_MO_path), 'Monthly GPP missing');
% assert(isfile(T_MO_path) && isfile(P_MO_path) && isfile(R_MO_path) && isfile(SW_MO_path), 'Monthly met files missing');
% 
% assert(isfile(GPP_AN_path) && isfile(T_AN_path) && isfile(P_AN_path) && isfile(R_AN_path) && isfile(SW_AN_path), 'Annual SSA files missing');
% 
% assert(isfile(GPP_LT_path) && isfile(T_LT_path) && isfile(P_LT_path) && isfile(R_LT_path) && isfile(SW_LT_path), 'Long-term Trend files missing');
% 
% assert(isfile(monoPath),    'monoGPP missing');
% assert(isfile(tippingPath), 'tippingGPP missing');
% 
% %% ================== Parameters ==================
% alpha = 0.05;
% MinN  = 60;
% qLow  = 0.25;
% 
% % 468 -> 25:444 = 420
% Tlen   = 420;
% rawLen = 468;
% sFrom  = 25;
% sTo    = 444;
% 
% %% ================== Veg types (IGBP 1..11 -> 9 groups) ==================
% vegNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'};
% vegCodeSets = { [1],[2],[3],[4],[5],[6 7],[8 9],[10],[11] };
% nVeg = numel(vegNames);
% 
% %% ================== Read IGBP/HFP ==================
% IGBP = imread(lulcPath); IGBP = IGBP';
% HFP  = imread(hfpPath);  HFP  = HFP';
% [nx, ny] = size(IGBP);
% fprintf('Grid: %dx%d\n', nx, ny);
% 
% valid_base = (IGBP>=1 & IGBP<=11) & (HFP<=25);
% 
% %% ================== Read risk masks ==================
% mono    = read_raw_2d(monoPath,   [nx,ny]);
% tipping = read_raw_2d(tippingPath,[nx,ny]);
% risk_mask = (mono==1) | (tipping==4);
% 
% %% ================== Read data blocks ==================
% fprintf('Reading data blocks...\n');
% 
% % Monthly
% GPP_MO = read_raw_3d(GPP_MO_path, [nx,ny,Tlen]);
% T_MO   = read_raw_3d(T_MO_path,   [nx,ny,rawLen]); T_MO  = T_MO(:,:,sFrom:sTo);
% P_MO   = read_raw_3d(P_MO_path,   [nx,ny,rawLen]); P_MO  = P_MO(:,:,sFrom:sTo);
% R_MO   = read_raw_3d(R_MO_path,   [nx,ny,rawLen]); R_MO  = R_MO(:,:,sFrom:sTo);
% SW_MO  = read_raw_3d(SW_MO_path,  [nx,ny,rawLen]); SW_MO = SW_MO(:,:,sFrom:sTo);
% 
% % Annual SSA
% GPP_AN = read_raw_3d(GPP_AN_path, [nx,ny,Tlen]);
% T_AN   = read_raw_3d(T_AN_path,   [nx,ny,rawLen]); T_AN  = T_AN(:,:,sFrom:sTo);
% P_AN   = read_raw_3d(P_AN_path,   [nx,ny,rawLen]); P_AN  = P_AN(:,:,sFrom:sTo);
% R_AN   = read_raw_3d(R_AN_path,   [nx,ny,rawLen]); R_AN  = R_AN(:,:,sFrom:sTo);
% SW_AN  = read_raw_3d(SW_AN_path,  [nx,ny,rawLen]); SW_AN = SW_AN(:,:,sFrom:sTo);
% 
% % Long-term Trend
% GPP_LT = read_raw_3d(GPP_LT_path, [nx,ny,Tlen]);
% T_LT   = read_raw_3d(T_LT_path,   [nx,ny,rawLen]); T_LT  = T_LT(:,:,sFrom:sTo);
% P_LT   = read_raw_3d(P_LT_path,   [nx,ny,rawLen]); P_LT  = P_LT(:,:,sFrom:sTo);
% R_LT   = read_raw_3d(R_LT_path,   [nx,ny,rawLen]); R_LT  = R_LT(:,:,sFrom:sTo);
% SW_LT  = read_raw_3d(SW_LT_path,  [nx,ny,rawLen]); SW_LT = SW_LT(:,:,sFrom:sTo);
% 
% fprintf('Data loaded. Start screening pixels...\n');
% 
% %% ================== Main screening ==================
% mask_monthly = false(nx,ny);
% mask_annual  = false(nx,ny);
% mask_longterm= false(nx,ny);
% 
% % ===== NEW: PCA diagnostics maps (only filled for water-limited pixels) =====
% expl1_MO  = nan(nx,ny,'single');  loadSW_MO = nan(nx,ny,'single');  loadP_MO = nan(nx,ny,'single');  corrSW_MO = nan(nx,ny,'single');  corrP_MO = nan(nx,ny,'single');
% expl1_AN  = nan(nx,ny,'single');  loadSW_AN = nan(nx,ny,'single');  loadP_AN = nan(nx,ny,'single');  corrSW_AN = nan(nx,ny,'single');  corrP_AN = nan(nx,ny,'single');
% expl1_LT  = nan(nx,ny,'single');  loadSW_LT = nan(nx,ny,'single');  loadP_LT = nan(nx,ny,'single');  corrSW_LT = nan(nx,ny,'single');  corrP_LT = nan(nx,ny,'single');
% 
% tRow = tic;
% for i = 1:nx
%     for j = 1:ny
%         if ~valid_base(i,j), continue; end
% 
%         % Monthly
%         [okMO, e1, lsw, lp, csw, cp] = is_water_limited_pixel( ...
%             squeeze(GPP_MO(i,j,:)), squeeze(SW_MO(i,j,:)), squeeze(P_MO(i,j,:)), squeeze(T_MO(i,j,:)), squeeze(R_MO(i,j,:)), ...
%             MinN, alpha, qLow);
% 
%         if okMO
%             mask_monthly(i,j) = true;
%             expl1_MO(i,j)  = single(e1);
%             loadSW_MO(i,j) = single(lsw);
%             loadP_MO(i,j)  = single(lp);
%             corrSW_MO(i,j) = single(csw);
%             corrP_MO(i,j)  = single(cp);
%         end
% 
%         % Annual
%         [okAN, e1, lsw, lp, csw, cp] = is_water_limited_pixel( ...
%             squeeze(GPP_AN(i,j,:)), squeeze(SW_AN(i,j,:)), squeeze(P_AN(i,j,:)), squeeze(T_AN(i,j,:)), squeeze(R_AN(i,j,:)), ...
%             MinN, alpha, qLow);
% 
%         if okAN
%             mask_annual(i,j) = true;
%             expl1_AN(i,j)  = single(e1);
%             loadSW_AN(i,j) = single(lsw);
%             loadP_AN(i,j)  = single(lp);
%             corrSW_AN(i,j) = single(csw);
%             corrP_AN(i,j)  = single(cp);
%         end
% 
%         % Long-term
%         [okLT, e1, lsw, lp, csw, cp] = is_water_limited_pixel( ...
%             squeeze(GPP_LT(i,j,:)), squeeze(SW_LT(i,j,:)), squeeze(P_LT(i,j,:)), squeeze(T_LT(i,j,:)), squeeze(R_LT(i,j,:)), ...
%             MinN, alpha, qLow);
% 
%         if okLT
%             mask_longterm(i,j) = true;
%             expl1_LT(i,j)  = single(e1);
%             loadSW_LT(i,j) = single(lsw);
%             loadP_LT(i,j)  = single(lp);
%             corrSW_LT(i,j) = single(csw);
%             corrP_LT(i,j)  = single(cp);
%         end
%     end
% 
%     if mod(i,40)==0
%         fprintf('  row %3d/720 | elapsed %.1fs\n', i, toc(tRow));
%         tRow = tic;
%     end
% end

% 第4类：长期水分限制 + 下降风险
mask_longterm_risk = mask_longterm & risk_mask & valid_base;

%% ================== Export masks to D:\ as 1/0 single raw ==================
out_monthly = 'D:\WaterLimited_Monthly.raw';
out_annual  = 'D:\WaterLimited_Annual.raw';
out_longterm= 'D:\WaterLimited_Longterm.raw';
out_ltrisk  = 'D:\WaterLimited_LongtermRisk.raw';

fid = fopen(out_monthly,'w');  fwrite(fid, single(mask_monthly),        'single'); fclose(fid);
fid = fopen(out_annual ,'w');  fwrite(fid, single(mask_annual),         'single'); fclose(fid);
fid = fopen(out_longterm,'w'); fwrite(fid, single(mask_longterm),       'single'); fclose(fid);
fid = fopen(out_ltrisk,'w');   fwrite(fid, single(mask_longterm_risk),  'single'); fclose(fid);

fprintf('\n✅ Masks saved to D:\\\n');
fprintf('  %s\n', out_monthly);
fprintf('  %s\n', out_annual);
fprintf('  %s\n', out_longterm);
fprintf('  %s\n', out_ltrisk);

%% ================== Veg-type percentages (within valid_base) ==================
totalPix = zeros(1,nVeg);
cntMO    = zeros(1,nVeg);
cntAN    = zeros(1,nVeg);
cntLT    = zeros(1,nVeg);
cntLR    = zeros(1,nVeg);

for v = 1:nVeg
    mveg = valid_base & ismember(IGBP, vegCodeSets{v});
    totalPix(v) = nnz(mveg);

    cntMO(v) = nnz(mveg & mask_monthly);
    cntAN(v) = nnz(mveg & mask_annual);
    cntLT(v) = nnz(mveg & mask_longterm);
    cntLR(v) = nnz(mveg & mask_longterm_risk);
end

pctMO = 100 * cntMO ./ max(totalPix,1);
pctAN = 100 * cntAN ./ max(totalPix,1);
pctLT = 100 * cntLT ./ max(totalPix,1);
pctLR = 100 * cntLR ./ max(totalPix,1);

fprintf('\n=== Water-limited percentage by vegetation type (%%, within valid_base) ===\n');
fprintf('%-6s  %10s  %10s  %10s  %10s  %12s\n','Veg','TotalPix','Monthly','Annual','Longterm','LongtermRisk');
for v=1:nVeg
    fprintf('%-6s  %10d  %9.2f%%  %9.2f%%  %9.2f%%  %11.2f%%\n', vegNames{v}, totalPix(v), pctMO(v), pctAN(v), pctLT(v), pctLR(v));
end

%% ================== Plot: 4 stacked bars + WHITE seams + % labels (>5%) + dashed boundary links ==================
M = [pctMO; pctAN; pctLT; pctLR];   % 4x9
scaleNames = {'Monthly','Annual','Long-term','Long-term (declining)'};
x = 1:4;

cols = [ ...
    0.20 0.45 0.75;  % ENF
    0.10 0.60 0.35;  % EBF
    0.50 0.30 0.70;  % DNF
    0.85 0.35 0.20;  % DBF
    0.90 0.70 0.20;  % MF
    0.65 0.65 0.65;  % SHL
    0.30 0.75 0.80;  % SVA
    0.95 0.55 0.15;  % GRA
    0.20 0.70 0.90;  % WET
];

fig = figure('Color','w','Position',[60 80 750 760]);
ax = axes('Parent',fig); hold(ax,'on');

barW = 0.62;
hb = bar(ax, x, M, 'stacked', 'BarWidth', barW);

pad = (1 - barW)/4;
xlim(ax, [x(1)-barW/2-pad, x(end)+barW/2+pad]);

for v=1:nVeg
    hb(v).FaceColor = cols(v,:);
    hb(v).EdgeColor = [1 1 1];
    hb(v).LineWidth = 1.4;
end

set(ax,'XTick',x,'XTickLabel',scaleNames,'FontSize',15,'TickDir','out','LineWidth',1.0);
ax.XTickLabelRotation = 20;
ylabel(ax,'Water-limited pixels (%)','FontSize',15);
grid(ax,'on'); ax.GridAlpha = 0.18;

cumM = cumsum(M,2);
lowM = [zeros(4,1), cumM(:,1:end-1)];

minLabel = 5.0;
labelFS  = 15;

for s = 1:4
    for v = 1:nVeg
        val = M(s,v);
        if ~(isfinite(val) && val > minLabel), continue; end
        ymid = (lowM(s,v) + cumM(s,v))/2;
        text(ax, x(s), ymid, sprintf('%.1f%%', val), ...
            'HorizontalAlignment','center','VerticalAlignment','middle', ...
            'FontSize',labelFS, 'Color',[0 0 0]);
    end
end

xL = x - barW/2;
xR = x + barW/2;

for v = 1:nVeg
    yb = cumM(:,v);
    if all(yb==0), continue; end
    lc = cols(v,:)*0.70;
    for s = 1:(numel(x)-1)
        plot(ax, [xR(s), xL(s+1)], [yb(s), yb(s+1)], '--', ...
            'Color', lc, 'LineWidth', 1.4);
    end
end

ylim(ax, [0, max(110, max(sum(M,2))+8)]);

lg = legend(ax, vegNames, 'Box','off');
lg.FontSize = 15;
lg.Units = 'normalized';
lg.Position = [0.69 0.58 0.28 0.36];

outFig = 'D:\WaterLimited_VegType_StackedBars_InLegend_NoTitle.png';
exportgraphics(fig, outFig, 'Resolution', 300);
fprintf('\n✅ Figure saved: %s\n', outFig);

%% ================== NEW FIGURE: PCA diagnostics (3 scales x 3 panels) ==================
%% ================== NEW FIGURE: PCA diagnostics (3 scales x 2 panels; remove loadings scatter) ==================
% 仅统计“水分限制像元”上的 PCA 结果（NaN 会自动剔除）

pcaFig = figure('Color','w','Position',[20 20 860 880]);
tlo = tiledlayout(pcaFig, 3, 2, 'Padding','compact','TileSpacing','compact');

scaleLab = {'Monthly','Annual','Long-term'};
Ecell = {expl1_MO,  expl1_AN,  expl1_LT};
CSW   = {corrSW_MO, corrSW_AN, corrSW_LT};

for s = 1:3
    expl1v = Ecell{s}; expl1v = expl1v(isfinite(expl1v));
    cswv   = CSW{s};   cswv   = cswv(isfinite(cswv));

    % (1) explained variance of PC1
    nexttile(tlo, (s-1)*2 + 1);
    if ~isempty(expl1v)
        histogram(expl1v, 25, 'Normalization','probability');
    else
        histogram(nan, 25);
    end
    set(gca,'TickDir','out','LineWidth',1.0,'FontSize',12);
    xlabel('Explained variance of PC1 (%)');
    ylabel('Probability');
    title(sprintf('%s | PC1 explained variance', scaleLab{s}), 'FontWeight','normal');

    % (2) corr(PC1, SWz) distribution (should be >=0 due to sign unification)
    nexttile(tlo, (s-1)*2 + 2);
    if ~isempty(cswv)
        histogram(cswv, 25, 'Normalization','probability');
        hold on;
        xline(0, 'k--', 'LineWidth', 1.0);
        hold off;
    else
        histogram(nan, 25);
    end
    set(gca,'TickDir','out','LineWidth',1.0,'FontSize',12);
    xlabel('corr(PC1, SW_z)');
    ylabel('Probability');
    title(sprintf('%s | Sign check (PC1 vs SW)', scaleLab{s}), 'FontWeight','normal');
end

outPCA = 'D:\WaterLimited_PCA_Diagnostics_3Scales.png';
exportgraphics(pcaFig, outPCA, 'Resolution', 300);
fprintf('\n✅ PCA diagnostics figure saved: %s\n', outPCA);

%% ================== Helper functions ==================
function [ok, expl1, loadSW, loadP, corrSW, corrP] = is_water_limited_pixel(y, sw, p, t, r, MinN, alpha, qLow)
    ok = false;

    % ===== default outputs =====
    expl1 = nan; loadSW = nan; loadP = nan; corrSW = nan; corrP = nan;

    y = y(:); sw = sw(:); p = p(:); t = t(:); r = r(:);

    % 数据清洗：确保数据有效并且 y>0
    m = isfinite(y) & isfinite(sw) & isfinite(p) & isfinite(t) & isfinite(r) & (y > 0);
    if sum(m) <= MinN, return; end

    y = y(m); sw = sw(m); p = p(m); t = t(m); r = r(m);

    % 主成分分析：SW 和 P 进行 PCA（标准化后）
    Xwp = zscore([sw, p]);
    try
        [coeff, score, ~, ~, explained] = pca(Xwp, 'Rows', 'complete');
        Wpc  = score(:, 1);
        expl1 = explained(1);
        load1 = coeff(:, 1);
    catch
        return;
    end

    % 统一方向：确保 corr(PC1, SWz) >= 0
    swz = Xwp(:, 1);
    pz  = Xwp(:, 2);

    try
        if corr(Wpc, swz, 'Rows', 'complete') < 0
            Wpc   = -Wpc;
            load1 = -load1;
        end
    catch
    end

    loadSW = load1(1);
    loadP  = load1(2);

    try
        corrSW = corr(Wpc, swz, 'Rows', 'complete');
    catch
        corrSW = nan;
    end
    try
        corrP  = corr(Wpc, pz, 'Rows', 'complete');
    catch
        corrP = nan;
    end

    % 回归分析：WPC 对 GPP 的岭回归（含交互项）
    yz = zscore(y);
    X  = zscore([Wpc, t, r]);
    Wz = X(:, 1); Tz = X(:, 2); Rz = X(:, 3);
    X_reg = [Wz, Tz, Rz, Wz .* Tz, Wz .* Rz];

    try
        mdl  = fitrlinear(X_reg, yz, 'Learner', 'leastsquares', ...
            'Regularization', 'ridge', 'Lambda', 0.1, 'FitBias', true);
        beta = mdl.Beta';
    catch
        return;
    end

    % 水分限制：beta_WPC > 0
    if ~isfinite(beta(1)) || beta(1) <= 0, return; end

    % 低土壤水分区域检验
    thr_sw = quantile(sw, qLow);
    low  = (sw <= thr_sw);
    high = ~low;
    if sum(low) < 10 || sum(high) < 10, return; end
    if mean(y(low), 'omitnan') >= mean(y(high), 'omitnan'), return; end
    try
        [~, p_sw] = ttest2(y(low), y(high), 'Vartype', 'unequal');
    catch
        p_sw = 1;
    end
    if ~(p_sw < alpha), return; end

    % 低降水区域检验
    thr_p = quantile(p, qLow);
    low  = (p <= thr_p);
    high = ~low;
    if sum(low) < 10 || sum(high) < 10, return; end
    if mean(y(low), 'omitnan') >= mean(y(high), 'omitnan'), return; end
    try
        [~, p_pp] = ttest2(y(low), y(high), 'Vartype', 'unequal');
    catch
        p_pp = 1;
    end
    if ~(p_pp < alpha), return; end

    ok = true;
end

function A = read_raw_3d(path, shape)
    fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s',path);
    A = fread(fid, prod(shape), 'single'); fclose(fid);
    A = reshape(A, shape);
end

function A = read_raw_2d(path, shape2)
    fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s',path);
    A = fread(fid, prod(shape2), 'single'); fclose(fid);
    A = reshape(A, shape2);
end
