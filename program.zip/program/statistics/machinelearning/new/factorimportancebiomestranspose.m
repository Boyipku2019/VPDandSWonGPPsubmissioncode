clear all; close all; clc;

%% ---------- 读取数据 ----------
HFP = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');
HFP = HFP';

countries = {'Monthly', 'Annual', 'Long-term'};   % 行：时间尺度 (semiannual is removed)
factors   = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','All biomes'};

IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP = IGBP';

% 读取R2数据
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPGBDTmonthlyR2.raw','r');
R2shortterm = fread(fid,[720*360],'single'); fclose(fid);
R2shortterm = reshape(R2shortterm,[720,360]);

fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPGBDTannualR2.raw','r');
R2annual = fread(fid,[720*360],'single'); fclose(fid);
R2annual = reshape(R2annual,[720,360]);

fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPGBDTlongtermR2.raw','r');
R2longterm = fread(fid,[720*360],'single'); fclose(fid);
R2longterm = reshape(R2longterm,[720,360]);

% 4 个月（4 因子）
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPGBDTmonthlyfactorimportance.raw','r');
shrotttermdata = fread(fid,[720*360*4],'single'); fclose(fid);
shrotttermdata = reshape(shrotttermdata,[720,360,4]);

% 年（4 因子）
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPGBDTannualfactorimportance.raw','r');
annualdata = fread(fid,[720*360*4],'single'); fclose(fid);
annualdata = reshape(annualdata,[720,360,4]);

% 长期（5 因子）
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPGBDTlongtermfactorimportance.raw','r');
longtermdata = fread(fid,[720*360*5],'single'); fclose(fid);
longtermdata = reshape(longtermdata,[720,360,5]);

% 每个尺度的因子个数（前三个=4，长期=5）
nShort  = size(shrotttermdata,   3);   % 4
nAnnual = size(annualdata,       3);   % 4
nLong   = size(longtermdata,     3);   % 5
maxF    = max([nShort,nAnnual,nLong]); % 5

%% ---------- 预分配容器 ----------
ENFmeancell = {}; EBFmeancell = {}; DNFmeancell = {}; DBFmeancell = {};
MFmeancell  = {}; SHLmeancell = {}; SVAmeancell = {}; GRAmeancell = {};
WETmeancell = {}; Allbiomescell = {};

ENFcount=0; EBFcount=0; DNFcount=0; DBFcount=0; MFcount=0; SHLcount=0; SVAcount=0; GRAcount=0; WETcount=0; countall=0;

%% ---------- 主循环：像元筛选 + 归一化 ----------
for i = 1:720
    for j = 1:360
        validBiome = (IGBP(i,j)>=1 && IGBP(i,j)<=11);
        validHFP   = (HFP(i,j) <= 25);

        % 仅选择R2值大于0.3的像元（你原来注释掉了，这里保持不启用）
        validR2short  = R2shortterm(i,j) > 0.3;
        validR2annual = R2annual(i,j) > 0.3;
        validR2long   = R2longterm(i,j) > 0.3;

        % 保证三个尺度各自有非零
        s1 = sum(shrotttermdata(i,j,:));
        s3 = sum(annualdata(i,j,:));
        s4 = sum(longtermdata(i,j,:));

        % 你原来是只要求非零，这里保持一致
        validData = (s1~=0 && s3~=0 && s4~=0);

        % 若你要启用R2筛选，把下面这一行改成：
        % if validBiome && validData && validHFP && validR2short && validR2annual && validR2long
        if validBiome && validData && validHFP

            % mean_valuestemp 维度：maxF x 3（因子 x 时间尺度）
            mean_valuestemp = nan(maxF,3,'single');

            % 4 months
            for f = 1:maxF
                if f <= nShort
                    mean_valuestemp(f,1) = shrotttermdata(i,j,f) / s1;
                else
                    mean_valuestemp(f,1) = nan;
                end
            end

            % Annual
            for f = 1:maxF
                if f <= nAnnual
                    mean_valuestemp(f,2) = annualdata(i,j,f) / s3;
                else
                    mean_valuestemp(f,2) = nan;
                end
            end

            % Long-term
            for f = 1:maxF
                if f <= nLong
                    mean_valuestemp(f,3) = longtermdata(i,j,f) / s4;
                else
                    mean_valuestemp(f,3) = nan;
                end
            end

            % All biomes
            countall = countall + 1;
            Allbiomescell{countall} = mean_valuestemp;

            % 各植被类型分类收集
            switch IGBP(i,j)
                case 1
                    ENFcount=ENFcount+1; ENFmeancell{ENFcount}=mean_valuestemp;
                case 2
                    EBFcount=EBFcount+1; EBFmeancell{EBFcount}=mean_valuestemp;
                case 3
                    DNFcount=DNFcount+1; DNFmeancell{DNFcount}=mean_valuestemp;
                case 4
                    DBFcount=DBFcount+1; DBFmeancell{DBFcount}=mean_valuestemp;
                case 5
                    MFcount =MFcount +1;  MFmeancell{MFcount}  =mean_valuestemp;
                case {6,7}
                    SHLcount=SHLcount+1; SHLmeancell{SHLcount}=mean_valuestemp;
                case {8,9}
                    SVAcount=SVAcount+1; SVAmeancell{SVAcount}=mean_valuestemp;
                case 10
                    GRAcount=GRAcount+1; GRAmeancell{GRAcount}=mean_valuestemp;
                case 11
                    WETcount=WETcount+1; WETmeancell{WETcount}=mean_valuestemp;
            end
        end
    end
    i; % 进度显示
end

%% ---------- 聚合：各类的均值与 SEM（忽略 NaN） ----------
data_groups     = cell(1,10);
std_dev_groups  = cell(1,10);  % 变量名保持不变，但里面存的是 SEM

[data_groups{1},  std_dev_groups{1}]  = agg_mean_sem(ENFmeancell, ENFcount, maxF);
[data_groups{2},  std_dev_groups{2}]  = agg_mean_sem(EBFmeancell, EBFcount, maxF);
[data_groups{3},  std_dev_groups{3}]  = agg_mean_sem(DNFmeancell, DNFcount, maxF);
[data_groups{4},  std_dev_groups{4}]  = agg_mean_sem(DBFmeancell, DBFcount, maxF);
[data_groups{5},  std_dev_groups{5}]  = agg_mean_sem(MFmeancell,  MFcount,  maxF);
[data_groups{6},  std_dev_groups{6}]  = agg_mean_sem(SHLmeancell, SHLcount, maxF);
[data_groups{7},  std_dev_groups{7}]  = agg_mean_sem(SVAmeancell, SVAcount, maxF);
[data_groups{8},  std_dev_groups{8}]  = agg_mean_sem(GRAmeancell, GRAcount, maxF);
[data_groups{9},  std_dev_groups{9}]  = agg_mean_sem(WETmeancell, WETcount, maxF);
[data_groups{10}, std_dev_groups{10}] = agg_mean_sem(Allbiomescell, countall, maxF);

%% ---------- 颜色与图例 ----------
colors = [ ...
     161,213,112;  % Soil Moisture
      60,168,197;  % Precipitation
     249,118,110;  % Temperature
     250,174, 90;  % Radiation
     160,160,160   % CO2（仅长期）
] / 255;

legend_labels = {'Soil Moisture','Precipitation','Temperature','Radiation','CO_2'};

%% ---------- 绘图 ----------
figure;
set(gcf, 'Position', [100, 100, 1500, 800]);  % 设置画布的大小
tiledlayout(2,5,'Padding','compact','TileSpacing','compact');

for ii = 1:10
    nexttile;
    % data_groups{ii} 是 (maxF x 3)，需要转置成 (3 x maxF)
    plot_group(data_groups{ii}', std_dev_groups{ii}', factors{ii}, countries, colors, (ii==1 || ii==6));

    % x 轴显示为百分比
    xlim([0 1]);
    xticks(0:0.2:1);
    xticklabels( arrayfun(@(x) sprintf('%.0f%%', x*100), xticks, 'UniformOutput', false) );
    if ii>=1 && ii<=5
        xlabel('');
    end
end

% 统一图例
lgd = legend(legend_labels,'Location','southoutside','Orientation','horizontal');
set(lgd,'Interpreter','tex','FontName','Arial');

set(gcf,'Color','w');

%% ================= 工具函数 =================
function [mean_values, sem_values] = agg_mean_sem(cellarr, ncount, maxF)
    % 将 cell 中的 maxF x 3 矩阵堆叠，并对第 3 维做均值与 SEM（忽略 NaN）
    if ncount == 0
        mean_values = nan(maxF,3);
        sem_values  = nan(maxF,3);
        return;
    end

    stacked = nan(maxF,3,ncount,'single');
    for k = 1:ncount
        stacked(:,:,k) = cellarr{k};
    end

    % 均值
    mean_values = mean(stacked, 3, 'omitnan');

    % SD（按样本维度）
    sd_values = std(stacked, 0, 3, 'omitnan');

    % 每个 (因子,尺度) 的有效样本数（非 NaN）
    n_eff = sum(~isnan(stacked), 3);

    % SEM = SD / sqrt(n)
    sem_values = sd_values ./ sqrt(n_eff);

    % 防止 n=0 造成 Inf
    sem_values(n_eff==0) = nan;
end

function plot_group(data_group, std_dev_group, title_str, countries, colors, show_ylabel)
    % data_group: (3 x maxF)   行=时间尺度, 列=因子(最多5列；前三个尺度第5列为 NaN)
    [ngroups, nbars] = size(data_group);
    groupwidth = min(0.8, nbars/(nbars + 1.5));
    errlw = 0.8;

    b = barh(data_group,'grouped'); hold on;
    for k = 1:length(b)
        b(k).FaceColor = colors(k,:);
        b(k).EdgeColor = 'none';
    end
    title(title_str,'FontWeight','bold','FontName','Arial');

    if show_ylabel
        set(gca,'YTick',1:ngroups,'YTickLabel',countries);
    else
        set(gca,'YTick',1:ngroups,'YTickLabel',[]);
    end

    xlabel('Percentage');
    set(gca,'FontName','Arial','FontSize',17);
    box on; grid on;

    % ===== 半边误差线：仅在右侧（超过部分）=====
    for k = 1:nbars
        % 每组中第 k 个柱的 y 位置（与 barh 对齐）
        y = (1:ngroups) - groupwidth/2 + (2*k-1) * groupwidth / (2*nbars);
        x  = data_group(:,k);
        xe = std_dev_group(:,k);
        mask = ~isnan(x) & ~isnan(xe);
        for m = find(mask)'
            x_start = x(m);            % 柱子的右端
            x_end   = x(m) + xe(m);    % 右端 + 误差（现在是 SEM）
            y_pos   = y(m);

            % 横线（右侧超出部分）
            line([x_start x_end],[y_pos y_pos],'Color','k','LineWidth',errlw);

            % 右端帽
            cap = 0.1; % 帽子的半高度
            line([x_end x_end],[y_pos-cap y_pos+cap],'Color','k','LineWidth',errlw);
        end
    end

    hold off;
end
