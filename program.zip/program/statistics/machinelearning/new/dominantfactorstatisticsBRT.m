clear all; close all; clc;

%% ---------------- 基础数据 ----------------
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif'); IGBP = IGBP';
HFP  = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');  HFP  = HFP';

% 因子颜色
colors = [ ...
    161,213,112;  % 1 Soil Moisture
    60,168,197;  % 2 Precipitation
     249,118,110;  % 3 Temperature
    250,174, 90;  % 4 Radiation
    160,160,160]; % 5 CO2（仅长期）
colors = colors/255;

% ===== 字体 24号 =====
labelFontSize = 48;




%% ========================================================================
% 只处理：Semiannual(4因子), Annual(4因子), Long-term(5因子)
% 掩膜：IGBP∈[1..11] 且 HFP<=25 且该像元该尺度数据非零
% 绘图：环状图（非 pie），空心半径比上版增加 15%
% ========================================================================
% ========================================================================

%% ---------------- 月（4 因子） ----------------
fprintf('Semiannual: 读取并计算主导因子...\n');
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPBRTmonthlyfactorimportance.raw','r');
data = fread(fid, [720*360*4], 'float32'); fclose(fid);
data = reshape(data, [720,360,4]);

dominant_factor = zeros(720,360,'single');
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)>=1 && IGBP(i,j)<=11) && (HFP(i,j)<=25) && data(i,j,1)~=0
            [~, max_idx] = max( reshape(data(i,j,1:4), [4,1]) );
            dominant_factor(i,j) = single(max_idx);
        end
    end
    if mod(i,40)==0, fprintf('  行进度 %3d/720\n', i); end
end

fid = fopen('D:\dominant_factor_monthly_GPPBRT.raw','w'); fwrite(fid, dominant_factor, 'float32'); fclose(fid);

mask_valid = (dominant_factor>=1 & dominant_factor<=4);
vals = dominant_factor(mask_valid);
counts4 = histcounts(vals, 0.5:1:4.5);
pct4 = 100 * counts4 / max(1,sum(counts4));

figure('Color','w','Position',[200 140 560 560]);
make_ring_chart_halfhole(pct4, colors(1:4,:), labelFontSize);



%% ---------------- 年（4 因子） ----------------
fprintf('Annual: 读取并计算主导因子...\n');
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPBRTannualfactorimportance.raw','r');
data = fread(fid, [720*360*4], 'float32'); fclose(fid);
data = reshape(data, [720,360,4]);

dominant_factor = zeros(720,360,'single');
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)>=1 && IGBP(i,j)<=11) && (HFP(i,j)<=25) && data(i,j,1)~=0
            [~, max_idx] = max( reshape(data(i,j,1:4), [4,1]) );
            dominant_factor(i,j) = single(max_idx);
        end
    end
    if mod(i,40)==0, fprintf('  行进度 %3d/720\n', i); end
end

fid = fopen('D:\dominant_factor_annual_GPPBRT.raw','w'); fwrite(fid, dominant_factor, 'float32'); fclose(fid);

mask_valid = (dominant_factor>=1 & dominant_factor<=4);
vals = dominant_factor(mask_valid);
counts4 = histcounts(vals, 0.5:1:4.5);
pct4 = 100 * counts4 / max(1,sum(counts4));

figure('Color','w','Position',[220 160 560 560]);
make_ring_chart_halfhole(pct4, colors(1:4,:), labelFontSize);


%% ---------------- 长期（5 因子） ----------------
fprintf('Long-term: 读取并计算主导因子...\n');
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\new\GPPBRTlongtermfactorimportance.raw','r');
data = fread(fid, [720*360*5], 'float32'); fclose(fid);
data = reshape(data, [720,360,5]);

dominant_factor = zeros(720,360,'single');
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)>=1 && IGBP(i,j)<=11) && (HFP(i,j)<=25) && data(i,j,1)~=0
            [~, max_idx] = max( reshape(data(i,j,1:5), [5,1]) );
            dominant_factor(i,j) = single(max_idx);
        end
    end
    if mod(i,40)==0, fprintf('  行进度 %3d/720\n', i); end
end

fid = fopen('D:\dominant_factor_longterm_GPPBRT.raw','w'); fwrite(fid, dominant_factor, 'float32'); fclose(fid);

mask_valid = (dominant_factor>=1 & dominant_factor<=5);
vals = dominant_factor(mask_valid);
counts5 = histcounts(vals, 0.5:1:5.5);
pct5 = 100 * counts5 / max(1,sum(counts5));

figure('Color','w','Position',[240 180 560 560]);
make_ring_chart_halfhole(pct5, colors(1:5,:), labelFontSize);

fprintf('✅ 完成：空心半径增加15%% (r_inner=0.316)，字体24号。\n');


%% ---------------- 工具函数：环状图（中空半径增加15%） ----------------
function make_ring_chart_halfhole(pcts, cols, fs)
    K = numel(pcts);
    share = pcts(:)' / max(1, sum(pcts));

    % —— 环参数 —— %
    r_outer = 0.70;         % 外半径
    r_inner = 0.316;        % 空心半径 = 原0.275×1.15
    nArc    = 120;          % 每段的插值点数

    clf; ax = axes; hold(ax,'on'); axis(ax,'equal','off');
    theta0 = pi/2;          % 从顶部开始
    edges  = [0, cumsum(share)] * 2*pi;

    for k = 1:K
        a1 = theta0 - edges(k+1);
        a0 = theta0 - edges(k);

        % 外弧与内弧
        th_outer = linspace(a0, a1, nArc);
        th_inner = linspace(a1, a0, nArc);

        x_outer = r_outer * cos(th_outer);  y_outer = r_outer * sin(th_outer);
        x_inner = r_inner * cos(th_inner);  y_inner = r_inner * sin(th_inner);

        % 扇形环带
        patch([x_outer x_inner], [y_outer y_inner], cols(k,:), ...
            'EdgeColor','w','LineWidth',1);

        % 百分比文本放在环带中部
        th_mid = (a0 + a1)/2;
        r_mid  = (r_outer + r_inner)/2;
        if pcts(k)>10
        text(r_mid*cos(th_mid), r_mid*sin(th_mid), sprintf('%.1f%%', pcts(k)), ...
            'HorizontalAlignment','center','VerticalAlignment','middle', ...
            'FontName','Arial','FontWeight','bold','FontSize',fs,'Color','k');
        end
    end
end
