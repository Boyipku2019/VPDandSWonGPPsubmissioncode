clear all;close all;clc;

% 示例数据生成
countries ={'Temperature', 'Precipitation', 'Radiation', 'SM','CO2'};
ENF=[];EBF=[];DNF=[];DBF=[];MF=[];SHL=[];SVA=[];GRA=[];WET=[];

factors = {'ENF', 'EBF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET',"All biomes"};

HFP=imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');
HFP=HFP';

IGBP=imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP=IGBP';

% 打开 .raw 文件
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\LAIRFalltermsfactorimportance.raw', 'r');
shrotttermdata = fread(fid, [720*360*4], 'float32');
fclose(fid);
shrotttermdata = reshape(shrotttermdata, [720, 360, 4]);

ENFmean=[]; EBFmean=[]; DNFmean=[]; DBFmean=[]; MFmean=[]; SHLmean=[];
SVAmean=[]; GRAmean=[]; WETmean=[]; Allbiomes=[];
ENFcount=0;EBFcount=0;DNFcount=0;DBFcount=0;MFcount=0;SHLcount=0;SVAcount=0;GRAcount=0;WETcount=0;countall=0;

for i=1:720
    for j=1:360
        if (IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11)&&shrotttermdata(i,j)~=0&&HFP(i,j)<=25
            mean_valuestemp=single(zeros(4,1));
            % 该像元贡献率综合归一化
            sumshort=sum(shrotttermdata(i,j,:));
            for factor=1:4
                mean_valuestemp(factor)=shrotttermdata(i,j,factor)/sumshort;
            end
            countall=countall+1;
            Allbiomes=[Allbiomes mean_valuestemp];

            if IGBP(i,j)==1,  ENFmean=[ENFmean mean_valuestemp]; end
            if IGBP(i,j)==2,  EBFmean=[EBFmean mean_valuestemp]; end
            if IGBP(i,j)==3,  DNFmean=[DNFmean mean_valuestemp]; end
            if IGBP(i,j)==4,  DBFmean=[DBFmean mean_valuestemp]; end
            if IGBP(i,j)==5,  MFmean=[MFmean mean_valuestemp];  end
            if (IGBP(i,j)==6||IGBP(i,j)==7), SHLmean=[SHLmean mean_valuestemp]; end
            if (IGBP(i,j)==8||IGBP(i,j)==9), SVAmean=[SVAmean mean_valuestemp]; end
            if IGBP(i,j)==10, GRAmean=[GRAmean mean_valuestemp]; end
            if IGBP(i,j)==11, WETmean=[WETmean mean_valuestemp]; end
        end
    end
    i;
end

ENFmeannew= mean(ENFmean, 2);
EBFmeannew= mean(EBFmean, 2);
DNFmeannew= mean(DNFmean, 2);
DBFmeannew= mean(DBFmean, 2);
MFmeannew= mean(MFmean, 2);
SHLmeannew= mean(SHLmean, 2);
SVAmeannew= mean(SVAmean, 2);
GRAmeannew= mean(GRAmean, 2);
WETmeannew= mean(WETmean, 2);
Allbiomesnew= mean(Allbiomes, 2);
data=[ENFmeannew EBFmeannew DNFmeannew DBFmeannew MFmeannew SHLmeannew SVAmeannew GRAmeannew WETmeannew Allbiomesnew];
data=data';

ENFstd= std(ENFmean, 0, 2);
EBFstd= std(EBFmean,  0,2);
DNFstd= std(DNFmean,  0,2);
DBFstd= std(DBFmean,  0,2);
MFstd= std(MFmean,  0,2);
SHLstd= std(SHLmean,  0,2);
SVAstd= std(SVAmean,  0,2);
GRAstd= std(GRAmean,  0,2);
WETstd= std(WETmean,  0,2);
Allbiomesstd= std(Allbiomes,  0,2);
std_dev=[ENFstd EBFstd DNFstd DBFstd MFstd SHLstd SVAstd GRAstd WETstd Allbiomesstd];
std_dev=std_dev';

% 自定义颜色
colors = [249,118,110;
          60,168,197;
          250,174,90;
          161,213,112]/255;

% 柱状图
fig = figure('Position', [100, 100, 800, 400]);
hBar = bar(data, 'grouped');
hold on;
for k = 1:4
    hBar(k).FaceColor = colors(k, :);
end

% -------- 只显示“上半部分”的标准差线 --------
numGroups = size(data, 1);
numBars = size(data, 2);
groupWidth = min(0.8, numBars/(numBars + 1.5));
for i = 1:numBars
    x = (1:numGroups) - groupWidth/2 + (2*i-1) * groupWidth / (2*numBars);
    % 下误差设为 0，上误差为 std_dev -> 仅画向上的误差条
    errorbar(x, data(:, i), zeros(numGroups,1), std_dev(:, i), ...
             'k', 'linestyle', 'none', 'CapSize', 6);
end
% -------------------------------------------

ylabel('Normalized factor importance');

xticks(1:numGroups);
xticklabels({'ENF', 'EBF', 'DNF', 'DBF', 'MF', 'SHL', 'SVA', 'GRA', 'WET', 'Allbiomes'});

ax = gca;
ax.YTickLabel = arrayfun(@(v) sprintf('%.0f%%', v*100), ax.YTick, 'UniformOutput', false);

legend('Temperature', 'Precipitation', 'Radiation', 'Soil Moisture', ...
       'Location', 'northeastoutside', 'Interpreter', 'tex');

grid on;
hold off;
