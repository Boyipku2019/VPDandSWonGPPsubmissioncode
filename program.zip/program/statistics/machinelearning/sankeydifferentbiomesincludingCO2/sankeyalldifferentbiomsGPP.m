% % clear all;
% %Option 1: use a table
% d = load('dummytable.mat');
% data = d.dummytable;
% 
% % Option 2: use a matrix
%   This example ilustrates a matrix with 
%   20 observations (rows) and 3 layers (columns) and 
%   3,5,2 categories per layer respectively.
clear all;close all;clc;
%figure;
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP = IGBP';
%输入四期的主导因子数据

shortterm=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\dominantfactor\dominant_factor4monthGPP.raw','r'); %打RAW文件
shortterm = fread(fid,720*360,'single'); % 读RAW数据
shortterm=reshape(shortterm,[720,360]);

innerannual=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\dominantfactor\dominant_factorsemiannualGPP.raw','r'); %打RAW文件
innerannual = fread(fid,720*360,'single'); % 读RAW数据
innerannual=reshape(innerannual,[720,360]);

interannual=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\dominantfactor\dominant_factorannualGPP.raw','r'); %打RAW文件
interannual = fread(fid,720*360,'single'); % 读RAW数据
interannual=reshape(interannual,[720,360]);

longterm=single(zeros(720,360));
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\dominantfactor\dominant_factorlongtermGPP.raw','r'); %打RAW文件
longterm = fread(fid,720*360,'single'); % 读RAW数据
longterm=reshape(longterm,[720,360]);

HFP  = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');
HFP  = HFP';
% 读取R2数据
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFglobal4monthR2.raw','r');
R2shortterm = fread(fid,[720*360],'single'); fclose(fid);
R2shortterm = reshape(R2shortterm,[720,360]);

fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFsemiannualR2.raw','r');
R2semiannual = fread(fid,[720*360],'single'); fclose(fid);
R2semiannual = reshape(R2semiannual,[720,360]);

fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFannualR2.raw','r');
R2annual = fread(fid,[720*360],'single'); fclose(fid);
R2annual = reshape(R2annual,[720,360]);

fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFlongtermR2.raw','r');
R2longterm = fread(fid,[720*360],'single'); fclose(fid);
R2longterm = reshape(R2longterm,[720,360]);
%%%&&R2shortterm(i,j)>0.3&&R2semiannual(i,j)>0.3&&R2annual(i,j)>0.3&&R2longterm(i,j)>0.3
biomenamenumber={1,2,3,4,5,[6,7],[8,9],10,11};
biomename = ["ENF", "EBF", "DNF", "DBF", "MF", "SHL", "SVA", "GRA", "WET"];
for mm=1:9
    data=[];
for i=1:720
    for j=1:360
         if ismember(IGBP(i,j), biomenamenumber{mm})&&shortterm(i, j)~=0&&innerannual(i, j)~=0&&interannual(i, j)~=0&&longterm(i, j)~=0&&HFP(i,j)<=25
  %  if IGBP(i,j)==1
%                    ENF=[ENF;a];
%                end
%                if IGBP(i,j)==2
%                   EBF=[EBF;a];
%                end
%                if IGBP(i,j)==3
%                    DNF=[DNF;a];
%                end
%                if IGBP(i,j)==4
%                     DBF=[DBF;a];
%                end
%                if IGBP(i,j)==5
%                     MF=[MF;a];
%                end
%                if (IGBP(i,j)==6||IGBP(i,j)==7)
%                    SHL=[SHL;a];
%                end
%                if (IGBP(i,j)==8||IGBP(i,j)==9)
%                    SVA=[SVA;a];
%                end
%                if IGBP(i,j)==10
%                    GRA=[GRA;a];
%                end
%                if IGBP(i,j)==11
%                     WET=[WET;a];
%                end
          temp=[shortterm(i,j) innerannual(i,j) interannual(i,j) longterm(i,j)];
          data=[data;temp];
         end
    end
    i
end
%样本输入矩阵格式
%data = [randi(6,[13000 1]) randi(6,[13000 1]) randi(6,[13000 1]) randi(6,[13000 1])];


%% Customizable options
% Colormap: can be the name of matlab colormaps or a matrix of (N x 3).
%   Important: N must be the max number of categories in a layer 
%   multiplied by the number of layers. 
%   In the example of Option 1, N should be 4 * 4 = 16;
%   In the example of Option 2, N should be 5 * 3 = 15;
options.color_map = 'parula';      
options.flow_transparency = 0.2;   % opacity of the flow paths
options.bar_width = 40;            % width of the category blocks
options.show_perc = true;          % show percentage over the blocks
options.text_color = [0 0 0 0.8];      % text color for the percentages
options.show_layer_labels = true;  % show layer names under the chart
options.show_cat_labels = false;   % show categories over the blocks.
options.show_legend = false;        % show legend with the category names. 
                                   % if the data is not a table, then the
                                   % categories are labeled as catX-layerY


plotSankeyFlowChart1(data,options);
title(biomename{mm});
% 将图像以 300 dpi 保存到 D 盘根目录
%print(['D:\saved_image',num2str(mm)], '-djpeg', '-r300');
% 获取当前的 figure 句柄
fig = gcf;

% 获取 figure 中的所有 axes（坐标轴）对象
axesHandles = findall(fig, 'Type', 'axes');

% 遍历每个 axes 对象
for i = 1:length(axesHandles)
    % 获取 axes 中的所有文本对象，包括标题、坐标轴标签、图例等
    titleHandle = get(axesHandles(i), 'Title');
    xlabelHandle = get(axesHandles(i), 'XLabel');
    ylabelHandle = get(axesHandles(i), 'YLabel');
    zlabelHandle = get(axesHandles(i), 'ZLabel');
    
    % 获取当前文本对象的字体大小，并调整为1.5倍
    set(titleHandle, 'FontSize', get(titleHandle, 'FontSize') * 1.5);
    set(xlabelHandle, 'FontSize', get(xlabelHandle, 'FontSize') * 1.5);
    set(ylabelHandle, 'FontSize', get(ylabelHandle, 'FontSize') * 1.5);
    set(zlabelHandle, 'FontSize', get(zlabelHandle, 'FontSize') * 1.5);
    
    % 如果图中有 legend（图例），调整 legend 的字体大小
    legendHandle = findobj(fig, 'Type', 'legend');
    if ~isempty(legendHandle)
        set(legendHandle, 'FontSize', get(legendHandle, 'FontSize') * 1.5);
    end
    
    % 获取并调整所有 text 对象的字体大小
    textHandles = findall(axesHandles(i), 'Type', 'text');
    for j = 1:length(textHandles)
        set(textHandles(j), 'FontSize', get(textHandles(j), 'FontSize') * 1.5);
    end
end



end


