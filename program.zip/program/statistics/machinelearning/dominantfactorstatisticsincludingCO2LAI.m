clear all;close all;clc;
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP = IGBP';
% % 4 个月（4 因子）
% fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRF4monthfactorimportance.raw','r');
% shrotttermdata = fread(fid,[720*360*4],'single'); fclose(fid);
% shrotttermdata = reshape(shrotttermdata,[720,360,4]);
% 
% % 半年（4 因子）
% fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFsemiannualfactorimportance.raw','r');
% innerannualdata = fread(fid,[720*360*4],'single'); fclose(fid);
% innerannualdata = reshape(innerannualdata,[720,360,4]);
% 
% % 年（4 因子）
% fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFannualfactorimportance.raw','r');
% annualdata = fread(fid,[720*360*4],'single'); fclose(fid);
% annualdata = reshape(annualdata,[720,360,4]);
% 
% % 长期（5 因子）
% fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFlongtermfactorimportance.raw','r');
% longtermdata = fread(fid,[720*360*5],'single'); fclose(fid);
% longtermdata = reshape(longtermdata,[720,360,5]);


% 打开 .raw 文件，假设文件名为 'data.raw'
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\LAI\LAIRF4monthfactorimportance.raw','r');

% 读取数据，假设数据类型是单精度浮点数，1440*721*6
data = fread(fid, [720*360*4], 'float32');

% 关闭文件
fclose(fid);

% 将一维数组重塑为三维数组
data = reshape(data, [720, 360, 4]);

% 初始化一个二维矩阵用于存储每个像元的主导因子索引
dominant_factor = zeros(720, 360);

% 循环遍历每个像元
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11)&&data(i, j, 1)~=0
        % 对第三维度上的6个值进行判断，找出最大值及其索引
        temp=data(i, j, :);
        temp=reshape(temp,4,1);
        [~, max_idx] = max(data(i, j, :));
        % 存储主导因子（第三维度索引值）
        dominant_factor(i, j) = max_idx;
        end
    end
    i
end

% dominant_factor 矩阵现在包含每个像元的主导因子的索引（1-6）
% 打开一个文件以写入 .raw 数据，保存路径为 E 盘根目录，文件名为 'dominant_factor.raw'
fid = fopen('D:\dominant_factor4monthLAI.raw', 'w');

% 将矩阵数据转换为单精度浮点数，或者根据需要转换为其他类型
% 假设 dominant_factor 是整数类型，如果需要保存为 float32，请将类型修改为 'float32'
fwrite(fid, dominant_factor, 'float32');

% 关闭文件
fclose(fid);



% 打开 .raw 文件，假设文件名为 'data.raw'
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\LAI\LAIRFsemiannualfactorimportance.raw','r');
% 读取数据，假设数据类型是单精度浮点数，1440*721*6
data = fread(fid, [720*360*4], 'float32');

% 关闭文件
fclose(fid);

% 将一维数组重塑为三维数组
data = reshape(data, [720, 360, 4]);

% 初始化一个二维矩阵用于存储每个像元的主导因子索引
dominant_factor = zeros(720, 360);

% 循环遍历每个像元
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11)&&data(i, j, 1)~=0
        % 对第三维度上的6个值进行判断，找出最大值及其索引
        temp=data(i, j, :);
        temp=reshape(temp,4,1);
        [~, max_idx] = max(data(i, j, :));
        % 存储主导因子（第三维度索引值）
        dominant_factor(i, j) = max_idx;
        end
    end
    i
end

% dominant_factor 矩阵现在包含每个像元的主导因子的索引（1-6）
% 打开一个文件以写入 .raw 数据，保存路径为 E 盘根目录，文件名为 'dominant_factor.raw'
fid = fopen('D:\dominant_factorsemiannualLAI.raw', 'w');

% 将矩阵数据转换为单精度浮点数，或者根据需要转换为其他类型
% 假设 dominant_factor 是整数类型，如果需要保存为 float32，请将类型修改为 'float32'
fwrite(fid, dominant_factor, 'float32');

% 关闭文件
fclose(fid);


% 打开 .raw 文件，假设文件名为 'data.raw'
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\LAI\LAIRFannualfactorimportance.raw','r');
% 读取数据，假设数据类型是单精度浮点数，1440*721*6
data = fread(fid, [720*360*4], 'float32');

% 关闭文件
fclose(fid);

% 将一维数组重塑为三维数组
data = reshape(data, [720, 360, 4]);

% 初始化一个二维矩阵用于存储每个像元的主导因子索引
dominant_factor = zeros(720, 360);

% 循环遍历每个像元
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11)&&data(i, j, 1)~=0
        % 对第三维度上的6个值进行判断，找出最大值及其索引
        temp=data(i, j, :);
        temp=reshape(temp,4,1);
        [~, max_idx] = max(data(i, j, :));
        % 存储主导因子（第三维度索引值）
        dominant_factor(i, j) = max_idx;
        end
    end
    i
end

% dominant_factor 矩阵现在包含每个像元的主导因子的索引（1-6）
% 打开一个文件以写入 .raw 数据，保存路径为 E 盘根目录，文件名为 'dominant_factor.raw'
fid = fopen('D:\dominant_factorannualLAI.raw', 'w');

% 将矩阵数据转换为单精度浮点数，或者根据需要转换为其他类型
% 假设 dominant_factor 是整数类型，如果需要保存为 float32，请将类型修改为 'float32'
fwrite(fid, dominant_factor, 'float32');

% 关闭文件
fclose(fid);
% 打开 .raw 文件，假设文件名为 'data.raw'
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\LAI\LAIRFlongtermfactorimportance.raw','r');
% 读取数据，假设数据类型是单精度浮点数，1440*721*6
data = fread(fid, [720*360*5], 'float32');

% 关闭文件
fclose(fid);

% 将一维数组重塑为三维数组
data = reshape(data, [720, 360, 5]);

% 初始化一个二维矩阵用于存储每个像元的主导因子索引
dominant_factor = zeros(720, 360);

% 循环遍历每个像元
for i = 1:720
    for j = 1:360
        if (IGBP(i,j)==1||IGBP(i,j)==3||IGBP(i,j)==2||IGBP(i,j)==4||IGBP(i,j)==5||IGBP(i,j)==6||IGBP(i,j)==7||IGBP(i,j)==8||IGBP(i,j)==9||IGBP(i,j)==10||IGBP(i,j)==11)&&data(i, j, 1)~=0
        % 对第三维度上的6个值进行判断，找出最大值及其索引
        temp=data(i, j, :);
        temp=reshape(temp,5,1);
        [~, max_idx] = max(data(i, j, :));
        % 存储主导因子（第三维度索引值）
        dominant_factor(i, j) = max_idx;
        end
    end
    i
end

% dominant_factor 矩阵现在包含每个像元的主导因子的索引（1-6）
% 打开一个文件以写入 .raw 数据，保存路径为 E 盘根目录，文件名为 'dominant_factor.raw'
fid = fopen('D:\dominant_factorlongtermLAI.raw', 'w');

% 将矩阵数据转换为单精度浮点数，或者根据需要转换为其他类型
% 假设 dominant_factor 是整数类型，如果需要保存为 float32，请将类型修改为 'float32'
fwrite(fid, dominant_factor, 'float32');

% 关闭文件
fclose(fid);