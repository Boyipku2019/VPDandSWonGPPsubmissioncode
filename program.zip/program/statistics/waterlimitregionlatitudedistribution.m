%% ================== Water-limited pixels: Latitudinal distribution across 4 scales ==================
% Scales:
%   (1) Monthly raw (420)
%   (2) Annual SSA (420)
%   (3) Long-term CEEMDAN Trend (420)   <-- NO risk filter
%   (4) Long-term (risk): Long-term water-limited AND (mono-decrease OR UD turning)
%
% Latitudinal distribution plot (4 figures):
%   - x-axis: Share of global water-limited pixels (%) at each latitude band (area-weighted by cos(lat))
%   - y-axis: Latitude (deg)
%
% ENVI header reference (lat/lon, 0.5 deg):
%   samples=720 (lon), lines=360 (lat)
%   UL corner: lon=-180, lat=90
%   Pixel size: 0.5 deg
%
% Outputs:
%   Masks (raw):
%     D:\WaterLimited_Monthly.raw
%     D:\WaterLimited_Annual.raw
%     D:\WaterLimited_Longterm.raw
%     D:\WaterLimited_LongtermRisk.raw
%   Figures (png):
%     D:\LatDist_WaterLimited_Monthly.png
%     D:\LatDist_WaterLimited_Annual.png
%     D:\LatDist_WaterLimited_Longterm.png
%     D:\LatDist_WaterLimited_LongtermRisk.png
%
% Tested: MATLAB R2021a

clear; clc; close all; warning('off','all');
tAll = tic;
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');

%% ================== Paths ==================
% Masks
lulcPath = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath  = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

% Monthly raw
GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw";
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw";
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw";

% Annual SSA
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');

% Long-term Trend (CEEMDAN Trend)
GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');

% Risk masks
monoPath    = 'G:\Resource use efficiencies new\dataresult\CEEMDANstatistics\monoworld_monoGPP.raw';   % mono decrease: value==1
tippingPath = 'G:\Resource use efficiencies new\dataresult\CEEMDANstatistics\tippingworldGPP.raw';     % UD: value==4

%% ================== Assertions ==================
assert(isfile(lulcPath), 'LULC not found: %s', lulcPath);
assert(isfile(hfpPath),  'HFP not found: %s',  hfpPath);

assert(isfile(GPP_MO_path), 'Monthly GPP not found');
assert(isfile(T_MO_path) && isfile(P_MO_path) && isfile(R_MO_path) && isfile(SW_MO_path), 'Monthly met files missing');

assert(isfile(GPP_AN_path) && isfile(T_AN_path) && isfile(P_AN_path) && isfile(R_AN_path) && isfile(SW_AN_path), 'Annual SSA files missing');

assert(isfile(GPP_LT_path) && isfile(T_LT_path) && isfile(P_LT_path) && isfile(R_LT_path) && isfile(SW_LT_path), 'Long-term Trend files missing');

assert(isfile(monoPath),    'monoGPP file missing: %s', monoPath);
assert(isfile(tippingPath), 'tippingGPP file missing: %s', tippingPath);

%% ================== Parameters ==================
alpha = 0.05;
MinN  = 60;
qLow  = 0.25;

% 468 -> 25:444 = 420
Tlen   = 420;
rawLen = 468;
sFrom  = 25;
sTo    = 444;

%% ================== Read IGBP/HFP ==================
IGBP = imread(lulcPath); IGBP = IGBP';
HFP  = imread(hfpPath);  HFP  = HFP';
[nx, ny] = size(IGBP);
fprintf('Grid: %dx%d\n', nx, ny);

valid_base = (IGBP>=1 & IGBP<=11) & (HFP<=25);

%% ================== Latitude vector from ENVI map info ==================
lat = 90 - (0:(ny-1))*0.5;  % 90 ... -89.5
lat = lat(:);               % 360x1
wLat = cosd(lat);
wLat(wLat < 0) = 0;

%% ================== Read risk masks ==================
mono    = read_raw_2d(monoPath,   [nx,ny]);
tipping = read_raw_2d(tippingPath,[nx,ny]);
risk_mask = (mono==1) | (tipping==4);

%% ================== Read data blocks ==================
fprintf('Reading data blocks...\n');

% Monthly
GPP_MO = read_raw_3d(GPP_MO_path, [nx,ny,Tlen]);
T_MO   = read_raw_3d(T_MO_path,   [nx,ny,rawLen]); T_MO  = T_MO(:,:,sFrom:sTo);
P_MO   = read_raw_3d(P_MO_path,   [nx,ny,rawLen]); P_MO  = P_MO(:,:,sFrom:sTo);
R_MO   = read_raw_3d(R_MO_path,   [nx,ny,rawLen]); R_MO  = R_MO(:,:,sFrom:sTo);
SW_MO  = read_raw_3d(SW_MO_path,  [nx,ny,rawLen]); SW_MO = SW_MO(:,:,sFrom:sTo);

% Annual SSA
GPP_AN = read_raw_3d(GPP_AN_path, [nx,ny,Tlen]);
T_AN   = read_raw_3d(T_AN_path,   [nx,ny,rawLen]); T_AN  = T_AN(:,:,sFrom:sTo);
P_AN   = read_raw_3d(P_AN_path,   [nx,ny,rawLen]); P_AN  = P_AN(:,:,sFrom:sTo);
R_AN   = read_raw_3d(R_AN_path,   [nx,ny,rawLen]); R_AN  = R_AN(:,:,sFrom:sTo);
SW_AN  = read_raw_3d(SW_AN_path,  [nx,ny,rawLen]); SW_AN = SW_AN(:,:,sFrom:sTo);

% Long-term Trend
GPP_LT = read_raw_3d(GPP_LT_path, [nx,ny,Tlen]);
T_LT   = read_raw_3d(T_LT_path,   [nx,ny,rawLen]); T_LT  = T_LT(:,:,sFrom:sTo);
P_LT   = read_raw_3d(P_LT_path,   [nx,ny,rawLen]); P_LT  = P_LT(:,:,sFrom:sTo);
R_LT   = read_raw_3d(R_LT_path,   [nx,ny,rawLen]); R_LT  = R_LT(:,:,sFrom:sTo);
SW_LT  = read_raw_3d(SW_LT_path,  [nx,ny,rawLen]); SW_LT = SW_LT(:,:,sFrom:sTo);

fprintf('Data loaded. Start screening pixels...\n');

%% ================== Main screening ==================
mask_monthly = false(nx,ny);
mask_annual  = false(nx,ny);
mask_longterm= false(nx,ny);

tRow = tic;
for i = 1:nx
    for j = 1:ny
        if ~valid_base(i,j), continue; end

        if is_water_limited_pixel( ...
                squeeze(GPP_MO(i,j,:)), squeeze(SW_MO(i,j,:)), squeeze(P_MO(i,j,:)), squeeze(T_MO(i,j,:)), squeeze(R_MO(i,j,:)), ...
                MinN, alpha, qLow)
            mask_monthly(i,j) = true;
        end

        if is_water_limited_pixel( ...
                squeeze(GPP_AN(i,j,:)), squeeze(SW_AN(i,j,:)), squeeze(P_AN(i,j,:)), squeeze(T_AN(i,j,:)), squeeze(R_AN(i,j,:)), ...
                MinN, alpha, qLow)
            mask_annual(i,j) = true;
        end

        if is_water_limited_pixel( ...
                squeeze(GPP_LT(i,j,:)), squeeze(SW_LT(i,j,:)), squeeze(P_LT(i,j,:)), squeeze(T_LT(i,j,:)), squeeze(R_LT(i,j,:)), ...
                MinN, alpha, qLow)
            mask_longterm(i,j) = true;
        end
    end

    if mod(i,40)==0
        fprintf('  row %3d/%d | elapsed %.1fs\n', i, nx, toc(tRow));
        tRow = tic;
    end
end

mask_longterm_risk = mask_longterm & risk_mask & valid_base;

%% ================== Export masks to D:\ ==================
out_monthly = 'D:\WaterLimited_Monthly.raw';
out_annual  = 'D:\WaterLimited_Annual.raw';
out_longterm= 'D:\WaterLimited_Longterm.raw';
out_ltrisk  = 'D:\WaterLimited_LongtermRisk.raw';

fid = fopen(out_monthly,'w');  fwrite(fid, single(mask_monthly),        'single'); fclose(fid);
fid = fopen(out_annual ,'w');  fwrite(fid, single(mask_annual),         'single'); fclose(fid);
fid = fopen(out_longterm,'w'); fwrite(fid, single(mask_longterm),       'single'); fclose(fid);
fid = fopen(out_ltrisk,'w');   fwrite(fid, single(mask_longterm_risk),  'single'); fclose(fid);

fprintf('\n✅ Masks saved to D:\\\n  %s\n  %s\n  %s\n  %s\n', out_monthly, out_annual, out_longterm, out_ltrisk);

%% ================== Latitudinal distributions (area-weighted share %) ==================
shareMO = calc_lat_share(mask_monthly,       valid_base, wLat);
shareAN = calc_lat_share(mask_annual,        valid_base, wLat);
shareLT = calc_lat_share(mask_longterm,      valid_base, wLat);
shareLR = calc_lat_share(mask_longterm_risk, valid_base, wLat);

%% ================== Plot 4 separate figures (smaller width & half height; no xlabel; no scale text) ==================
purple = [0.65 0.00 0.70];

% 原先示例：figW=720, figH=340
% 现在：宽度=1/5，高度=1/2
figW = round(720/5);   % 144
figH = round(340/2);   % 170

plot_lat_dist_compact(lat, shareMO, purple, 'D:\LatDist_WaterLimited_Monthly.png',      figW, figH);
plot_lat_dist_compact(lat, shareAN, purple, 'D:\LatDist_WaterLimited_Annual.png',       figW, figH);
plot_lat_dist_compact(lat, shareLT, purple, 'D:\LatDist_WaterLimited_Longterm.png',     figW, figH);
plot_lat_dist_compact(lat, shareLR, purple, 'D:\LatDist_WaterLimited_LongtermRisk.png', figW, figH);

fprintf('\n✅ Done. Total time: %.1f minutes\n', toc(tAll)/60);

%% ================== Helper functions ==================
function ok = is_water_limited_pixel(y, sw, p, t, r, MinN, alpha, qLow)
ok = false;
y = y(:); sw = sw(:); p = p(:); t = t(:); r = r(:);

m = isfinite(y) & isfinite(sw) & isfinite(p) & isfinite(t) & isfinite(r) & (y>0);
if sum(m) <= MinN, return; end

y = y(m); sw = sw(m); p = p(m); t = t(m); r = r(m);

X = zscore([sw, p, t, r]);
if any(~isfinite(X(:))), return; end
yz = zscore(y);

try
    mdl = fitlm(X, yz, 'Intercept', true);
catch
    return;
end

b = mdl.Coefficients.Estimate;  % [intercept, sw, p, t, r]
if numel(b) < 5, return; end
beta_sw = b(2);
beta_p  = b(3);
if ~(beta_sw > 0 && beta_p > 0), return; end

% Low SW test
thr_sw = quantile(sw, qLow);
low = (sw <= thr_sw); high = ~low;
if sum(low) < 10 || sum(high) < 10, return; end
if mean(y(low),'omitnan') >= mean(y(high),'omitnan'), return; end
try
    [~, p_sw] = ttest2(y(low), y(high), 'Vartype','unequal');
catch
    p_sw = 1;
end
if ~(p_sw < alpha), return; end

% Low P test
thr_p = quantile(p, qLow);
low = (p <= thr_p); high = ~low;
if sum(low) < 10 || sum(high) < 10, return; end
if mean(y(low),'omitnan') >= mean(y(high),'omitnan'), return; end
try
    [~, p_pp] = ttest2(y(low), y(high), 'Vartype','unequal');
catch
    p_pp = 1;
end
if ~(p_pp < alpha), return; end

ok = true;
end

function share = calc_lat_share(maskWL, valid_base, wLat)
[nx, ny] = size(maskWL);
wlWeighted = zeros(ny,1);

for j = 1:ny
    m = valid_base(:,j);
    if ~any(m), wlWeighted(j) = 0; continue; end
    nWL = nnz(maskWL(:,j) & m);
    wlWeighted(j) = nWL * wLat(j);
end

tot = sum(wlWeighted);
if tot <= 0
    share = zeros(ny,1);
else
    share = 100 * wlWeighted / tot;
end
end

function plot_lat_dist_compact(lat, share, fillCol, outPng, figW, figH)
% Compact: same fonts, narrow width, half height, NO xlabel, NO scale text

figure('Color','w','Position',[60 80 figW figH]);
ax = axes; hold(ax,'on');

sharePlot = share;  % no smoothing

xx = [zeros(size(sharePlot)); flipud(sharePlot)];
yy = [lat; flipud(lat)];
patch('XData',xx,'YData',yy,'FaceColor',fillCol,'EdgeColor','none','FaceAlpha',0.95);

grid(ax,'on'); ax.GridAlpha = 0.20;
box(ax,'off');
set(ax,'TickDir','out','LineWidth',1.0,'FontSize',13);

ylim(ax, [-90 90]);
yticks(ax, -90:30:90);
ylabel(ax,'Latitude (°)','FontSize',14);

xlim(ax, [0, max(0.1, prctile(sharePlot(isfinite(sharePlot)), 99.5))*1.10]);
% xlabel(ax,'');  % ✅ 去掉 xlabel（不画）

exportgraphics(gcf, outPng, 'Resolution', 300);
fprintf('✅ Saved: %s\n', outPng);
end

function A = read_raw_3d(path, shape)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s',path);
A = fread(fid, prod(shape), 'single'); fclose(fid);
A = reshape(A, shape);
end

function A = read_raw_2d(path, shape2)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s',path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end
