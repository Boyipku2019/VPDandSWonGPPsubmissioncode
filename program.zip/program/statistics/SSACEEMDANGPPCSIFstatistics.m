%% =========================================================================
% 6×1 Nature-style figure
% GPP (1984–2018) + CSIF (2001–2020)
% Monthly / SSA-Annual / CEEMDAN-Long-term
% Add variance contribution (%) into subplot titles
% R2021a compatible
% -------------------------------------------------------------------------

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');

%% ================== Paths ==================
lulcPath = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath  = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw";
GPP_AN_path = "G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_SSA_Annual_4comp.raw";
GPP_LT_path = "G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_CEEMDAN_Trend_4comp.raw";

CSIF_MO_path = "G:\Resource use efficiencies new\dataprocessed\CSIF20012022_3D.raw";
CSIF_AN_path = "G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CSIF05_SSA_Annual_3comp.raw";
CSIF_LT_path = "G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CSIF05_CEEMDAN_Trend_3comp.raw";

outFig = 'D:\GPP_CSIF_6x1_with_variance_contribution.png';

nx = 720; 
ny = 360;

%% ================== Mask ==================
IGBP = imread(lulcPath)';   
HFP  = imread(hfpPath)';    
valid_mask = ismember(IGBP,1:11) & (HFP<=25);
valid_lin  = find(valid_mask(:));

%% ================== Read Mean Curves (RAW, for variance calculation) ==================
mu_gpp_mo_raw = mean_curve_only(GPP_MO_path, nx, ny, valid_lin);
mu_gpp_an_raw = mean_curve_only(GPP_AN_path, nx, ny, valid_lin);
mu_gpp_lt_raw = mean_curve_only(GPP_LT_path, nx, ny, valid_lin);

mu_csif_mo_raw = mean_curve_only(CSIF_MO_path, nx, ny, valid_lin);
mu_csif_an_raw = mean_curve_only(CSIF_AN_path, nx, ny, valid_lin);
mu_csif_lt_raw = mean_curve_only(CSIF_LT_path, nx, ny, valid_lin);

% Trim CSIF to 2001–2020 (240 months), keep all three scales consistent
mu_csif_mo_raw = mu_csif_mo_raw(1:240);
mu_csif_an_raw = mu_csif_an_raw(1:240);
mu_csif_lt_raw = mu_csif_lt_raw(1:240);

%% ================== Variance Contribution (%) ==================
% Monthly is baseline = 100%
gpp_var_mo = nanvar(mu_gpp_mo_raw, 1);
gpp_var_an = nanvar(mu_gpp_an_raw, 1);
gpp_var_lt = nanvar(mu_gpp_lt_raw, 1);

csif_var_mo = nanvar(mu_csif_mo_raw, 1);
csif_var_an = nanvar(mu_csif_an_raw, 1);
csif_var_lt = nanvar(mu_csif_lt_raw, 1);

gpp_contrib_mo = 100;
gpp_contrib_an = gpp_var_an / gpp_var_mo * 100;
gpp_contrib_lt = gpp_var_lt / gpp_var_mo * 100;

csif_contrib_mo = 100;
csif_contrib_an = csif_var_an / csif_var_mo * 100;
csif_contrib_lt = csif_var_lt / csif_var_mo * 100;

fprintf('\n================ Variance Contribution ================\n');
fprintf('GPP  Monthly  : %.2f%%\n', gpp_contrib_mo);
fprintf('GPP  Annual   : %.2f%%\n', gpp_contrib_an);
fprintf('GPP  Long-term: %.2f%%\n', gpp_contrib_lt);
fprintf('CSIF Monthly  : %.2f%%\n', csif_contrib_mo);
fprintf('CSIF Annual   : %.2f%%\n', csif_contrib_an);
fprintf('CSIF Long-term: %.2f%%\n', csif_contrib_lt);

%% ================== Normalize to 0–1 for plotting only ==================
mu_gpp_mo = normalize_01(mu_gpp_mo_raw);
mu_gpp_an = normalize_01(mu_gpp_an_raw);
mu_gpp_lt = normalize_01(mu_gpp_lt_raw);

mu_csif_mo = normalize_01(mu_csif_mo_raw);
mu_csif_an = normalize_01(mu_csif_an_raw);
mu_csif_lt = normalize_01(mu_csif_lt_raw);

%% ================== Time Axes ==================
x_gpp  = datetime(1984,1,15) + calmonths(0:419);
xx_gpp = datenum(x_gpp);

x_csif  = datetime(2001,1,15) + calmonths(0:239);
xx_csif = datenum(x_csif);

xt_gpp  = datenum(datetime(1984:5:2018,1,1));
xl_gpp  = string(1984:5:2018);

xt_csif = datenum(datetime(2001:4:2020,1,1));
xl_csif = string(2001:4:2020);

%% ================== Style ==================
colGPP  = [0.10 0.35 0.70];
colCSIF = [0.00 0.60 0.55];

LW    = 2.0;
FS    = 12;
AXLW  = 1.0;
ptSize = 10;

%% ================== Figure ==================
fig = figure('Color','w');
set(fig,'Position',[200,40,1000,850]);

tiledlayout(6,1,'Padding','compact','TileSpacing','compact');
axs = gobjects(6,1);

%% ---------------- Titles with variance contribution ----------------
titlesGPP = { ...
    sprintf('GPP | Monthly (Var = %.1f%%)', gpp_contrib_mo), ...
    sprintf('GPP | Annual (Var = %.1f%%)',  gpp_contrib_an), ...
    sprintf('GPP | Long-term (Var = %.1f%%)', gpp_contrib_lt)};

titlesCSIF = { ...
    sprintf('CSIF | Monthly (Var = %.1f%%)', csif_contrib_mo), ...
    sprintf('CSIF | Annual (Var = %.1f%%)',  csif_contrib_an), ...
    sprintf('CSIF | Long-term (Var = %.1f%%)', csif_contrib_lt)};

dataGPP  = {mu_gpp_mo, mu_gpp_an, mu_gpp_lt};
dataCSIF = {mu_csif_mo, mu_csif_an, mu_csif_lt};

%% ---------------- GPP ----------------
for i = 1:3
    axs(i) = nexttile(i);
    plot(xx_gpp, dataGPP{i}, '-', 'Color', colGPP, 'LineWidth', LW); 
    hold on;
    scatter(xx_gpp, dataGPP{i}, ptSize, ...
        'MarkerFaceColor','none', ...
        'MarkerEdgeColor',colGPP, ...
        'LineWidth',0.6);
    title(titlesGPP{i}, 'FontWeight','bold');
    xlim([xx_gpp(1) xx_gpp(end)]);
    format_axis(axs(i), xt_gpp, xl_gpp, FS, AXLW);
    if i < 3
        axs(i).XTickLabel = [];
    end
end

%% ---------------- CSIF ----------------
for i = 1:3
    axs(i+3) = nexttile(i+3);
    plot(xx_csif, dataCSIF{i}, '-', 'Color', colCSIF, 'LineWidth', LW); 
    hold on;
    scatter(xx_csif, dataCSIF{i}, ptSize, ...
        'MarkerFaceColor','none', ...
        'MarkerEdgeColor',colCSIF, ...
        'LineWidth',0.6);
    title(titlesCSIF{i}, 'FontWeight','bold');
    xlim([xx_csif(1) xx_csif(end)]);
    format_axis(axs(i+3), xt_csif, xl_csif, FS, AXLW);
    if i < 3
        axs(i+3).XTickLabel = [];
    end
end

xlabel(axs(6), 'Year');

%% ================== Shared Y Label (R2021a safe) ==================
axes('Position',[0 0 1 1], 'Visible','off');
text(0.02,0.5,'Normalized GPP/CSIF', ...
    'Units','normalized', ...
    'Rotation',90, ...
    'HorizontalAlignment','center', ...
    'VerticalAlignment','middle', ...
    'FontSize',FS+1, ...
    'FontWeight','bold');

%% ================== Export ==================
exportgraphics(fig, outFig, 'Resolution',300);
fprintf('\nFigure saved: %s\n', outFig);

%% =========================================================================
%% ============================ Functions ============================

function nt = detect_nt(path, nx, ny)
    d = dir(path);
    nt = d.bytes / 4 / (nx * ny);
end

function mu = mean_curve_only(path, nx, ny, valid_lin)
    nt = detect_nt(path, nx, ny);
    stride = nx * ny;
    mmap = memmapfile(path, 'Format', {'single',[stride*nt 1],'x'});
    mu = nan(nt,1);
    for t = 1:nt
        idx = valid_lin + (t-1) * stride;
        v = double(mmap.Data.x(idx));
        v = v(isfinite(v));
        if ~isempty(v)
            mu(t) = mean(v);
        end
    end
end

function y = normalize_01(y)
    good = isfinite(y);
    mn = min(y(good));
    mx = max(y(good));
    if mx > mn
        y = (y - mn) ./ (mx - mn);
    else
        y(:) = 0;
    end
end

function format_axis(ax, xt, xl, FS, AXLW)
    ax.FontSize = FS;
    ax.LineWidth = AXLW;
    ax.TickDir = 'out';
    ax.YLim = [0 1];
    ax.YTick = 0:0.5:1;
    ax.XTick = xt;
    ax.XTickLabel = xl;
    grid(ax,'on');
    ax.GridAlpha = 0.08;
    box(ax,'off');
end