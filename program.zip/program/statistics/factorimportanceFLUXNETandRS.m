%% ================== run_RS_FLUXNET_combined_no4m_with_titles.m ==================
% 合并 RS 与 FLUXNET 的因子贡献，横向分组条形图
% 变更：
%  1) 移除“4 months”尺度（不显示、不参与统计）
%  2) 子图标题显示“植被缩写 + 全称”；不显示整图标题
%  3) “All biomes” -> “Average”
%  4) HH/DD/MM 标签替换为 “Half-hourly / Daily / Monthly”
%  兼容：MATLAB R2021a

clear; close all; clc; warning('off','all');
set(0,'DefaultAxesFontName','Arial'); set(0,'DefaultTextFontName','Arial');

%% ---------- 常量 ----------
vegNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'};  % 改名
% ⭐ 新增：对应全称（与 vegNames 一一对应）
vegFullNames = { ...
    'Evergreen Needleleaf Forest', ...
    'Evergreen Broadleaf Forest',  ...
    'Deciduous Needleleaf Forest', ...
    'Deciduous Broadleaf Forest',  ...
    'Mixed Forest',                ...
    'Shrubland',                   ...
    'Savanna',                     ...
    'Grassland',                   ...
    'Wetlands',                    ...
    'Average'};

% —— 去掉 4 months —— 仅保留 RS 三个行名：
rs_scales   = {'Semiannual','Annual','Long-term'};         % 3 行（不含 4 months）
flux_scales = {'Half-hourly','Daily','Monthly'};           % 3 行（替换 HH/DD/MM）
all_scales  = [flux_scales, rs_scales];                    % 顺序：Half-hourly/Daily/Monthly/Semi/Annual/Long
maxF = 5;                                                  % 最多5个因子（长期含CO2）

% 颜色（与原程序一致）
C = [ ...
    249,118,110;  % Temperature
     60,168,197;  % Precipitation
    250,174, 90;  % Radiation
    161,213,112;  % Soil Moisture
    160,160,160]; % CO2（仅长期）
colors = C/255;
legend_labels = {'Temperature','Precipitation','Radiation','Soil Moisture','CO_2'};

%% ---------- 路径（与原始保持一致） ----------
HFP  = imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');  HFP=HFP';
IGBP = imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif'); IGBP=IGBP';

% RS：R² 栅格
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFglobal4monthR2.raw','r'); R2_4m  = fread(fid,[720*360],'single'); fclose(fid); R2_4m  = reshape(R2_4m,[720,360]);  %#ok<NASGU>
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFsemiannualR2.raw','r');   R2_sa  = fread(fid,[720*360],'single'); fclose(fid); R2_sa  = reshape(R2_sa,[720,360]);
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFannualR2.raw','r');       R2_an  = fread(fid,[720*360],'single'); fclose(fid); R2_an  = reshape(R2_an,[720,360]);
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFlongtermR2.raw','r');     R2_lt  = fread(fid,[720*360],'single'); fclose(fid); R2_lt  = reshape(R2_lt,[720,360]);

% RS：因子重要性立方体（长期=5因子；“4 months”会读但不使用）
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRF4monthfactorimportance.raw','r');   rs_4m = fread(fid,[720*360*4],'single'); fclose(fid); rs_4m = reshape(rs_4m,[720,360,4]); %#ok<NASGU>
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFsemiannualfactorimportance.raw','r');rs_sa = fread(fid,[720*360*4],'single'); fclose(fid); rs_sa = reshape(rs_sa,[720,360,4]);
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFannualfactorimportance.raw','r');    rs_an = fread(fid,[720*360*4],'single'); fclose(fid); rs_an = reshape(rs_an,[720,360,4]);
fid = fopen('G:\Resource use efficiencies new\dataresult\machinelearning\GPP\GPPRFlongtermfactorimportance.raw','r');  rs_lt = fread(fid,[720*360*5],'single'); fclose(fid); rs_lt = reshape(rs_lt,[720,360,5]);

%% ---------- Ⅰ. RS端：按像元筛选→按植被类型聚合（均值/标准差） ----------
% 移除 4 months：仅检查 Semiannual / Annual / Long-term
NsampCap = inf;
R2thr = 0.30;
maxRows_RS = 3;   % 仅 3 行（Semiannual, Annual, Long-term）
cellRS = cell(1, numel(vegNames)); cntRS = zeros(1,numel(vegNames));

totalRS = 720*360; doneRS = 0; lastPctRS = -1; 
fprintf('RS 像元筛选与聚合开始（不包含 4 months），总像元=%d ...\n', totalRS);

for i = 1:720
    for j = 1:360
        % —— 进度打印（每 +1% 打印）——
        doneRS = doneRS + 1;
        pct = floor(doneRS/totalRS*100);
        if pct > lastPctRS
            fprintf('[RS] %3d%%  (%d / %d)\n', pct, doneRS, totalRS);
            lastPctRS = pct;
        end

        if ~(IGBP(i,j)>=1 && IGBP(i,j)<=11), continue; end
        if ~(HFP(i,j)<=25), continue; end

        % 只检查三尺度（不含4m）
        s_sa = sum(rs_sa(i,j,:)); ok_sa = (R2_sa(i,j)>R2thr && s_sa~=0);
        s_an = sum(rs_an(i,j,:)); ok_an = (R2_an(i,j)>R2thr && s_an~=0);
        s_lt = sum(rs_lt(i,j,:)); ok_lt = (R2_lt(i,j)>R2thr && s_lt~=0);
        if ~(ok_sa && ok_an && ok_lt), continue; end

        % 归一化→拼成 maxF×3（列= Semiannual / Annual / Long-term）
        M = nan(maxF, maxRows_RS, 'single');
        M(1:4,1) = reshape(rs_sa(i,j,:), [4,1]) / s_sa;  % Semiannual
        M(1:4,2) = reshape(rs_an(i,j,:), [4,1]) / s_an;  % Annual
        tmp = reshape(rs_lt(i,j,:), [5,1]) / s_lt;       % Long-term（含CO2）
        M(1:5,3) = tmp;

        % Average
        cellRS{10}{end+1} = M; cntRS(10)=cntRS(10)+1;

        % 指定植被类型
        gid = IGBP(i,j);
        switch gid
            case 1, vi=1;  % ENF
            case 2, vi=2;  % EBF
            case 3, vi=3;  % DNF
            case 4, vi=4;  % DBF
            case 5, vi=5;  % MF
            case {6,7}, vi=6; % SHL
            case {8,9}, vi=7; % SVA
            case 10, vi=8; % GRA
            case 11, vi=9; % WET
            otherwise, vi=[];
        end
        if ~isempty(vi)
            if cntRS(vi) < NsampCap
                cellRS{vi}{end+1} = M; cntRS(vi)=cntRS(vi)+1;
            end
        end
    end
end
fprintf("RS 像元聚合完成：各类样本数 = %s\n", mat2str(cntRS));

% RS 各类均值/标准差： meanRS{vi} = 3×5（行=Semi/Annual/Long；列=因子）
meanRS = cell(1,numel(vegNames)); stdRS = cell(1,numel(vegNames));
for vi=1:numel(vegNames)
    if isempty(cellRS{vi})
        meanRS{vi} = nan(maxRows_RS, maxF); stdRS{vi} = nan(maxRows_RS, maxF);
        continue;
    end
    stk = cat(3, cellRS{vi}{:});      % [5 x 3 x N]
    m  = mean(stk, 3, 'omitnan');     % [5 x 3]
    s  =  std(stk, 0, 3, 'omitnan');  % [5 x 3]
    meanRS{vi} = m.';                 % → [3 x 5]
    stdRS{vi}  = s.';                 % → [3 x 5]
end

%% ---------- Ⅱ. FLUXNET 端（R²>0.30；标签改为 Half-hourly/Daily/Monthly） ----------
rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir    = fullfile(rootFolder, 'dataafteruncompression');
siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');
assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);

% 站点-植被映射
site2veg = containers.Map('KeyType','char','ValueType','char');
hasVegMap = false;
if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);
        names = string(Tsite{:,1}); vegs = string(Tsite{:,8});
        for i=1:numel(names), site2veg(char(strtrim(names(i))))=char(strtrim(vegs(i))); end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx，后续无法按植被类型聚合。\n');
    end
end

yName   = 'GPP_DT_VUT_REF';
coreX   = {'TA_F_MDS','P_F','SW_IN_F_MDS'};
allCSV  = dir(fullfile(dataDir,'*.csv'));
files = [];
for i = 1:numel(allCSV)
    nm = allCSV(i).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        files = [files; allCSV(i)]; %#ok<AGROW>
    end
end
if isempty(files), error('未找到 文件名包含 FULLSET 的 HH/DD/MM 文件。'); end

rows = {};
fprintf('FLUXNET 站点建模开始，总文件=%d ...\n', numel(files));
for k=1:numel(files)
    f = fullfile(files(k).folder, files(k).name);
    msg = '';
    try
        opts = detectImportOptions(f);
        varNames = opts.VariableNames;
        needFixed = [ {yName}, coreX ];
        if ~all(ismember(needFixed, varNames))
            msg = '缺少必需列，跳过';
            fprintf('[FX] %4d/%4d  %-60s  %s\n', k, numel(files), files(k).name, msg);
            continue;
        end
        swcMask = ~cellfun('isempty', regexp(varNames,'^SWC_F_MDS_\d+$','once'));
        swcCols = varNames(swcMask);
        if isempty(swcCols)
            msg = '无SWC层，跳过';
            fprintf('[FX] %4d/%4d  %-60s  %s\n', k, numel(files), files(k).name, msg);
            continue;
        end

        opts.SelectedVariableNames = [needFixed, swcCols];
        T = readtable(f, opts);
        T = sentinel2nan(T, opts.SelectedVariableNames);
        SWCmat = T{:, swcCols}; if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
        SWC_avg = mean(SWCmat,2,'omitnan');

        yv = T.(yName); ta=T.TA_F_MDS; pp=T.P_F; sw=T.SW_IN_F_MDS;
        mask = ~isnan(yv) & (yv>0) & ~isnan(ta) & ~isnan(pp) & ~isnan(sw) & ~isnan(SWC_avg);
        Tm = T(mask,:); SWC_avg = SWC_avg(mask);
        nobs = height(Tm);
        if nobs<=40
            msg = sprintf('有效样本过少(n=%d)，跳过', nobs);
            fprintf('[FX] %4d/%4d  %-60s  %s\n', k, numel(files), files(k).name, msg);
            continue;
        end

        X = [Tm.TA_F_MDS, Tm.P_F, Tm.SW_IN_F_MDS, SWC_avg];
        Y = Tm.(yName);

        rng(2025 + k);
        cv = cvpartition(size(X,1),'Holdout',0.2);
        Xtr = X(training(cv),:); Ytr=Y(training(cv));
        Xte = X(test(cv),:);    Yte=Y(test(cv));

        [Xtr_n, ps] = mapminmax(Xtr'); Xtr_n=Xtr_n'; Xte_n = mapminmax('apply', Xte', ps)';

        numTrees=300; mtry=2; leafMin=5;
        Mdl = TreeBagger(numTrees, Xtr_n, Ytr,'Method','regression', ...
            'OOBPrediction','On','MinLeafSize',leafMin,'NumPredictorsToSample',mtry);

        y_pred = predict(Mdl, Xte_n);
        SST = sum((Yte-mean(Yte)).^2); SSE = sum((Yte-y_pred).^2);
        R2_val = (SST>0) * (1 - SSE/SST);
        rmse_val = sqrt(mean((Yte - y_pred).^2));

        % 置换重要性（验证集）
        p = size(Xte_n,2); mse0 = mean((Yte - y_pred).^2);
        w = zeros(1,p);
        for j=1:p
            Xperm = Xte_n; Xperm(:,j)=Xperm(randperm(size(Xperm,1)),j);
            y_perm = predict(Mdl, Xperm);
            w(j) = mean((Yte - y_perm).^2) - mse0;
        end
        w = max(w,0); s = sum(w); pct = (s>0) * (100*w/s);

        sitename = parse_site_from_filename(files(k).name);
        veg=''; if hasVegMap && isKey(site2veg, sitename), veg=site2veg(sitename); end
        scale = detect_scale_from_filename(files(k).name);  % 先得到 HH/DD/MM
        % —— 输出消息 —— 
        msg = sprintf('OK  R2=%.3f  n=%d  pct=[%.1f %.1f %.1f %.1f]', R2_val, nobs, pct);
        % —— 保存行（先用原尺度，后面统一映射行名为 Half-hourly/Daily/Monthly）——
        rows(end+1,:) = {files(k).name, sitename, veg, scale, nobs, rmse_val, R2_val, pct(1), pct(2), pct(3), pct(4)}; %#ok<SAGROW>
    catch ME
        msg = ['失败: ' ME.message];
    end
    fprintf('[FX] %4d/%4d  %-60s  %s\n', k, numel(files), files(k).name, msg);
end
if isempty(rows), error('没有可用的 FLUXNET 站点结果。'); end
Tsite_all = cell2table(rows,'VariableNames',{'file','site','vegtype','scale','n_obs','rmse_val','R2_val','pct_TA','pct_P','pct_SWIN','pct_SWC'});
R2min = 0.30;
Tsite = Tsite_all(Tsite_all.R2_val > R2min, :);
fprintf('FLUXNET 有效模型数（R2>%.2f）：%d / %d\n', R2min, height(Tsite), height(Tsite_all));

% 将尺度缩写映射为目标标签（Half-hourly / Daily / Monthly）
Tsite.scale = regexprep(Tsite.scale, '^HH$','Half-hourly');
Tsite.scale = regexprep(Tsite.scale, '^DD$','Daily');
Tsite.scale = regexprep(Tsite.scale, '^MM$','Monthly');

% 按植被类型×尺度聚合（均值/标准差），得到 meanFL{vi}=3×4（行=Half-hourly/Daily/Monthly；列=4因子）
scalesFL = flux_scales;   % 目标显示标签
meanFL = cell(1,numel(vegNames)); stdFL = cell(1,numel(vegNames)); nFL = cell(1,numel(vegNames));
for vi=1:numel(vegNames)
    vname = vegNames{vi};
    if strcmp(vname,'Average')
        Td = Tsite;
    else
        Td = Tsite(strcmp(Tsite.vegtype, vname), :);
    end
    M = nan(numel(scalesFL),4); S = nan(numel(scalesFL),4); N = zeros(numel(scalesFL),1);
    for si=1:numel(scalesFL)
        Ts = Td(strcmp(Td.scale, scalesFL{si}), :);
        if isempty(Ts), continue; end
        X = [Ts.pct_TA, Ts.pct_P, Ts.pct_SWIN, Ts.pct_SWC];
        M(si,:) = mean(X,1,'omitnan');
        S(si,:) =  std(X,0,1,'omitnan');
        N(si)   = height(Ts);
    end
    meanFL{vi} = M; stdFL{vi} = S; nFL{vi}=N;
end

%% ---------- Ⅲ. 合并：行=Half-hourly/Daily/Monthly/Semiannual/Annual/Long-term，列=最多5因子 ----------
combMean = cell(1,numel(vegNames)); combStd = cell(1,numel(vegNames)); combMask = cell(1,numel(vegNames));
for vi=1:numel(vegNames)
    M = nan(numel(all_scales), maxF);
    S = nan(numel(all_scales), maxF);

    % FLUXNET: 前 3 行（按 Half-hourly/Daily/Monthly），列1-4
    if ~isempty(meanFL{vi})
        M(1:3,1:4) = meanFL{vi} / 100;      % → 0~1
        S(1:3,1:4) = stdFL{vi}  / 100;
    end

    % RS: 后 3 行（Semiannual/Annual/Long-term）
    if ~isempty(meanRS{vi})
        M(4:6, :) = meanRS{vi};             % 已是 0~1
        S(4:6, :) = stdRS{vi};
    end

    rowValid = any(~isnan(M), 2);
    combMean{vi} = M;
    combStd{vi}  = S;
    combMask{vi} = rowValid;
end

%% ---------- Ⅳ. 作图（子图标题 = 缩写 + 全称；无整图标题） ----------
figure('Color','w','Position',[60 60 1500 820]);
tiledlayout(2,5,'Padding','compact','TileSpacing','compact');

for vi=1:numel(vegNames)
    nexttile; hold on;
    M = combMean{vi}; S = combStd{vi}; rowValid = combMask{vi};
    M = M(rowValid,:); S = S(rowValid,:);
    ylabels = all_scales(rowValid);

    if isempty(M)
        axis off;
        continue;
    end

    [ngroups, nbars] = size(M);
    b = barh(M, 'grouped'); 
    for k=1:numel(b)
        b(k).EdgeColor = 'none';
        if k<=size(colors,1)
            b(k).FaceColor = colors(k,:);
        else
            b(k).FaceColor = [0.8 0.8 0.8];
        end
    end

    % 误差线（右侧半边）
    groupwidth = min(0.8, nbars/(nbars + 1.5));
    errlw = 0.8;
    for k=1:nbars
        y = (1:ngroups) - groupwidth/2 + (2*k-1) * groupwidth / (2*nbars);
        x  = M(:,k);
        xe = S(:,k);
        mask = ~isnan(x) & ~isnan(xe);
        for m = find(mask)'
            x_start = x(m); x_end = x(m) + xe(m);
            line([x_start x_end],[y(m) y(m)],'Color','k','LineWidth',errlw);
            cap = 0.10;
            line([x_end x_end],[y(m)-cap y(m)+cap],'Color','k','LineWidth',errlw);
        end
    end

    set(gca,'YTick',1:ngroups,'YTickLabel',ylabels,'FontName','Arial','FontSize',12);
    xlim([0 1]); xticks(0:0.2:1);
    xticklabels( arrayfun(@(x) sprintf('%.0f%%', x*100), xticks, 'UniformOutput', false) );
    box on; grid on;

    % ⭐ 子图标题：植被缩写 + 全称（其余不改）
    title(sprintf('%s', vegNames{vi}), 'FontWeight','bold','FontSize',12);

    % 下排加 x 轴标签（如需隐藏可注释）
    if vi<=5, xlabel(''); else, xlabel('Percentage'); end
end

% 统一图例（底部）
legend(legend_labels, 'Location','southoutside','Orientation','horizontal','Box','off');

% 不设置整图标题
saveas(gcf,'RS_FLUXNET_combined_no4m_titles_fullnames.png');
fprintf('✅ 成图保存：%s\n', fullfile(pwd,'RS_FLUXNET_combined_no4m_titles_fullnames.png'));

%% ================= 工具函数 =================
function T = sentinel2nan(T, names)
    for i = 1:numel(names)
        vname = names{i};
        if ~ismember(vname, T.Properties.VariableNames), continue; end
        v = T.(vname);
        if ~isnumeric(v), v = double(str2double(string(v))); end
        v(v<=-9990 | v>=9.9e8) = NaN;   % -9999 与超大异常值
        T.(vname) = v;
    end
end

function site = parse_site_from_filename(fname)
    site = '';
    try
        s = string(fname);
        a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
        if ~isempty(a) && ~isempty(b) && b>a
            site = char(extractBetween(s,a+4,b-1));
        else
            tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
            if ~isempty(tok), site = tok{1}; else, site = fname; end
        end
    catch
        site = fname;
    end
end

function scale = detect_scale_from_filename(fname)
    if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
        scale = 'HH';
    elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
        scale = 'DD';
    elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
        scale = 'MM';
    else
        scale = 'OTHER';
    end
end
