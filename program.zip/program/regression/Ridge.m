% %% =========================================================================================
% % 6 scales (Fluxnet HH/DD/MM + RS Monthly/Annual/Long-term)
% % Ridge (NO interactions) + FIG1 (coef mean±SEM; CV-R2>0.3) + FIG2 (CV-R2 hist)
% % FIG3 unchanged: RS Long-term only partial-residual quantile curves (2×2)
% %
% % FLUXNET reading & WL classification EXACTLY follows your WL-screening program:
% %   - scan FULLSET HH/DD/MM CSV in dataafteruncompression
% %   - variables: GPP_DT_VUT_REF, TA_F_MDS, P_F, SW_IN_F_MDS, VPD_F, SWC_F_MDS_*
% %   - SW = mean(SWC_*) across layers
% %   - WL classification: one-sided Welch t-test + partialcorr_fast + one-sided p
% %
% % (UPDATED ONLY FIG4 in your original description; here we KEEP your current FIG4 FULL-period)
% % + (NEW FIG5): dominance bars like the attached figure:
% %   - SW dominance in SW-limited (RS Monthly/Annual/Long-term) from FIG1 row1 right 3 panels
% %   - VPD dominance in VPD-limited (RS Monthly/Annual/Long-term) from FIG1 row2 right 3 panels
% %   - Dominance = |beta_target| / sum(|beta_all|)
% %
% % Tested: MATLAB R2021a
% % -----------------------------------------------------------------------------------------
% 
% clear; clc; close all; warning('off','all');
% set(groot,'DefaultAxesFontName','Arial');
% set(groot,'DefaultTextFontName','Arial');
% rng(2025);
% 
% tAll = tic;
% 
% %% ===================== Ridge settings =====================
% Kfold_outer = 5;
% minN_ridge_flux = struct('HH',40,'DD',40,'MM',40);  % keep same as your WL minN_total_map
% minN_ridge_rs   = 40;
% R2_keep_for_coef = 0;
% ridgeLambda = 0.05;
% 
% %% ===================== WL screening settings (same as your program) =====================
% alpha = 0.05;
% qLow  = 25;
% qHigh = 75;
% 
% % RS Monthly GS filter
% useMonthlyGS = true;
% gsFracP90_RS = 0.2;
% 
% % Optional GS filter for FLUXNET MM (keep same default OFF)
% useGS_for_MM_flux = false;
% gsFracP90_flux = 0.2;
% 
% %% ===================== RS Paths (same as your program) =====================
% rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
% lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
% hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';
% 
% GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw"; % 720x360x420
% T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";  % 468
% P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";   % 468
% R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw"; % 468
% SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw"; % 468
% VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468
% 
% GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
% T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
% P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
% R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
% SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
% VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');
% 
% GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
% T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
% P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
% R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
% SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
% VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
% CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 492
% 
% % WL maps already computed by your WL program (we directly read them)
% WL_MO_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw';
% WL_AN_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_Annual_q25_ttest_pcor_f32_720x360.raw';
% WL_LT_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeuntil2018\WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw';
% 
% %% ===================== FLUXNET Paths (exactly your program) =====================
% rootFolder_FLUX = 'G:\GlobalData\FLUXNET2015Tier2Data';
% dataDir_FLUX    = fullfile(rootFolder_FLUX, 'dataafteruncompression');
% siteXlsx        = fullfile(rootFolder_FLUX, 'FLUXsitelistnew.xlsx'); % optional lat/lon
% assert(isfolder(dataDir_FLUX), 'FLUXNET 数据目录不存在：%s', dataDir_FLUX);
% 
% %% ===================== Outputs =====================
% outDir = 'D:\';
% if ~exist(outDir,'dir'), mkdir(outDir); end
% 
% outFig1 = fullfile(outDir, sprintf('FIG1_RIDGE_noInter_6scales_CVR2gt%.1f_lambda%.3f.png', R2_keep_for_coef, ridgeLambda));
% outFig2 = fullfile(outDir, sprintf('FIG2_RIDGE_noInter_6scales_CVR2_hist_lambda%.3f.png', ridgeLambda));
% outFig3 = fullfile(outDir, sprintf('FIG3_LongTerm_partialResidual_quantileCurves_CVR2gt%.1f_lambda%.3f_2x2byWL.png', R2_keep_for_coef, ridgeLambda));
% outFig4 = fullfile(outDir, sprintf('FIG4_LongTerm_conditionalSlopes_FULL_1984_2018_lambda%.3f.png', ridgeLambda));
% outFig5 = fullfile(outDir, sprintf('FIG5_Dominance_SW_in_SWlimited__VPD_in_VPDlimited_RS_3scales_lambda%.3f.png', ridgeLambda));
% 
% %% ===================== Basic RS dims =====================
% nx = 720; ny = 360;
% 
% %% ===================== Check RS files =====================
% mustFiles_RS = {lulcPath,hfpPath,...
%     GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path,...
%     GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path,...
%     GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path,CO2_LT_path,...
%     WL_MO_path, WL_AN_path, WL_LT_path};
% 
% for k=1:numel(mustFiles_RS)
%     assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
% end
% 
% %% ===================== RS mask =====================
% IGBP = imread(lulcPath)'; 
% HFP  = imread(hfpPath)';
% 
% assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
% valid_mask = ismember(IGBP,1:10) & (HFP<=25);
% nValid_RS = nnz(valid_mask);
% fprintf('RS valid pixels (veg & HFP<=25): %d\n', nValid_RS);
% 
% %% ===================== Read RS WL maps =====================
% WL_MO = read_raw_2d_single(WL_MO_path,[nx ny]);
% WL_AN = read_raw_2d_single(WL_AN_path,[nx ny]);
% WL_LT = read_raw_2d_single(WL_LT_path,[nx ny]);
% 
% WL_MO(~ismember(WL_MO,[0 1 2 3 4])) = 0;
% WL_AN(~ismember(WL_AN,[0 1 2 3 4])) = 0;
% WL_LT(~ismember(WL_LT,[0 1 2 3 4])) = 0;
% 
% %% ===================== Read RS data blocks (auto-detect 420 vs 468) =====================
% fprintf('Reading RS data blocks...\n');
% Tlen   = 420;
% rawLen = 468;
% sFrom  = 25;
% sTo    = 444;
% 
% % Monthly
% GPP_MO = read_raw_3d_auto(GPP_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
% T_MO   = read_raw_3d_auto(T_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% P_MO   = read_raw_3d_auto(P_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% R_MO   = read_raw_3d_auto(R_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% SW_MO  = read_raw_3d_auto(SW_MO_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
% VPD_MO = read_raw_3d_auto(VPD_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
% 
% % Annual
% GPP_AN = read_raw_3d_auto(GPP_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
% T_AN   = read_raw_3d_auto(T_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% P_AN   = read_raw_3d_auto(P_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% R_AN   = read_raw_3d_auto(R_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% SW_AN  = read_raw_3d_auto(SW_AN_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
% VPD_AN = read_raw_3d_auto(VPD_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
% 
% % Long-term
% GPP_LT = read_raw_3d_auto(GPP_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
% T_LT   = read_raw_3d_auto(T_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% P_LT   = read_raw_3d_auto(P_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% R_LT   = read_raw_3d_auto(R_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
% SW_LT  = read_raw_3d_auto(SW_LT_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
% VPD_LT = read_raw_3d_auto(VPD_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
% 
% % CO2 (492 -> 420)
% CO2_LT = read_raw_3d_fixed492_slice420(CO2_LT_path, nx, ny, 492, 25, 444);
% 
% fprintf('RS data loaded.\n');
% 
% %% =========================================================================================
% %% ===================== Containers for 6×4 =====================
% % rows: 1 HH(F), 2 DD(F), 3 MM(F), 4 MO(RS), 5 AN(RS), 6 LT(RS)
% coefCell = cell(6,4);   % store beta only if CV-R2 > R2_keep_for_coef
% r2Cell   = cell(6,4);   % store all CV-R2
% 
% scaleNames = {'Half-hourly (Fluxnet)','Daily (Fluxnet)','Monthly (Fluxnet)', ...
%               'Monthly (RS)','Annual (RS)','Long-term (RS)'};
% classNames = {'SW-limited','VPD-limited','Co-limited','Average'};
% 
% termNames_noCO2 = {'SW','VPD','T','P','R'};
% termNames_CO2   = {'SW','VPD','T','P','R','CO2'};
% 
% %% =========================================================================================
% %% ===================== PART 1: FLUXNET read + WL class + ridge ============================
% fprintf('\n================== FLUXNET | read CSV + WL class + ridge ==================\n');
% 
% % FLUX variable names (exactly your WL program)
% yName = 'GPP_DT_VUT_REF';
% vT    = 'TA_F_MDS';
% vP    = 'P_F';
% vR    = 'SW_IN_F_MDS';
% vVPD  = 'VPD_F';
% swcRegex = '^SWC_F_MDS_\d+$';
% 
% scaleList = {'HH','DD','MM'};
% minN_total_map = containers.Map(scaleList, [300, 100, 40]);
% minN_group_map = containers.Map(scaleList, [50,  20,  10]);
% 
% % optional site lat/lon map (same as your WL program)
% site2lat = containers.Map('KeyType','char','ValueType','double');
% site2lon = containers.Map('KeyType','char','ValueType','double');
% 
% if exist(siteXlsx,'file')
%     try
%         Ts = readtable(siteXlsx);
%         vns = lower(string(Ts.Properties.VariableNames));
%         siteCol = 1;
%         latCol = find(contains(vns,'lat'), 1);
%         lonCol = find(contains(vns,'lon'), 1);
%         if ~isempty(latCol) && ~isempty(lonCol)
%             names = string(Ts{:,siteCol});
%             lats  = Ts{:,latCol};
%             lons  = Ts{:,lonCol};
%             for i = 1:numel(names)
%                 kk = char(strtrim(names(i)));
%                 if isempty(kk), continue; end
%                 latv = double(lats(i));
%                 lonv = double(lons(i));
%                 if isfinite(latv) && isfinite(lonv)
%                     site2lat(kk) = latv;
%                     site2lon(kk) = lonv;
%                 end
%             end
%             fprintf('✅ FLUX: 读取到站点 lat/lon 映射。\n');
%         end
%     catch
%     end
% end
% 
% % Collect target CSVs (exactly your WL program)
% allCSV = dir(fullfile(dataDir_FLUX,'*.csv'));
% targets = [];
% for ii = 1:numel(allCSV)
%     nm = allCSV(ii).name;
%     if contains(nm,'FULLSET','IgnoreCase',true) && ...
%        ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
%          contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
%          contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
%         targets = [targets; allCSV(ii)]; %#ok<AGROW>
%     end
% end
% assert(~isempty(targets), '未找到 文件名包含 FULLSET 的 HH/DD/MM CSV。');
% fprintf('FLUXNET 可用文件（HH/DD/MM）：%d 个\n', numel(targets));
% 
% seen = containers.Map('KeyType','char','ValueType','logical');
% 
% t0 = tic;
% for k = 1:numel(targets)
%     fpath = fullfile(targets(k).folder, targets(k).name);
%     [scaleTag, siteName] = parse_scale_site_from_filename(targets(k).name);
%     if ~ismember(scaleTag, scaleList), continue; end
% 
%     key = sprintf('%s__%s', siteName, scaleTag);
%     if isKey(seen,key), continue; end
%     seen(key) = true;
% 
%     try
%         opts = detectImportOptions(fpath);
%         varNames = opts.VariableNames;
% 
%         needFixed = {yName, vT, vP, vR, vVPD};
%         if ~all(ismember(needFixed, varNames))
%             continue;
%         end
% 
%         swcMask = ~cellfun('isempty', regexp(varNames, swcRegex,'once'));
%         swcCols = varNames(swcMask);
%         if isempty(swcCols)
%             continue;
%         end
% 
%         % read table (exactly your WL program)
%         selectVars = [needFixed, swcCols];
%         opts.SelectedVariableNames = selectVars;
%         Ttab = readtable(fpath, opts);
%         Ttab = sentinel2nan(Ttab, opts.SelectedVariableNames);
% 
%         % series
%         Y   = Ttab.(yName);
%         TA  = Ttab.(vT);
%         PP  = Ttab.(vP);
%         RR  = Ttab.(vR);
%         VPD = Ttab.(vVPD);
% 
%         SWCmat = Ttab{:, swcCols};
%         if ~isfloat(SWCmat), SWCmat = double(SWCmat); end
%         SW = mean(SWCmat, 2, 'omitnan');
% 
%         % optional GS for MM (default OFF)
%         if useGS_for_MM_flux && strcmp(scaleTag,'MM')
%             ytmp = double(Y(:));
%             ok0 = isfinite(ytmp) & (ytmp > 0);
%             if nnz(ok0) >= 5
%                 P90 = prctile(ytmp(ok0), 90);
%                 thr = gsFracP90_flux * P90;
%                 gsMask = (ytmp > thr);
%             else
%                 gsMask = false(size(ytmp));
%             end
%             Y(~gsMask)   = NaN;
%             TA(~gsMask)  = NaN;
%             PP(~gsMask)  = NaN;
%             RR(~gsMask)  = NaN;
%             SW(~gsMask)  = NaN;
%             VPD(~gsMask) = NaN;
%         end
% 
%         % finite mask
%         mask = isfinite(Y) & (Y>0) & isfinite(TA) & isfinite(PP) & isfinite(RR) & isfinite(SW) & isfinite(VPD);
%         Y   = double(Y(mask));
%         TA  = double(TA(mask));
%         PP  = double(PP(mask));
%         RR  = double(RR(mask));
%         SW  = double(SW(mask));
%         VPD = double(VPD(mask));
% 
%         minN_total = minN_total_map(scaleTag);
%         minN_group = minN_group_map(scaleTag);
% 
%         if numel(Y) < minN_total
%             continue; % insufficient
%         end
% 
%         % ---- WL classification (exactly your WL program) ----
%         vpd_group_ok = is_highX_limits_gpp(Y, VPD, qHigh, alpha, minN_total, minN_group);
%         Z_vpd = [TA, PP, RR, SW];
%         [rv, pv2] = partialcorr_fast(Y, VPD, Z_vpd);
%         pv1 = p_one_sided_from_two(pv2, rv, -1);
%         vpd_pcor_ok = isfinite(pv1) && (pv1 < alpha) && (rv < 0);
%         vpd_lim = vpd_group_ok && vpd_pcor_ok;
% 
%         sw_group_ok = is_lowX_limits_gpp(Y, SW, qLow, alpha, minN_total, minN_group);
%         Z_sw = [TA, PP, RR, VPD];
%         [rsw, psw2] = partialcorr_fast(Y, SW, Z_sw);
%         psw1 = p_one_sided_from_two(psw2, rsw, +1);
%         sw_pcor_ok = isfinite(psw1) && (psw1 < alpha) && (rsw > 0);
%         sw_lim = sw_group_ok && sw_pcor_ok;
% 
%         if sw_lim && ~vpd_lim
%             cls = 1;
%         elseif vpd_lim && ~sw_lim
%             cls = 2;
%         elseif sw_lim && vpd_lim
%             cls = 3;
%         else
%             cls = 4;
%         end
% 
%         % ---- Ridge (NO interactions) for this site-scale ----
%         [okR, beta, R2cv] = ridge_one_series_noInter(Y, SW, VPD, TA, PP, RR, [], false, minN_total, Kfold_outer, ridgeLambda);
%         if ~okR
%             continue;
%         end
% 
%         rowIdx = scale2row_flux(scaleTag); % HH->1 DD->2 MM->3
% 
%         % store R2 always into Average
%         r2Cell{rowIdx,4} = [r2Cell{rowIdx,4}; R2cv]; %#ok<AGROW>
%         if cls>=1 && cls<=3
%             r2Cell{rowIdx,cls} = [r2Cell{rowIdx,cls}; R2cv]; %#ok<AGROW>
%         end
% 
%         if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%             coefCell{rowIdx,4} = [coefCell{rowIdx,4}; beta]; %#ok<AGROW>
%             if cls>=1 && cls<=3
%                 coefCell{rowIdx,cls} = [coefCell{rowIdx,cls}; beta]; %#ok<AGROW>
%             end
%         end
% 
%     catch
%         continue;
%     end
% 
%     if mod(k,50)==0
%         fprintf('FLUX progress %d/%d | elapsed %.1fs\n', k, numel(targets), toc(t0));
%         t0 = tic;
%     end
% end
% 
% fprintf('FLUXNET ridge done.\n');
% 
% %% =========================================================================================
% %% ===================== PART 2: RS ridge by WL maps =======================================
% fprintf('\n================== RS | ridge by WL maps ==================\n');
% 
% % FIG3 accumulators (RS long-term only, unchanged; FULL period)
% nbinsX   = 10;
% nbinsCtl = 8;
% xCenters = 5:10:95;
% 
% sum_SW_LT  = zeros(2, nbinsCtl, nbinsX);
% cnt_SW_LT  = zeros(2, nbinsCtl, nbinsX);
% sum_VPD_LT = zeros(2, nbinsCtl, nbinsX);
% cnt_VPD_LT = zeros(2, nbinsCtl, nbinsX);
% 
% tRow = tic;
% nVisited = 0;
% nValidBase = nnz(valid_mask);
% 
% for i = 1:nx
%     for j = 1:ny
%         if ~valid_mask(i,j), continue; end
%         nVisited = nVisited + 1;
% 
%         % ---------- RS Monthly (row 4) ----------
%         c = WL_MO(i,j);
%         if c>=1 && c<=3
%             y  = squeeze(GPP_MO(i,j,:));
%             sw = squeeze(SW_MO(i,j,:));
%             vpd= squeeze(VPD_MO(i,j,:));
%             tt = squeeze(T_MO(i,j,:));
%             pp = squeeze(P_MO(i,j,:));
%             rr = squeeze(R_MO(i,j,:));
% 
%             if useMonthlyGS
%                 [y, sw, vpd, tt, pp, rr] = apply_gs_filter(y, sw, vpd, tt, pp, rr, [], gsFracP90_RS);
%             end
% 
%             [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, [], false, minN_ridge_rs, Kfold_outer, ridgeLambda);
%             if okR
%                 r2Cell{4,c} = [r2Cell{4,c}; R2cv]; %#ok<AGROW>
%                 r2Cell{4,4} = [r2Cell{4,4}; R2cv]; %#ok<AGROW>
%                 if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%                     coefCell{4,c} = [coefCell{4,c}; beta]; %#ok<AGROW>
%                     coefCell{4,4} = [coefCell{4,4}; beta]; %#ok<AGROW>
%                 end
%             end
%         end
% 
%         % ---------- RS Annual (row 5) ----------
%         c = WL_AN(i,j);
%         if c>=1 && c<=3
%             y  = squeeze(GPP_AN(i,j,:));
%             sw = squeeze(SW_AN(i,j,:));
%             vpd= squeeze(VPD_AN(i,j,:));
%             tt = squeeze(T_AN(i,j,:));
%             pp = squeeze(P_AN(i,j,:));
%             rr = squeeze(R_AN(i,j,:));
% 
%             [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, [], false, minN_ridge_rs, Kfold_outer, ridgeLambda);
%             if okR
%                 r2Cell{5,c} = [r2Cell{5,c}; R2cv]; %#ok<AGROW>
%                 r2Cell{5,4} = [r2Cell{5,4}; R2cv]; %#ok<AGROW>
%                 if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%                     coefCell{5,c} = [coefCell{5,c}; beta]; %#ok<AGROW>
%                     coefCell{5,4} = [coefCell{5,4}; beta]; %#ok<AGROW>
%                 end
%             end
%         end
% 
%         % ---------- RS Long-term (row 6) ----------
%         c = WL_LT(i,j);
%         if c>=1 && c<=3
%             y  = squeeze(GPP_LT(i,j,:));
%             sw = squeeze(SW_LT(i,j,:));
%             vpd= squeeze(VPD_LT(i,j,:));
%             tt = squeeze(T_LT(i,j,:));
%             pp = squeeze(P_LT(i,j,:));
%             rr = squeeze(R_LT(i,j,:));
%             co2= squeeze(CO2_LT(i,j,:));
% 
%             [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, co2, true, minN_ridge_rs, Kfold_outer, ridgeLambda);
%             if okR
%                 r2Cell{6,c} = [r2Cell{6,c}; R2cv]; %#ok<AGROW>
%                 r2Cell{6,4} = [r2Cell{6,4}; R2cv]; %#ok<AGROW>
% 
%                 if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%                     coefCell{6,c} = [coefCell{6,c}; beta]; %#ok<AGROW>
%                     coefCell{6,4} = [coefCell{6,4}; beta]; %#ok<AGROW>
% 
%                     % FIG3 accumulators only for SW-limited or VPD-limited
%                     if c==1 || c==2
%                         regionRow = c; % 1 SW-limited; 2 VPD-limited
%                         [sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT] = add_fig3_quantile_curves_longterm_only( ...
%                             regionRow, sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT, ...
%                             y, sw, vpd, tt, pp, rr, co2, beta);
%                     end
%                 end
%             end
%         end
%     end
% 
%     if mod(i,40)==0
%         pct = 100*(nVisited/max(nValidBase,1));
%         fprintf('  RS row %3d/720 | visited %d/%d (%.1f%%) | elapsed %.1fs\n', ...
%             i, nVisited, nValidBase, pct, toc(tRow));
%         tRow = tic;
%     end
% end
% 
% fprintf('RS ridge done.\n');
close all;
%% =========================================================================================
%% ===================== FIG1: coefficients (3×6; no Average) ===============================
col_SW  = [0.63 0.82 0.45];
col_VPD = [0.55 0.40 0.74];
col_T   = [0.96 0.51 0.49];
col_P   = [0.25 0.63 0.76];
col_R   = [0.96 0.72 0.36];
col_CO2 = [0.70 0.70 0.70];

fs_tick  = 10;
fs_title = 11;

figure('Color','w','Position',[100 -500 1550 1250]);
tiledlayout(3,6,'Padding','compact','TileSpacing','compact');

classIdxList = 1:3;    % remove Average (4)

for ri = 1:3
    ci = classIdxList(ri); % 1=SW-limited 2=VPD-limited 3=Co-limited

    for si = 1:6
        ax = nexttile((ri-1)*6 + si);
        B  = coefCell{si,ci};

        if isempty(B)
            axis(ax,'off');
            title(ax, sprintf('%s | %s | n=0', scaleNames{si}, classNames{ci}), ...
                'FontSize',fs_title,'FontWeight','bold');
            continue;
        end

        m   = mean(B,1,'omitnan');
        sd  = std(B,0,1,'omitnan');
        n   = size(B,1);
        sem = sd ./ sqrt(max(n,1));

        isLongTermRS = (si==6); % only RS LT uses CO2
        if ~isLongTermRS
            termColors = [col_SW; col_VPD; col_T; col_P; col_R];
            x_plot = 1:numel(termNames_noCO2);

            bh = bar(ax, x_plot, m, 0.78); hold(ax,'on');
            bh.FaceColor = 'flat';
            bh.CData = termColors;

            errorbar(ax, x_plot, m, sem, 'k', 'LineStyle','none','LineWidth',0.8);
            yline(ax,0,'k-','LineWidth',0.8);
            set(ax,'XTick',x_plot,'XTickLabel',termNames_noCO2,'FontSize',fs_tick,'TickDir','out');
        else
            termColors = [col_SW; col_VPD; col_T; col_P; col_R; col_CO2];
            x_plot = 1:numel(termNames_CO2);

            bh = bar(ax, x_plot, m, 0.78); hold(ax,'on');
            bh.FaceColor = 'flat';
            bh.CData = termColors;

            errorbar(ax, x_plot, m, sem, 'k', 'LineStyle','none','LineWidth',0.8);
            yline(ax,0,'k-','LineWidth',0.8);
            set(ax,'XTick',x_plot,'XTickLabel',termNames_CO2,'FontSize',fs_tick,'TickDir','out');
        end

        grid(ax,'on'); box(ax,'off'); xtickangle(ax,45);
        title(ax, sprintf('%s | %s', scaleNames{si}, classNames{ci}), ...
            'FontSize',fs_title,'FontWeight','bold');

        if si==1
            text(ax,-0.55,0.50,classNames{ci},'Units','normalized', ...
                'Rotation',90,'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontSize',fs_title,'FontWeight','bold');
        end
    end
end

exportgraphics(gcf,outFig1,'Resolution',300);
fprintf('✅ FIG1 Saved: %s\n', outFig1);

%% =========================================================================================
%% ===================== FIG2: CV-R2 histograms (3×6; no Average) ===========================
figure('Color','w','Position',[100 -500 1550 1250]);
tiledlayout(3,6,'Padding','compact','TileSpacing','compact');

edges = linspace(-0.5, 1, 31);

for ri = 1:3
    ci = classIdxList(ri);

    for si = 1:6
        ax = nexttile((ri-1)*6 + si);
        R2 = r2Cell{si,ci};

        if isempty(R2)
            axis(ax,'off');
            title(ax, sprintf('%s | %s | n=0', scaleNames{si}, classNames{ci}), ...
                'FontSize',fs_title,'FontWeight','bold');
            continue;
        end

        R2 = R2(isfinite(R2));
        histogram(ax, R2, edges); hold(ax,'on');
        xline(ax, R2_keep_for_coef, 'k--', 'LineWidth', 1.0);

        grid(ax,'on'); box(ax,'off');
        xlim(ax,[edges(1) edges(end)]);
        xlabel(ax,'CV-R^2'); ylabel(ax,'Count');

        title(ax, sprintf('%s | %s', scaleNames{si}, classNames{ci}), ...
            'FontSize',fs_title,'FontWeight','bold');

        if si==1
            text(ax,-0.55,0.50,classNames{ci},'Units','normalized', ...
                'Rotation',90,'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontSize',fs_title,'FontWeight','bold');
        end
    end
end

exportgraphics(gcf,outFig2,'Resolution',300);
fprintf('✅ FIG2 Saved: %s\n', outFig2);

%% =========================================================================================
%% ===================== FIG3 (unchanged): RS Long-term quantile curves (2×2) ===============
%% ===================== FIG3: RS Long-term quantile curves (2×2) =====================
fs = 1.5;   % 字体统一放大倍数

mean_SW_LT  = sum_SW_LT  ./ max(cnt_SW_LT,  1);
mean_VPD_LT = sum_VPD_LT ./ max(cnt_VPD_LT, 1);

ctlLabels = {'10–20%','20–30%','30–40%','40–50%','50–60%','60–70%','70–80%','80–90%'};
rowNames  = {'SW-limited','VPD-limited'};

colsVPD = make_color_gradient([0.55 0.40 0.74], nbinsCtl);
colsSW  = make_color_gradient([0.63 0.82 0.45], nbinsCtl);

pos0 = [0 0 1700 900];
pos0(3) = round(pos0(3)*0.70);
figure('Color','w','Position',pos0);

tlo = tiledlayout(2,2,'Padding','compact','TileSpacing','compact');
tlo.Units = 'normalized';
tlo.OuterPosition = [0 0.18 1 0.70];   % 给下方图例留更多空间

hLegendLeft  = gobjects(nbinsCtl,1);
hLegendRight = gobjects(nbinsCtl,1);

for rr = 1:2
    % ---------------- 左列：GPP-SW ----------------
    ax1 = nexttile((rr-1)*2 + 1);
    hold(ax1,'on');

    h1 = gobjects(nbinsCtl,1);
    for k = 1:nbinsCtl
        yk = squeeze(mean_SW_LT(rr,k,:));
        if all(~isfinite(yk))
            continue;
        end
        h1(k) = plot(ax1, xCenters, yk(:), '-o', ...
            'LineWidth',1.2, ...
            'MarkerSize',4, ...
            'Color',colsVPD(k,:));
    end

    yline(ax1,0,'k-','LineWidth',0.8);
    xlim(ax1,[0 100]);
    ylim(ax1,[-1 1]);
    grid(ax1,'on');
    box(ax1,'off');

    set(ax1,'FontSize',10*fs);

    xlabel(ax1,'SW (percentile)','FontSize',10*fs);
    ylabel(ax1,'GPP residual (z-score)','FontSize',10*fs);
    title(ax1, sprintf('Long-term | %s | GPP–SW', rowNames{rr}), ...
        'FontWeight','bold','FontSize',11*fs);

    if rr==2
        hLegendLeft = h1;
    end

    % ---------------- 右列：GPP-VPD ----------------
    ax2 = nexttile((rr-1)*2 + 2);
    hold(ax2,'on');

    h2 = gobjects(nbinsCtl,1);
    for k = 1:nbinsCtl
        yk = squeeze(mean_VPD_LT(rr,k,:));
        if all(~isfinite(yk))
            continue;
        end
        h2(k) = plot(ax2, xCenters, yk(:), '-o', ...
            'LineWidth',1.2, ...
            'MarkerSize',4, ...
            'Color',colsSW(k,:));
    end

    yline(ax2,0,'k-','LineWidth',0.8);
    xlim(ax2,[0 100]);
    ylim(ax2,[-1 1]);
    grid(ax2,'on');
    box(ax2,'off');

    set(ax2,'FontSize',10*fs);

    xlabel(ax2,'VPD (percentile)','FontSize',10*fs);
    ylabel(ax2,'GPP residual (z-score)','FontSize',10*fs);
    title(ax2, sprintf('Long-term | %s | GPP–VPD', rowNames{rr}), ...
        'FontWeight','bold','FontSize',11*fs);

    if rr==2
        hLegendRight = h2;
    end
end

keepL = isgraphics(hLegendLeft);
keepR = isgraphics(hLegendRight);

% ===== 通过“每个图例条目加一个空白第二行”来增大行间距 =====
labelsL_all = strcat('VPD = ', ctlLabels);
labelsR_all = strcat('SW = ',  ctlLabels);

labelsL = cell(sum(keepL),1);
tmpL = labelsL_all(keepL);
for i = 1:numel(tmpL)
    labelsL{i} = sprintf('%s\\newline ', tmpL{i});
end

labelsR = cell(sum(keepR),1);
tmpR = labelsR_all(keepR);
for i = 1:numel(tmpR)
    labelsR{i} = sprintf('%s\\newline ', tmpR{i});
end

% 左图例
lgdL = legend(hLegendLeft(keepL), labelsL, ...
    'NumColumns',2, ...
    'Location','none', ...
    'FontSize',10*fs, ...
    'Interpreter','tex');
lgdL.Box = 'off';

% 右图例
lgdR = legend(hLegendRight(keepR), labelsR, ...
    'NumColumns',2, ...
    'Location','none', ...
    'FontSize',10*fs, ...
    'Interpreter','tex');
lgdR.Box = 'off';

set(lgdL,'Units','normalized');
set(lgdR,'Units','normalized');

% 线段稍长一点
lgdL.ItemTokenSize = [22, 12];
lgdR.ItemTokenSize = [22, 12];

% 图例框再高一些
drawnow;
lgdL.Position = [0.06 -0.14 0.40 0.24];
lgdR.Position = [0.54 -0.14 0.40 0.24];
drawnow;

exportgraphics(gcf, outFig3, 'Resolution', 300);
fprintf('✅ FIG3 Saved: %s\n', outFig3);

%% =====================================================================================
%% ===================== FIG4: conditional-slope summary (FULL period) ==================
mean_SW_LT_full  = sum_SW_LT  ./ max(cnt_SW_LT,  1);
mean_VPD_LT_full = sum_VPD_LT ./ max(cnt_VPD_LT, 1);

slopes_VPD_given_SW_full = compute_slopes_from_lines(mean_VPD_LT_full, xCenters);
slopes_SW_given_VPD_full = compute_slopes_from_lines(mean_SW_LT_full,  xCenters);

colsVPD_bins = make_color_gradient(col_VPD, 8);
colsSW_bins  = make_color_gradient(col_SW,  8);

figure('Color','w','Position',[200 120 620 520]);
ax = axes;
hold(ax,'on');

xG  = [1 2 3 4];
jit = linspace(-0.14, 0.14, 8);

% ================= SW-limited =================
rr = 1;
for k = 1:8
    yk = slopes_VPD_given_SW_full(rr,k);
    if ~isfinite(yk)
        continue;
    end
    scatter(ax, xG(1)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsVPD_bins(k,:), ...
        'MarkerEdgeColor','w', ...
        'MarkerFaceAlpha',0.95);
end
scatter(ax, xG(1), mean(slopes_VPD_given_SW_full(rr,:), 'omitnan'), ...
    70, 'ks', 'filled');

for k = 1:8
    yk = slopes_SW_given_VPD_full(rr,k);
    if ~isfinite(yk)
        continue;
    end
    scatter(ax, xG(2)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsSW_bins(k,:), ...
        'MarkerEdgeColor','w', ...
        'MarkerFaceAlpha',0.95);
end
scatter(ax, xG(2), mean(slopes_SW_given_VPD_full(rr,:), 'omitnan'), ...
    70, 'ks', 'filled');

% ================= VPD-limited =================
rr = 2;
for k = 1:8
    yk = slopes_VPD_given_SW_full(rr,k);
    if ~isfinite(yk)
        continue;
    end
    scatter(ax, xG(3)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsVPD_bins(k,:), ...
        'MarkerEdgeColor','w', ...
        'MarkerFaceAlpha',0.95);
end
scatter(ax, xG(3), mean(slopes_VPD_given_SW_full(rr,:), 'omitnan'), ...
    70, 'ks', 'filled');

for k = 1:8
    yk = slopes_SW_given_VPD_full(rr,k);
    if ~isfinite(yk)
        continue;
    end
    scatter(ax, xG(4)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsSW_bins(k,:), ...
        'MarkerEdgeColor','w', ...
        'MarkerFaceAlpha',0.95);
end
scatter(ax, xG(4), mean(slopes_SW_given_VPD_full(rr,:), 'omitnan'), ...
    70, 'ks', 'filled');

yline(ax,0,'k--','LineWidth',0.9);
xline(ax,2.5,'k--','LineWidth',1.0);

set(ax, ...
    'XLim',[0.5 4.5], ...
    'TickDir','out', ...
    'FontSize',11*fs);

set(ax,'XTick',xG,'XTickLabel',{ ...
    'ΔGPP(VPD | SW)', ...
    'ΔGPP(SW | VPD)', ...
    'ΔGPP(VPD | SW)', ...
    'ΔGPP(SW | VPD)'});

ylabel(ax,'Slope (ΔGPP residual per percentile)','FontSize',11*fs);
grid(ax,'on');
box(ax,'off');

yl = ylim(ax);
yTop = yl(2) - 0.05*range(yl);

text(ax,1.5,yTop,'SW-limited', ...
    'HorizontalAlignment','center', ...
    'FontWeight','bold', ...
    'FontSize',12*fs);

text(ax,3.5,yTop,'VPD-limited', ...
    'HorizontalAlignment','center', ...
    'FontWeight','bold', ...
    'FontSize',12*fs);

exportgraphics(gcf, outFig4, 'Resolution', 300);
fprintf('✅ FIG4 Saved (FULL period): %s\n', outFig4);



%% =========================================================================================
%% ===================================== HELPERS ==========================================

function slopes = compute_slopes_from_lines(M3, xCenters)
slopes = nan(size(M3,1), size(M3,2));
x = xCenters(:);
for rr = 1:size(M3,1)
    for k = 1:size(M3,2)
        y = squeeze(M3(rr,k,:));
        mk = isfinite(x) & isfinite(y);
        if nnz(mk) < 3
            slopes(rr,k) = NaN;
            continue;
        end
        p = polyfit(x(mk), y(mk), 1);
        slopes(rr,k) = p(1);
    end
end
end

function rowIdx = scale2row_flux(scaleTag)
switch upper(scaleTag)
    case 'HH', rowIdx = 1;
    case 'DD', rowIdx = 2;
    case 'MM', rowIdx = 3;
    otherwise, rowIdx = NaN;
end
end

function [ok, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, t, p, r, co2, useCO2, minN, Kfold_outer, lambda)
ok=false; beta=[]; R2cv=NaN;

y=y(:); sw=sw(:); vpd=vpd(:); t=t(:); p=p(:); r=r(:);
if useCO2, co2=co2(:); end

if useCO2
    mk0 = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd)&isfinite(t)&isfinite(p)&isfinite(r)&isfinite(co2);
else
    mk0 = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd)&isfinite(t)&isfinite(p)&isfinite(r);
end

if nnz(mk0) < minN, return; end

y  = double(y(mk0));
sw = double(sw(mk0));
vpd= double(vpd(mk0));
t  = double(t(mk0));
pp = double(p(mk0));
rr = double(r(mk0));
if useCO2, co2 = double(co2(mk0)); end

if ~useCO2
    Xraw = [sw, vpd, t, pp, rr];
else
    Xraw = [sw, vpd, t, pp, rr, co2];
end

M = [y Xraw];
good = all(isfinite(M),2);
y = y(good); Xraw = Xraw(good,:);

n = size(Xraw,1);
if n < minN, return; end

K = min(Kfold_outer, n);
folds = blocked_kfold(n, K);

yhat = nan(n,1);
ytrue_all = nan(n,1);

for k=1:K
    te = folds{k};
    tr = true(n,1); tr(te)=false;

    Xtr0 = Xraw(tr,:); ytr0 = y(tr);
    Xte0 = Xraw(te,:); yte0 = y(te);

    [Xtr, muX, sigX] = zscore_train_apply(Xtr0);
    Xte = (Xte0 - muX) ./ sigX;

    [ytr, muy, sigy] = zscore_train_apply(ytr0);
    yte = (yte0 - muy) ./ sigy;

    if any(~isfinite(Xtr(:))) || any(~isfinite(Xte(:))) || any(~isfinite(ytr)) || any(~isfinite(yte))
        continue;
    end

    try
        mdl = fitrlinear(Xtr, ytr, 'Learner','leastsquares', ...
            'Regularization','ridge', 'Lambda',lambda, 'FitBias',true);
        yhat(te) = predict(mdl, Xte);
        ytrue_all(te) = yte;
    catch
    end
end

good2 = isfinite(yhat) & isfinite(ytrue_all);
if nnz(good2) < max(10, round(0.6*n)), return; end

ssRes = sum((ytrue_all(good2) - yhat(good2)).^2);
ssTot = sum((ytrue_all(good2) - mean(ytrue_all(good2))).^2);
if ssTot <= 0, return; end
R2cv = 1 - ssRes/ssTot;

% coefficients on FULL standardized data
Xfull = zscore(Xraw);
yfull = zscore(y);
goodF = all(isfinite([yfull Xfull]),2);
Xfull = Xfull(goodF,:); yfull = yfull(goodF);

nF = size(Xfull,1);
if nF < minN, return; end

try
    mdlF = fitrlinear(Xfull, yfull, 'Learner','leastsquares', ...
        'Regularization','ridge', 'Lambda',lambda, 'FitBias',true);
    beta = mdlF.Beta';
catch
    beta=[]; return;
end

if any(~isfinite(beta)), beta=[]; return; end
ok=true;
end

function [y, sw, vpd, tt, pp, rr, co2] = apply_gs_filter(y, sw, vpd, tt, pp, rr, co2, fracP90)
y = y(:); sw=sw(:); vpd=vpd(:); tt=tt(:); pp=pp(:); rr=rr(:);
if ~isempty(co2), co2=co2(:); end

yd = double(y);
ok0 = isfinite(yd) & (yd>0);
if nnz(ok0) < 5
    y(:)=NaN; sw(:)=NaN; vpd(:)=NaN; tt(:)=NaN; pp(:)=NaN; rr(:)=NaN;
    if ~isempty(co2), co2(:)=NaN; end
    return;
end
P90 = prctile(yd(ok0), 90);
thr = fracP90 * P90;
gsMask = (yd > thr);

y(~gsMask)=NaN; sw(~gsMask)=NaN; vpd(~gsMask)=NaN; tt(~gsMask)=NaN; pp(~gsMask)=NaN; rr(~gsMask)=NaN;
if ~isempty(co2), co2(~gsMask)=NaN; end
end

function A = read_raw_3d_auto(path, shape2, Tlen, rawLen, sFrom, sTo)
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);
nTot = numel(dat);
n1 = nx*ny*Tlen;
n2 = nx*ny*rawLen;
if nTot == n1
    A = reshape(dat, [nx, ny, Tlen]);
elseif nTot == n2
    A = reshape(dat, [nx, ny, rawLen]);
    A = A(:,:,sFrom:sTo);
else
    error('Unexpected file size for %s: got %d floats; expected %d (420) or %d (468).', path, nTot, n1, n2);
end
end

function A = read_raw_2d_single(path, shape2)
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end

function CO2 = read_raw_3d_fixed492_slice420(path, nx, ny, co2Len, sFrom, sTo)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s', path);
tmp = fread(fid, nx*ny*co2Len, 'single');
fclose(fid);
tmp = reshape(tmp, [nx, ny, co2Len]);
CO2 = tmp(:,:,sFrom:sTo);
end

function folds = blocked_kfold(n, K)
edges = round(linspace(0, n, K+1));
folds = cell(K,1);
for k=1:K
    a = edges(k)+1; b = edges(k+1);
    folds{k} = (a:b)';
end
end

function [Z, mu, sig] = zscore_train_apply(X)
mu  = mean(X,1,'omitnan');
sig = std(X,0,1,'omitnan');
sig(sig < 1e-12) = 1;
Z = (X - mu) ./ sig;
end

function Tout = sentinel2nan(T, names)
for i = 1:numel(names)
    vname = names{i};
    if ~ismember(vname, T.Properties.VariableNames), continue; end
    v = T.(vname);
    if ~isnumeric(v)
        v = double(str2double(string(v)));
    else
        v = double(v);
    end
    v(v<=-9990 | v>=9.9e8) = NaN;
    T.(vname) = v;
end
Tout = T;
end

function [scaleTag, siteName] = parse_scale_site_from_filename(fname)
siteName = '';
try
    s = string(fname);
    a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
    if ~isempty(a) && ~isempty(b) && b>a
        siteName = char(extractBetween(s,a+4,b-1));
    else
        tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
        if ~isempty(tok), siteName = tok{1}; else, siteName = fname; end
    end
catch
    siteName = fname;
end

if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
    scaleTag = 'HH';
elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
    scaleTag = 'DD';
elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
    scaleTag = 'MM';
else
    scaleTag = 'OTHER';
end
end

function ok = is_lowX_limits_gpp(gpp, X, qPercent, alpha, minN_total, minN_group)
ok = false;
gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total, return; end
gpp = gpp(mask); X = X(mask);

q = prctile(X, qPercent);
idx_low  = (X <= q);
idx_high = (X >  q);

nL = nnz(idx_low); nH = nnz(idx_high);
if (nL < minN_group) || (nH < minN_group), return; end

gL = gpp(idx_low);
gH = gpp(idx_high);

if mean(gL) >= mean(gH), return; end

try
    [h, p] = ttest2(gL, gH, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function ok = is_highX_limits_gpp(gpp, X, qPercentHigh, alpha, minN_total, minN_group)
ok = false;
gpp = double(gpp(:));
X   = double(X(:));

mask = isfinite(gpp) & (gpp>0) & isfinite(X);
if nnz(mask) < minN_total, return; end
gpp = gpp(mask); X = X(mask);

qH = prctile(X, qPercentHigh);
idx_high = (X >= qH);
idx_low  = (X <  qH);

nH = nnz(idx_high); nL = nnz(idx_low);
if (nH < minN_group) || (nL < minN_group), return; end

gH = gpp(idx_high);
gL = gpp(idx_low);

if mean(gH) >= mean(gL), return; end

try
    [h, p] = ttest2(gH, gL, 'Vartype','unequal', 'Tail','left', 'Alpha', alpha);
    ok = (h==1) && (p < alpha);
catch
    ok = false;
end
end

function p1 = p_one_sided_from_two(p2, r, expectSign)
if ~isfinite(p2) || ~isfinite(r)
    p1 = NaN; return;
end
if expectSign > 0
    if r > 0, p1 = p2/2; else, p1 = 1; end
else
    if r < 0, p1 = p2/2; else, p1 = 1; end
end
end

function [r, p] = partialcorr_fast(y, x, Z)
r = NaN; p = NaN;
y = y(:); x = x(:);
if isempty(Z)
    M = [y x];
else
    Z = double(Z);
    M = [y x Z];
end
good = all(isfinite(M),2);
M = M(good,:);

n = size(M,1);
k = size(M,2) - 2;
df = n - k - 2;
if df < 3, return; end

yy = M(:,1);
xx = M(:,2);

if k==0
    ry = yy - mean(yy);
    rx = xx - mean(xx);
else
    ZZ = M(:,3:end);
    A  = [ones(n,1), ZZ];
    by = A \ yy;  ry = yy - A*by;
    bx = A \ xx;  rx = xx - A*bx;
end

ry = ry - mean(ry);
rx = rx - mean(rx);
den = sqrt(sum(ry.^2) * sum(rx.^2));
if den==0, return; end

r = sum(ry .* rx) / den;
t = r * sqrt(df / max(1e-12, (1 - r^2)));
p = 2 * (1 - tcdf(abs(t), df));
end

function cols = make_color_gradient(baseColor, n)
cols = zeros(n,3);
for k = 1:n
    a = k/n;
    cols(k,:) = (1-a)*[1 1 1] + a*baseColor;
end
end

function [sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT] = add_fig3_quantile_curves_longterm_only( ...
    regionRow, sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT, ...
    y, sw, vpd, t, p, r, co2, beta)

y = y(:); sw = sw(:); vpd = vpd(:); t = t(:); p = p(:); r = r(:); co2 = co2(:);

mk0 = isfinite(y) & (y>0) & isfinite(sw) & isfinite(vpd) & isfinite(t) & isfinite(p) & isfinite(r) & isfinite(co2);
if nnz(mk0) < 40, return; end

y  = double(y(mk0));
sw = double(sw(mk0));
vpd= double(vpd(mk0));
t  = double(t(mk0));
pp = double(p(mk0));
rr = double(r(mk0));
co2= double(co2(mk0));

yz  = zscore(y);
tz  = zscore(t);
pz  = zscore(pp);
rz  = zscore(rr);
cz  = zscore(co2);

good = all(isfinite([yz tz pz rz cz sw vpd]),2);
yz = yz(good); tz = tz(good); pz = pz(good); rz = rz(good); cz = cz(good);
sw = sw(good); vpd = vpd(good);
if numel(yz) < 40, return; end

idx_nonwater = [3 4 5 6]; % T,P,R,CO2
Xnw = [tz, pz, rz, cz];
bNW = beta(idx_nonwater);
y_res = yz - Xnw * bNW(:);

swPct  = empirical_percentile(sw);
vpdPct = empirical_percentile(vpd);

swBin  = min(10, max(1, floor(swPct/10) + 1));
vpdBin = min(10, max(1, floor(vpdPct/10) + 1));

ctlBins = 2:9;  % 10–20..80–90

for vb = ctlBins
    ctlIdx = vb - 1;
    mk = (vpdBin == vb);
    if ~any(mk), continue; end
    sb = swBin(mk);
    yr = y_res(mk);

    for xb = 1:10
        mk2 = (sb == xb);
        if ~any(mk2), continue; end
        sum_SW_LT(regionRow, ctlIdx, xb) = sum_SW_LT(regionRow, ctlIdx, xb) + sum(yr(mk2), 'omitnan');
        cnt_SW_LT(regionRow, ctlIdx, xb) = cnt_SW_LT(regionRow, ctlIdx, xb) + nnz(isfinite(yr(mk2)));
    end
end

for sbc = ctlBins
    ctlIdx = sbc - 1;
    mk = (swBin == sbc);
    if ~any(mk), continue; end
    vb = vpdBin(mk);
    yr = y_res(mk);

    for xb = 1:10
        mk2 = (vb == xb);
        if ~any(mk2), continue; end
        sum_VPD_LT(regionRow, ctlIdx, xb) = sum_VPD_LT(regionRow, ctlIdx, xb) + sum(yr(mk2), 'omitnan');
        cnt_VPD_LT(regionRow, ctlIdx, xb) = cnt_VPD_LT(regionRow, ctlIdx, xb) + nnz(isfinite(yr(mk2)));
    end
end
end

function pct = empirical_percentile(x)
x = x(:);
n = numel(x);
if n < 2
    pct = zeros(size(x));
    return;
end
[~,~,rk] = unique(x, 'sorted');
pct = 100 * ((double(rk) - 0.5) / n);
end

function p = get_pair_p(cmat, g1, g2)
p = NaN;
if isempty(cmat), return; end
k = find((cmat(:,1)==g1 & cmat(:,2)==g2) | (cmat(:,1)==g2 & cmat(:,2)==g1), 1);
if ~isempty(k)
    p = cmat(k,6);
end
end

function s = stars_from_p(p)
if ~isfinite(p)
    s = '';
elseif p < 0.001
    s = '***';
elseif p < 0.01
    s = '**';
elseif p < 0.05
    s = '*';
else
    s = '';
end
end

function add_bracket_with_stars(ax, x1, x2, y, txt)
if isempty(txt), return; end
dy = 0.01 * range(ylim(ax));
if ~isfinite(dy) || dy<=0, dy = 0.01; end
plot(ax,[x1 x1 x2 x2],[y y+dy y+dy y],'k-','LineWidth',1.0);
text(ax, mean([x1 x2]), y+dy*1.2, txt, 'HorizontalAlignment','center', 'FontWeight','bold', 'FontSize',14);
end
