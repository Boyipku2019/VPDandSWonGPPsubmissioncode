%% =========================================================================================
% RS only (Monthly/Annual/Long-term)
% Ridge (NO interactions)
% + FIG6: Scatter (beta vs Aridity Index) | 2 rows × 3 cols (MO/AN/LT) + fitted line
% + FIG7: Violin (beta by vegetation type) | 2 rows × 3 cols (MO/AN/LT)
%
% Updates:
%   - AI < 0 invalid
%   - No FIG1/FIG2/FIG3
%   - FIG7 colored by veg type (Nature-like)
%   - FIG7 LT y-lim = [-1, 1]
%   - NEW: FIG6 adds linear fit line in each subplot
%
% Tested: MATLAB R2021a
% -----------------------------------------------------------------------------------------

clear; clc; close all; warning('off','all');
set(groot,'DefaultAxesFontName','Arial');
set(groot,'DefaultTextFontName','Arial');
rng(2025);

tAll = tic;

%% ===================== Ridge settings =====================
Kfold_outer = 5;
minN_ridge_rs   = 40;
R2_keep_for_coef = 0;
ridgeLambda = 0.05;

%% ===================== RS Paths =====================
rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';

GPP_MO_path = "G:\Resource use efficiencies new\dataprocessed\GPP19842018_3D.raw"; % 720x360x420
T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";  % 468
P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";   % 468
R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw"; % 468
SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw"; % 468
VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468

GPP_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_SSA_Annual_4comp.raw');
T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');

GPP_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','GPP05_CEEMDAN_Trend_4comp.raw');
T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 492

WL_MO_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF\WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw';
WL_AN_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF\WLclass_Annual_q25_ttest_pcor_f32_720x360.raw';
WL_LT_path = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF\WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw';

aridityPath = 'G:\GlobalData\aridityindex\WorldClim_2_1_1970-2000\resample720360.tif';

%% ===================== Outputs =====================
outDir = 'D:\';
if ~exist(outDir,'dir'), mkdir(outDir); end

outFig6 = fullfile(outDir, sprintf('FIG6_Beta_vs_Aridity_RS_3scales_lambda%.3f_withFit.png', ridgeLambda));
outFig7 = fullfile(outDir, sprintf('FIG7_Violin_Beta_byVeg_RS_3scales_lambda%.3f.png', ridgeLambda));

%% ===================== Basic RS dims =====================
nx = 720; ny = 360;

%% ===================== Check files =====================
mustFiles_RS = {lulcPath,hfpPath,aridityPath,...
    GPP_MO_path,T_MO_path,P_MO_path,R_MO_path,SW_MO_path,VPD_MO_path,...
    GPP_AN_path,T_AN_path,P_AN_path,R_AN_path,SW_AN_path,VPD_AN_path,...
    GPP_LT_path,T_LT_path,P_LT_path,R_LT_path,SW_LT_path,VPD_LT_path,CO2_LT_path,...
    WL_MO_path, WL_AN_path, WL_LT_path};

for k=1:numel(mustFiles_RS)
    assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
end

%% ===================== RS masks =====================
IGBP = imread(lulcPath)';
HFP  = imread(hfpPath)';
assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');

valid_mask = ismember(IGBP,1:10) & (HFP<=25);
fprintf('RS valid pixels (veg & HFP<=25): %d\n', nnz(valid_mask));

%% ===================== Read Aridity Index =====================
AI = imread(aridityPath)';         % transpose
AI = double(AI);
AI(~isfinite(AI)) = NaN;
AI(AI < 0) = NaN;                  % invalid if <0

%% ===================== Read RS WL maps =====================
WL_MO = read_raw_2d_single(WL_MO_path,[nx ny]);
WL_AN = read_raw_2d_single(WL_AN_path,[nx ny]);
WL_LT = read_raw_2d_single(WL_LT_path,[nx ny]);

WL_MO(~ismember(WL_MO,[0 1 2 3 4])) = 0;
WL_AN(~ismember(WL_AN,[0 1 2 3 4])) = 0;
WL_LT(~ismember(WL_LT,[0 1 2 3 4])) = 0;

%% ===================== Read RS data blocks (auto-detect 420 vs 468) =====================
fprintf('Reading RS data blocks...\n');
Tlen   = 420;
rawLen = 468;
sFrom  = 25;
sTo    = 444;

GPP_MO = read_raw_3d_auto(GPP_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_MO   = read_raw_3d_auto(T_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_MO   = read_raw_3d_auto(P_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_MO   = read_raw_3d_auto(R_MO_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_MO  = read_raw_3d_auto(SW_MO_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_MO = read_raw_3d_auto(VPD_MO_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

GPP_AN = read_raw_3d_auto(GPP_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_AN   = read_raw_3d_auto(T_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_AN   = read_raw_3d_auto(P_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_AN   = read_raw_3d_auto(R_AN_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_AN  = read_raw_3d_auto(SW_AN_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_AN = read_raw_3d_auto(VPD_AN_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

GPP_LT = read_raw_3d_auto(GPP_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);
T_LT   = read_raw_3d_auto(T_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
P_LT   = read_raw_3d_auto(P_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
R_LT   = read_raw_3d_auto(R_LT_path,   [nx,ny], Tlen, rawLen, sFrom, sTo);
SW_LT  = read_raw_3d_auto(SW_LT_path,  [nx,ny], Tlen, rawLen, sFrom, sTo);
VPD_LT = read_raw_3d_auto(VPD_LT_path, [nx,ny], Tlen, rawLen, sFrom, sTo);

CO2_LT = read_raw_3d_fixed492_slice420(CO2_LT_path, nx, ny, 492, 25, 444);

fprintf('RS data loaded.\n');

%% =========================================================================================
%% ===================== per-pixel beta maps for FIG6/FIG7 =============================
betaSW_MO = nan(nx,ny,'single');  betaVPD_MO = nan(nx,ny,'single');
betaSW_AN = nan(nx,ny,'single');  betaVPD_AN = nan(nx,ny,'single');
betaSW_LT = nan(nx,ny,'single');  betaVPD_LT = nan(nx,ny,'single');

%% =========================================================================================
%% ===================== RS ridge by WL maps (only store betas) =============================
fprintf('\n================== RS | ridge by WL maps (store betas) ==================\n');

tRow = tic;
nVisited = 0;
nValidBase = nnz(valid_mask);

for i = 1:nx
    for j = 1:ny
        if ~valid_mask(i,j), continue; end
        nVisited = nVisited + 1;

        % Monthly
        c = WL_MO(i,j);
        if c==1 || c==2
            y  = squeeze(GPP_MO(i,j,:));
            sw = squeeze(SW_MO(i,j,:));
            vpd= squeeze(VPD_MO(i,j,:));
            tt = squeeze(T_MO(i,j,:));
            pp = squeeze(P_MO(i,j,:));
            rr = squeeze(R_MO(i,j,:));

            [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, [], false, minN_ridge_rs, Kfold_outer, ridgeLambda);
            if okR && isfinite(R2cv) && (R2cv > R2_keep_for_coef)
                if c==1, betaSW_MO(i,j)  = single(beta(1)); end
                if c==2, betaVPD_MO(i,j) = single(beta(2)); end
            end
        end

        % Annual
        c = WL_AN(i,j);
        if c==1 || c==2
            y  = squeeze(GPP_AN(i,j,:));
            sw = squeeze(SW_AN(i,j,:));
            vpd= squeeze(VPD_AN(i,j,:));
            tt = squeeze(T_AN(i,j,:));
            pp = squeeze(P_AN(i,j,:));
            rr = squeeze(R_AN(i,j,:));

            [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, [], false, minN_ridge_rs, Kfold_outer, ridgeLambda);
            if okR && isfinite(R2cv) && (R2cv > R2_keep_for_coef)
                if c==1, betaSW_AN(i,j)  = single(beta(1)); end
                if c==2, betaVPD_AN(i,j) = single(beta(2)); end
            end
        end

        % Long-term
        c = WL_LT(i,j);
        if c==1 || c==2
            y  = squeeze(GPP_LT(i,j,:));
            sw = squeeze(SW_LT(i,j,:));
            vpd= squeeze(VPD_LT(i,j,:));
            tt = squeeze(T_LT(i,j,:));
            pp = squeeze(P_LT(i,j,:));
            rr = squeeze(R_LT(i,j,:));
            co2= squeeze(CO2_LT(i,j,:));

            [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, co2, true, minN_ridge_rs, Kfold_outer, ridgeLambda);
            if okR && isfinite(R2cv) && (R2cv > R2_keep_for_coef)
                if c==1, betaSW_LT(i,j)  = single(beta(1)); end
                if c==2, betaVPD_LT(i,j) = single(beta(2)); end
            end
        end
    end

    if mod(i,40)==0
        pct = 100*(nVisited/max(nValidBase,1));
        fprintf('  RS row %3d/720 | visited %d/%d (%.1f%%) | elapsed %.1fs\n', ...
            i, nVisited, nValidBase, pct, toc(tRow));
        tRow = tic;
    end
end
fprintf('RS ridge done.\n');

%% =========================================================================================
%% ===================== FIG6: Scatter beta vs Aridity + fitted line (2×3) ==================
figure('Color','w','Position',[120 80 1500 820]);
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

scaleTitles = {'Monthly (RS)','Annual (RS)','Long-term (RS)'};
betaSW_maps  = {betaSW_MO, betaSW_AN, betaSW_LT};
betaVPD_maps = {betaVPD_MO,betaVPD_AN,betaVPD_LT};
WL_maps      = {WL_MO, WL_AN, WL_LT};

for sc = 1:3
    % -------- SW-limited row --------
    ax = nexttile(sc); hold(ax,'on');
    mk = valid_mask & (WL_maps{sc}==1) & isfinite(AI) & isfinite(betaSW_maps{sc});
    x = AI(mk); y = double(betaSW_maps{sc}(mk));
    scatter(ax, x, y, 8, 'filled', 'MarkerFaceAlpha',0.18, 'MarkerEdgeAlpha',0.18);

    % fit line
    add_linear_fitline(ax, x, y);

    grid(ax,'on'); box(ax,'off');
    xlabel(ax,'Aridity Index');
    ylabel(ax,'\beta_{SW} (standardized)');
    title(ax, sprintf('SW-limited | %s', scaleTitles{sc}), 'FontWeight','bold');
    [r0,p0] = corr(x(:), y(:), 'Type','Pearson', 'Rows','complete');
    if isfinite(r0) && isfinite(p0)
        text(ax,0.02,0.98,sprintf('r=%.2f, p=%.2g', r0, p0),...
            'Units','normalized','HorizontalAlignment','left','VerticalAlignment','top',...
            'FontWeight','bold','FontSize',11);
    end

    % -------- VPD-limited row --------
    ax = nexttile(3+sc); hold(ax,'on');
    mk = valid_mask & (WL_maps{sc}==2) & isfinite(AI) & isfinite(betaVPD_maps{sc});
    x = AI(mk); y = double(betaVPD_maps{sc}(mk));
    scatter(ax, x, y, 8, 'filled', 'MarkerFaceAlpha',0.18, 'MarkerEdgeAlpha',0.18);

    % fit line
    add_linear_fitline(ax, x, y);

    grid(ax,'on'); box(ax,'off');
    xlabel(ax,'Aridity Index');
    ylabel(ax,'\beta_{VPD} (standardized)');
    title(ax, sprintf('VPD-limited | %s', scaleTitles{sc}), 'FontWeight','bold');
    [r0,p0] = corr(x(:), y(:), 'Type','Pearson', 'Rows','complete');
    if isfinite(r0) && isfinite(p0)
        text(ax,0.02,0.98,sprintf('r=%.2f, p=%.2g', r0, p0),...
            'Units','normalized','HorizontalAlignment','left','VerticalAlignment','top',...
            'FontWeight','bold','FontSize',11);
    end
end

exportgraphics(gcf,outFig6,'Resolution',300);
fprintf('✅ FIG6 Saved: %s\n', outFig6);

%% =========================================================================================
%% ===================== FIG7: Violin beta by vegetation type (2×3) =========================
vegNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'};
vegCols = [ ...
    0.20 0.45 0.20;  % ENF
    0.10 0.60 0.40;  % EBF
    0.15 0.35 0.55;  % DNF
    0.55 0.25 0.25;  % DBF
    0.35 0.60 0.25;  % MF
    0.55 0.55 0.20;  % SHL
    0.35 0.35 0.65;  % SVA
    0.90 0.55 0.15;  % GRA
    0.20 0.70 0.80]; % WET

figure('Color','w','Position',[120 -80 1650 920]);
tiledlayout(2,3,'Padding','compact','TileSpacing','compact');

for sc = 1:3
    % SW-limited
    ax = nexttile(sc); hold(ax,'on');
    mk_base = valid_mask & (WL_maps{sc}==1) & isfinite(betaSW_maps{sc});
    dataCell = collect_by_veg(double(betaSW_maps{sc}), IGBP, mk_base);
    violin_groupplot_colored(ax, dataCell, vegNames, vegCols);
    ylabel(ax,'\beta_{SW} (standardized)');
    title(ax, sprintf('SW-limited | %s', scaleTitles{sc}), 'FontWeight','bold');

    % VPD-limited
    ax = nexttile(3+sc); hold(ax,'on');
    mk_base = valid_mask & (WL_maps{sc}==2) & isfinite(betaVPD_maps{sc});
    dataCell = collect_by_veg(double(betaVPD_maps{sc}), IGBP, mk_base);
    violin_groupplot_colored(ax, dataCell, vegNames, vegCols);
    ylabel(ax,'\beta_{VPD} (standardized)');
    title(ax, sprintf('VPD-limited | %s', scaleTitles{sc}), 'FontWeight','bold');
end

% LT panels y-lim
axLT1 = nexttile(3); ylim(axLT1,[-1 1]);
axLT2 = nexttile(6); ylim(axLT2,[-1 1]);

exportgraphics(gcf,outFig7,'Resolution',300);
fprintf('✅ FIG7 Saved: %s\n', outFig7);

fprintf('\nALL DONE. Total time: %.1f s\n', toc(tAll));

%% =========================================================================================
%% ===================================== HELPERS ==========================================

function add_linear_fitline(ax, x, y)
x = double(x(:)); y = double(y(:));
mk = isfinite(x) & isfinite(y);
x = x(mk); y = y(mk);
if numel(x) < 30, return; end

% robust-ish: simple polyfit on trimmed extremes (reduce leverage)
q1 = prctile(x,1); q2 = prctile(x,99);
mk2 = (x>=q1) & (x<=q2);
x2 = x(mk2); y2 = y(mk2);
if numel(x2) < 30
    x2 = x; y2 = y;
end

p = polyfit(x2, y2, 1);
xx = linspace(min(x2), max(x2), 60);
yy = polyval(p, xx);

plot(ax, xx, yy, 'k-', 'LineWidth',1.4);

% show slope
txt = sprintf('slope=%.3f', p(1));
text(ax,0.02,0.88,txt,...
    'Units','normalized','HorizontalAlignment','left','VerticalAlignment','top',...
    'FontWeight','bold','FontSize',11);
end

function [ok, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, t, p, r, co2, useCO2, minN, Kfold_outer, lambda)
ok=false; beta=[]; R2cv=NaN;

y=y(:); sw=sw(:); vpd=vpd(:); t=t(:); p=p(:); r=r(:);
if useCO2, co2=co2(:); end

if useCO2
    mk0 = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd)&isfinite(t)&isfinite(p)&isfinite(r)&isfinite(co2);
else
    mk0 = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd)&isfinite(t)&isfinite(p)&isfinite(r);
end
if nnz(mk0) < minN, return; end

y  = double(y(mk0));
sw = double(sw(mk0));
vpd= double(vpd(mk0));
t  = double(t(mk0));
pp = double(p(mk0));
rr = double(r(mk0));
if useCO2, co2 = double(co2(mk0)); end

if ~useCO2
    Xraw = [sw, vpd, t, pp, rr];
else
    Xraw = [sw, vpd, t, pp, rr, co2];
end

M = [y Xraw];
good = all(isfinite(M),2);
y = y(good); Xraw = Xraw(good,:);

n = size(Xraw,1);
if n < minN, return; end

K = min(Kfold_outer, n);
folds = blocked_kfold(n, K);

yhat = nan(n,1);
ytrue_all = nan(n,1);

for k=1:K
    te = folds{k};
    tr = true(n,1); tr(te)=false;

    Xtr0 = Xraw(tr,:); ytr0 = y(tr);
    Xte0 = Xraw(te,:); yte0 = y(te);

    [Xtr, muX, sigX] = zscore_train_apply(Xtr0);
    Xte = (Xte0 - muX) ./ sigX;

    [ytr, muy, sigy] = zscore_train_apply(ytr0);
    yte = (yte0 - muy) ./ sigy;

    if any(~isfinite(Xtr(:))) || any(~isfinite(Xte(:))) || any(~isfinite(ytr)) || any(~isfinite(yte))
        continue;
    end

    try
        mdl = fitrlinear(Xtr, ytr, 'Learner','leastsquares', ...
            'Regularization','ridge', 'Lambda',lambda, 'FitBias',true);
        yhat(te) = predict(mdl, Xte);
        ytrue_all(te) = yte;
    catch
    end
end

good2 = isfinite(yhat) & isfinite(ytrue_all);
if nnz(good2) < max(10, round(0.6*n)), return; end

ssRes = sum((ytrue_all(good2) - yhat(good2)).^2);
ssTot = sum((ytrue_all(good2) - mean(ytrue_all(good2))).^2);
if ssTot <= 0, return; end
R2cv = 1 - ssRes/ssTot;

Xfull = zscore(Xraw);
yfull = zscore(y);
goodF = all(isfinite([yfull Xfull]),2);
Xfull = Xfull(goodF,:); yfull = yfull(goodF);

nF = size(Xfull,1);
if nF < minN, return; end

try
    mdlF = fitrlinear(Xfull, yfull, 'Learner','leastsquares', ...
        'Regularization','ridge', 'Lambda',lambda, 'FitBias',true);
    beta = mdlF.Beta';
catch
    beta=[]; return;
end

if any(~isfinite(beta)), beta=[]; return; end
ok=true;
end

function A = read_raw_3d_auto(path, shape2, Tlen, rawLen, sFrom, sTo)
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);
nTot = numel(dat);
n1 = nx*ny*Tlen;
n2 = nx*ny*rawLen;
if nTot == n1
    A = reshape(dat, [nx, ny, Tlen]);
elseif nTot == n2
    A = reshape(dat, [nx, ny, rawLen]);
    A = A(:,:,sFrom:sTo);
else
    error('Unexpected file size for %s: got %d floats; expected %d (420) or %d (468).', path, nTot, n1, n2);
end
end

function A = read_raw_2d_single(path, shape2)
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end

function CO2 = read_raw_3d_fixed492_slice420(path, nx, ny, co2Len, sFrom, sTo)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s', path);
tmp = fread(fid, nx*ny*co2Len, 'single');
fclose(fid);
tmp = reshape(tmp, [nx, ny, co2Len]);
CO2 = tmp(:,:,sFrom:sTo);
end

function folds = blocked_kfold(n, K)
edges = round(linspace(0, n, K+1));
folds = cell(K,1);
for k=1:K
    a = edges(k)+1; b = edges(k+1);
    folds{k} = (a:b)';
end
end

function [Z, mu, sig] = zscore_train_apply(X)
mu  = mean(X,1,'omitnan');
sig = std(X,0,1,'omitnan');
sig(sig < 1e-12) = 1;
Z = (X - mu) ./ sig;
end

function dataCell = collect_by_veg(valMap, IGBP, mk_base)
dataCell = cell(1,9);
if ~any(mk_base(:)), return; end

mk = mk_base & isfinite(valMap);

dataCell{1} = valMap(mk & (IGBP==1));                     % ENF
dataCell{2} = valMap(mk & (IGBP==2));                     % EBF
dataCell{3} = valMap(mk & (IGBP==3));                     % DNF
dataCell{4} = valMap(mk & (IGBP==4));                     % DBF
dataCell{5} = valMap(mk & (IGBP==5));                     % MF
dataCell{6} = valMap(mk & (IGBP==6 | IGBP==7));           % SHL
dataCell{7} = valMap(mk & (IGBP==8 | IGBP==9));           % SVA
dataCell{8} = valMap(mk & (IGBP==10));                    % GRA
dataCell{9} = valMap(mk & (IGBP==11));                    % WET
end

function violin_groupplot_colored(ax, dataCell, labels, cols)
G = numel(dataCell);
hold(ax,'on');

x = 1:G;
maxW = 0.38;

for g = 1:G
    d = dataCell{g};
    d = d(isfinite(d));
    if numel(d) < 20
        if ~isempty(d)
            jitter = (rand(size(d))-0.5)*0.18;
            scatter(ax, x(g)+jitter, d, 6, 'filled', ...
                'MarkerFaceColor', cols(g,:), 'MarkerEdgeColor','none', ...
                'MarkerFaceAlpha',0.12);
            plot(ax, [x(g)-0.16 x(g)+0.16], [median(d) median(d)], 'k-', 'LineWidth',1.1);
        end
        continue;
    end

    try
        [f,yy] = ksdensity(d, 'NumPoints', 160);
    catch
        yy = linspace(min(d), max(d), 160);
        f = ones(size(yy));
    end
    f = f / max(f) * maxW;

    xp = [x(g)-f, fliplr(x(g)+f)];
    yp = [yy,     fliplr(yy)];
    patch(ax, xp, yp, cols(g,:), 'EdgeColor','none', 'FaceAlpha',0.55);

    plot(ax, [x(g) x(g)], [min(yy) max(yy)], 'k-', 'LineWidth',0.6, 'Color',[0 0 0 0.35]);

    md = median(d);
    plot(ax, [x(g)-0.16 x(g)+0.16], [md md], 'k-', 'LineWidth',1.2);
end

set(ax,'XTick',x,'XTickLabel',labels,'TickDir','out','FontSize',11);
xtickangle(ax,45);
grid(ax,'on'); box(ax,'off');
xlim(ax,[0.5 G+0.5]);
end
