% %% =========================================================================================
% % RS ONLY (Monthly/Annual/Long-term; CSIF) | 2001–2020 alignment
% % Ridge (NO interactions)
% % FIG1: coef mean±SEM (CV-R2>R2_keep_for_coef)  | 3 classes × 3 RS scales
% % FIG2: CV-R2 hist                              | 3 classes × 3 RS scales
% % FIG3: RS Long-term only partial-residual quantile curves (2×2)
% % FIG4: conditional-slope summary (FULL 2001–2020)
% %
% % REMOVED:
% %   - ALL FLUXNET parts
% %   - FIG5 dominance bars
% %   - FIG1/FIG2 FLUXNET columns
% %
% % THIS EDIT (CSIF + 2001–2020 alignment):
% %   - Replace RS GPP with CSIF (all RS scales are 720×360×264; 2001–2022 monthly)
% %   - All variables (CSIF + ERA5 env + CO2 + WL maps) are aligned to 2001–2020 only
% %       * CSIF 264 (2001–2022) -> 1:240 (2001–2020)
% %       * ERA5 monthly 468 (1982–2020) -> 229:468 (2001–2020)
% %       * CO2 492 (1982–2022) -> 229:468 (2001–2020)
% %   - WL background maps folder:
% %       G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF
% %
% % Tested: MATLAB R2021a
% % -----------------------------------------------------------------------------------------
% 
% clear; clc; close all; warning('off','all');
% set(groot,'DefaultAxesFontName','Arial');
% set(groot,'DefaultTextFontName','Arial');
% rng(2025);
% 
% tAll = tic;
% 
% %% ===================== Ridge settings =====================
% Kfold_outer = 5;
% minN_ridge_rs   = 40;
% R2_keep_for_coef = 0;
% ridgeLambda = 0.05;
% 
% %% ===================== RS Paths (CSIF + original env paths) =====================
% rootFolder_RS = 'G:\Resource use efficiencies new\dataresult';
% lulcPath      = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';
% hfpPath       = 'G:\Resource use efficiencies new\dataprocessed\HFP05.tif';
% 
% % ---------- CSIF (ALL RS scales are 720×360×264; 2001–2022) ----------
% CSIF_MO_path = "G:\Resource use efficiencies new\dataprocessed\CSIF20012022_3D.raw"; % 720x360x264 (2001–2022)
% CSIF_AN_path = "G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CSIF05_SSA_Annual_3comp.raw"; % 720x360x264
% CSIF_LT_path = "G:\Resource use efficiencies new\dataresult\SSACEEMDAN\CSIF05_CEEMDAN_Trend_3comp.raw"; % 720x360x264
% 
% % ---------- Monthly env (keep original paths; 468 for 1982–2020) ----------
% T_MO_path   = "G:\Resource use efficiencies new\dataprocessed\t2m_1982_2020_resized_shifted.raw";  % 468
% P_MO_path   = "G:\Resource use efficiencies new\dataprocessed\tp_1982_2020_resized_shifted.raw";   % 468
% R_MO_path   = "G:\Resource use efficiencies new\dataprocessed\ssrd_1982_2020_resized_shifted.raw"; % 468
% SW_MO_path  = "G:\Resource use efficiencies new\dataprocessed\sw_total_1982_2020_resized_shifted.raw"; % 468
% VPD_MO_path = "G:\Resource use efficiencies new\dataprocessed\ERA5_VPD_1982_2020_monthly_720x360x468_f32_kPa.raw"; % 468
% 
% % ---------- Annual env (keep original paths) ----------
% T_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_SSA_Annual_4comp.raw');
% P_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_SSA_Annual_4comp.raw');
% R_AN_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_SSA_Annual_4comp.raw');
% SW_AN_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_SSA_Annual_4comp.raw');
% VPD_AN_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_SSA_Annual_4comp.raw');
% 
% % ---------- Long-term env + CO2 (keep original paths) ----------
% T_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','T05_CEEMDAN_Trend_4comp.raw');
% P_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','P05_CEEMDAN_Trend_4comp.raw');
% R_LT_path   = fullfile(rootFolder_RS,'SSACEEMDAN','R05_CEEMDAN_Trend_4comp.raw');
% SW_LT_path  = fullfile(rootFolder_RS,'SSACEEMDAN','SW05_CEEMDAN_Trend_4comp.raw');
% VPD_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','VPD05_CEEMDAN_Trend_4comp.raw');
% CO2_LT_path = fullfile(rootFolder_RS,'SSACEEMDAN','CO205_CEEMDAN_Trend_4comp.raw'); % 492 (1982–2022)
% 
% % ---------- WL maps (CHANGED folder) ----------
% WL_root_CSIF = 'G:\Resource use efficiencies new\dataresult\waterlimitregion\VPDandSWjudgeCSIF';
% WL_MO_path = fullfile(WL_root_CSIF,'WLclass_Monthly_q25_ttest_pcor_GS0p2P90_f32_720x360.raw');
% WL_AN_path = fullfile(WL_root_CSIF,'WLclass_Annual_q25_ttest_pcor_f32_720x360.raw');
% WL_LT_path = fullfile(WL_root_CSIF,'WLclass_LongTerm_q25_ttest_pcor_CO2_f32_720x360.raw');
% 
% %% ===================== Outputs =====================
% outDir = 'D:\';
% if ~exist(outDir,'dir'), mkdir(outDir); end
% 
% outFig1 = fullfile(outDir, sprintf('FIG1_RIDGE_noInter_RS3scales_CVR2gt%.1f_lambda%.3f_CSIF_2001_2020.png', R2_keep_for_coef, ridgeLambda));
% outFig2 = fullfile(outDir, sprintf('FIG2_RIDGE_noInter_RS3scales_CVR2_hist_lambda%.3f_CSIF_2001_2020.png', ridgeLambda));
% outFig3 = fullfile(outDir, sprintf('FIG3_LongTerm_partialResidual_quantileCurves_CVR2gt%.1f_lambda%.3f_CSIF_2001_2020_2x2byWL.png', R2_keep_for_coef, ridgeLambda));
% outFig4 = fullfile(outDir, sprintf('FIG4_LongTerm_conditionalSlopes_FULL_2001_2020_lambda%.3f_CSIF.png', ridgeLambda));
% 
% %% ===================== Basic RS dims =====================
% nx = 720; ny = 360;
% 
% %% ===================== Check RS files =====================
% mustFiles_RS = {lulcPath,hfpPath,...
%     CSIF_MO_path, T_MO_path, P_MO_path, R_MO_path, SW_MO_path, VPD_MO_path,...
%     CSIF_AN_path, T_AN_path, P_AN_path, R_AN_path, SW_AN_path, VPD_AN_path,...
%     CSIF_LT_path, T_LT_path, P_LT_path, R_LT_path, SW_LT_path, VPD_LT_path, CO2_LT_path,...
%     WL_MO_path, WL_AN_path, WL_LT_path};
% 
% for k=1:numel(mustFiles_RS)
%     assert(isfile(mustFiles_RS{k}), 'File not found: %s', mustFiles_RS{k});
% end
% 
% %% ===================== RS mask =====================
% IGBP = imread(lulcPath)'; 
% HFP  = imread(hfpPath)';
% 
% assert(all(size(IGBP)==[nx ny]) && all(size(HFP)==[nx ny]), 'LULC/HFP must be 720x360');
% valid_mask = ismember(IGBP,1:10) & (HFP<=25);
% nValid_RS = nnz(valid_mask);
% fprintf('RS valid pixels (veg & HFP<=25): %d\n', nValid_RS);
% 
% %% ===================== Read RS WL maps =====================
% WL_MO = read_raw_2d_single(WL_MO_path,[nx ny]);
% WL_AN = read_raw_2d_single(WL_AN_path,[nx ny]);
% WL_LT = read_raw_2d_single(WL_LT_path,[nx ny]);
% 
% WL_MO(~ismember(WL_MO,[0 1 2 3 4])) = 0;
% WL_AN(~ismember(WL_AN,[0 1 2 3 4])) = 0;
% WL_LT(~ismember(WL_LT,[0 1 2 3 4])) = 0;
% 
% %% ===================== Read RS data blocks (ALIGN TO 2001–2020) =====================
% fprintf('Reading RS data blocks (CSIF aligned to 2001–2020)...\n');
% 
% % target window: 2001-01 .. 2020-12 (240 months)
% Tlen_target = 240;
% 
% % CSIF (2001–2022: 264) -> 1:240
% csifFrom = 1;
% csifTo   = 240;
% 
% % ERA5 env (1982–2020: 468) -> 2001–2020 => 229:468
% envFrom  = 229;
% envTo    = 468;
% 
% % Monthly (CSIF + env)
% CSIF_MO = read_raw_3d_slice_by_nt(CSIF_MO_path, [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% T_MO    = read_raw_3d_slice_by_nt(T_MO_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% P_MO    = read_raw_3d_slice_by_nt(P_MO_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% R_MO    = read_raw_3d_slice_by_nt(R_MO_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% SW_MO   = read_raw_3d_slice_by_nt(SW_MO_path,   [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% VPD_MO  = read_raw_3d_slice_by_nt(VPD_MO_path,  [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% 
% % Annual
% CSIF_AN = read_raw_3d_slice_by_nt(CSIF_AN_path, [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% T_AN    = read_raw_3d_slice_by_nt(T_AN_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% P_AN    = read_raw_3d_slice_by_nt(P_AN_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% R_AN    = read_raw_3d_slice_by_nt(R_AN_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% SW_AN   = read_raw_3d_slice_by_nt(SW_AN_path,   [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% VPD_AN  = read_raw_3d_slice_by_nt(VPD_AN_path,  [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% 
% % Long-term
% CSIF_LT = read_raw_3d_slice_by_nt(CSIF_LT_path, [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% T_LT    = read_raw_3d_slice_by_nt(T_LT_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% P_LT    = read_raw_3d_slice_by_nt(P_LT_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% R_LT    = read_raw_3d_slice_by_nt(R_LT_path,    [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% SW_LT   = read_raw_3d_slice_by_nt(SW_LT_path,   [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% VPD_LT  = read_raw_3d_slice_by_nt(VPD_LT_path,  [nx,ny], Tlen_target, csifFrom, csifTo, envFrom, envTo);
% 
% % CO2: 492 (1982–2022) -> 2001–2020 => 229:468 (240)
% CO2_LT  = read_raw_3d_fixedLen_slice(CO2_LT_path, nx, ny, 492, envFrom, envTo);
% 
% fprintf('RS data loaded.\n');
% 
% %% =========================================================================================
% %% ===================== Containers for RS 3 scales × 4 classes ============================
% % rows: 1 MO(RS), 2 AN(RS), 3 LT(RS)
% coefCell = cell(3,4);   % store beta only if CV-R2 > R2_keep_for_coef
% r2Cell   = cell(3,4);   % store all CV-R2
% 
% scaleNames = {'Monthly (RS)','Annual (RS)','Long-term (RS)'};
% classNames = {'SW-limited','VPD-limited','Co-limited','Average'};
% 
% termNames_noCO2 = {'SW','VPD','T','P','R'};
% termNames_CO2   = {'SW','VPD','T','P','R','CO2'};
% 
% %% =========================================================================================
% %% ===================== RS ridge by WL maps ===============================================
% fprintf('\n================== RS | ridge by WL maps (CSIF 2001–2020) ==================\n');
% 
% % FIG3 accumulators (RS long-term only; FULL period within 2001–2020)
% nbinsX   = 10;
% nbinsCtl = 8;
% xCenters = 5:10:95;
% 
% sum_SW_LT  = zeros(2, nbinsCtl, nbinsX);
% cnt_SW_LT  = zeros(2, nbinsCtl, nbinsX);
% sum_VPD_LT = zeros(2, nbinsCtl, nbinsX);
% cnt_VPD_LT = zeros(2, nbinsCtl, nbinsX);
% 
% tRow = tic;
% nVisited = 0;
% nValidBase = nnz(valid_mask);
% 
% for i = 1:nx
%     for j = 1:ny
%         if ~valid_mask(i,j), continue; end
%         nVisited = nVisited + 1;
% 
%         % ---------- RS Monthly (row 1) ----------
%         c = WL_MO(i,j);
%         if c>=1 && c<=3
%             y  = squeeze(CSIF_MO(i,j,:));
%             sw = squeeze(SW_MO(i,j,:));
%             vpd= squeeze(VPD_MO(i,j,:));
%             tt = squeeze(T_MO(i,j,:));
%             pp = squeeze(P_MO(i,j,:));
%             rr = squeeze(R_MO(i,j,:));
% 
%             [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, [], false, minN_ridge_rs, Kfold_outer, ridgeLambda);
%             if okR
%                 r2Cell{1,c} = [r2Cell{1,c}; R2cv]; %#ok<AGROW>
%                 r2Cell{1,4} = [r2Cell{1,4}; R2cv]; %#ok<AGROW>
%                 if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%                     coefCell{1,c} = [coefCell{1,c}; beta]; %#ok<AGROW>
%                     coefCell{1,4} = [coefCell{1,4}; beta]; %#ok<AGROW>
%                 end
%             end
%         end
% 
%         % ---------- RS Annual (row 2) ----------
%         c = WL_AN(i,j);
%         if c>=1 && c<=3
%             y  = squeeze(CSIF_AN(i,j,:));
%             sw = squeeze(SW_AN(i,j,:));
%             vpd= squeeze(VPD_AN(i,j,:));
%             tt = squeeze(T_AN(i,j,:));
%             pp = squeeze(P_AN(i,j,:));
%             rr = squeeze(R_AN(i,j,:));
% 
%             [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, [], false, minN_ridge_rs, Kfold_outer, ridgeLambda);
%             if okR
%                 r2Cell{2,c} = [r2Cell{2,c}; R2cv]; %#ok<AGROW>
%                 r2Cell{2,4} = [r2Cell{2,4}; R2cv]; %#ok<AGROW>
%                 if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%                     coefCell{2,c} = [coefCell{2,c}; beta]; %#ok<AGROW>
%                     coefCell{2,4} = [coefCell{2,4}; beta]; %#ok<AGROW>
%                 end
%             end
%         end
% 
%         % ---------- RS Long-term (row 3) ----------
%         c = WL_LT(i,j);
%         if c>=1 && c<=3
%             y  = squeeze(CSIF_LT(i,j,:));
%             sw = squeeze(SW_LT(i,j,:));
%             vpd= squeeze(VPD_LT(i,j,:));
%             tt = squeeze(T_LT(i,j,:));
%             pp = squeeze(P_LT(i,j,:));
%             rr = squeeze(R_LT(i,j,:));
%             co2= squeeze(CO2_LT(i,j,:));
% 
%             [okR, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, tt, pp, rr, co2, true, minN_ridge_rs, Kfold_outer, ridgeLambda);
%             if okR
%                 r2Cell{3,c} = [r2Cell{3,c}; R2cv]; %#ok<AGROW>
%                 r2Cell{3,4} = [r2Cell{3,4}; R2cv]; %#ok<AGROW>
% 
%                 if isfinite(R2cv) && (R2cv > R2_keep_for_coef)
%                     coefCell{3,c} = [coefCell{3,c}; beta]; %#ok<AGROW>
%                     coefCell{3,4} = [coefCell{3,4}; beta]; %#ok<AGROW>
% 
%                     % FIG3 accumulators only for SW-limited or VPD-limited
%                     if c==1 || c==2
%                         regionRow = c; % 1 SW-limited; 2 VPD-limited
%                         [sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT] = add_fig3_quantile_curves_longterm_only( ...
%                             regionRow, sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT, ...
%                             y, sw, vpd, tt, pp, rr, co2, beta);
%                     end
%                 end
%             end
%         end
%     end
% 
%     if mod(i,40)==0
%         pct = 100*(nVisited/max(nValidBase,1));
%         fprintf('  RS row %3d/720 | visited %d/%d (%.1f%%) | elapsed %.1fs\n', ...
%             i, nVisited, nValidBase, pct, toc(tRow));
%         tRow = tic;
%     end
% end

fprintf('RS ridge done.\n');
close all;

%% =========================================================================================
%% ===================== FIG1: coefficients (3 classes × 3 RS scales) =======================
col_SW  = [0.63 0.82 0.45];
col_VPD = [0.55 0.40 0.74];
col_T   = [0.96 0.51 0.49];
col_P   = [0.25 0.63 0.76];
col_R   = [0.96 0.72 0.36];
col_CO2 = [0.70 0.70 0.70];

fs_tick  = 10;
fs_title = 11;

figure('Color','w','Position',[150 80 1100 850]);
tiledlayout(3,3,'Padding','compact','TileSpacing','compact');

classIdxList = 1:3; % remove Average
rowsRS = 1:3;       % MO, AN, LT

for ri = 1:3
    ci = classIdxList(ri); % 1=SW-limited 2=VPD-limited 3=Co-limited

    for si = 1:3
        ax = nexttile((ri-1)*3 + si);
        B  = coefCell{rowsRS(si),ci};

        if isempty(B)
            axis(ax,'off');
            title(ax, sprintf('%s | %s | n=0', scaleNames{si}, classNames{ci}), ...
                'FontSize',fs_title,'FontWeight','bold');
            continue;
        end

        m   = mean(B,1,'omitnan');
        sd  = std(B,0,1,'omitnan');
        n   = size(B,1);
        sem = sd ./ sqrt(max(n,1));

        isLongTermRS = (si==3); % only RS LT uses CO2

        if ~isLongTermRS
            termColors = [col_SW; col_VPD; col_T; col_P; col_R];
            x_plot = 1:numel(termNames_noCO2);

            bh = bar(ax, x_plot, m, 0.78); hold(ax,'on');
            bh.FaceColor = 'flat';
            bh.CData = termColors;

            errorbar(ax, x_plot, m, sem, 'k', 'LineStyle','none','LineWidth',0.8);
            yline(ax,0,'k-','LineWidth',0.8);
            set(ax,'XTick',x_plot,'XTickLabel',termNames_noCO2,'FontSize',fs_tick,'TickDir','out');
        else
            termColors = [col_SW; col_VPD; col_T; col_P; col_R; col_CO2];
            x_plot = 1:numel(termNames_CO2);

            bh = bar(ax, x_plot, m, 0.78); hold(ax,'on');
            bh.FaceColor = 'flat';
            bh.CData = termColors;

            errorbar(ax, x_plot, m, sem, 'k', 'LineStyle','none','LineWidth',0.8);
            yline(ax,0,'k-','LineWidth',0.8);
            set(ax,'XTick',x_plot,'XTickLabel',termNames_CO2,'FontSize',fs_tick,'TickDir','out');
        end

        grid(ax,'on'); box(ax,'off'); xtickangle(ax,45);
        title(ax, sprintf('%s | %s', scaleNames{si}, classNames{ci}), ...
            'FontSize',fs_title,'FontWeight','bold');

        if si==1
            text(ax,-0.55,0.50,classNames{ci},'Units','normalized', ...
                'Rotation',90,'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontSize',fs_title,'FontWeight','bold');
        end
    end
end

exportgraphics(gcf,outFig1,'Resolution',300);
fprintf('✅ FIG1 Saved: %s\n', outFig1);

%% =========================================================================================
%% ===================== FIG2: CV-R2 histograms (3 classes × 3 RS scales) ==================
figure('Color','w','Position',[150 80 1100 850]);
tiledlayout(3,3,'Padding','compact','TileSpacing','compact');

edges = linspace(-0.5, 1, 31);

for ri = 1:3
    ci = classIdxList(ri);

    for si = 1:3
        ax = nexttile((ri-1)*3 + si);
        R2 = r2Cell{rowsRS(si),ci};

        if isempty(R2)
            axis(ax,'off');
            title(ax, sprintf('%s | %s | n=0', scaleNames{si}, classNames{ci}), ...
                'FontSize',fs_title,'FontWeight','bold');
            continue;
        end

        R2 = R2(isfinite(R2));
        histogram(ax, R2, edges); hold(ax,'on');
        xline(ax, R2_keep_for_coef, 'k--', 'LineWidth', 1.0);

        grid(ax,'on'); box(ax,'off');
        xlim(ax,[edges(1) edges(end)]);
        xlabel(ax,'CV-R^2'); ylabel(ax,'Count');

        title(ax, sprintf('%s | %s', scaleNames{si}, classNames{ci}), ...
            'FontSize',fs_title,'FontWeight','bold');

        if si==1
            text(ax,-0.55,0.50,classNames{ci},'Units','normalized', ...
                'Rotation',90,'HorizontalAlignment','center','VerticalAlignment','middle', ...
                'FontSize',fs_title,'FontWeight','bold');
        end
    end
end

exportgraphics(gcf,outFig2,'Resolution',300);
fprintf('✅ FIG2 Saved: %s\n', outFig2);

%% =========================================================================================
%% ===================== FIG3: RS Long-term quantile curves (2×2) ==========================
mean_SW_LT  = sum_SW_LT  ./ max(cnt_SW_LT,  1);
mean_VPD_LT = sum_VPD_LT ./ max(cnt_VPD_LT, 1);

ctlLabels = {'10–20%','20–30%','30–40%','40–50%','50–60%','60–70%','70–80%','80–90%'};
rowNames  = {'SW-limited','VPD-limited'};

colsVPD = make_color_gradient([0.55 0.40 0.74], nbinsCtl);
colsSW  = make_color_gradient([0.63 0.82 0.45], nbinsCtl);

pos0 = [0 0 1450 900];
pos0(3) = round(pos0(3)*0.70);
figure('Color','w','Position',pos0);

tlo = tiledlayout(2,2,'Padding','compact','TileSpacing','compact');
tlo.Units = 'normalized';
tlo.OuterPosition = [0 0.15 1 0.74];

hLegendLeft  = gobjects(nbinsCtl,1);
hLegendRight = gobjects(nbinsCtl,1);

for rr = 1:2
    ax1 = nexttile((rr-1)*2 + 1); hold(ax1,'on');
    h1 = gobjects(nbinsCtl,1);
    for k = 1:nbinsCtl
        yk = squeeze(mean_SW_LT(rr,k,:));
        if all(~isfinite(yk)), continue; end
        h1(k) = plot(ax1, xCenters, yk(:), '-o', 'LineWidth',1.2,'MarkerSize',4,'Color',colsVPD(k,:));
    end
    yline(ax1,0,'k-','LineWidth',0.8);
    xlim(ax1,[0 100]); ylim(ax1,[-1 1]);
    grid(ax1,'on'); box(ax1,'off');
    xlabel(ax1,'SW (percentile)');
    ylabel(ax1,'CSIF residual (z-score)');
    title(ax1, sprintf('Long-term | %s | CSIF–SW (control VPD bins)', rowNames{rr}), 'FontWeight','bold');
    if rr==2, hLegendLeft = h1; end

    ax2 = nexttile((rr-1)*2 + 2); hold(ax2,'on');
    h2 = gobjects(nbinsCtl,1);
    for k = 1:nbinsCtl
        yk = squeeze(mean_VPD_LT(rr,k,:));
        if all(~isfinite(yk)), continue; end
        h2(k) = plot(ax2, xCenters, yk(:), '-o', 'LineWidth',1.2,'MarkerSize',4,'Color',colsSW(k,:));
    end
    yline(ax2,0,'k-','LineWidth',0.8);
    xlim(ax2,[0 100]); ylim(ax2,[-1 1]);
    grid(ax2,'on'); box(ax2,'off');
    xlabel(ax2,'VPD (percentile)');
    ylabel(ax2,'CSIF residual (z-score)');
    title(ax2, sprintf('Long-term | %s | CSIF–VPD (control SW bins)', rowNames{rr}), 'FontWeight','bold');
    if rr==2, hLegendRight = h2; end
end

keepL = isgraphics(hLegendLeft);
keepR = isgraphics(hLegendRight);

lgdL = legend(hLegendLeft(keepL), strcat('VPD = ', ctlLabels(keepL)), 'NumColumns',2,'Location','none'); lgdL.Box = 'off';
lgdR = legend(hLegendRight(keepR), strcat('SW = ', ctlLabels(keepR)), 'NumColumns',2,'Location','none'); lgdR.Box = 'off';

set(lgdL,'Units','normalized'); set(lgdR,'Units','normalized');
lgdL.Position = [0.06 -0.1 0.40 0.15];
lgdR.Position = [0.54 -0.1 0.40 0.15];

exportgraphics(gcf, outFig3, 'Resolution', 300);
fprintf('✅ FIG3 Saved: %s\n', outFig3);

%% =========================================================================================
%% ===================== FIG4: conditional-slope summary (FULL period 2001–2020) ============
mean_SW_LT_full  = sum_SW_LT  ./ max(cnt_SW_LT,  1);
mean_VPD_LT_full = sum_VPD_LT ./ max(cnt_VPD_LT, 1);

slopes_VPD_given_SW_full = compute_slopes_from_lines(mean_VPD_LT_full, xCenters);
slopes_SW_given_VPD_full = compute_slopes_from_lines(mean_SW_LT_full,  xCenters);

colsVPD_bins = make_color_gradient(col_VPD, 8);
colsSW_bins  = make_color_gradient(col_SW,  8);

figure('Color','w','Position',[200 120 620 520]);
ax = axes; hold(ax,'on');

xG  = [1 2 3 4];
jit = linspace(-0.14, 0.14, 8);

% ================= SW-limited =================
rr = 1;
for k = 1:8
    yk = slopes_VPD_given_SW_full(rr,k);
    if ~isfinite(yk), continue; end
    scatter(ax, xG(1)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsVPD_bins(k,:), ...
        'MarkerEdgeColor','w','MarkerFaceAlpha',0.95);
end
scatter(ax, xG(1), mean(slopes_VPD_given_SW_full(rr,:), 'omitnan'), 70,'ks','filled');

for k = 1:8
    yk = slopes_SW_given_VPD_full(rr,k);
    if ~isfinite(yk), continue; end
    scatter(ax, xG(2)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsSW_bins(k,:), ...
        'MarkerEdgeColor','w','MarkerFaceAlpha',0.95);
end
scatter(ax, xG(2), mean(slopes_SW_given_VPD_full(rr,:), 'omitnan'), 70,'ks','filled');

% ================= VPD-limited =================
rr = 2;
for k = 1:8
    yk = slopes_VPD_given_SW_full(rr,k);
    if ~isfinite(yk), continue; end
    scatter(ax, xG(3)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsVPD_bins(k,:), ...
        'MarkerEdgeColor','w','MarkerFaceAlpha',0.95);
end
scatter(ax, xG(3), mean(slopes_VPD_given_SW_full(rr,:), 'omitnan'), 70,'ks','filled');

for k = 1:8
    yk = slopes_SW_given_VPD_full(rr,k);
    if ~isfinite(yk), continue; end
    scatter(ax, xG(4)+jit(k), yk, 55, 'filled', ...
        'MarkerFaceColor', colsSW_bins(k,:), ...
        'MarkerEdgeColor','w','MarkerFaceAlpha',0.95);
end
scatter(ax, xG(4), mean(slopes_SW_given_VPD_full(rr,:), 'omitnan'), 70,'ks','filled');

yline(ax,0,'k--','LineWidth',0.9);
xline(ax,2.5,'k--','LineWidth',1.0);

set(ax,'XLim',[0.5 4.5],'TickDir','out','FontSize',11);
set(ax,'XTick',xG,'XTickLabel',{ ...
    'ΔCSIF(VPD | SW)', ...
    'ΔCSIF(SW | VPD)', ...
    'ΔCSIF(VPD | SW)', ...
    'ΔCSIF(SW | VPD)'});

ylabel(ax,'Slope (ΔCSIF residual per percentile)');
grid(ax,'on'); box(ax,'off');

yl = ylim(ax);
yTop = yl(2) - 0.05*range(yl);
text(ax,1.5,yTop,'SW-limited', 'HorizontalAlignment','center','FontWeight','bold','FontSize',12);
text(ax,3.5,yTop,'VPD-limited','HorizontalAlignment','center','FontWeight','bold','FontSize',12);

exportgraphics(gcf,outFig4,'Resolution',300);
fprintf('✅ FIG4 Saved (FULL period 2001–2020): %s\n', outFig4);

fprintf('\n✅ ALL DONE | Total time %.1f min\n', toc(tAll)/60);

%% =========================================================================================
%% ===================================== HELPERS ==========================================

function slopes = compute_slopes_from_lines(M3, xCenters)
slopes = nan(size(M3,1), size(M3,2));
x = xCenters(:);
for rr = 1:size(M3,1)
    for k = 1:size(M3,2)
        y = squeeze(M3(rr,k,:));
        mk = isfinite(x) & isfinite(y);
        if nnz(mk) < 3
            slopes(rr,k) = NaN;
            continue;
        end
        p = polyfit(x(mk), y(mk), 1);
        slopes(rr,k) = p(1);
    end
end
end

function [ok, beta, R2cv] = ridge_one_series_noInter(y, sw, vpd, t, p, r, co2, useCO2, minN, Kfold_outer, lambda)
ok=false; beta=[]; R2cv=NaN;

y=y(:); sw=sw(:); vpd=vpd(:); t=t(:); p=p(:); r=r(:);
if useCO2, co2=co2(:); end

if useCO2
    mk0 = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd)&isfinite(t)&isfinite(p)&isfinite(r)&isfinite(co2);
else
    mk0 = isfinite(y)&(y>0)&isfinite(sw)&isfinite(vpd)&isfinite(t)&isfinite(p)&isfinite(r);
end

if nnz(mk0) < minN, return; end

y  = double(y(mk0));
sw = double(sw(mk0));
vpd= double(vpd(mk0));
t  = double(t(mk0));
pp = double(p(mk0));
rr = double(r(mk0));
if useCO2, co2 = double(co2(mk0)); end

if ~useCO2
    Xraw = [sw, vpd, t, pp, rr];
else
    Xraw = [sw, vpd, t, pp, rr, co2];
end

M = [y Xraw];
good = all(isfinite(M),2);
y = y(good); Xraw = Xraw(good,:);

n = size(Xraw,1);
if n < minN, return; end

K = min(Kfold_outer, n);
folds = blocked_kfold(n, K);

yhat = nan(n,1);
ytrue_all = nan(n,1);

for k=1:K
    te = folds{k};
    tr = true(n,1); tr(te)=false;

    Xtr0 = Xraw(tr,:); ytr0 = y(tr);
    Xte0 = Xraw(te,:); yte0 = y(te);

    [Xtr, muX, sigX] = zscore_train_apply(Xtr0);
    Xte = (Xte0 - muX) ./ sigX;

    [ytr, muy, sigy] = zscore_train_apply(ytr0);
    yte = (yte0 - muy) ./ sigy;

    if any(~isfinite(Xtr(:))) || any(~isfinite(Xte(:))) || any(~isfinite(ytr)) || any(~isfinite(yte))
        continue;
    end

    try
        mdl = fitrlinear(Xtr, ytr, 'Learner','leastsquares', ...
            'Regularization','ridge', 'Lambda',lambda, 'FitBias',true);
        yhat(te) = predict(mdl, Xte);
        ytrue_all(te) = yte;
    catch
    end
end

good2 = isfinite(yhat) & isfinite(ytrue_all);
if nnz(good2) < max(10, round(0.6*n)), return; end

ssRes = sum((ytrue_all(good2) - yhat(good2)).^2);
ssTot = sum((ytrue_all(good2) - mean(ytrue_all(good2))).^2);
if ssTot <= 0, return; end
R2cv = 1 - ssRes/ssTot;

% coefficients on FULL standardized data
Xfull = zscore(Xraw);
yfull = zscore(y);
goodF = all(isfinite([yfull Xfull]),2);
Xfull = Xfull(goodF,:); yfull = yfull(goodF);

nF = size(Xfull,1);
if nF < minN, return; end

try
    mdlF = fitrlinear(Xfull, yfull, 'Learner','leastsquares', ...
        'Regularization','ridge', 'Lambda',lambda, 'FitBias',true);
    beta = mdlF.Beta';
catch
    beta=[]; return;
end

if any(~isfinite(beta)), beta=[]; return; end
ok=true;
end

function A = read_raw_3d_slice_by_nt(path, shape2, Tlen_target, csifFrom, csifTo, envFrom, envTo)
nx = shape2(1); ny = shape2(2);
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
dat = fread(fid, inf, 'single'); fclose(fid);

nTot = numel(dat);
assert(mod(nTot, nx*ny)==0, 'File size not divisible by nx*ny: %s', path);
nt = nTot/(nx*ny);

dat = reshape(dat, [nx, ny, nt]);

if nt == Tlen_target
    A = dat;
elseif nt == 264
    A = dat(:,:,csifFrom:csifTo);
elseif nt == 468
    A = dat(:,:,envFrom:envTo);
else
    error('Unsupported nt=%d for %s. Expected 240/264/468.', nt, path);
end

assert(size(A,3)==Tlen_target, 'Slice length mismatch for %s. got %d, need %d.', path, size(A,3), Tlen_target);
end

function A = read_raw_2d_single(path, shape2)
fid = fopen(path,'r'); assert(fid>0, 'Cannot open: %s', path);
A = fread(fid, prod(shape2), 'single'); fclose(fid);
A = reshape(A, shape2);
end

function X = read_raw_3d_fixedLen_slice(path, nx, ny, nt_fix, sFrom, sTo)
fid = fopen(path,'r'); assert(fid>0,'Cannot open: %s', path);
tmp = fread(fid, nx*ny*nt_fix, 'single');
fclose(fid);
tmp = reshape(tmp, [nx, ny, nt_fix]);
X = tmp(:,:,sFrom:sTo);
end

function folds = blocked_kfold(n, K)
edges = round(linspace(0, n, K+1));
folds = cell(K,1);
for k=1:K
    a = edges(k)+1; b = edges(k+1);
    folds{k} = (a:b)';
end
end

function [Z, mu, sig] = zscore_train_apply(X)
mu  = mean(X,1,'omitnan');
sig = std(X,0,1,'omitnan');
sig(sig < 1e-12) = 1;
Z = (X - mu) ./ sig;
end

function cols = make_color_gradient(baseColor, n)
cols = zeros(n,3);
for k = 1:n
    a = k/n;
    cols(k,:) = (1-a)*[1 1 1] + a*baseColor;
end
end

function [sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT] = add_fig3_quantile_curves_longterm_only( ...
    regionRow, sum_SW_LT, cnt_SW_LT, sum_VPD_LT, cnt_VPD_LT, ...
    y, sw, vpd, t, p, r, co2, beta)

y = y(:); sw = sw(:); vpd = vpd(:); t = t(:); p = p(:); r = r(:); co2 = co2(:);

mk0 = isfinite(y) & (y>0) & isfinite(sw) & isfinite(vpd) & isfinite(t) & isfinite(p) & isfinite(r) & isfinite(co2);
if nnz(mk0) < 40, return; end

y  = double(y(mk0));
sw = double(sw(mk0));
vpd= double(vpd(mk0));
t  = double(t(mk0));
pp = double(p(mk0));
rr = double(r(mk0));
co2= double(co2(mk0));

yz  = zscore(y);
tz  = zscore(t);
pz  = zscore(pp);
rz  = zscore(rr);
cz  = zscore(co2);

good = all(isfinite([yz tz pz rz cz sw vpd]),2);
yz = yz(good); tz = tz(good); pz = pz(good); rz = rz(good); cz = cz(good);
sw = sw(good); vpd = vpd(good);
if numel(yz) < 40, return; end

idx_nonwater = [3 4 5 6]; % T,P,R,CO2
Xnw = [tz, pz, rz, cz];
bNW = beta(idx_nonwater);
y_res = yz - Xnw * bNW(:);

swPct  = empirical_percentile(sw);
vpdPct = empirical_percentile(vpd);

swBin  = min(10, max(1, floor(swPct/10) + 1));
vpdBin = min(10, max(1, floor(vpdPct/10) + 1));

ctlBins = 2:9;  % 10–20..80–90

for vb = ctlBins
    ctlIdx = vb - 1;
    mk = (vpdBin == vb);
    if ~any(mk), continue; end
    sb = swBin(mk);
    yr = y_res(mk);

    for xb = 1:10
        mk2 = (sb == xb);
        if ~any(mk2), continue; end
        sum_SW_LT(regionRow, ctlIdx, xb) = sum_SW_LT(regionRow, ctlIdx, xb) + sum(yr(mk2), 'omitnan');
        cnt_SW_LT(regionRow, ctlIdx, xb) = cnt_SW_LT(regionRow, ctlIdx, xb) + nnz(isfinite(yr(mk2)));
    end
end

for sbc = ctlBins
    ctlIdx = sbc - 1;
    mk = (swBin == sbc);
    if ~any(mk), continue; end
    vb = vpdBin(mk);
    yr = y_res(mk);

    for xb = 1:10
        mk2 = (vb == xb);
        if ~any(mk2), continue; end
        sum_VPD_LT(regionRow, ctlIdx, xb) = sum_VPD_LT(regionRow, ctlIdx, xb) + sum(yr(mk2), 'omitnan');
        cnt_VPD_LT(regionRow, ctlIdx, xb) = cnt_VPD_LT(regionRow, ctlIdx, xb) + nnz(isfinite(yr(mk2)));
    end
end
end

function pct = empirical_percentile(x)
x = x(:);
n = numel(x);
if n < 2
    pct = zeros(size(x));
    return;
end
[~,~,rk] = unique(x, 'sorted');
pct = 100 * ((double(rk) - 0.5) / n);
end
