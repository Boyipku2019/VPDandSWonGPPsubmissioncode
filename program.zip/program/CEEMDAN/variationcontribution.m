
clear all;close all;clc;
IGBP=imread('G:\Resource use efficiencies new\dataprocessed\LULC05.tif');
IGBP=IGBP';
HFP=imread('G:\Resource use efficiencies new\dataprocessed\HFP05.tif');
HFP=HFP';



%%��ȡGPP����
Variationcontribution=single(zeros(720,360,4));
fid = fopen('G:\Resource use efficiencies new\dataresult\CEEMDAN\VariancecontributionCO205.raw','r'); %��RAW�ļ�
Variationcontribution = fread(fid,720*360*4,'single'); % ��RAW����
fclose(fid); % �ر��ļ�
Variationcontribution=reshape(Variationcontribution,[720,360,4]);

ENFshort=[];
EBFshort=[];
DNFshort=[];
DBFshort=[];
MFshort=[];
SHLshort=[];
SVAshort=[];
GRAshort=[];
WETshort=[];

ENFlong=[];
EBFlong=[];
DNFlong=[];
DBFlong=[];
MFlong=[];
SHLlong=[];
SVAlong=[];
GRAlong=[];
WETlong=[];


ENFInnerannual=[];
EBFInnerannual=[];
DNFInnerannual=[];
DBFInnerannual=[];
MFInnerannual=[];
SHLInnerannual=[];
SVAInnerannual=[];
GRAInnerannual=[];
WETInnerannual=[];

ENFInterannual=[];
EBFInterannual=[];
DNFInterannual=[];
DBFInterannual=[];
MFInterannual=[];
SHLInterannual=[];
SVAInterannual=[];
GRAInterannual=[];
WETInterannual=[];
%����ͳ�����ڱ仯
for i=1:720
    for j=1:360
      
       
                           if IGBP(i,j)==1&&HFP(i,j)<=25
                               ENFshort=[ENFshort;Variationcontribution(i,j,1)];
                               ENFlong=[ENFlong;Variationcontribution(i,j,2)];
                               ENFInnerannual=[ENFInnerannual;Variationcontribution(i,j,3)];
                              ENFInterannual=[ENFInterannual;Variationcontribution(i,j,4)];
                              aa=0;
                           end
                           if IGBP(i,j)==2&&HFP(i,j)<=25
                               
                               EBFshort=[EBFshort;Variationcontribution(i,j,1)];
                               EBFlong=[EBFlong;Variationcontribution(i,j,2)];
                               EBFInnerannual=[EBFInnerannual;Variationcontribution(i,j,3)];
                               EBFInterannual=[EBFInterannual;Variationcontribution(i,j,4)];
                           end
                           if IGBP(i,j)==3&&HFP(i,j)<=25
                               
                               DNFshort=[DNFshort;Variationcontribution(i,j,1)];
                               DNFlong=[DNFlong;Variationcontribution(i,j,2)];
                               DNFInnerannual=[DNFInnerannual;Variationcontribution(i,j,3)];
                              DNFInterannual=[DNFInterannual;Variationcontribution(i,j,4)];
                           end
                           if IGBP(i,j)==4&&HFP(i,j)<=25
                                
                                DBFshort=[DBFshort;Variationcontribution(i,j,1)];
                               DBFlong=[DBFlong;Variationcontribution(i,j,2)];
                              DBFInnerannual=[DBFInnerannual;Variationcontribution(i,j,3)];
                              DBFInterannual=[DBFInterannual;Variationcontribution(i,j,4)];
                           end
                           if IGBP(i,j)==5&&HFP(i,j)<=25
                                
                               MFshort=[MFshort;Variationcontribution(i,j,1)];
                               MFlong=[MFlong;Variationcontribution(i,j,2)];
                               MFInnerannual=[MFInnerannual;Variationcontribution(i,j,3)];
                              MFInterannual=[MFInterannual;Variationcontribution(i,j,4)];
                           end
                           if (IGBP(i,j)==6||IGBP(i,j)==7)&&HFP(i,j)<=25
                              
                               SHLshort=[SHLshort;Variationcontribution(i,j,1)];
                               SHLlong=[SHLlong;Variationcontribution(i,j,2)];
                               SHLInnerannual=[SHLInnerannual;Variationcontribution(i,j,3)];
                             SHLInterannual=[SHLInterannual;Variationcontribution(i,j,4)];
                           end
                           if (IGBP(i,j)==8||IGBP(i,j)==9)&&HFP(i,j)<=25
                               
                               SVAshort=[SVAshort;Variationcontribution(i,j,1)];
                               SVAlong=[SVAlong;Variationcontribution(i,j,2)];
                                 SVAInnerannual=[ SVAInnerannual;Variationcontribution(i,j,3)];
                               SVAInterannual=[  SVAInterannual;Variationcontribution(i,j,4)];
                           end
                           if IGBP(i,j)==10&&HFP(i,j)<=25
                               
                               GRAshort=[GRAshort;Variationcontribution(i,j,1)];
                               GRAlong=[GRAlong;Variationcontribution(i,j,2)];
                               GRAInnerannual=[GRAInnerannual;Variationcontribution(i,j,3)];
                              GRAInterannual=[ GRAInterannual;Variationcontribution(i,j,4)];
                           end
                           if IGBP(i,j)==11&&HFP(i,j)<=25
                                
                                WETshort=[WETshort;Variationcontribution(i,j,1)];
                               WETlong=[WETlong;Variationcontribution(i,j,2)];
                              WETInnerannual=[ WETInnerannual;Variationcontribution(i,j,3)];
                              WETInterannual=[ WETInterannual;Variationcontribution(i,j,4)];
                           end
                   
         
      

       
    end
    i
end




% Data Setup
data=single(zeros(9,4));
errors=single(zeros(9,4));

% Mean and standard deviation data setup
data(1,1)=mean(ENFshort);errors(1,1)=std(ENFshort);
data(1,2)=mean(ENFlong);errors(1,2)=std(ENFlong);
data(1,3)=mean(ENFInnerannual);errors(1,3)=std(ENFInnerannual);
data(1,4)=mean(ENFInterannual);errors(1,4)=std(ENFInterannual);

data(2,1)=mean(EBFshort);errors(2,1)=std(EBFshort);
data(2,2)=mean(EBFlong);errors(2,2)=std(EBFlong);
data(2,3)=mean(EBFInnerannual);errors(2,3)=std(EBFInnerannual);
data(2,4)=mean(EBFInterannual);errors(2,4)=std(EBFInterannual);

data(3,1)=mean(DNFshort);errors(3,1)=std(DNFshort);
data(3,2)=mean(DNFlong);errors(3,2)=std(DNFlong);
data(3,3)=mean(DNFInnerannual);errors(3,3)=std(DNFInnerannual);
data(3,4)=mean(DNFInterannual);errors(3,4)=std(DNFInterannual);

data(4,1)=mean(DBFshort);errors(4,1)=std(DBFshort);
data(4,2)=mean(DBFlong);errors(4,2)=std(DBFlong);
data(4,3)=mean(DBFInnerannual);errors(4,3)=std(DBFInnerannual);
data(4,4)=mean(DBFInterannual);errors(4,4)=std(DBFInterannual);

data(5,1)=mean(MFshort);errors(5,1)=std(MFshort);
data(5,2)=mean(MFlong);errors(5,2)=std(MFlong);
data(5,3)=mean(MFInnerannual);errors(5,3)=std(MFInnerannual);
data(5,4)=mean(MFInterannual);errors(5,4)=std(MFInterannual);

data(6,1)=mean(SHLshort);errors(6,1)=std(SHLshort);
data(6,2)=mean(SHLlong);errors(6,2)=std(SHLlong);
data(6,3)=mean(SHLInnerannual);errors(6,3)=std(SHLInnerannual);
data(6,4)=mean(SHLInterannual);errors(6,4)=std(SHLInterannual);

data(7,1)=mean(SVAshort);errors(7,1)=std(SVAshort);
data(7,2)=mean(SVAlong);errors(7,2)=std(SVAlong);
data(7,3)=mean(SVAInnerannual);errors(7,3)=std(SVAInnerannual);
data(7,4)=mean(SVAInterannual);errors(7,4)=std(SVAInterannual);

data(8,1)=mean(GRAshort);errors(8,1)=std(GRAshort);
data(8,2)=mean(GRAlong);errors(8,2)=std(GRAlong);
data(8,3)=mean(GRAInnerannual);errors(8,3)=std(GRAInnerannual);
data(8,4)=mean(GRAInterannual);errors(8,4)=std(GRAInterannual);

data(9,1)=mean(WETshort);errors(9,1)=std(WETshort);
data(9,2)=mean(WETlong);errors(9,2)=std(WETlong);
data(9,3)=mean(WETInnerannual);errors(9,3)=std(WETInnerannual);
data(9,4)=mean(WETInterannual);errors(9,4)=std(WETInterannual);

data=data*100;
errors=errors*100;

% Bar colors setup - adding a fourth color
colors = [
    0, 0.2, 0.6;   % Dark blue with adjusted saturation
    0, 0.5, 0.1;   % Dark green with adjusted saturation
   
    0.6 0.6 0.6; % Dark red with adjusted saturation 
   0.9 0.6 0.2; % Dark gray
];

% Creating the bar chart
figure;
% Set figure size [left, bottom, width, height] in pixels
set(gcf, 'Position', [100, 100, 900, 500]);  % Example size 800x600 pixels
hold on;
b = bar(data, 'grouped');

% Set the colors and widths of the bars
for k = 1:4
    b(k).FaceColor = colors(k, :);
    b(k).BarWidth = 1 * b(k).BarWidth;
end

% Adding error bars
ngroups = size(data, 1);
nbars = size(data, 2);
groupwidth = min(0.8, nbars/(nbars + 1.5));
for i = 1:nbars
    x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    errorbar(x, data(:,i), errors(:,i), 'k', 'linestyle', 'none', 'CapSize', 5);
end

% Setting axis labels and title
%xlabel('Group');
ylabel('Variation contribution');
set(gca, 'XTickLabel', {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET'});

% Adjusting the y-axis to show percentage
ytickformat('percentage');

% Adjusting the legend to include the fourth parameter
legend({'FirstIMF', 'LastIMF', 'Intra-annual group', 'Inter-annual group'}, ...
       'Location', 'southoutside', 'Orientation', 'horizontal');

% Improving appearance
box on;
grid on;
hold off;

% Save the figure as a high-resolution image suitable for publications
print('bar_chart_wider', '-dpng', '-r300');
