%% ===== 一次拟合 → 直接输出到韦恩图（区域=partial R²%） =====
clear; clc; rng(2025)

% ===== 1) 你的数据：把本段替换为真实 T, SW, R, Y(GPP) =====
n = 200;
Sigma = [1 0.30 0.20; 0.30 1 0.18; 0.20 0.18 1];
X = mvnrnd([0 0 0], Sigma, n);   % [T, SW, R]
T = X(:,1); SW = X(:,2); R = X(:,3);
% 例子里含主效应+交互
bT=0.55; bSW=0.45; bR=0.30; bTS=0.35; bTR=0.18; bSR=-0.25; bTSR=0.16;
Y = bT*T + bSW*SW + bR*R + bTS*(T.*SW) + bTR*(T.*R) + bSR*(SW.*R) ...
    + bTSR*(T.*SW.*R) + 1.15*randn(n,1);

% ===== 2) 一次拟合全模型：Y ~ T*SW*R =====
Z = zscore([T SW R]); Tz = Z(:,1); SWz = Z(:,2); Rz = Z(:,3);
tbl = table(Y,Tz,SWz,Rz,'VariableNames',{'Y','T','SW','R'});
mdl_full = fitlm(tbl,'Y ~ T*SW*R');

% 总平方和与全模型SSE/R²
SST = mdl_full.SST;
SSE_full = mdl_full.SSE;
R2_full  = 1 - SSE_full/SST;

% ===== 3) 对每个“具体项”做一次“移除该项再拟合”，算 partial R²（独立贡献）
SSE_noT   = fitlm(tbl,'Y ~ SW + R + T:SW + T:R + SW:R + T:SW:R').SSE;
SSE_noSW  = fitlm(tbl,'Y ~ T  + R + T:SW + T:R + SW:R + T:SW:R').SSE;
SSE_noR   = fitlm(tbl,'Y ~ T  + SW+ T:SW + T:R + SW:R + T:SW:R').SSE;
SSE_noTS  = fitlm(tbl,'Y ~ T + SW + R + T:R + SW:R + T:SW:R').SSE;
SSE_noTR  = fitlm(tbl,'Y ~ T + SW + R + T:SW + SW:R + T:SW:R').SSE;
SSE_noSR  = fitlm(tbl,'Y ~ T + SW + R + T:SW + T:R + T:SW:R').SSE;
SSE_noTSR = fitlm(tbl,'Y ~ T + SW + R + T:SW + T:R + SW:R').SSE;

dR2_T   = (SSE_noT   - SSE_full)/SST;
dR2_SW  = (SSE_noSW  - SSE_full)/SST;
dR2_R   = (SSE_noR   - SSE_full)/SST;
dR2_TS  = (SSE_noTS  - SSE_full)/SST;
dR2_TR  = (SSE_noTR  - SSE_full)/SST;
dR2_SR  = (SSE_noSR  - SSE_full)/SST;
dR2_TSR = (SSE_noTSR - SSE_full)/SST;

% 转为“占已解释方差的百分比”，并做数值清理/归一
pct = 100 * [dR2_T dR2_SW dR2_R dR2_TS dR2_TR dR2_SR dR2_TSR] / R2_full;
pct = max(pct,0);                               % 负值截0（数值误差）
pct = pct * (100/sum(pct));                     % 归一到总和=100%
[pct_T,pct_SW,pct_R,pct_TS,pct_TR,pct_SR,pct_TSR] = deal(pct(1),pct(2),pct(3),pct(4),pct(5),pct(6),pct(7));

% ===== 4) 画三圆韦恩图（区域内直接写百分比）
figure('Color','w','Position',[80 80 520 520]); axis off; axis equal; hold on
r = 1.2;
C1 = [-0.75,  0.30];  % 左 (T)
C2 = [ 0.75,  0.30];  % 右 (SW)
C3 = [ 0.00, -0.60];  % 下 (R)
cols = [0.50 0.70 0.90; 0.98 0.70 0.50; 0.60 0.85 0.60]; % 蓝/橙/绿
th = linspace(0,2*pi,600);
fill(C1(1)+r*cos(th), C1(2)+r*sin(th), cols(1,:), 'FaceAlpha',0.55, 'EdgeColor','none');
fill(C2(1)+r*cos(th), C2(2)+r*sin(th), cols(2,:), 'FaceAlpha',0.55, 'EdgeColor','none');
fill(C3(1)+r*cos(th), C3(2)+r*sin(th), cols(3,:), 'FaceAlpha',0.55, 'EdgeColor','none');
plot(C1(1)+r*cos(th), C1(2)+r*sin(th), 'Color',cols(1,:)*0.6);
plot(C2(1)+r*cos(th), C2(2)+r*sin(th), 'Color',cols(2,:)*0.6);
plot(C3(1)+r*cos(th), C3(2)+r*sin(th), 'Color',cols(3,:)*0.6);

% 文本位置（与示例图一致的视觉位置）
pos.onlyT   = C1 + [-0.30,  0.15];
pos.onlySW  = C2 + [ 0.30,  0.15];
pos.onlyR   = C3 + [ 0.00, -0.28];
pos.TS      = (C1+C2)/2 + [ 0.00, 0.38];
pos.TR      = (C1+C3)/2 + [-0.22,-0.05];
pos.SR      = (C2+C3)/2 + [ 0.22,-0.05];
pos.TSR     = [0, 0.00];

% 在区域内写百分比（保留两位小数）
fmt = @(x) sprintf('%.2f%%', x);
fs  = 12;
text(pos.onlyT(1),  pos.onlyT(2),  fmt(pct_T),   'HorizontalAlignment','center','FontSize',fs);
text(pos.onlySW(1), pos.onlySW(2), fmt(pct_SW),  'HorizontalAlignment','center','FontSize',fs);
text(pos.onlyR(1),  pos.onlyR(2),  fmt(pct_R),   'HorizontalAlignment','center','FontSize',fs);
text(pos.TS(1),     pos.TS(2),     fmt(pct_TS),  'HorizontalAlignment','center','FontSize',fs);
text(pos.TR(1),     pos.TR(2),     fmt(pct_TR),  'HorizontalAlignment','center','FontSize',fs);
text(pos.SR(1),     pos.SR(2),     fmt(pct_SR),  'HorizontalAlignment','center','FontSize',fs);
text(pos.TSR(1),    pos.TSR(2),    fmt(pct_TSR), 'HorizontalAlignment','center','FontSize',fs, 'FontWeight','bold');

% 三个圆的标题
text(C1(1), C1(2)+r+0.18, 'T',  'HorizontalAlignment','center','FontSize',12);
text(C2(1), C2(2)+r+0.18, 'SW', 'HorizontalAlignment','center','FontSize',12);
text(C3(1), C3(2)-r-0.20, 'R',  'HorizontalAlignment','center','FontSize',12);
title('Partial R^2 mapped to Venn regions (percent of explained variance)'); 

%% ===== 一次拟合 → 直接输出到韦恩图（区域=partial R²%） =====
clear; clc; rng(2025)

% ===== 1) 你的数据：把本段替换为真实 T, SW, R, Y(GPP) =====
n = 200;
Sigma = [1 0.30 0.20; 0.30 1 0.18; 0.20 0.18 1];
X = mvnrnd([0 0 0], Sigma, n);   % [T, SW, R]
T = X(:,1); SW = X(:,2); R = X(:,3);
% 例子里含主效应+交互
bT=0.55; bSW=0.45; bR=0.30; bTS=0.35; bTR=0.18; bSR=-0.25; bTSR=0.16;
Y = bT*T + bSW*SW + bR*R + bTS*(T.*SW) + bTR*(T.*R) + bSR*(SW.*R) ...
    + bTSR*(T.*SW.*R) + 1.15*randn(n,1);

% ===== 2) 一次拟合全模型：Y ~ T*SW*R =====
Z = zscore([T SW R]); Tz = Z(:,1); SWz = Z(:,2); Rz = Z(:,3);
tbl = table(Y,Tz,SWz,Rz,'VariableNames',{'Y','T','SW','R'});
mdl_full = fitlm(tbl,'Y ~ T*SW*R');

% 总平方和与全模型SSE/R²
SST = mdl_full.SST;
SSE_full = mdl_full.SSE;
R2_full  = 1 - SSE_full/SST;

% ===== 3) 对每个“具体项”做一次“移除该项再拟合”，算 partial R²（独立贡献）
SSE_noT   = fitlm(tbl,'Y ~ SW + R + T:SW + T:R + SW:R + T:SW:R').SSE;
SSE_noSW  = fitlm(tbl,'Y ~ T  + R + T:SW + T:R + SW:R + T:SW:R').SSE;
SSE_noR   = fitlm(tbl,'Y ~ T  + SW+ T:SW + T:R + SW:R + T:SW:R').SSE;
SSE_noTS  = fitlm(tbl,'Y ~ T + SW + R + T:R + SW:R + T:SW:R').SSE;
SSE_noTR  = fitlm(tbl,'Y ~ T + SW + R + T:SW + SW:R + T:SW:R').SSE;
SSE_noSR  = fitlm(tbl,'Y ~ T + SW + R + T:SW + T:R + T:SW:R').SSE;
SSE_noTSR = fitlm(tbl,'Y ~ T + SW + R + T:SW + T:R + SW:R').SSE;

dR2_T   = (SSE_noT   - SSE_full)/SST;
dR2_SW  = (SSE_noSW  - SSE_full)/SST;
dR2_R   = (SSE_noR   - SSE_full)/SST;
dR2_TS  = (SSE_noTS  - SSE_full)/SST;
dR2_TR  = (SSE_noTR  - SSE_full)/SST;
dR2_SR  = (SSE_noSR  - SSE_full)/SST;
dR2_TSR = (SSE_noTSR - SSE_full)/SST;

% 转为“占已解释方差的百分比”，并做数值清理/归一
pct = 100 * [dR2_T dR2_SW dR2_R dR2_TS dR2_TR dR2_SR dR2_TSR] / R2_full;
pct = max(pct,0);                               % 负值截0（数值误差）
pct = pct * (100/sum(pct));                     % 归一到总和=100%
[pct_T,pct_SW,pct_R,pct_TS,pct_TR,pct_SR,pct_TSR] = deal(pct(1),pct(2),pct(3),pct(4),pct(5),pct(6),pct(7));

% ===== 4) 画三圆韦恩图（区域内直接写百分比）
figure('Color','w','Position',[80 80 520 520]); axis off; axis equal; hold on
r = 1.2;
C1 = [-0.75,  0.30];  % 左 (T)
C2 = [ 0.75,  0.30];  % 右 (SW)
C3 = [ 0.00, -0.60];  % 下 (R)
cols = [0.50 0.70 0.90; 0.98 0.70 0.50; 0.60 0.85 0.60]; % 蓝/橙/绿
th = linspace(0,2*pi,600);
fill(C1(1)+r*cos(th), C1(2)+r*sin(th), cols(1,:), 'FaceAlpha',0.55, 'EdgeColor','none');
fill(C2(1)+r*cos(th), C2(2)+r*sin(th), cols(2,:), 'FaceAlpha',0.55, 'EdgeColor','none');
fill(C3(1)+r*cos(th), C3(2)+r*sin(th), cols(3,:), 'FaceAlpha',0.55, 'EdgeColor','none');
plot(C1(1)+r*cos(th), C1(2)+r*sin(th), 'Color',cols(1,:)*0.6);
plot(C2(1)+r*cos(th), C2(2)+r*sin(th), 'Color',cols(2,:)*0.6);
plot(C3(1)+r*cos(th), C3(2)+r*sin(th), 'Color',cols(3,:)*0.6);

% 文本位置（与示例图一致的视觉位置）
pos.onlyT   = C1 + [-0.30,  0.15];
pos.onlySW  = C2 + [ 0.30,  0.15];
pos.onlyR   = C3 + [ 0.00, -0.28];
pos.TS      = (C1+C2)/2 + [ 0.00, 0.38];
pos.TR      = (C1+C3)/2 + [-0.22,-0.05];
pos.SR      = (C2+C3)/2 + [ 0.22,-0.05];
pos.TSR     = [0, 0.00];

% 在区域内写百分比（保留两位小数）
fmt = @(x) sprintf('%.2f%%', x);
fs  = 12;
text(pos.onlyT(1),  pos.onlyT(2),  fmt(pct_T),   'HorizontalAlignment','center','FontSize',fs);
text(pos.onlySW(1), pos.onlySW(2), fmt(pct_SW),  'HorizontalAlignment','center','FontSize',fs);
text(pos.onlyR(1),  pos.onlyR(2),  fmt(pct_R),   'HorizontalAlignment','center','FontSize',fs);
text(pos.TS(1),     pos.TS(2),     fmt(pct_TS),  'HorizontalAlignment','center','FontSize',fs);
text(pos.TR(1),     pos.TR(2),     fmt(pct_TR),  'HorizontalAlignment','center','FontSize',fs);
text(pos.SR(1),     pos.SR(2),     fmt(pct_SR),  'HorizontalAlignment','center','FontSize',fs);
text(pos.TSR(1),    pos.TSR(2),    fmt(pct_TSR), 'HorizontalAlignment','center','FontSize',fs, 'FontWeight','bold');

% 三个圆的标题
text(C1(1), C1(2)+r+0.18, 'T',  'HorizontalAlignment','center','FontSize',12);
text(C2(1), C2(2)+r+0.18, 'SW', 'HorizontalAlignment','center','FontSize',12);
text(C3(1), C3(2)-r-0.20, 'R',  'HorizontalAlignment','center','FontSize',12);
title('Partial R^2 mapped to Venn regions (percent of explained variance)');