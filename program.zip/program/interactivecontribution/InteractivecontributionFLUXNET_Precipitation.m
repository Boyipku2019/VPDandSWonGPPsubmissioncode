%% ================== run_fluxnet_venn_TRS_3x7_compact_fixN.m ==================
% 目标：在 HH/DD/MM 三个时间尺度上，计算三因子（T, R, P）的主效应与交互效应 partial R²
%      并在 3×7 矩阵中作图（行=尺度；列=植被类型：ENF, EBF, DBF, MF, GRA, WET, All biomes）
% 重要修改：顶部列标题只显示植被类型；每个子图的 (n=...) 放在子图下方，紧贴本子图，避免歧义
% 模型：一次线性 Y ~ T*R*P；partial R² 用“移除该项”的 ΔSSE/SST 法
% 筛选：FULLSET；Y>0；TA/SWIN/P_F 非 NaN；样本 > MinN；AdjR² > 阈值

clear; clc; rng(2025); warning('off','all');

%% ---- 参数 ----
AdjR2min = 0.30;    % 进入统计的最小 Adjusted R^2（与随机森林对齐可设 0）
MinN     = 20;      % 单站点最小样本数（原为 40，按你需求适当放宽）

% 统一字体
set(0,'DefaultAxesFontName','Arial');
set(0,'DefaultTextFontName','Arial');

%% ---- 路径配置（按需修改）----
rootFolder = 'G:\GlobalData\FLUXNET2015Tier2Data';
dataDir    = fullfile(rootFolder, 'dataafteruncompression');
siteXlsx   = fullfile(rootFolder, 'FLUXsitelistnew.xlsx');   % 第1列=站点；第8列(H)=植被类型
assert(isfolder(dataDir), '数据目录不存在：%s', dataDir);

%% ---- 站点→植被类型映射 ----
site2veg = containers.Map('KeyType','char','ValueType','char');
hasVegMap = false;
if exist(siteXlsx,'file')
    try
        Tsite = readtable(siteXlsx);
        names = string(Tsite{:,1});
        vegs  = string(Tsite{:,8});   % H列
        for i=1:numel(names)
            k = strtrim(names(i)); v = strtrim(vegs(i));
            if ~isempty(k); site2veg(char(k)) = char(v); end
        end
        hasVegMap = true;
    catch
        fprintf('⚠️ 无法读取 FLUXsitelistnew.xlsx，后续无法按植被类型聚合。\n');
    end
end

%% ---- 仅收集 文件名含 FULLSET 且为 HH/DD/MM ----
allCSV = dir(fullfile(dataDir,'*.csv'));
files = [];
for i = 1:numel(allCSV)
    nm = allCSV(i).name;
    if contains(nm,'FULLSET','IgnoreCase',true) && ...
       ( contains(nm,'FULLSET_HH','IgnoreCase',true) || contains(nm,'_HH_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_DD','IgnoreCase',true) || contains(nm,'_DD_','IgnoreCase',true) || ...
         contains(nm,'FULLSET_MM','IgnoreCase',true) || contains(nm,'_MM_','IgnoreCase',true) )
        files = [files; allCSV(i)]; %#ok<AGROW>
    end
end
if isempty(files), error('未找到 文件名包含 FULLSET 的 HH/DD/MM 文件。'); end
fprintf('发现可用文件 %d 个（文件名包含 FULLSET，且仅 HH/DD/MM）。\n', numel(files));

%% ---- 变量名 ----
yName   = 'GPP_DT_VUT_REF';
x_T     = 'TA_F_MDS';          % Temperature → T（红）
x_R     = 'SW_IN_F_MDS';       % Radiation   → R（黄）
x_P     = 'P_F';               % Precipitation → 作为第三个因子（蓝）
coreNeed = {yName, x_T, x_R, x_P};  % 三个自变量：T, R, P

%% ---- 逐文件：读取→筛选→一次模型 partial R² ----
res_header = {'file','site','vegtype','scale','n_obs','AdjR2_full', ...
              'pct_T','pct_R','pct_SW','pct_TR','pct_TS','pct_RS','pct_TRS'};
rows = {};

for k = 1:numel(files)
    f = fullfile(files(k).folder, files(k).name);
    if ~contains(files(k).name,'FULLSET','IgnoreCase',true), continue; end
    fprintf('\n[%s] %d/%d 处理：%s\n', datestr(now,'HH:MM:SS'), k, numel(files), files(k).name);
    
    try
        % --- 探测列
        opts = detectImportOptions(f);
        varNames = opts.VariableNames;
        
        % 固定列检查（GPP, TA, SWIN, P）
        availFixed = intersect(coreNeed, varNames, 'stable');
        if ~all(ismember(coreNeed, availFixed))
            fprintf('  ↳ 缺少必需列（GPP/TA/SWIN/P_F），跳过。\n');
            continue;
        end
        
        % --- 选择读取列
        opts.SelectedVariableNames = availFixed;
        T = readtable(f, opts);
        
        % --- 将 -9999/极端异常值→NaN
        T = sentinel2nan(T, opts.SelectedVariableNames);
        
        % --- 行筛选
        Y  = T.(yName);
        TT = T.(x_T);
        RR = T.(x_R);
        PP = T.(x_P);        % 此处是降水
        
        mask = ~isnan(Y) & (Y > 0) & ~isnan(TT) & ~isnan(RR) & ~isnan(PP);
        Y  = Y(mask);
        TT = TT(mask);
        RR = RR(mask);
        SW_avg = PP(mask);   % 为了尽量少改，仍沿用 SW_avg 这个变量名（含义已变为降水）
        
        nobs = numel(Y);
        if nobs <= MinN
            fprintf('  ↳ 有效样本太少(%d ≤ %d)，跳过。\n', nobs, MinN);
            continue;
        end
        
        % --- 标准化三自变量（zscore）
        Z = zscore([TT, RR, SW_avg]);   % [T, R, P]，第三列现在是降水
        Tz = Z(:,1); Rz = Z(:,2); SWz = Z(:,3);
        tbl = table(Y, Tz, Rz, SWz, 'VariableNames', {'Y','T','R','SW'});
        
        % ===== 拟合一次全模型：Y ~ T*R*SW（第三个实际上是 P）=====
        mdl_full = fitlm(tbl,'Y ~ T*R*SW');   % 含主效应、两两交互、三重交互
        SST      = mdl_full.SST;
        SSE_full = mdl_full.SSE;
        R2_full  = 1 - SSE_full/SST;
        AdjR2    = mdl_full.Rsquared.Adjusted;
        
        % ===== “移除某项再拟合” 计算 partial R²（独立贡献）=====
        SSE_noT   = fitlm(tbl,'Y ~ R + SW + T:R + T:SW + R:SW + T:R:SW').SSE;
        SSE_noR   = fitlm(tbl,'Y ~ T + SW + T:R + T:SW + R:SW + T:R:SW').SSE;
        SSE_noSW  = fitlm(tbl,'Y ~ T + R  + T:R + T:SW + R:SW + T:R:SW').SSE;
        SSE_noTR  = fitlm(tbl,'Y ~ T + R + SW + T:SW + R:SW + T:R:SW').SSE;
        SSE_noTS  = fitlm(tbl,'Y ~ T + R + SW + T:R  + R:SW + T:R:SW').SSE;
        SSE_noRS  = fitlm(tbl,'Y ~ T + R + SW + T:R  + T:SW + T:R:SW').SSE;
        SSE_noTRS = fitlm(tbl,'Y ~ T + R + SW + T:R  + T:SW + R:SW').SSE;
        
        dR2_T   = (SSE_noT   - SSE_full)/SST;
        dR2_R   = (SSE_noR   - SSE_full)/SST;
        dR2_SW  = (SSE_noSW  - SSE_full)/SST;
        dR2_TR  = (SSE_noTR  - SSE_full)/SST;
        dR2_TS  = (SSE_noTS  - SSE_full)/SST;
        dR2_RS  = (SSE_noRS  - SSE_full)/SST;
        dR2_TRS = (SSE_noTRS - SSE_full)/SST;
        
        % 转百分比（占已解释方差），负值截0并归一到100%
        pct = 100 * [dR2_T dR2_R dR2_SW dR2_TR dR2_TS dR2_RS dR2_TRS] / max(R2_full,eps);
        pct = max(pct, 0);
        ssum = sum(pct);
        if ssum > 0, pct = pct * (100/ssum); end
        [pct_T,pct_R,pct_SW,pct_TR,pct_TS,pct_RS,pct_TRS] = deal(pct(1),pct(2),pct(3),pct(4),pct(5),pct(6),pct(7));
        
        % ---- 站点名 / 植被类型 / 尺度
        sitename = parse_site_from_filename(files(k).name);
        veg = ''; if hasVegMap && isKey(site2veg, sitename), veg = site2veg(sitename); end
        scale = detect_scale_from_filename(files(k).name);
        
        fprintf('  ↳ n=%d, AdjR^2=%.3f | pct[T R P TR TP RP TRP]=[%.1f %.1f %.1f %.1f %.1f %.1f %.1f]\n', ...
                nobs, AdjR2, pct_T,pct_R,pct_SW,pct_TR,pct_TS,pct_RS,pct_TRS);
        
        % 结果入表（后续再按 AdjR² 阈值过滤）
        rows(end+1,:) = {files(k).name, sitename, veg, scale, nobs, AdjR2, ...
                         pct_T,pct_R,pct_SW,pct_TR,pct_TS,pct_RS,pct_TRS}; %#ok<SAGROW>
    catch ME
        fprintf('  ↳ 失败已跳过。原因：%s\n', ME.message);
    end
end

if isempty(rows), error('没有可用的站点结果。'); end
Tsite_all = cell2table(rows,'VariableNames',res_header);
writetable(Tsite_all,'site_partialR2_TRS_all.csv');
fprintf('\n已保存每站点 partial R² 明细（不设阈值）：site_partialR2_TRS_all.csv\n');

%% ---- 仅使用 AdjR² > 阈值 的模型做统计 ----
Tsite = Tsite_all(Tsite_all.AdjR2_full > AdjR2min, :);
if isempty(Tsite)
    error('没有满足 AdjR^2 > %.2f 的有效模型；无法统计。', AdjR2min);
end
fprintf('用于统计的有效模型数：%d（AdjR^2 > %.2f）。\n', height(Tsite), AdjR2min);

%% ---- 仅保留 HH/DD/MM 三种尺度 ----
scales = {'HH','DD','MM'};
labels_scale = {'Half-hourly','Daily','Monthly'};
Tsite = Tsite( ismember(Tsite.scale, scales), :);

%% ---- 按 植被类型 × 尺度 聚合均值/标准差 ----
vegWanted = {'ENF','EBF','DBF','MF','GRA','WET'};         % 6 种
vegListForPlot = [vegWanted, {'Average'}];             % 第7列

% stat(vi).(scl).mean/std/n，顺序 [T R P TR TP RP TRP]（但变量名继续沿用 SW）
stat = struct();
for vi = 1:numel(vegListForPlot)
    vname = vegListForPlot{vi};
    if strcmp(vname,'Average')
        Tv = Tsite;
    else
        Tv = Tsite(strcmp(Tsite.vegtype, vname), :);
    end
    stat(vi).name = vname;
    
    for si = 1:numel(scales)
        scl = scales{si};
        Ts = Tv(strcmp(Tv.scale, scl), :);
        
        if isempty(Ts)
            m = nan(1,7); s = nan(1,7); n = 0;
        else
            M = [Ts.pct_T, Ts.pct_R, Ts.pct_SW, Ts.pct_TR, Ts.pct_TS, Ts.pct_RS, Ts.pct_TRS];
            m = mean(M,1,'omitnan');
            s = std(M,0,1,'omitnan');
            n = height(Ts);
        end
        stat(vi).(scl).mean = m;
        stat(vi).(scl).std  = s;
        stat(vi).(scl).n    = n;
    end
end

%% ---- 3×7 韦恩图矩阵：行=时间尺度；列=植被类型（紧凑+大字体+小图；n 放子图下方）----
figure('Color','w','Position',[120 120 1500 760]);  % 接近全屏
tiledlayout(3,7,'Padding','compact','TileSpacing','none');

rowTitles = {'Half-hourly','Daily','Monthly'};
for si = 1:numel(scales)
    scl = scales{si};
    for vi = 1:numel(vegListForPlot)
        nexttile((si-1)*7 + vi);
        
        m = stat(vi).(scl).mean;    % [T R P TR TP RP TRP]
        n = stat(vi).(scl).n;
        
        if n==0 || all(isnan(m))
            axis off;
            % 顶部列标题：只写植被类型，不显示 n（避免歧义）
            if si==1
                title(vegListForPlot{vi},'FontWeight','bold','FontSize',13,'Interpreter','none','FontName','Arial');
            end
            % 左侧行标题
            if vi==1
                text(-0.14,0.5,rowTitles{si},'Units','normalized','HorizontalAlignment','center',...
                    'FontWeight','bold','FontSize',13,'Rotation',90,'FontName','Arial');
            end
            % 在子图正下方仍给出 n=0，且紧贴本行子图
            text(0,-1.14,'(n=0)','HorizontalAlignment','center','FontSize',10.5,'FontName','Arial','Color',[0.55 0.55 0.55]);
            continue;
        end
        
        % 绘制韦恩图（T=红，R=黄，P=蓝）
        draw_venn3_TRS_compact(m);
        
        % 顶部列标题：仅植被类型（无 n）
        if si==1
            title(vegListForPlot{vi}, 'FontWeight','bold','FontSize',13,'Interpreter','none','FontName','Arial');
        end
        % 左侧行标题（靠近一些）
        if vi==1
            text(-0.14,0.5,rowTitles{si},'Units','normalized','HorizontalAlignment','center',...
                'FontWeight','bold','FontSize',13,'Rotation',90,'FontName','Arial');
        end
        
        % —— 把 (n=xx) 放到“本子图下方”，紧贴该行子图 ——
        text(0, -1.14, sprintf('(n=%d)', n), 'HorizontalAlignment','center',...
             'FontSize',10.5,'FontName','Arial');
    end
end

% sgtitle('Partial R^2 of T–R–P across vegetation types and timescales', ...
%     'FontWeight','bold','FontSize',15,'FontName','Arial');

saveas(gcf,'Venn_TRS_3x7_partialR2_compact_fixN.png');
fprintf('图已保存：Venn_TRS_3x7_partialR2_compact_fixN.png\n');

disp('全部完成。');

%% ================== 辅助函数 ==================
function T = sentinel2nan(T, names)
    % 将 -9999 / 极端异常值 → NaN（便于统一筛选）
    for i = 1:numel(names)
        vname = names{i};
        if ~ismember(vname, T.Properties.VariableNames), continue; end
        v = T.(vname);
        if ~isnumeric(v), v = double(str2double(string(v))); end
        v(v<=-9990 | v>=9.9e8) = NaN;   % 常见哨兵与异常极值
        T.(vname) = v;
    end
end

function site = parse_site_from_filename(fname)
    site = '';
    try
        s = string(fname);
        a = strfind(s,"FLX_"); b = strfind(s,"_FLUXNET");
        if ~isempty(a) && ~isempty(b) && b>a
            site = char(extractBetween(s,a+4,b-1));
        else
            tok = regexp(fname,'FLX_([A-Z]{2}-[A-Za-z0-9]+)_','tokens','once');
            if ~isempty(tok), site = tok{1}; else, site = fname; end
        end
    catch
        site = fname;
    end
end

function scale = detect_scale_from_filename(fname)
    if contains(fname,'FULLSET_HH','IgnoreCase',true) || contains(fname,'_HH_','IgnoreCase',true)
        scale = 'HH';
    elseif contains(fname,'FULLSET_DD','IgnoreCase',true) || contains(fname,'_DD_','IgnoreCase',true)
        scale = 'DD';
    elseif contains(fname,'FULLSET_MM','IgnoreCase',true) || contains(fname,'_MM_','IgnoreCase',true)
        scale = 'MM';
    else
        scale = 'OTHER';
    end
end

function draw_venn3_TRS_compact(pct)
% pct = [T R P TR TP RP TRP]
% 颜色：T=红，R=黄，P=蓝

    axis off; axis equal; hold on
    r = 0.90;
    C_T  = [-0.62,  0.24];
    C_R  = [ 0.62,  0.24];
    C_SW = [ 0.00, -0.48];   % 第三个圆的位置不变，只是含义从 SW → P
    
    colT  = [0.92 0.40 0.35];   % 红 (T)
    colR  = [0.98 0.85 0.40];   % 黄 (R)
    colSW = [0.40 0.60 0.90];   % 蓝 (P，原来是绿色)

    th = linspace(0,2*pi,360);
    fill(C_T(1)+r*cos(th),  C_T(2)+r*sin(th),  colT,  'FaceAlpha',0.58, 'EdgeColor','none');
    fill(C_R(1)+r*cos(th),  C_R(2)+r*sin(th),  colR,  'FaceAlpha',0.58, 'EdgeColor','none');
    fill(C_SW(1)+r*cos(th), C_SW(2)+r*sin(th), colSW, 'FaceAlpha',0.58, 'EdgeColor','none');
    plot(C_T(1)+r*cos(th),  C_T(2)+r*sin(th),  'Color',colT*0.6,'LineWidth',0.6);
    plot(C_R(1)+r*cos(th),  C_R(2)+r*sin(th),  'Color',colR*0.6,'LineWidth',0.6);
    plot(C_SW(1)+r*cos(th), C_SW(2)+r*sin(th), 'Color',colSW*0.6,'LineWidth',0.6);

    pos.onlyT = C_T  + [-0.24,  0.10];
    pos.onlyR = C_R  + [ 0.24,  0.10];
    pos.onlyS = C_SW + [ 0.00, -0.21];
    pos.TR    = (C_T+C_R)/2  + [ 0.00, 0.28];
    pos.TS    = (C_T+C_SW)/2 + [-0.17,-0.03];
    pos.RS    = (C_R+C_SW)/2 + [ 0.17,-0.03];
    pos.TRS   = [0, 0.00];

    fmt = @(x) sprintf('%.1f%%', x);
    fs  = 12;
    text(pos.onlyT(1), pos.onlyT(2), fmt(pct(1)), 'HorizontalAlignment','center','FontSize',fs,'FontName','Arial');
    text(pos.onlyR(1), pos.onlyR(2), fmt(pct(2)), 'HorizontalAlignment','center','FontSize',fs,'FontName','Arial');
    text(pos.onlyS(1), pos.onlyS(2), fmt(pct(3)), 'HorizontalAlignment','center','FontSize',fs,'FontName','Arial');
    text(pos.TR(1),    pos.TR(2),    fmt(pct(4)), 'HorizontalAlignment','center','FontSize',fs,'FontName','Arial');
    text(pos.TS(1),    pos.TS(2),    fmt(pct(5)), 'HorizontalAlignment','center','FontSize',fs,'FontName','Arial');
    text(pos.RS(1),    pos.RS(2),    fmt(pct(6)), 'HorizontalAlignment','center','FontSize',fs,'FontName','Arial');
    text(pos.TRS(1),   pos.TRS(2),   fmt(pct(7)), 'HorizontalAlignment','center','FontSize',fs,...
         'FontWeight','bold','FontName','Arial');

    text(C_T(1),  C_T(2)+r+0.07, 'T',  'HorizontalAlignment','center','FontSize',13,'FontWeight','bold','FontName','Arial','Color',[0.82 0.35 0.30]);
    text(C_R(1),  C_R(2)+r+0.07, 'R',  'HorizontalAlignment','center','FontSize',13,'FontWeight','bold','FontName','Arial','Color',[0.88 0.76 0.36]);
    text(C_SW(1), C_SW(2)-r-0.09,'P',  'HorizontalAlignment','center','FontSize',13,'FontWeight','bold','FontName','Arial','Color',[0.30 0.45 0.80]);
end
