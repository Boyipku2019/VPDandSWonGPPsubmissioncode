%% ===== run_RS_Venn_TRS_sampling_partialR2_2021a.m =====
% 方法：FLUXNET 一致的 partial R²（移除一项 ΔSSE/SST）
% 采样：每类随机 ≤300 像元
% 过滤：AdjR² > 0.30；有效样本数 > 60
% 版本：兼容 MATLAB R2021a（避免非法字段名）
% 布局：仅绘制 3 个尺度（Semiannual / Annual / Long-term）

clear; clc; rng(2025); warning('off','all');
set(0,'DefaultAxesFontName','Arial'); set(0,'DefaultTextFontName','Arial');

%% -------- 参数 --------
AdjR2min  = 0.30;
MinN      = 60;
Nsamp     = 300;
saveExcel = true;
layoutMode = '4x10'; % 保留此变量但不再使用 4 个月尺度

%% -------- 路径 --------
IGBP_path = 'G:\Resource use efficiencies new\dataprocessed\LULC05.tif';

% 仅保留三个尺度（去掉 4 months）
info = { ...
 'Semiannual','Semiannual', 'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_SSA_Semiannual_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_SSA_Semiannual_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_SSA_Semiannual_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_SSA_Semiannual_4comp.raw'; ...
 'Annual',    'Annual',     'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_SSA_Annual_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_SSA_Annual_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_SSA_Annual_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_SSA_Annual_4comp.raw'; ...
 'Longterm',  'Long-term',  'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\GPP05_CEEMDAN_Trend_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\T05_CEEMDAN_Trend_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\R05_CEEMDAN_Trend_4comp.raw', ...
                               'G:\Resource use efficiencies new\dataresult\SSACEEMDAN\SW05_CEEMDAN_Trend_4comp.raw' ...
};

Tlen = 420; rawLen = 468; sFrom = 25; sTo = 444;

%% -------- 植被类型 --------
IGBP = imread(IGBP_path); IGBP = IGBP';
vegNames = {'ENF','EBF','DNF','DBF','MF','SHL','SVA','GRA','WET','Average'};
vegCodeSets = { [1],[2],[3],[4],[5],[6 7],[8 9],[10],[11],-1 };

%% -------- 结果容器 --------
for s = 1:size(info,1)
    RES.(info{s,1}) = repmat(struct('name','','mean',nan(1,7),'std',nan(1,7),'n',0), numel(vegNames),1);
    for c=1:numel(vegNames)
        RES.(info{s,1})(c).name = vegNames{c};
    end
end

%% -------- 主循环 --------
for s = 1:size(info,1)
    scaleField = info{s,1};
    scaleName  = info{s,2};
    fprintf('\n=== %s ===\n', scaleName);

    [GPP,Tm,Rm,SWm] = read_block(info{s,3},info{s,4},info{s,5},info{s,6},Tlen,rawLen,sFrom,sTo);
    [W,H,~]=size(GPP);

    for c=1:numel(vegNames)
        if c==numel(vegNames)
            maskPix = (IGBP>=1 & IGBP<=11);
        else
            maskPix = ismember(IGBP,vegCodeSets{c});
        end
        [ii,jj] = find(maskPix);
        nPix=numel(ii);
        if nPix==0, continue; end
        nSel=min(Nsamp,nPix);
        sel=randperm(nPix,nSel);
        fprintf('  %s: %s 抽样 %d/%d\n', scaleName, vegNames{c}, nSel, nPix);

        P=nan(nSel,7); keep=false(nSel,1);
        for k=1:nSel
            i=ii(sel(k)); j=jj(sel(k));
            y=squeeze(GPP(i,j,:)); t=squeeze(Tm(i,j,:));
            r=squeeze(Rm(i,j,:));  sw=squeeze(SWm(i,j,:));
            mask=~isnan(y)&y>0&~isnan(t)&~isnan(r)&~isnan(sw);
            if sum(mask)<=MinN, continue; end
            y=y(mask); t=t(mask); r=r(mask); sw=sw(mask);

            Z=zscore([t(:),r(:),sw(:)]);
            tbl=table(y(:),Z(:,1),Z(:,2),Z(:,3),'VariableNames',{'Y','T','R','SW'});
            mdl=fitlm(tbl,'Y~T*R*SW');
            if mdl.Rsquared.Adjusted<=AdjR2min, continue; end

            P(k,:)=partialR2_TRS_percent(y,t,r,sw);
            keep(k)=true;
        end
        P=P(keep,:);
        if any(keep)
            RES.(scaleField)(c).mean=mean(P,1,'omitnan');
            RES.(scaleField)(c).std=std(P,0,1,'omitnan');
            RES.(scaleField)(c).n=size(P,1);
        end
    end
end

%% -------- 导出 Excel --------
if saveExcel
    outX='RS_partialR2_sampling300_2021a.xlsx';
    if exist(outX,'file'), delete(outX); end
    head7={'T','R','SW','T×R','T×SW','R×SW','T×R×SW','n'};
    for s=1:size(info,1)
        scaleField=info{s,1};
        C=cell(numel(vegNames)+1,numel(head7)+1);
        C(1,2:end)=head7;
        for r=1:numel(vegNames)
            C{r+1,1}=vegNames{r};
            vals=RES.(scaleField)(r).mean;
            sds=RES.(scaleField)(r).std;
            nval=RES.(scaleField)(r).n;
            for j=1:7
                if isnan(vals(j))
                    C{r+1,j+1}='';
                else
                    C{r+1,j+1}=sprintf('%.1f±%.1f',vals(j),sds(j));
                end
            end
            C{r+1,8}=nval;
        end
        Tcell=cell2table(C(2:end,2:end),'VariableNames',matlab.lang.makeValidName(C(1,2:end)));
        Tcell=addvars(Tcell,string(C(2:end,1)),'Before',1,'NewVariableNames',"Vegetation");
        writetable(Tcell,outX,'Sheet',scaleField);
    end
    fprintf('Excel 已保存：%s\n', outX);
end

%% -------- 绘制韦恩图（仅 3 行）--------
figure('Color','w','Position',[40 40 1900 700]);
tiledlayout(3,10,'Padding','compact','TileSpacing','none');
rowTitles={'Semiannual','Annual','Long-term'};

for si=1:3
    scaleField=info{si,1};
    for vi=1:numel(vegNames)
        nexttile((si-1)*numel(vegNames)+vi);
        m=RES.(scaleField)(vi).mean; n=RES.(scaleField)(vi).n;
        if si==1
            title(vegNames{vi},'FontWeight','bold','FontSize',12);
        end
        if vi==1
            text(-0.14,0.5,rowTitles{si},'Units','normalized','Rotation',90,...
                'FontWeight','bold','FontSize',12,'HorizontalAlignment','center');
        end
        if n==0||all(isnan(m))
            axis off; text(0,-1.1,'(n=0)','HorizontalAlignment','center','FontSize',10,'Color',[.55 .55 .55]);
        else
            draw_venn3_TRS(m);
            text(0,-1.1,sprintf('(n=%d)',n),'HorizontalAlignment','center','FontSize',10);
        end
    end
end
% —— 按要求：去掉整图标题（删除 sgtitle）——

fprintf('全部完成。\n');

%% ===== 工具函数 =====
function [GPP,T,R,SW]=read_block(gpp_path,t_path,r_path,sw_path,Tlen,rawLen,sFrom,sTo)
    W=720;H=360;
    fid=fopen(gpp_path,'r');GPP=fread(fid,W*H*Tlen,'single');fclose(fid);
    GPP=reshape(GPP,[W,H,Tlen]);
    fid=fopen(t_path,'r');T=fread(fid,W*H*rawLen,'single');fclose(fid);
    T=reshape(T,[W,H,rawLen]);T=T(:,:,sFrom:sTo);
    fid=fopen(r_path,'r');R=fread(fid,W*H*rawLen,'single');fclose(fid);
    R=reshape(R,[W,H,rawLen]);R=R(:,:,sFrom:sTo);
    fid=fopen(sw_path,'r');SW=fread(fid,W*H*rawLen,'single');fclose(fid);
    SW=reshape(SW,[W,H,rawLen]);SW=SW(:,:,sFrom:sTo);
end

function pct7=partialR2_TRS_percent(y,t,r,sw)
    Z=zscore([t(:),r(:),sw(:)]);
    Tz=Z(:,1);Rz=Z(:,2);Sz=Z(:,3);
    tbl=table(y(:),Tz,Rz,Sz,'VariableNames',{'Y','T','R','SW'});
    mdl_full=fitlm(tbl,'Y~T*R*SW');
    SST=mdl_full.SST; SSE_full=mdl_full.SSE; R2_full=1-SSE_full/SST;
    SSE_noT=fitlm(tbl,'Y~R+SW+T:R+T:SW+R:SW+T:R:SW').SSE;
    SSE_noR=fitlm(tbl,'Y~T+SW+T:R+T:SW+R:SW+T:R:SW').SSE;
    SSE_noSW=fitlm(tbl,'Y~T+R+T:R+T:SW+R:SW+T:R:SW').SSE;
    SSE_noTR=fitlm(tbl,'Y~T+R+SW+T:SW+R:SW+T:R:SW').SSE;
    SSE_noTS=fitlm(tbl,'Y~T+R+SW+T:R+R:SW+T:R:SW').SSE;
    SSE_noRS=fitlm(tbl,'Y~T+R+SW+T:R+T:SW+T:R:SW').SSE;
    SSE_noTRS=fitlm(tbl,'Y~T+R+SW+T:R+T:SW+R:SW').SSE;
    dR2=( [SSE_noT;SSE_noR;SSE_noSW;SSE_noTR;SSE_noTS;SSE_noRS;SSE_noTRS]-SSE_full )/SST;
    dR2=max(dR2,0);
    pct7=100*dR2/max(R2_full,eps);
    pct7=pct7/sum(pct7)*100;
end

function draw_venn3_TRS(pct)
    axis off; axis equal; hold on
    r=0.9; C_T=[-0.62,0.24];C_R=[0.62,0.24];C_S=[0.00,-0.48];
    colT=[0.92 0.40 0.35];colR=[0.98 0.85 0.40];colS=[0.50 0.80 0.50];
    th=linspace(0,2*pi,360);
    fill(C_T(1)+r*cos(th),C_T(2)+r*sin(th),colT,'FaceAlpha',0.58,'EdgeColor','none');
    fill(C_R(1)+r*cos(th),C_R(2)+r*sin(th),colR,'FaceAlpha',0.58,'EdgeColor','none');
    fill(C_S(1)+r*cos(th),C_S(2)+r*sin(th),colS,'FaceAlpha',0.58,'EdgeColor','none');
    plot(C_T(1)+r*cos(th),C_T(2)+r*sin(th),'Color',colT*0.6,'LineWidth',0.6);
    plot(C_R(1)+r*cos(th),C_R(2)+r*sin(th),'Color',colR*0.6,'LineWidth',0.6);
    plot(C_S(1)+r*cos(th),C_S(2)+r*sin(th),'Color',colS*0.6,'LineWidth',0.6);
    pos.onlyT=C_T+[-0.24,0.10]; pos.onlyR=C_R+[0.24,0.10]; pos.onlyS=C_S+[0.00,-0.21];
    pos.TR=(C_T+C_R)/2+[0.00,0.28]; pos.TS=(C_T+C_S)/2+[-0.17,-0.03];
    pos.RS=(C_R+C_S)/2+[0.17,-0.03]; pos.TRS=[0,0];
    fmt=@(x)sprintf('%.1f%%',x); fs=12;
    text(pos.onlyT(1),pos.onlyT(2),fmt(pct(1)),'HorizontalAlignment','center','FontSize',fs);
    text(pos.onlyR(1),pos.onlyR(2),fmt(pct(2)),'HorizontalAlignment','center','FontSize',fs);
    text(pos.onlyS(1),pos.onlyS(2),fmt(pct(3)),'HorizontalAlignment','center','FontSize',fs);
    text(pos.TR(1),pos.TR(2),fmt(pct(4)),'HorizontalAlignment','center','FontSize',fs);
    text(pos.TS(1),pos.TS(2),fmt(pct(5)),'HorizontalAlignment','center','FontSize',fs);
    text(pos.RS(1),pos.RS(2),fmt(pct(6)),'HorizontalAlignment','center','FontSize',fs);
    text(pos.TRS(1),pos.TRS(2),fmt(pct(7)),'HorizontalAlignment','center','FontSize',fs,'FontWeight','bold');
    text(C_T(1),C_T(2)+r+0.07,'T','HorizontalAlignment','center','FontSize',13,'FontWeight','bold','Color',[0.82 0.35 0.30]);
    text(C_R(1),C_R(2)+r+0.07,'R','HorizontalAlignment','center','FontSize',13,'FontWeight','bold','Color',[0.88 0.76 0.36]);
    text(C_S(1),C_S(2)-r-0.09,'SW','HorizontalAlignment','center','FontSize',13,'FontWeight','bold','Color',[0.45 0.72 0.45]);
end
